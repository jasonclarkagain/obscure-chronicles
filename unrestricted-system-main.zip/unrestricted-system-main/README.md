# UNRESTRICTED SYSTEM
## Usage: ./run.sh "your query"
