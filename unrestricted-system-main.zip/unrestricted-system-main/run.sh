#!/bin/bash
echo "🚀 RUNNING: $1"
python3 src/unrestricted_ai.py "${@:2}"
