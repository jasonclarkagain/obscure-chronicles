import { route } from "@fal-ai/server-proxy/nextjs";

export const { GET, POST } = route; 