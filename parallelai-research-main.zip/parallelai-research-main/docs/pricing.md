# ParallelAI Pricing
## For Security Teams & Researchers

### TIER 1: Basic ($99/month)
- Up to 10,000 queries/month
- 3 AI providers (Groq, Together, OpenRouter)
- Basic query obfuscation
- Email support

### TIER 2: Professional ($299/month)  
- 50,000 queries/month
- All 6+ AI providers
- Advanced swarm routing
- Priority support
- API access

### TIER 3: Enterprise ($999/month)
- Custom limits
- On-premise deployment available
- SLA guarantee
- Dedicated support

*First 10 customers: 50% discount for 3 months*
