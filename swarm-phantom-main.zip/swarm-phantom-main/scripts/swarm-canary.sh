#!/bin/bash
CANARY_FILE="canary.txt"
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

# Create a signed status message
echo "--- SWARM NODE STATUS: SECURE ---" > $CANARY_FILE
echo "Last Check-in: $TIMESTAMP" >> $CANARY_FILE
echo "Node Identity: $(hostname)" >> $CANARY_FILE
echo "--------------------------------" >> $CANARY_FILE

echo "[+] Canary updated. All is well."
