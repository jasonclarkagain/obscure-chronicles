#!/bin/bash
echo "--- SWARM PERFORMANCE BENCHMARK ---"
# Test 1: Encryption Speed
dd if=/dev/urandom bs=1M count=100 of=test.bin 2>/dev/null
START=$(date +%s%N)
./swarm-enc seal -m "$(cat test.bin)" -d "Benchmarking" > /dev/null
END=$(date +%s%N)
DIFF=$(( (END - START) / 1000000 ))
echo "[+] 100MB AEAD Seal Time: $DIFF ms ($(( 100000 / $DIFF )) MB/s)"

# Test 2: Network Health
TOR_STATUS=$(systemctl is-active tor)
echo "[+] Tor Circuit Status: $TOR_STATUS"

# Test 3: Stealth Variance
CHATTER_COUNT=$(crontab -l | grep -c "swarm-chatter")
echo "[+] Decoy Density: $CHATTER_COUNT tasks/hour"
rm test.bin
