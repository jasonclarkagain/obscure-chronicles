#!/bin/bash
NODE_ID=$(hostname)
STATUS_DIR="node_status"
mkdir -p $STATUS_DIR

# 1. Performance Benchmark (AES/X25519 Engine Speed)
dd if=/dev/urandom bs=1M count=50 of=bench.tmp 2>/dev/null
START=$(date +%s%N)
./swarm-enc seal -m "$(cat bench.tmp)" -d "Benchmark" > /dev/null
END=$(date +%s%N)
rm bench.tmp
ENC_SPEED=$(( 50000 / $(( (END - START) / 1000000 )) )) # MB/s

# 2. System Health
CPU_LOAD=$(top -bn1 | grep "Cpu(s)" | awk '{print 100 - $8}')
MEM_FREE=$(free -m | awk '/Mem:/ { print $4 }')
TOR_STATUS=$(systemctl is-active tor)

# 3. Stealth Metric (Decoy Consistency)
# Measures if the decoy chatter is running as scheduled
DECOY_HEALTH=$(crontab -l | grep -c "swarm-chatter.sh")

# 4. JSON Generation
cat << STATUS > $STATUS_DIR/$NODE_ID.json
{
  "last_checkin": "$(date -u)",
  "metrics": {
    "encryption_speed_mbs": "$ENC_SPEED",
    "cpu_usage_pct": "$CPU_LOAD",
    "mem_free_mb": "$MEM_FREE",
    "stealth_decoy_score": "$DECOY_HEALTH",
    "tor_active": "$TOR_STATUS"
  }
}
STATUS

# 5. Secure Push to Dashboard Branch
git checkout -B status-logs
git add $STATUS_DIR/$NODE_ID.json
git commit -m "Metrics Update: $NODE_ID [Speed: ${ENC_SPEED}MB/s]"
git push origin status-logs --force
git checkout main
