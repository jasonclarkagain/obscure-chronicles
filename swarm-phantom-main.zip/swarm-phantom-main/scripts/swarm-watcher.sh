#!/bin/bash
# The Killswitch Watcher

# 1. Check if the LIVE_SIGNAL file exists in the repo
if [ ! -f "LIVE_SIGNAL" ]; then
    echo "[!!!] KILLSWITCH DETECTED. MASTER SIGNAL LOST."
    echo "[!] Initiating Nuke Protocol..."
    
    # Execute your existing nuke script
    ./scripts/swarm-nuke.sh
    
    # Wipe the directory itself as a final act
    cd /tmp
    rm -rf ~/swarm-phantom
    
    exit 1
fi

echo "[+] Master signal active. Continuing operations."
