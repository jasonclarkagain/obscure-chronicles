#!/bin/bash
while true; do
    clear
    echo "======================================"
    echo "       SWARM C2 - GHOST OPS v5.0     "
    echo "======================================"
    echo "1) Identity Card      2) Seal Intel"
    echo "3) Stealth Listen     4) Transmit"
    echo "5) Read Black Box     6) Exit"
    echo "======================================"
    read -p ">> " opt

    case $opt in
        1) ./swarm-exchange.sh; read -p "Enter..." ;;
        2) 
            read -p "Real Intel: " msg
            read -p "Decoy: " dec
            swarm-enc seal -m "$msg" -d "$dec"
            read -p "Enter..." 
            ;;
        3) ./swarm-listen.sh; read -p "Enter..." ;;
        4) 
            read -p "Target IP: " ip
            read -p "Packet Hex: " hex
            echo "$hex" | nc -w 3 $ip 9999
            echo "[+] Transmitted."
            read -p "Enter..." 
            ;;
        5)
            read -s -p "Enter PIN: " pin
            echo
            if [ "$pin" == "0000" ]; then
                [ -f .blackbox.log ] && cat .blackbox.log || echo "Black Box is empty."
                read -p "Enter..."
            elif [ "$pin" == "6666" ]; then
                echo "[!!!] NUKE INITIATED. PURGING SYSTEM..."
                rm -f .blackbox.log .swarm.key swarm-listen.sh swarm-exchange.sh incoming.packet
                echo "System Purged. Self-destructing dashboard..."
                sleep 2
                (rm "$0" &)
                exit 0
            else
                echo "Access Denied."
                read -p "Enter..."
            fi
            ;;
        6) exit 0 ;;
    esac
done
