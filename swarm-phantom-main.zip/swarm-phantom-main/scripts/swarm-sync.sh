#!/bin/bash
PROJECT_DIR="$HOME/swarm-phantom"
cd $PROJECT_DIR

echo "[*] Checking for updates from the Swarm..."
git fetch origin

# Check if we are behind the remote
LOCAL=$(git rev-parse @)
REMOTE=$(git rev-parse @{u})

if [ $LOCAL != $REMOTE ]; then
    echo "[!] Update found. Synchronizing..."
    git pull origin main
    
    # Recompile if source changed
    if [ -d "src" ]; then
        cargo build --release
        sudo cp target/release/swarm-enc /usr/local/bin/
    fi
    
    # Refresh the systemd service
    sudo systemctl restart swarm-listener.service
    echo "[+] Node updated and restarted."
else
    echo "[+] Node is already up to date."
fi
