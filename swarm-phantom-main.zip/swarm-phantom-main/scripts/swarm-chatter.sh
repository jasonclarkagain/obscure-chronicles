#!/bin/bash
DECOYS=(
  "System update check: 0 errors"
  "NTP sync successful"
  "DHCP lease renewed for eth0"
  "Log rotation completed"
  "Thermal sensors: 42C - Normal"
)
MSG=${DECOYS[$RANDOM % ${#DECOYS[@]}]}
PACKET_RAW=$(swarm-enc seal -m "$MSG" -d "Routine System Maintenance Log")
HEX=$(echo "$PACKET_RAW" | sed -n '/PHANTOM PACKET/,/----------/p' | sed '1d;$d')
echo "$HEX" | nc -w 2 127.0.0.1 9999
