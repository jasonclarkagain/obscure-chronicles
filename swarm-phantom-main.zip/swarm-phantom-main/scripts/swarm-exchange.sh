#!/bin/bash
if [ ! -f .swarm.key ]; then
    echo "[!] No identity found. Generating..."
    swarm-enc generate > full_identity.txt
    grep "SECRET" full_identity.txt | awk '{print $2}' > .swarm.key
    chmod 600 .swarm.key
    rm full_identity.txt
fi
PUBKEY=$(swarm-enc generate | grep "PUBKEY" | awk '{print $2}' | head -n 1)
echo "--- SWARM CONTACT CARD ---"
echo "PUBKEY: $PUBKEY"
echo "--------------------------"
