#!/bin/bash
PORT=9999
LOG_FILE=".blackbox.log"

echo "[*] Phantom Listener active (STEALTH MODE)..."
nc -l -p $PORT > incoming.packet

# Use the Master PIN (0000) to recover the real intel
# We append the result to a hidden log with a timestamp
INTEL=$(swarm-enc open -p "$(cat incoming.packet)" -i 0000 2>/dev/null | grep "[RECOVERED]" | sed 's/\[RECOVERED\]: //')

if [ ! -z "$INTEL" ]; then
    TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$TIMESTAMP] $INTEL" >> "$LOG_FILE"
    echo "[+] Intel archived to $LOG_FILE. Key destroyed."
else
    echo "[!] Decryption failed or Intel expired."
fi

rm incoming.packet
