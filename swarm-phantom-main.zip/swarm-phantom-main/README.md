# Swarm-Phantom: Asynchronous Cryptographic Messaging Framework

A proof-of-concept framework for asynchronous, deniable communication over non-reliable transport layers. This project explores the implementation of **X25519 key exchange** and **Authenticated Encryption with Associated Data (AEAD)** in high-latency environments.

## Core Features
- **Deniable Authentication:** Multi-PIN logic for varied data recovery states.
- **Temporal Constraints:** Built-in Time-to-Live (TTL) for cryptographic payloads.
- **Node Monitoring:** Integrity verification through warrant canary automation.
- **Network Obfuscation:** Background noise generation to mask legitimate traffic patterns.

## Technical Architecture
The system consists of a Rust-based encryption engine and a suite of POSIX-compliant management scripts.

- `swarm-enc`: The core cryptographic engine.
- `scripts/swarm-listen.sh`: System daemon for packet ingress.
- `scripts/swarm-c2.sh`: Administrative interface for node management.

## Disclaimer
This software is provided for educational and research purposes only. The authors are not responsible for any misuse of this framework.
