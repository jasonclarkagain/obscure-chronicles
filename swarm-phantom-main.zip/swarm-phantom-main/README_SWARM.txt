--- SWARM PHANTOM OPS v5.0 ---
DEPLOYMENT:
1. Run './setup.sh' (requires sudo for binary and systemd).
2. Identity key is stored in '.swarm.key'.

OPERATIONS:
- Run './swarm-c2.sh' for the main dashboard.
- Master PIN: 0000 (View logs/Open packets)
- Nuke PIN: 6666 (Wipe all scripts and logs)

NETWORK:
- Listener runs on Port 9999 (Systemd).
- Traffic is logged to '.blackbox.log'.
