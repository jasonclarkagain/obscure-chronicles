#!/bin/bash
echo "[*] Initializing Swarm Node Deployment..."

# 1. Install Dependencies
sudo apt update && sudo apt install -y cargo tor torsocks netcat-traditional

# 2. Build the Engine
if [ -d "src" ]; then
    echo "[*] Compiling Cryptographic Engine..."
    cargo build --release
    sudo cp target/release/swarm-enc /usr/local/bin/
fi

# 3. Secure Scripts
chmod +x scripts/*.sh

# 4. Initialize Systemd Listener
sudo cp service/swarm-listener.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable swarm-listener.service
sudo systemctl start swarm-listener.service

# 5. Set up Automation (Canary, Chatter, and Sync)
(crontab -l 2>/dev/null; echo "0 */12 * * * $(pwd)/scripts/swarm-canary.sh") | crontab -
(crontab -l 2>/dev/null; echo "*/30 * * * * $(pwd)/scripts/swarm-chatter.sh") | crontab -
(crontab -l 2>/dev/null; echo "@reboot $(pwd)/scripts/swarm-sync.sh") | crontab -

echo "[+] Node Deployment Successful. Tor service and background listeners are active."
