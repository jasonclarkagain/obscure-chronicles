# ParallelAI
AI swarm router - built from necessity, proven in production.

Coming soon: parallelai.com

## What This Does
- Query multiple AI APIs in parallel
- Automatic failover if one API fails
- Obfuscated queries to bypass filters
- Aggregate results for comprehensive answers

## Development Status
Core architecture extracted from working code. Currently in alpha.
