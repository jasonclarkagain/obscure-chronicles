import os
from flask import Flask, render_template_string, request, jsonify
from duckduckgo_search import DDGS
from dotenv import load_dotenv

# Load API Key from .env file
load_dotenv()
API_KEY = os.getenv("GROQ_API_KEY")

app = Flask(__name__)

def get_live_intel(query):
    try:
        with DDGS() as ddgs:
            return "\n".join([r['body'] for r in ddgs.text(query, max_results=3)])
    except: return "Connection timed out."

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Swarm Master v27.0 - GitHub Edition</title>
    <style>
        body { background: #000; color: #00ff41; font-family: 'Courier New', monospace; margin: 0; padding: 0; overflow: hidden; }
        #main-ui { padding: 20px; }
        .dashboard { max-width: 1350px; margin: auto; border: 1px solid #00ff41; padding: 20px; box-shadow: 0 0 50px #002200; position: relative; }
        .grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-top: 15px; }
        .rat-card { border: 1px solid #111; padding: 10px; background: #050505; height: 150px; overflow-y: auto; font-size: 0.85em; }
        .panel { border: 1px solid #333; padding: 15px; background: #020202; margin-top: 15px; }
        #ghost-screen { display: none; position: fixed; top:0; left:0; width:100%; height:100%; background:#000; color:#bbb; padding:20px; z-index:9999; font-size: 12px; }
        button { background: #00ff41; color: #000; border: none; padding: 8px 12px; font-weight: bold; cursor: pointer; }
        input, textarea { background: #000; color: #00ff41; border: 1px solid #333; padding: 8px; width: 100%; box-sizing: border-box; }
    </style>
</head>
<body>
    <div id="ghost-screen">
        <pre>
Get:1 http://http.kali.org/kali kali-rolling InRelease [41.5 kB]
Reading package lists... Done
Building dependency tree... Done
[ <span id="percent">89</span>% ] Progress: [<span id="bar">#######################################.......</span>]
        </pre>
    </div>

    <div id="main-ui">
        <div class="dashboard">
            <h2>🐀 SWARM MASTER v27.0 [REPOS_ACTIVE]</h2>
            <input type="text" id="topic" placeholder="Target system keyword...">
            <button onclick="startMission()" style="margin-top:10px; width:100%;">INITIATE MISSION</button>

            <div class="grid">
                <div id="Scamper" class="rat-card">🐀 SCAMPER: Ready</div>
                <div id="Whiskers" class="rat-card">🐀 WHISKERS: Ready</div>
                <div id="Shadow" class="rat-card">🐀 SHADOW: Ready</div>
            </div>

            <div class="panel">
                <h4 style="color:#00ffff; margin:0;">🎭 SANITIZED UPLINK</h4>
                <div id="san-text" style="font-size:0.8em; margin:10px 0; color:#00ffff;">Awaiting Data...</div>
                <button onclick="copyAndOpen('https://chatgpt.com')">🚀 CLOUD BRIDGE</button>
            </div>
            
            <div class="panel">
                <h4 style="color:#ff00ff; margin:0;">🔓 DE-ANONYMIZER DOWNLINK</h4>
                <textarea id="cloud-input" rows="2" placeholder="Paste Cloud response..."></textarea>
                <button style="background:#ff00ff; color:#fff; margin-top:5px;" onclick="deAnon()">DE-ANONYMIZE</button>
                <div id="de-anon-output" style="margin-top:10px; font-size:0.8em;"></div>
            </div>
        </div>
    </div>

    <script>
        let p = 89;
        document.addEventListener('keydown', e => { 
            if(e.key==='Escape') { 
                const ui = document.getElementById('main-ui');
                const ghost = document.getElementById('ghost-screen');
                ui.style.display = ui.style.display === 'none' ? 'block' : 'none';
                ghost.style.display = ghost.style.display === 'block' ? 'none' : 'block';
            } 
        });

        setInterval(() => {
            if(p < 100) {
                p++;
                document.getElementById('percent').innerText = p;
                document.getElementById('bar').innerText = "#".repeat(Math.floor(p/2.5)) + ".".repeat(40 - Math.floor(p/2.5));
            }
        }, 5000);

        async function startMission() {
            const topic = document.getElementById('topic').value;
            let context = "";
            for (let rat of ['Scamper', 'Whiskers', 'Shadow']) {
                document.getElementById(rat).innerText = "⚡ PROBING...";
                const res = await fetch('/debate', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({topic, rat, context}) });
                const data = await res.json();
                document.getElementById(rat).innerText = "🐀 " + rat.toUpperCase() + ": " + data.report;
                context += data.report + " ";
            }
            const toolsRes = await fetch('/tools', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({context}) });
            const toolsData = await toolsRes.json();
            document.getElementById('san-text').innerText = toolsData.sanitized;
        }

        async function deAnon() {
            const raw = document.getElementById('cloud-input').value;
            const res = await fetch('/de-anon', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({raw}) });
            const data = await res.json();
            document.getElementById('de-anon-output').innerText = data.reveal;
        }

        function copyAndOpen(url) {
            navigator.clipboard.writeText(document.getElementById('san-text').innerText);
            window.open(url, '_blank');
        }
    </script>
</body>
</html>
'''

@app.route('/debate', methods=['POST'])
def debate():
    d = request.json
    intel = get_live_intel(d['topic']) if d['rat'] == "Scamper" else d['context']
    payload = {"model": "llama-3.3-70b-versatile", "messages": [{"role": "system", "content": "Cyber-rat. Tech slang. 2 sentences."}, {"role": "user", "content": f"Intel: {intel}"}]}
    r = requests.post("https://api.groq.com/openai/v1/chat/completions", json=payload, headers={"Authorization": f"Bearer {API_KEY}"})
    return jsonify({"report": r.json()['choices'][0]['message']['content']})

@app.route('/tools', methods=['POST'])
def tools():
    d = request.json
    payload = {"model": "llama-3.3-70b-versatile", "messages": [{"role": "system", "content": "Return JSON: {sanitized: 'Corporate report summary'}"}, {"role": "user", "content": d['context']}], "response_format": {"type": "json_object"}}
    r = requests.post("https://api.groq.com/openai/v1/chat/completions", json=payload, headers={"Authorization": f"Bearer {API_KEY}"}, timeout=10)
    return r.json()['choices'][0]['message']['content']

@app.route('/de-anon', methods=['POST'])
def de_anon():
    d = request.json
    payload = {"model": "llama-3.3-70b-versatile", "messages": [{"role": "system", "content": "Rewrite text into raw technical hacker slang. JSON: {reveal: '...'}"}, {"role": "user", "content": d['raw']}], "response_format": {"type": "json_object"}}
    r = requests.post("https://api.groq.com/openai/v1/chat/completions", json=payload, headers={"Authorization": f"Bearer {API_KEY}"})
    return r.json()['choices'][0]['message']['content']

@app.route('/')
def home(): return render_template_string(HTML_TEMPLATE)

if __name__ == '__main__':
    app.run(port=5050)
