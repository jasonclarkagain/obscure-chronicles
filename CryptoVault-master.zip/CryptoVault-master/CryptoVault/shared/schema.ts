import { pgTable, text, serial, integer, boolean, jsonb, timestamp, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  currencies: jsonb("currencies").notNull(), // Array of supported currencies with addresses
  isActive: boolean("is_active").notNull().default(true),
  createdAt: text("created_at").notNull(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  walletId: integer("wallet_id").notNull(),
  currency: text("currency").notNull(),
  type: text("type").notNull(), // 'send' | 'receive'
  amount: text("amount").notNull(),
  address: text("address").notNull(),
  txHash: text("tx_hash"),
  status: text("status").notNull().default("pending"), // 'pending' | 'confirmed' | 'failed'
  createdAt: text("created_at").notNull(),
});

// Security audit log table for tracking all activities
export const securityLogs = pgTable("security_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  walletId: integer("wallet_id").references(() => wallets.id),
  action: varchar("action", { length: 100 }).notNull(), // 'wallet_created', 'key_generated', 'transaction_initiated', etc.
  category: varchar("category", { length: 50 }).notNull(), // 'wallet', 'security', 'transaction', 'authentication'
  severity: varchar("severity", { length: 20 }).notNull().default("info"), // 'info', 'warning', 'critical'
  details: jsonb("details"), // Encrypted sensitive data
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  sessionId: varchar("session_id", { length: 255 }),
  success: boolean("success").notNull().default(true),
  errorMessage: text("error_message"),
  metadata: jsonb("metadata"), // Additional context data
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertWalletSchema = createInsertSchema(wallets).pick({
  userId: true,
  name: true,
  currencies: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  walletId: true,
  currency: true,
  type: true,
  amount: true,
  address: true,
  txHash: true,
  status: true,
});

export const insertSecurityLogSchema = createInsertSchema(securityLogs).pick({
  userId: true,
  walletId: true,
  action: true,
  category: true,
  severity: true,
  details: true,
  ipAddress: true,
  userAgent: true,
  sessionId: true,
  success: true,
  errorMessage: true,
  metadata: true,
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  wallets: many(wallets),
  securityLogs: many(securityLogs),
}));

export const walletsRelations = relations(wallets, ({ one, many }) => ({
  user: one(users, { fields: [wallets.userId], references: [users.id] }),
  transactions: many(transactions),
  securityLogs: many(securityLogs),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  wallet: one(wallets, { fields: [transactions.walletId], references: [wallets.id] }),
}));

export const securityLogsRelations = relations(securityLogs, ({ one }) => ({
  user: one(users, { fields: [securityLogs.userId], references: [users.id] }),
  wallet: one(wallets, { fields: [securityLogs.walletId], references: [wallets.id] }),
}));

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type Wallet = typeof wallets.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertSecurityLog = z.infer<typeof insertSecurityLogSchema>;
export type SecurityLog = typeof securityLogs.$inferSelect;
