# CryptoVault - Secure Cryptocurrency Wallet Application

A comprehensive web-based cryptocurrency wallet application with advanced security features, multi-currency support, and professional banking aesthetics.

## Features

### 🔐 Security First
- **Multi-Step Mnemonic Generation**: 12/18/24 word recovery phrases with confirmation
- **Screenshot Protection**: Prevents unauthorized capture during sensitive operations
- **Encrypted Security Logging**: Complete audit trail with encrypted sensitive data
- **Hardware-Grade Security**: Browser-compatible cryptographic libraries

### 💰 Multi-Currency Support
- **8 Major Cryptocurrencies**: Bitcoin, Ethereum, Litecoin, Bitcoin Cash, XRP, Cardano, Solana, Polygon
- **Secure Wallet Generation**: Hierarchical deterministic (HD) wallet support
- **Paper Wallet Certificates**: Premium banking-style printable backups with QR codes

### 🎓 Educational Features
- **25 Banker's Tips**: Professional investment advice with daily rotation
- **Financial Time Machine**: Investment scenario simulation across different timeframes
- **AR Investment Advisor**: Interactive market analysis and guidance
- **Risk Assessment**: Color-coded risk levels for all investment strategies

### 🏦 Professional Banking Theme
- **Animation-Free Interface**: Clean, distraction-free professional design
- **Monopoly Banker Character**: Friendly guide throughout the application
- **Swiss Bank Aesthetics**: Premium certificate styling and vault terminology

## Technology Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and building
- **Tailwind CSS** with shadcn/ui components
- **Wouter** for lightweight routing
- **TanStack Query** for server state management

### Backend
- **Express.js** with TypeScript
- **PostgreSQL** with Drizzle ORM
- **Neon Serverless** database hosting
- **Zod** for runtime validation

### Security & Crypto
- **bitcoinjs-lib** for Bitcoin operations
- **ethers.js** for Ethereum operations
- **Web Crypto API** for secure random generation
- **AES encryption** for sensitive data logging

## Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL database (or Neon account)

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/cryptovault.git
cd cryptovault
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
# Copy and configure your database URL
export DATABASE_URL="your_postgresql_connection_string"
```

4. **Initialize the database**
```bash
npm run db:push
```

5. **Start the development server**
```bash
npm run dev
```

6. **Open your browser**
Navigate to `http://localhost:5000`

## Project Structure

```
├── client/src/           # React frontend application
│   ├── components/       # Reusable UI components
│   ├── pages/           # Application pages/routes
│   ├── hooks/           # Custom React hooks
│   └── lib/             # Utility functions and crypto operations
├── server/              # Express.js backend
│   ├── routes.ts        # API route definitions
│   ├── storage.ts       # Database operations
│   └── security-logger.ts # Security audit logging
├── shared/              # Shared TypeScript types and schemas
└── components.json      # shadcn/ui configuration
```

## API Endpoints

### Wallet Operations
- `GET /api/wallets/:userId` - Retrieve user wallets
- `POST /api/wallets` - Create new wallet
- `GET /api/transactions/:walletId` - Get wallet transactions

### Security Logging
- `GET /api/security/logs/:userId` - Access security audit logs
- `GET /api/security/summary/:userId` - Security activity summary
- `POST /api/security/log` - Create security log entry

## Security Features

### Mnemonic Protection
- Client-side generation using Web Crypto API
- No server-side storage of recovery phrases
- Multi-step confirmation process
- Screenshot prevention during sensitive operations

### Database Security
- Encrypted storage of sensitive data
- Foreign key constraints for data integrity
- Comprehensive audit logging
- IP address and session tracking

### Privacy Controls
- Right-click context menu disabled during key operations
- Keyboard shortcut prevention (Print Screen, F12, etc.)
- Page blur when browser loses focus
- Hand-written backup requirement

## Development

### Database Migrations
```bash
# Push schema changes to database
npm run db:push

# Generate migration files (if needed)
npm run db:generate
```

### Environment Setup
The application uses Vite for frontend development with hot reloading and Express.js for the backend API server.

### Testing
All 8 cryptocurrencies have been thoroughly tested with complete wallet generation pipelines. Security features including screenshot protection, mnemonic validation, and database logging are fully operational.

## Deployment

The application is designed for deployment on platforms supporting Node.js applications with PostgreSQL databases:

1. **Replit Deployments** (Recommended)
2. **Vercel** with Neon database
3. **Railway** with PostgreSQL
4. **Heroku** with Heroku Postgres

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- **Banking Theme**: Inspired by classic Monopoly banking aesthetics
- **Security Design**: Following cryptocurrency industry best practices
- **Educational Content**: Professional investment banking guidance
- **Created by**: Jason Clark ([jason-clark.org](https://jason-clark.org))

## Support

For support, questions, or feature requests, please open an issue on GitHub or contact the development team.

---

**⚠️ Security Notice**: This application generates real cryptocurrency private keys. Always backup your recovery phrases securely and never share them with anyone. The developers are not responsible for lost funds due to improper key management.