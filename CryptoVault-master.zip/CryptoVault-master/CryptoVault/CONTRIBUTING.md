# Contributing to CryptoVault

Thank you for your interest in contributing to CryptoVault! This document provides guidelines for contributing to this cryptocurrency wallet application.

## Table of Contents
- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Process](#development-process)
- [Security Guidelines](#security-guidelines)
- [Pull Request Process](#pull-request-process)

## Code of Conduct

This project follows a professional code of conduct. Please be respectful and constructive in all interactions.

## Getting Started

### Prerequisites
- Node.js 18 or higher
- PostgreSQL database access
- Basic understanding of React, TypeScript, and cryptocurrency concepts

### Development Setup
1. Fork the repository
2. Clone your fork: `git clone https://github.com/yourusername/cryptovault.git`
3. Install dependencies: `npm install`
4. Set up your database connection in environment variables
5. Initialize database: `npm run db:push`
6. Start development server: `npm run dev`

## Development Process

### Branch Naming
- Feature branches: `feature/description-of-feature`
- Bug fixes: `fix/description-of-bug`
- Security updates: `security/description-of-fix`

### Commit Messages
Use conventional commit format:
- `feat: add new cryptocurrency support`
- `fix: resolve mnemonic validation issue`
- `security: improve key generation entropy`
- `docs: update API documentation`

### Code Style
- Use TypeScript for all new code
- Follow existing naming conventions
- Add proper JSDoc comments for complex functions
- Maintain the banking theme aesthetic
- No animations or distracting visual effects

## Security Guidelines

### Cryptocurrency Security
- Never log or store private keys in plaintext
- Use secure random generation for all cryptographic operations
- Follow HD wallet standards for key derivation
- Implement proper input validation

### Database Security
- Use parameterized queries only
- Encrypt sensitive data before storage
- Implement proper access controls
- Log all security-relevant operations

### Frontend Security
- Validate all user inputs
- Implement screenshot protection for sensitive operations
- Use secure communication with backend
- Follow OWASP guidelines

## Pull Request Process

### Before Submitting
1. Ensure all tests pass
2. Update documentation if needed
3. Add security review for crypto-related changes
4. Test with multiple cryptocurrencies
5. Verify no sensitive data is exposed in logs

### PR Description
Include:
- Description of changes
- Security implications (if any)
- Testing performed
- Screenshots for UI changes
- Breaking changes (if any)

### Review Process
- All PRs require review from project maintainers
- Security-related changes require additional review
- Cryptocurrency integration changes require thorough testing
- UI changes must maintain banking theme consistency

## Areas for Contribution

### High Priority
- Additional cryptocurrency support
- Enhanced security features
- Mobile responsive improvements
- Accessibility enhancements

### Medium Priority
- Performance optimizations
- Additional educational content
- Advanced portfolio features
- Integration with external APIs

### Documentation
- API documentation improvements
- Security best practices guide
- Deployment guides
- User tutorials

## Testing Guidelines

### Manual Testing
- Test complete wallet creation flow
- Verify all 8 cryptocurrencies work properly
- Test mnemonic confirmation process
- Validate paper wallet generation
- Check security logging functionality

### Security Testing
- Verify screenshot protection works
- Test mnemonic phrase security
- Validate encrypted logging
- Check for sensitive data leaks
- Test input validation

## Reporting Issues

### Bug Reports
Include:
- Steps to reproduce
- Expected vs actual behavior
- Browser and version
- Console errors (if any)
- Screenshots (if relevant)

### Security Issues
For security vulnerabilities:
1. **Do NOT** open a public issue
2. Email security concerns privately
3. Provide detailed description
4. Include reproduction steps
5. Allow time for investigation

## Questions?

- Check existing issues and documentation first
- For general questions, open a discussion
- For specific bugs, create an issue
- For security concerns, contact maintainers privately

Thank you for contributing to CryptoVault and helping make cryptocurrency more secure and accessible!