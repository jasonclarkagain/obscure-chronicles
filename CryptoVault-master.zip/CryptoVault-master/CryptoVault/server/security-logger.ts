import { db } from './db';
import { securityLogs, type InsertSecurityLog } from '@shared/schema';
import crypto from 'crypto';

interface SecurityLogContext {
  userId?: number;
  walletId?: number;
  ipAddress?: string;
  userAgent?: string;
  sessionId?: string;
}

interface LogDetails {
  walletName?: string;
  currency?: string;
  amount?: string;
  address?: string;
  privateKey?: string;
  publicKey?: string;
  mnemonic?: string[];
  transactionHash?: string;
  errorDetails?: any;
  [key: string]: any;
}

class SecureLogger {
  private encryptionKey: string;

  constructor() {
    // Use environment variable or generate a key for encryption
    this.encryptionKey = process.env.ENCRYPTION_KEY || 'default-key-change-in-production';
  }

  // Encrypt sensitive data before storing
  private encryptSensitiveData(data: any): string {
    try {
      const cipher = crypto.createCipher('aes-256-cbc', this.encryptionKey);
      let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
      encrypted += cipher.final('hex');
      return encrypted;
    } catch (error) {
      console.error('Encryption error:', error);
      return JSON.stringify({ error: 'Failed to encrypt data' });
    }
  }

  // Decrypt sensitive data when needed
  private decryptSensitiveData(encryptedData: string): any {
    try {
      const decipher = crypto.createDecipher('aes-256-cbc', this.encryptionKey);
      let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      return JSON.parse(decrypted);
    } catch (error) {
      console.error('Decryption error:', error);
      return { error: 'Failed to decrypt data' };
    }
  }

  // Log wallet creation with all details
  async logWalletCreation(context: SecurityLogContext, details: LogDetails) {
    const encryptedDetails = this.encryptSensitiveData({
      walletName: details.walletName,
      currencies: details.currencies,
      createdAt: new Date().toISOString(),
      type: 'wallet_creation'
    });

    await this.createLog({
      ...context,
      action: 'wallet_created',
      category: 'wallet',
      severity: 'info',
      details: { encrypted: encryptedDetails },
      success: true,
      metadata: {
        walletCount: details.walletCount,
        supportedCurrencies: details.supportedCurrencies
      }
    });
  }

  // Log mnemonic phrase generation
  async logMnemonicGeneration(context: SecurityLogContext, details: LogDetails) {
    const encryptedDetails = this.encryptSensitiveData({
      mnemonicLength: details.mnemonic?.length,
      entropy: details.entropy,
      timestamp: new Date().toISOString(),
      type: 'mnemonic_generation'
    });

    await this.createLog({
      ...context,
      action: 'mnemonic_generated',
      category: 'security',
      severity: 'critical',
      details: { encrypted: encryptedDetails },
      success: true,
      metadata: {
        phraseLength: details.mnemonic?.length,
        generationMethod: 'secure_random'
      }
    });
  }

  // Log private key generation
  async logKeyGeneration(context: SecurityLogContext, details: LogDetails) {
    const encryptedDetails = this.encryptSensitiveData({
      currency: details.currency,
      publicKeyPreview: details.publicKey?.slice(0, 10) + '...',
      privateKeyHash: crypto.createHash('sha256').update(details.privateKey || '').digest('hex'),
      timestamp: new Date().toISOString(),
      type: 'key_generation'
    });

    await this.createLog({
      ...context,
      action: 'crypto_keys_generated',
      category: 'security',
      severity: 'critical',
      details: { encrypted: encryptedDetails },
      success: true,
      metadata: {
        currency: details.currency,
        keyType: 'hierarchical_deterministic'
      }
    });
  }

  // Log address generation
  async logAddressGeneration(context: SecurityLogContext, details: LogDetails) {
    const encryptedDetails = this.encryptSensitiveData({
      currency: details.currency,
      address: details.address,
      derivationPath: details.derivationPath,
      timestamp: new Date().toISOString(),
      type: 'address_generation'
    });

    await this.createLog({
      ...context,
      action: 'address_generated',
      category: 'wallet',
      severity: 'info',
      details: { encrypted: encryptedDetails },
      success: true,
      metadata: {
        currency: details.currency,
        addressType: details.addressType
      }
    });
  }

  // Log transaction initiation
  async logTransactionInitiation(context: SecurityLogContext, details: LogDetails) {
    const encryptedDetails = this.encryptSensitiveData({
      currency: details.currency,
      amount: details.amount,
      fromAddress: details.fromAddress,
      toAddress: details.toAddress,
      fee: details.fee,
      timestamp: new Date().toISOString(),
      type: 'transaction_initiation'
    });

    await this.createLog({
      ...context,
      action: 'transaction_initiated',
      category: 'transaction',
      severity: 'warning',
      details: { encrypted: encryptedDetails },
      success: true,
      metadata: {
        currency: details.currency,
        transactionType: details.type
      }
    });
  }

  // Log transaction completion
  async logTransactionCompletion(context: SecurityLogContext, details: LogDetails) {
    const encryptedDetails = this.encryptSensitiveData({
      transactionHash: details.transactionHash,
      status: details.status,
      confirmations: details.confirmations,
      blockNumber: details.blockNumber,
      timestamp: new Date().toISOString(),
      type: 'transaction_completion'
    });

    await this.createLog({
      ...context,
      action: 'transaction_completed',
      category: 'transaction',
      severity: 'info',
      details: { encrypted: encryptedDetails },
      success: details.status === 'completed',
      errorMessage: details.status === 'failed' ? details.errorMessage : undefined,
      metadata: {
        currency: details.currency,
        finalStatus: details.status
      }
    });
  }

  // Log security events
  async logSecurityEvent(context: SecurityLogContext, action: string, details: LogDetails, success: boolean = true) {
    const encryptedDetails = this.encryptSensitiveData({
      ...details,
      timestamp: new Date().toISOString(),
      type: 'security_event'
    });

    await this.createLog({
      ...context,
      action,
      category: 'security',
      severity: success ? 'info' : 'critical',
      details: { encrypted: encryptedDetails },
      success,
      errorMessage: success ? undefined : details.errorDetails?.message
    });
  }

  // Log authentication events
  async logAuthentication(context: SecurityLogContext, action: string, success: boolean, details?: LogDetails) {
    const encryptedDetails = details ? this.encryptSensitiveData({
      ...details,
      timestamp: new Date().toISOString(),
      type: 'authentication'
    }) : null;

    await this.createLog({
      ...context,
      action,
      category: 'authentication',
      severity: success ? 'info' : 'warning',
      details: encryptedDetails ? { encrypted: encryptedDetails } : null,
      success,
      errorMessage: success ? undefined : details?.errorDetails?.message
    });
  }

  // Core logging function
  private async createLog(logData: Omit<InsertSecurityLog, 'createdAt'>) {
    try {
      await db.insert(securityLogs).values({
        userId: logData.userId,
        walletId: logData.walletId,
        action: logData.action,
        category: logData.category,
        severity: logData.severity || 'info',
        details: logData.details,
        ipAddress: logData.ipAddress,
        userAgent: logData.userAgent,
        sessionId: logData.sessionId,
        success: logData.success !== undefined ? logData.success : true,
        errorMessage: logData.errorMessage,
        metadata: logData.metadata
      });
    } catch (error) {
      console.error('Failed to create security log:', error);
      // Don't throw - logging failures shouldn't break the application
    }
  }

  // Retrieve logs with decryption (for authorized access only)
  async getLogs(userId?: number, limit: number = 100) {
    try {
      const logs = await db.select()
        .from(securityLogs)
        .where(userId ? undefined : undefined) // Add proper where clause if userId provided
        .orderBy(securityLogs.createdAt)
        .limit(limit);

      return logs.map(log => ({
        ...log,
        decryptedDetails: log.details?.encrypted ? 
          this.decryptSensitiveData(log.details.encrypted) : 
          log.details
      }));
    } catch (error) {
      console.error('Failed to retrieve security logs:', error);
      return [];
    }
  }

  // Get security summary statistics
  async getSecuritySummary(userId?: number) {
    try {
      // This would need proper aggregation queries
      const logs = await this.getLogs(userId, 1000);
      
      return {
        totalLogs: logs.length,
        recentActivity: logs.slice(-10),
        criticalEvents: logs.filter(log => log.severity === 'critical').length,
        warningEvents: logs.filter(log => log.severity === 'warning').length,
        failedOperations: logs.filter(log => !log.success).length,
        categorySummary: {
          wallet: logs.filter(log => log.category === 'wallet').length,
          security: logs.filter(log => log.category === 'security').length,
          transaction: logs.filter(log => log.category === 'transaction').length,
          authentication: logs.filter(log => log.category === 'authentication').length
        }
      };
    } catch (error) {
      console.error('Failed to get security summary:', error);
      return null;
    }
  }
}

export const secureLogger = new SecureLogger();
export default secureLogger;