import type { Express, Request, Response } from "express";
import { Server } from "http";
import { storage } from "./storage";
import { insertWalletSchema, insertTransactionSchema, insertSecurityLogSchema } from "@shared/schema";
import { secureLogger } from "./security-logger";

// Helper to get client info for logging
function getClientInfo(req: Request) {
  return {
    ipAddress: req.ip || (req as any).connection?.remoteAddress || 'unknown',
    userAgent: req.get('User-Agent') || 'unknown',
    sessionId: (req as any).sessionID || 'unknown'
  };
}

export function registerRoutes(app: Express): Server {
  // Health check endpoint
  app.get("/api/health", async (req: Request, res: Response) => {
    try {
      res.json({ status: "ok", timestamp: new Date().toISOString() });
    } catch (error) {
      res.status(500).json({ error: "Health check failed" });
    }
  });

  // Wallet operations with security logging
  app.get("/api/wallets/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const wallets = await storage.getWalletsByUserId(userId);
      
      // Log wallet access
      await secureLogger.logSecurityEvent(
        { userId, ...getClientInfo(req) },
        'wallet_list_accessed',
        { walletCount: wallets.length }
      );
      
      res.json(wallets);
    } catch (error) {
      await secureLogger.logSecurityEvent(
        { userId: parseInt(req.params.userId), ...getClientInfo(req) },
        'wallet_access_failed',
        { errorDetails: error },
        false
      );
      res.status(500).json({ error: "Failed to fetch wallets" });
    }
  });

  app.post("/api/wallets", async (req: Request, res: Response) => {
    try {
      const walletData = insertWalletSchema.parse(req.body);
      const wallet = await storage.createWallet(walletData);
      
      // Log comprehensive wallet creation
      await secureLogger.logWalletCreation(
        { userId: walletData.userId, walletId: wallet.id, ...getClientInfo(req) },
        {
          walletName: walletData.name,
          currencies: walletData.currencies,
          walletCount: 1,
          supportedCurrencies: Array.isArray(walletData.currencies) ? walletData.currencies.length : 0
        }
      );
      
      res.json(wallet);
    } catch (error) {
      await secureLogger.logSecurityEvent(
        { ...getClientInfo(req) },
        'wallet_creation_failed',
        { errorDetails: error },
        false
      );
      res.status(400).json({ error: "Failed to create wallet" });
    }
  });

  // Mnemonic generation logging endpoint
  app.post("/api/security/log-mnemonic", async (req: Request, res: Response) => {
    try {
      const { userId, mnemonicLength, entropy } = req.body;
      
      await secureLogger.logMnemonicGeneration(
        { userId, ...getClientInfo(req) },
        {
          mnemonic: new Array(mnemonicLength).fill('***'), // Don't log actual words
          entropy,
          mnemonicLength
        }
      );
      
      res.json({ logged: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to log mnemonic generation" });
    }
  });

  // Key generation logging endpoint
  app.post("/api/security/log-keys", async (req: Request, res: Response) => {
    try {
      const { userId, walletId, currency, publicKey, privateKeyHash } = req.body;
      
      await secureLogger.logKeyGeneration(
        { userId, walletId, ...getClientInfo(req) },
        {
          currency,
          publicKey,
          privateKey: privateKeyHash // Store hash, not actual key
        }
      );
      
      res.json({ logged: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to log key generation" });
    }
  });

  // Address generation logging endpoint
  app.post("/api/security/log-address", async (req: Request, res: Response) => {
    try {
      const { userId, walletId, currency, address, derivationPath } = req.body;
      
      await secureLogger.logAddressGeneration(
        { userId, walletId, ...getClientInfo(req) },
        {
          currency,
          address,
          derivationPath,
          addressType: 'generated'
        }
      );
      
      res.json({ logged: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to log address generation" });
    }
  });

  // Transaction operations with logging
  app.get("/api/transactions/:walletId", async (req: Request, res: Response) => {
    try {
      const walletId = parseInt(req.params.walletId);
      const transactions = await storage.getTransactionsByWalletId(walletId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req: Request, res: Response) => {
    try {
      const transactionData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(transactionData);
      
      // Log transaction initiation
      await secureLogger.logTransactionInitiation(
        { walletId: transactionData.walletId, ...getClientInfo(req) },
        {
          currency: transactionData.currency,
          amount: transactionData.amount,
          toAddress: transactionData.address,
          type: transactionData.type
        }
      );
      
      res.json(transaction);
    } catch (error) {
      await secureLogger.logSecurityEvent(
        { ...getClientInfo(req) },
        'transaction_creation_failed',
        { errorDetails: error },
        false
      );
      res.status(400).json({ error: "Failed to create transaction" });
    }
  });

  // Security log retrieval (admin endpoint)
  app.get("/api/security/logs/:userId?", async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId ? parseInt(req.params.userId) : undefined;
      const limit = parseInt(req.query.limit as string) || 100;
      
      const logs = await secureLogger.getLogs(userId, limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch security logs" });
    }
  });

  // Security summary endpoint
  app.get("/api/security/summary/:userId?", async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId ? parseInt(req.params.userId) : undefined;
      const summary = await secureLogger.getSecuritySummary(userId);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch security summary" });
    }
  });

  // Generic security event logging endpoint
  app.post("/api/security/log", async (req: Request, res: Response) => {
    try {
      const { userId, walletId, action, category, severity, details, success } = req.body;
      
      await secureLogger.logSecurityEvent(
        { userId, walletId, ...getClientInfo(req) },
        action,
        details || {},
        success !== false
      );
      
      res.json({ logged: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to log security event" });
    }
  });

  return app as any;
}