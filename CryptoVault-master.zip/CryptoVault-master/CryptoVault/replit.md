# Overview

This is a cryptocurrency wallet application built with a modern full-stack architecture. The application allows users to create secure crypto wallets with recovery phrases, supporting multiple cryptocurrencies including Bitcoin, Ethereum, and Litecoin. The system uses a React frontend with TypeScript, Express.js backend, and PostgreSQL database with Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and building
- **UI Library**: shadcn/ui components built on top of Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens for crypto-themed colors
- **State Management**: React hooks and TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **API Design**: RESTful API with proper error handling and logging middleware
- **Development Setup**: Hot reloading with Vite middleware integration

### Data Storage Solutions
- **Primary Database**: PostgreSQL (configured for Neon serverless) - **ACTIVE**
- **ORM**: Drizzle with schema-first approach
- **Session Storage**: Connect-pg-simple for PostgreSQL-backed sessions
- **Database Storage**: Full database integration with DatabaseStorage class

## Key Components

### Database Schema
- **Users Table**: Stores user credentials (id, username, password)
- **Wallets Table**: Multi-currency wallet support with JSONB for currency data
- **Transactions Table**: Transaction history with status tracking

### Frontend Components
- **Wallet Creation Flow**: Multi-step wizard for secure wallet generation
- **Security Features**: Screenshot protection and secure mnemonic handling
- **Dashboard**: Portfolio overview with multi-currency support
- **Paper Wallet**: Printable backup functionality

### Backend Services
- **Storage Layer**: Abstract interface with in-memory and database implementations
- **Wallet Management**: CRUD operations for wallets and transactions
- **API Routes**: RESTful endpoints with proper validation using Zod

## Data Flow

1. **Wallet Creation**: Users progress through steps to generate secure recovery phrases
2. **Mnemonic Generation**: Client-side cryptographic generation using Web Crypto API
3. **Wallet Storage**: Encrypted wallet data stored in PostgreSQL
4. **Transaction Tracking**: Real-time balance and transaction history
5. **Security Validation**: Multi-step confirmation and backup procedures

## External Dependencies

### Core Libraries
- **Crypto Libraries**: bitcoinjs-lib for Bitcoin operations, ethers for Ethereum
- **UI Framework**: Radix UI primitives with custom shadcn/ui components
- **Database**: Drizzle ORM with PostgreSQL adapter
- **Validation**: Zod for runtime type checking and API validation

### Development Tools
- **Build System**: Vite with React plugin and TypeScript support
- **Database Tools**: Drizzle Kit for migrations and schema management
- **Replit Integration**: Custom plugins for development environment

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized React application to dist/public
- **Backend**: esbuild compiles TypeScript server to single ESM bundle
- **Database**: Drizzle migrations handle schema updates

### Environment Configuration
- **Development**: Hot reloading with Vite middleware integration
- **Production**: Optimized builds with proper error handling
- **Database**: Environment-based connection strings for different stages

### Security Considerations
- **Client-side Security**: Screenshot protection and secure key generation
- **Server Security**: Input validation, error handling, and secure session management
- **Database Security**: Parameterized queries and proper connection handling

The application prioritizes security in cryptocurrency operations while maintaining a user-friendly experience through modern UI patterns and comprehensive error handling.

## Testing & Validation

### Final Comprehensive System Verification (January 14, 2025)
- **Complete Animation-Free Interface**: Successfully removed all animations while maintaining professional banking aesthetics
- **Full Cryptocurrency Pipeline**: All 8 supported cryptocurrencies (BTC, ETH, LTC, BCH, XRP, ADA, SOL, MATIC) generating wallets properly
- **Secure Paper Wallet System**: Premium certificate-style paper wallets with QR codes and banking-grade security protocols
- **Database & API Integration**: PostgreSQL with security logging, wallet storage, and comprehensive API endpoints fully operational
- **Educational Features Verified**: 25 banker's tips, Financial Time Machine, AR Investment Advisor all functioning correctly
- **Security Implementation**: Screenshot protection, mnemonic validation, foreign key constraints, and encrypted logging working perfectly
- **Production Ready Status**: Complete wallet creation flow from welcome → phrase selection → mnemonic → confirmation → dashboard → paper printing verified
- **Banking Theme Excellence**: Monopoly Banker character, vault terminology, and Swiss bank security aesthetics maintained throughout

### Global Crypto Timezone Feature (January 14, 2025)
- **Expanded Global Coverage**: Real-time monitoring of 16 major financial centers across Asia-Pacific, Europe, Americas, and Middle East & Africa
- **Enhanced Visualization**: Animated pulse effects, color-coded status indicators, and gradient backgrounds for live market distinction
- **Advanced Market Data**: Professional-grade trading volumes, market caps, participant metrics, and dominant cryptocurrency analysis
- **Live Market Pulse**: Real-time statistics showing active markets, high-activity centers, and combined global trading volumes
- **Interactive Features**: Regional filtering with enhanced UI animations, hover effects, and responsive grid layouts
- **Institutional-Grade Presentation**: Banking-themed design with sophisticated visual elements and real-time data updates

### Interactive 3D Crypto Globe (January 14, 2025)
- **Google Earth-Style Controls**: Full mouse drag functionality with momentum-based movement and smooth deceleration
- **Advanced 3D Mathematics**: Proper rotation matrices for realistic globe manipulation with X/Y axis transformations
- **Interactive Market Pins**: Color-coded pinpoints with varying heights representing trading volumes and activity levels
- **Professional Zoom Controls**: Mouse wheel zoom (0.3x to 3x) with depth-sorted rendering for proper visibility
- **Market Selection System**: Click-to-select functionality with detailed market information display
- **Authentic Geographic Data**: 16 real market locations with accurate latitude/longitude coordinates

### 3D Transaction Flow Visualization (January 14, 2025)
- **Animated Particle System**: Real-time 3D particle flows representing transactions between wallets
- **Curved Path Animation**: Bezier curve-based movement with trailing effects and smooth interpolation
- **Interactive Transaction Details**: Click-to-select flowing particles for detailed transaction information
- **Dynamic Wallet Nodes**: 3D wallet representations with pulsing effects and connection indicators
- **Advanced Visual Effects**: Particle trails, glow effects, shadows, and gradient backgrounds
- **Comprehensive Filtering**: Filter by transaction type (incoming/outgoing/internal) with real-time updates
- **Performance Optimized**: Efficient canvas rendering with 60fps animations and particle management

### Cryptocurrency Market Heatmap (January 14, 2025)
- **Real-time Market Visualization**: Color-coded heatmap showing 20+ cryptocurrencies with live market data
- **Multiple Metric Views**: Switch between 24h change, volume, volatility, 7-day, and 30-day performance
- **Interactive Data Exploration**: Click any cryptocurrency cell for detailed market information
- **Dynamic Color Mapping**: Intensity-based coloring with animated pulsing effects for market activity
- **Advanced Statistics**: Best/worst performers, market averages, and comprehensive market analysis
- **Professional Market Data**: Authentic price data, market caps, trading volumes, and performance metrics

### Personalized Learning Path System (January 14, 2025)
- **AI-Powered Recommendations**: Personalized learning paths based on portfolio size and wallet count
- **Comprehensive Curriculum**: 3 learning tracks (Fundamentals, Security Expert, Professional Trader)
- **Interactive Module System**: 20+ learning modules with progress tracking and prerequisites
- **One-Click Learning Actions**: Instant access to security checkups, portfolio analysis, and educational content
- **Gamified Progress**: Achievement badges, completion tracking, and milestone rewards
- **Adaptive Difficulty**: Content automatically adjusts based on user experience level and portfolio characteristics

## Recent Changes

### Complete Animation Removal & Comprehensive System Testing (January 14, 2025)
- **Total Animation Elimination**: Systematically removed ALL animations from entire codebase including animate-pulse, hover:animate-bounce, transition-all, and hover effects
- **Component-by-Component Cleanup**: Cleaned WelcomeStep, PhraseLengthStep, MnemonicGenerationStep, MnemonicConfirmationStep, WalletDashboard, and PaperWalletView
- **Comprehensive Testing Complete**: Verified all 8 cryptocurrencies, 3 mnemonic lengths, paper wallet functionality, and security features
- **Database Integration Verified**: PostgreSQL connection, security logging, and API endpoints all operational
- **Banking Theme Maintained**: Professional appearance without any animated or flashing elements per user requirements

### Clean Header Navigation & 3D Wallet Navigator (January 14, 2025)
- **Clean Header Menu**: Created professional header navigation with CryptoVault branding and menu items
- **Active State Indicators**: Navigation highlights current page with money-gradient styling
- **Simplified Aesthetics**: Removed clutter from wallet dashboard and streamlined the design
- **3D Wallet Navigation**: Interactive wallet navigator with smooth transitions and keyboard controls
- **Arrow Key Support**: Navigate wallets using left/right arrows, Enter to select
- **Canvas Animations**: 3D transformations with perspective, rotation, and scaling effects
- **Wallet Details Modal**: Click wallet cards to view detailed information and copy functions

### Separate Canvas Visualization Pages (January 14, 2025)
- **Created Dedicated Pages**: Globe, heatmap, and Financial Time Machine moved to separate pages (/globe, /heatmap, /financial-time-machine)
- **Navigation Integration**: Added navigation buttons in wallet dashboard header and dedicated tools section
- **Canvas Debugging**: Added test canvas components for troubleshooting rendering issues
- **Route Configuration**: Updated App.tsx with new routes for visualization pages
- **User Experience**: Improved accessibility by separating complex visualizations from main dashboard

### Comprehensive Secure Database Logging System (January 14, 2025)
- **Database Schema**: Added security_logs table with encrypted sensitive data storage
- **Security Logger Service**: Created comprehensive logging service with AES encryption for sensitive data
- **Complete Activity Tracking**: Logs wallet creation, mnemonic generation, key generation, address creation, transactions
- **API Integration**: Full REST endpoints for security logging with IP tracking, user agents, session IDs
- **Storage Integration**: Added security logging to DatabaseStorage interface
- **Client-Side Logger**: Created client security logger for frontend integration

### Financial Time Machine Feature (January 14, 2025)
- **Expanded Cryptocurrency Coverage**: 10 major cryptocurrencies with authentic historical returns
- **Advanced Market Scenarios**: Crypto winter, bull market, consolidation, and hyperadoption modeling
- **Dollar Cost Averaging Simulator**: Interactive DCA calculator with volatility-based projections
- **Extended Time Horizons**: 1, 2, 3, 5, 10, and 15-year investment scenarios
- **Enhanced Investment Amounts**: $100 to $50,000 flexible investment options
- **Professional Risk Assessment**: Probability-weighted outcomes with detailed trigger events
- **Advanced Mode Toggle**: Basic and advanced interfaces for different user experience levels

### AR Investment Advisor Feature (January 14, 2025)
- **Augmented Reality Mode**: Immersive investment advisor experience with Monopoly Banker mascot
- **Real-time Market Analysis**: Live scanning and overlay of investment opportunities and risks
- **Voice-Activated Guidance**: Natural conversation interface for personalized investment advice
- **Contextual Insights**: AR overlays showing market conditions, portfolio analysis, and actionable recommendations
- **Camera Integration**: Environment-based AR experience with floating banker avatar and speech bubbles
- **Professional Market Data**: Fear & Greed Index, Bitcoin dominance, institutional flows, and options sentiment
- **Interactive Controls**: Voice commands, insight refresh, and seamless AR mode activation/deactivation

### Interactive Educational Features (January 14, 2025)
- **Banker's Tip of the Day**: Implemented comprehensive cryptocurrency investment education system
- **25 Authentic Investment Tips**: Covering diversification, security, DeFi, regulation, and market analysis
- **Daily Rotation System**: Tips change automatically based on current date for ongoing education
- **Risk Assessment Integration**: Color-coded risk levels (low/medium/high) for each investment strategy
- **Multi-Component Integration**: Full tips on dashboard/welcome, mini tips on flow steps
- **Actionable Advice Sections**: Expandable sections with specific steps users can take immediately

### Monopoly Banker Character Integration (January 14, 2025)
- **Custom SVG Monopoly Banker**: Created detailed banker character with monocle, top hat, mustache, and bow tie
- **Dynamic Animations**: Added hover effects and interactive animations throughout the application
- **Consistent Character Placement**: Integrated monopoly banker across all wallet flow steps
- **Enhanced Banking Theme**: Strengthened the monopoly/banker aesthetic with character presence
- **Footer Addition**: Added requested footer crediting Jason Clark with link to jason-clark.org

### Comprehensive Banking Theme Enhancement (January 14, 2025)
- **Enhanced Mnemonic Generation**: Upgraded with "Vault Master Keys" theme and banker security protocol
- **Vault Security Verification**: Transformed confirmation step with banking terminology
- **Digital Fortune Dashboard**: Complete portfolio styling with banker aesthetics
- **Floating Currency Symbols**: Added animated currency symbols around banker character
- **Elite Banking Messaging**: Enhanced all text with sophisticated banking language

### Database Integration (January 14, 2025)
- **Added PostgreSQL Database**: Provisioned and configured Neon serverless PostgreSQL database
- **Database Connection**: Created `server/db.ts` with proper connection setup using Drizzle ORM
- **Storage Layer Migration**: Replaced MemStorage with DatabaseStorage class for persistent data storage
- **Schema Migration**: Successfully pushed database schema with users, wallets, and transactions tables
- **Full CRUD Operations**: Implemented complete database operations for wallets and transactions

### Crypto Wallet Features
- **Multi-Currency Support**: 8 major cryptocurrencies (Bitcoin, Ethereum, Litecoin, Bitcoin Cash, XRP, Cardano, Solana, Polygon)
- **Browser-Compatible Crypto**: Replaced Node.js-dependent libraries with browser-compatible implementations
- **Mnemonic Security**: 12/18/24 word phrase generation with confirmation steps
- **Screenshot Protection**: Active during sensitive operations to prevent unauthorized capture
- **Paper Wallet Printing**: Full offline backup functionality with QR codes