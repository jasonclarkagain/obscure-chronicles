import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { BankersTip } from '@/components/ui/bankers-tip';
import { FinancialTimeMachine } from '@/components/ui/financial-time-machine';
import { ARInvestmentAdvisor } from '@/components/ui/ar-investment-advisor';
import { CryptoTimezone } from '@/components/ui/crypto-timezone';
import { PersonalizedLearning } from '@/components/ui/learning-path';
import { ThreeWalletViewer } from '@/components/ui/three-wallet-viewer';
import { Card, CardContent } from '@/components/ui/card';
import { WalletIcon, PlusIcon, ArrowDownIcon, ArrowUpIcon, CopyIcon, ReceiptIcon, GlobeIcon, BarChart3Icon, MapIcon } from 'lucide-react';
import { type CryptoWallet } from '@/lib/crypto';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

interface WalletDashboardProps {
  wallets: CryptoWallet[];
  onShowPaperWallet: () => void;
}

export function WalletDashboard({ wallets, onShowPaperWallet }: WalletDashboardProps) {
  const { toast } = useToast();
  const [generatedAddresses, setGeneratedAddresses] = useState<{[key: string]: string[]}>({});

  const totalValue = wallets.reduce((sum, wallet) => {
    const value = parseFloat(wallet.usdValue.replace('$', '').replace(',', ''));
    return sum + value;
  }, 0);

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Unable to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const generateNewAddress = (symbol: string) => {
    // Generate a new address based on the cryptocurrency type
    const generateAddress = () => {
      const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
      let result = '';
      
      // Different address formats for different cryptocurrencies
      switch (symbol) {
        case 'BTC':
          result = '1' + Array.from({length: 33}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
          break;
        case 'ETH':
        case 'MATIC':
          result = '0x' + Array.from({length: 40}, () => '0123456789abcdef'[Math.floor(Math.random() * 16)]).join('');
          break;
        case 'LTC':
          result = 'L' + Array.from({length: 33}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
          break;
        case 'BCH':
          result = 'bitcoincash:q' + Array.from({length: 40}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
          break;
        case 'XRP':
          result = 'r' + Array.from({length: 33}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
          break;
        case 'ADA':
          result = 'addr1' + Array.from({length: 54}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
          break;
        case 'SOL':
          result = Array.from({length: 44}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
          break;
        default:
          result = '1' + Array.from({length: 33}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
      }
      return result;
    };

    const newAddress = generateAddress();
    
    setGeneratedAddresses(prev => ({
      ...prev,
      [symbol]: [...(prev[symbol] || []), newAddress]
    }));

    toast({
      title: "New Address Generated!",
      description: `Fresh ${symbol} deposit address created`,
    });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Simple Header */}
      <div className="text-center">
        <div className="flex items-center justify-center space-x-4 mb-4">
          <MonopolyBanker size="md" className="hover:animate-pulse" />
          <div>
            <h2 className="text-3xl font-bold text-green-800 font-serif">Your Digital Fortune</h2>
            <p className="text-green-600">Elite Banking Portfolio</p>
          </div>
        </div>
      </div>

      {/* Portfolio Overview */}
      <div className="banker-gradient rounded-2xl p-8 text-white shadow-2xl border-4 border-yellow-400">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-2 font-serif">💎 Total Portfolio Value</h3>
              <div className="text-5xl font-bold mb-4 text-yellow-400">${totalValue.toFixed(2)}</div>
              <div className="flex items-center space-x-6 text-green-200">
                <span className="flex items-center text-lg">
                  <WalletIcon className="w-6 h-6 mr-2" />
                  {wallets.length} Digital Assets
                </span>
                <span className="flex items-center text-lg">
                  <ReceiptIcon className="w-6 h-6 mr-2" />
                  Secured Vault
                </span>
              </div>
            </div>
            <div className="text-right">
              <div className="w-24 h-24 gold-accent rounded-full flex items-center justify-center shadow-2xl">
                <span className="text-4xl">💰</span>
              </div>
            </div>
          </div>
      </div>

      {/* Currency Wallets */}
      <div className="grid lg:grid-cols-2 gap-8">
          {wallets.map((wallet) => (
            <Card key={wallet.currency} className="bg-gradient-to-br from-green-50 to-emerald-100 border-2 border-green-200 shadow-xl">
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg border-2 border-yellow-400 ${
                      wallet.color === 'orange-500' ? 'bg-orange-500' :
                      wallet.color === 'blue-500' ? 'bg-blue-500' :
                      wallet.color === 'gray-500' ? 'bg-gray-500' :
                      wallet.color === 'green-500' ? 'bg-green-500' :
                      wallet.color === 'blue-600' ? 'bg-blue-600' :
                      wallet.color === 'blue-700' ? 'bg-blue-700' :
                      wallet.color === 'purple-500' ? 'bg-purple-500' :
                      wallet.color === 'purple-600' ? 'bg-purple-600' :
                      'bg-gray-500'
                    }`}>
                      <span>{wallet.icon}</span>
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-green-800 font-serif">{wallet.name}</h4>
                      <span className="text-base text-green-600 font-medium">{wallet.symbol}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-800">{wallet.balance} {wallet.symbol}</div>
                    <div className="text-base text-green-600">{wallet.usdValue}</div>
                  </div>
                </div>
                
                <div className="bg-white border-2 border-green-300 rounded-xl p-4 mb-6 shadow-md">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-base font-bold text-green-800">💼 Primary Vault Address</span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => copyToClipboard(wallet.address, 'Primary Address')}
                      className="text-green-700 hover:bg-green-100 h-auto p-2 border border-green-300 rounded-lg"
                    >
                      <CopyIcon className="w-4 h-4 mr-1" />
                      Copy
                    </Button>
                  </div>
                  <code className="text-sm text-green-700 break-all block font-mono bg-green-50 p-2 rounded">
                    {wallet.address}
                  </code>
                </div>

                {/* Generated Addresses Section */}
                {generatedAddresses[wallet.symbol] && generatedAddresses[wallet.symbol].length > 0 && (
                  <div className="bg-white border-2 border-blue-300 rounded-xl p-4 mb-6 shadow-md">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-base font-bold text-blue-800">🔄 Generated Deposit Addresses</span>
                      <span className="text-sm text-blue-600">{generatedAddresses[wallet.symbol].length} addresses</span>
                    </div>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {generatedAddresses[wallet.symbol].map((address, index) => (
                        <div key={index} className="flex items-center justify-between bg-blue-50 p-2 rounded">
                          <code className="text-xs text-blue-700 font-mono flex-1 mr-2 truncate">
                            {address}
                          </code>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => copyToClipboard(address, `Address ${index + 1}`)}
                            className="text-blue-700 hover:bg-blue-100 h-auto p-1 border border-blue-300 rounded"
                          >
                            <CopyIcon className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="flex space-x-3">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1 border-2 border-green-300 text-green-700 hover:bg-green-50 font-medium py-2"
                    onClick={() => generateNewAddress(wallet.symbol)}
                  >
                    <PlusIcon className="w-4 h-4 mr-2" />
                    💰 New Address
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1 border-2 border-green-300 text-green-700 hover:bg-green-50 font-medium py-2">
                    <ArrowUpIcon className="w-4 h-4 mr-2" />
                    💸 Send
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
      </div>

      {/* 3D Wallet Navigation */}
      <ThreeWalletViewer wallets={wallets} />

      {/* Recent Transactions */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-100 border-2 border-green-200 shadow-xl">
        <CardContent className="p-8">
          <div className="border-b-2 border-green-300 pb-6 mb-8">
            <h3 className="text-2xl font-bold text-green-800 font-serif flex items-center">
              📊 Banking Transaction Ledger
            </h3>
          </div>
          <div className="text-center py-16">
            <div className="w-20 h-20 gold-accent rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
              <span className="text-3xl">📋</span>
            </div>
            <h4 className="text-xl font-bold text-green-800 mb-3 font-serif">Pristine Banking Record</h4>
            <p className="text-green-600">Your elite financial transactions will be meticulously documented here</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
