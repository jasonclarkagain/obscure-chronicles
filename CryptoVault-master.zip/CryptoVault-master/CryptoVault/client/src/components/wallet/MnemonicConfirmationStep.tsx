import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { Card, CardContent } from '@/components/ui/card';
import { RotateCcwIcon } from 'lucide-react';
import { shuffleArray } from '@/lib/crypto';

interface MnemonicConfirmationStepProps {
  mnemonicWords: string[];
  onBack: () => void;
  onConfirmed: () => void;
}

export function MnemonicConfirmationStep({ mnemonicWords, onBack, onConfirmed }: MnemonicConfirmationStepProps) {
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [shuffledWords, setShuffledWords] = useState<string[]>([]);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  useEffect(() => {
    setShuffledWords(shuffleArray(mnemonicWords));
  }, [mnemonicWords]);

  const selectWord = (word: string) => {
    if (selectedWords.length >= mnemonicWords.length) return;
    
    setSelectedWords(prev => [...prev, word]);
  };

  const resetSelection = () => {
    setSelectedWords([]);
    setIsCorrect(null);
  };

  useEffect(() => {
    if (selectedWords.length === mnemonicWords.length) {
      const correct = selectedWords.every((word, index) => word === mnemonicWords[index]);
      setIsCorrect(correct);
    }
  }, [selectedWords, mnemonicWords]);

  const getAvailableWords = () => {
    return shuffledWords.filter(word => {
      const selectedCount = selectedWords.filter(w => w === word).length;
      const originalCount = mnemonicWords.filter(w => w === word).length;
      return selectedCount < originalCount;
    });
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-12">
        <div className="mb-6 flex justify-center">
          <MonopolyBanker size="lg" />
        </div>
        <h2 className="text-3xl font-bold text-green-800 mb-4 font-serif">Vault Security Verification</h2>
        <p className="text-xl text-green-700 max-w-3xl mx-auto">Prove your mastery of the vault combination by selecting each word in perfect sequence. Only a true banker remembers every detail.</p>
      </div>

      <Card className="mb-12 bg-gradient-to-br from-green-50 to-emerald-100 border-4 border-green-200 shadow-2xl">
        <CardContent className="p-10">
          <h4 className="text-2xl font-bold text-green-800 mb-8 font-serif text-center">🎯 Select the vault keys in perfect order:</h4>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
            {Array.from({ length: mnemonicWords.length }, (_, index) => (
              <div
                key={index}
                className={`h-16 border-3 rounded-xl flex items-center justify-center text-base font-medium transition-all shadow-lg
                  ${selectedWords[index]
                    ? 'border-yellow-400 bg-yellow-100 text-green-800 font-bold shadow-xl'
                    : 'border-dashed border-gray-300 text-gray-400'
                  }`}
              >
                {selectedWords[index] ? `${index + 1}. ${selectedWords[index]}` : `Word ${index + 1}`}
              </div>
            ))}
          </div>

          <div className="border-t-4 border-green-300 pt-8">
            <h5 className="text-xl font-bold text-green-800 mb-6 font-serif text-center">🎪 Available Vault Keys (click to select):</h5>
            <div className="flex flex-wrap gap-3 justify-center">
              {getAvailableWords().map((word, index) => (
                <Button
                  key={`${word}-${index}`}
                  variant="outline"
                  onClick={() => selectWord(word)}
                  className="text-green-700 hover:bg-green-100 border-2 border-green-300 px-4 py-2 font-medium rounded-xl shadow-md hover:shadow-lg transition-all"
                  disabled={selectedWords.length >= mnemonicWords.length}
                >
                  {word}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {isCorrect === false && (
        <div className="bg-gradient-to-r from-red-50 to-orange-50 border-2 border-red-200 rounded-2xl p-6 mb-8 shadow-xl">
          <p className="text-red-700 text-center text-lg font-medium">❌ Vault sequence incorrect. A true banker never forgets the combination. Please try again.</p>
        </div>
      )}

      {isCorrect === true && (
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-2xl p-6 mb-8 shadow-xl">
          <p className="text-green-700 text-center text-lg font-bold">✅ Magnificent! Your vault mastery is confirmed. The keys match perfectly!</p>
        </div>
      )}

      <div className="text-center mb-12">
        <Button variant="ghost" onClick={resetSelection} className="text-green-700 hover:bg-green-100 px-6 py-3 border-2 border-green-300 rounded-xl font-medium">
          <RotateCcwIcon className="w-5 h-5 mr-2" />
          🔄 Reset Combination
        </Button>
      </div>

      <div className="flex justify-center space-x-8">
        <Button 
          variant="outline" 
          onClick={onBack} 
          className="px-8 py-4 text-lg border-2 border-green-300 text-green-700 hover:bg-green-50 font-medium"
        >
          ← Back to Vault Keys
        </Button>
        <Button 
          onClick={onConfirmed}
          className={`px-12 py-4 text-xl font-bold shadow-2xl border-2 border-yellow-400 hover:border-yellow-300 transition-all duration-300 transform hover:scale-105 ${isCorrect ? 'money-gradient hover:bg-green-700' : 'bg-gray-400 cursor-not-allowed'}`}
          disabled={!isCorrect}
        >
          {isCorrect ? '🏦 Open the Vault! 🏦' : '🔒 Vault Locked - Complete Verification'}
        </Button>
      </div>
    </div>
  );
}
