import { useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

interface ScreenshotProtectionProps {
  children: React.ReactNode;
  enabled?: boolean;
}

export function ScreenshotProtection({ children, enabled = true }: ScreenshotProtectionProps) {
  const { toast } = useToast();

  useEffect(() => {
    if (!enabled) return;

    const showSecurityAlert = () => {
      toast({
        title: "Screenshot Protection Active",
        description: "Screenshots are disabled for your security. Please write down your recovery phrase by hand.",
        variant: "destructive",
      });
    };

    // Disable right-click context menu
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    // Disable common screenshot shortcuts
    const handleKeyDown = (e: KeyboardEvent) => {
      // Disable Print Screen, F12, Ctrl+Shift+I, etc.
      if (
        e.key === 'PrintScreen' ||
        e.key === 'F12' ||
        (e.ctrlKey && e.shiftKey && e.key === 'I') ||
        (e.ctrlKey && e.shiftKey && e.key === 'C') ||
        (e.ctrlKey && e.key === 'u')
      ) {
        e.preventDefault();
        showSecurityAlert();
      }
    };

    // Blur content when page loses focus
    const handleVisibilityChange = () => {
      if (document.hidden) {
        document.body.style.filter = 'blur(5px)';
      } else {
        document.body.style.filter = 'none';
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.body.style.filter = 'none';
    };
  }, [enabled, toast]);

  return (
    <div className={enabled ? 'screenshot-protected' : ''}>
      {children}
    </div>
  );
}
