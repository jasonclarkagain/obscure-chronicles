import { Button } from '@/components/ui/button';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { BankersTip } from '@/components/ui/bankers-tip';
import { FinancialTimeMachine } from '@/components/ui/financial-time-machine';
import { ARInvestmentAdvisor } from '@/components/ui/ar-investment-advisor';
import { Card, CardContent } from '@/components/ui/card';
import { ShieldIcon, KeyIcon, CoinsIcon, PrinterIcon, AlertTriangleIcon, DollarSignIcon, TrendingUpIcon } from 'lucide-react';

interface WelcomeStepProps {
  onNext: () => void;
}

export function WelcomeStep({ onNext }: WelcomeStepProps) {
  return (
    <div className="max-w-5xl mx-auto relative">
      {/* Monopoly Banker Character */}
      <div className="text-center mb-12">
        <div className="relative inline-block mb-8">
          <MonopolyBanker size="xl" />
          
          {/* Golden coins floating around */}

        </div>
        
        <h2 className="text-4xl font-bold text-green-800 mb-4 font-serif">
          🎩 Welcome to Banker's Vault 🎩
        </h2>
        <p className="text-xl text-green-700 max-w-3xl mx-auto leading-relaxed">
          Step into the most prestigious digital bank vault. Generate your cryptocurrency fortune with the security of a Swiss bank and the elegance of old money.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 mb-12">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-100 border-2 border-green-200 shadow-xl">
          <CardContent className="p-8">
            <div className="w-16 h-16 money-gradient rounded-xl flex items-center justify-center mb-6 shadow-lg">
              <KeyIcon className="text-white w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-green-800 mb-3 font-serif">🔐 Vault Security</h3>
            <p className="text-green-700 leading-relaxed">Swiss-bank level cryptographic security with mnemonic phrases generated using the finest banking standards.</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-yellow-50 to-amber-100 border-2 border-yellow-200 shadow-xl">
          <CardContent className="p-8">
            <div className="w-16 h-16 gold-accent rounded-xl flex items-center justify-center mb-6 shadow-lg">
              <CoinsIcon className="text-white w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-amber-800 mb-3 font-serif">💰 Multi-Fortune</h3>
            <p className="text-amber-700 leading-relaxed">Manage Bitcoin, Ethereum, Litecoin, and other premium digital assets like a true financial baron.</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-emerald-50 to-green-100 border-2 border-emerald-200 shadow-xl">
          <CardContent className="p-8">
            <div className="w-16 h-16 banker-gradient rounded-xl flex items-center justify-center mb-6 shadow-lg">
              <PrinterIcon className="text-green-200 w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-emerald-800 mb-3 font-serif">📜 Paper Bonds</h3>
            <p className="text-emerald-700 leading-relaxed">Generate elegant paper wallets with the sophistication of vintage bearer bonds.</p>
          </CardContent>
        </Card>
      </div>

      <div className="bg-gradient-to-r from-red-50 to-orange-50 border-2 border-red-200 rounded-2xl p-8 mb-12 shadow-xl">
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
            <AlertTriangleIcon className="text-red-600 w-6 h-6" />
          </div>
          <div>
            <h4 className="text-xl font-bold text-red-800 mb-4 font-serif">⚠️ Banker's Code of Conduct</h4>
            <ul className="text-red-700 space-y-2 text-base leading-relaxed">
              <li>🤫 <strong>Never disclose</strong> your recovery phrase to any soul</li>
              <li>🏦 <strong>Store securely</strong> in your private safety deposit box</li>
              <li>👑 <strong>Guard jealously</strong> - anyone with your phrase controls your fortune</li>
              <li>📸 <strong>Screenshot protection</strong> active during sensitive operations</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="text-center">
        <div className="relative inline-block">
          <Button 
            onClick={onNext} 
            className="money-gradient hover:bg-green-700 px-12 py-6 text-xl font-bold shadow-2xl border-2 border-yellow-400 hover:border-yellow-300 transition-all duration-300 transform hover:scale-105"
          >
            🏦 Open New Vault 🏦
          </Button>
          <div className="absolute -top-2 -right-2 w-6 h-6 gold-accent rounded-full animate-ping"></div>
        </div>
        <p className="text-base text-green-700 mt-6 font-medium">By proceeding, you join the elite circle of digital banking</p>
        
        {/* Banker's Lamp */}
        <div className="mt-8 flex justify-center">
          <div className="relative">
            <div className="w-8 h-12 bg-amber-600 rounded-t-full"></div>
            <div className="w-12 h-6 banker-gradient rounded-full -mt-2"></div>
            <div className="w-16 h-3 bg-amber-800 rounded-full -mt-1"></div>
            <div className="absolute top-0 left-2 w-4 h-4 bg-green-400 rounded-full opacity-60 animate-pulse"></div>
          </div>
        </div>
      </div>

      {/* Educational Features */}
      <div className="mt-12 space-y-8">
        <BankersTip />
        <FinancialTimeMachine />
        <ARInvestmentAdvisor />
      </div>
    </div>
  );
}
