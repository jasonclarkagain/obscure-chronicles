import { CheckIcon } from 'lucide-react';

interface ProgressIndicatorProps {
  currentStep: 'welcome' | 'phrase-length' | 'mnemonic' | 'confirm' | 'wallet' | 'paper-wallet';
  className?: string;
}

export function ProgressIndicator({ currentStep, className = '' }: ProgressIndicatorProps) {
  const steps = [
    { id: 'welcome', label: '1', name: 'Welcome' },
    { id: 'phrase-length', label: '2', name: 'Length' },
    { id: 'mnemonic', label: '3', name: 'Generate' },
    { id: 'confirm', label: '4', name: 'Confirm' },
    { id: 'wallet', label: '✓', name: 'Complete' },
  ];

  const getCurrentStepIndex = () => {
    return steps.findIndex(step => step.id === currentStep);
  };

  const currentIndex = getCurrentStepIndex();

  if (currentStep === 'paper-wallet') {
    return null; // Hide on paper wallet view
  }

  return (
    <div className={`fixed bottom-6 left-1/2 transform -translate-x-1/2 no-print ${className}`}>
      <div className="bg-white rounded-full px-6 py-3 shadow-lg border flex items-center space-x-4">
        {steps.map((step, index) => (
          <div key={step.id} className="flex items-center space-x-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-colors
                ${index <= currentIndex
                  ? 'bg-crypto-blue text-white'
                  : 'bg-gray-200 text-gray-500'
                }`}
            >
              {index < currentIndex ? (
                <CheckIcon className="w-4 h-4" />
              ) : (
                step.label
              )}
            </div>
            {index < steps.length - 1 && (
              <div
                className={`w-8 h-1 transition-colors
                  ${index < currentIndex ? 'bg-crypto-blue' : 'bg-gray-200'}
                `}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
