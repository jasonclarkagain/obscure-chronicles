import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeftIcon, PrinterIcon, ShieldIcon, StarIcon, CrownIcon } from 'lucide-react';
import { type CryptoWallet } from '@/lib/crypto';
import { generateQRCode } from '@/lib/crypto';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';

interface PaperWalletViewProps {
  wallets: CryptoWallet[];
  mnemonicWords: string[];
  onBack: () => void;
}

export function PaperWalletView({ wallets, mnemonicWords, onBack }: PaperWalletViewProps) {
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const serialNumber = `SV-${Date.now().toString().slice(-8)}`;
  const certificateId = `CERT-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Screen Controls */}
      <div className="flex items-center justify-between mb-8 no-print">
        <div className="flex items-center space-x-4">
          <MonopolyBanker size="md" />
          <div>
            <h2 className="text-2xl font-bold text-green-800 font-serif">Premium Paper Wallet Certificate</h2>
            <p className="text-green-600">Banking-grade security documentation</p>
          </div>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" onClick={onBack} className="border-green-300 text-green-700 hover:bg-green-50">
            <ArrowLeftIcon className="w-4 h-4 mr-2" />
            Back to Vault
          </Button>
          <Button onClick={handlePrint} className="bg-green-700 hover:bg-green-800 text-white">
            <PrinterIcon className="w-4 h-4 mr-2" />
            Print Certificate
          </Button>
        </div>
      </div>

      {/* Premium Bond-Style Paper Wallet */}
      <div className="print-area bg-white">
        {/* Ornate Header with Banking Insignia */}
        <div className="relative border-8 border-double border-green-800 bg-gradient-to-br from-green-50 via-yellow-50 to-green-50 p-8 print:border-black print:bg-white">
          
          {/* Decorative Corner Elements */}
          <div className="absolute top-4 left-4 w-12 h-12 border-4 border-green-700 print:border-black transform rotate-45"></div>
          <div className="absolute top-4 right-4 w-12 h-12 border-4 border-green-700 print:border-black transform rotate-45"></div>
          <div className="absolute bottom-4 left-4 w-12 h-12 border-4 border-green-700 print:border-black transform rotate-45"></div>
          <div className="absolute bottom-4 right-4 w-12 h-12 border-4 border-green-700 print:border-black transform rotate-45"></div>

          {/* Header Section */}
          <div className="text-center mb-12 relative z-10">
            <div className="flex justify-center items-center mb-6">
              <div className="bg-green-700 print:bg-black text-white p-4 rounded-full mr-4">
                <ShieldIcon className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-4xl font-serif font-bold text-green-800 print:text-black tracking-wide">
                  SECUREVAULT
                </h1>
                <p className="text-lg font-serif italic text-green-700 print:text-black">
                  Digital Asset Certificate
                </p>
              </div>
              <div className="bg-yellow-500 print:bg-gray-300 text-green-800 print:text-black p-4 rounded-full ml-4">
                <CrownIcon className="w-8 h-8" />
              </div>
            </div>
            
            <div className="border-t-4 border-b-4 border-double border-green-700 print:border-black py-4 mx-8">
              <h2 className="text-2xl font-serif text-green-800 print:text-black">
                CERTIFICATE OF DIGITAL WEALTH
              </h2>
              <p className="text-sm font-serif text-green-600 print:text-black mt-2">
                This document certifies the holder's ownership of encrypted digital assets
              </p>
            </div>
          </div>

          {/* Certificate Details */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div className="space-y-4">
              <div className="border-2 border-green-600 print:border-black bg-white p-4 rounded-lg">
                <h4 className="font-serif font-bold text-green-800 print:text-black mb-2">Certificate Information</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="font-medium text-green-700 print:text-black">Issue Date:</span>
                    <span className="font-mono text-green-800 print:text-black">{currentDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-green-700 print:text-black">Serial Number:</span>
                    <span className="font-mono text-green-800 print:text-black">{serialNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-green-700 print:text-black">Certificate ID:</span>
                    <span className="font-mono text-green-800 print:text-black">{certificateId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-green-700 print:text-black">Asset Count:</span>
                    <span className="font-mono text-green-800 print:text-black">{wallets.length} Cryptocurrencies</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="border-2 border-green-600 print:border-black bg-white p-4 rounded-lg">
                <h4 className="font-serif font-bold text-green-800 print:text-black mb-2">Security Classification</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <StarIcon key={i} className="w-4 h-4 text-yellow-500 print:text-black fill-current" />
                      ))}
                    </div>
                    <span className="font-serif text-green-800 print:text-black">Maximum Security</span>
                  </div>
                  <p className="text-green-700 print:text-black italic">
                    "Cryptographically secured with military-grade encryption protocols"
                  </p>
                  <div className="border-t border-green-300 print:border-black pt-2 mt-2">
                    <span className="text-xs font-serif text-green-600 print:text-black">
                      Authorized by SecureVault Banking Consortium
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Recovery Phrase Section - Premium Bond Style */}
          <div className="border-4 border-double border-green-700 print:border-black bg-gradient-to-r from-yellow-50 to-green-50 print:bg-white p-8 mb-8">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-serif font-bold text-green-800 print:text-black">
                MASTER RECOVERY PHRASE
              </h3>
              <p className="text-sm font-serif italic text-green-700 print:text-black mt-2">
                "The sacred words that unlock your digital fortune"
              </p>
              <div className="w-32 h-1 bg-green-700 print:bg-black mx-auto mt-4"></div>
            </div>
            
            <div className="grid grid-cols-4 gap-4 mb-6">
              {mnemonicWords.map((word, index) => (
                <div key={index} className="relative">
                  <div className="border-2 border-green-600 print:border-black bg-white p-4 rounded-lg text-center shadow-lg">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-700 print:bg-black text-white print:text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
                      {index + 1}
                    </div>
                    <span className="font-mono font-bold text-lg text-green-800 print:text-black block mt-2">
                      {word}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center text-xs font-serif text-green-600 print:text-black italic">
              "Guard these words as you would guard your most precious treasure"
            </div>
          </div>

          {/* Wallet Addresses Section */}
          <div className="space-y-6 mb-8">
            <div className="text-center">
              <h3 className="text-2xl font-serif font-bold text-green-800 print:text-black">
                DIGITAL ASSET REGISTRY
              </h3>
              <div className="w-48 h-1 bg-green-700 print:bg-black mx-auto mt-2"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {wallets.map((wallet, index) => (
                <div key={index} className="border-3 border-green-600 print:border-black bg-white rounded-lg overflow-hidden shadow-lg">
                  <div className="bg-green-700 print:bg-black text-white print:text-white p-4">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{wallet.icon}</span>
                      <div>
                        <h4 className="font-serif font-bold text-lg">{wallet.name}</h4>
                        <p className="text-sm opacity-90">{wallet.symbol} • {wallet.currency}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-6 space-y-4">
                    <div>
                      <h5 className="font-serif font-bold text-green-800 print:text-black mb-2">Public Address</h5>
                      <div className="bg-gray-50 print:bg-white print:border print:border-gray-400 p-3 rounded border-2 border-green-200 print:border-black">
                        <code className="text-xs font-mono text-green-800 print:text-black break-all">
                          {wallet.address}
                        </code>
                      </div>
                    </div>

                    <div>
                      <h5 className="font-serif font-bold text-green-800 print:text-black mb-2">Private Key</h5>
                      <div className="bg-red-50 print:bg-white print:border print:border-gray-400 p-3 rounded border-2 border-red-300 print:border-black">
                        <code className="text-xs font-mono text-red-800 print:text-black break-all">
                          {wallet.privateKey}
                        </code>
                      </div>
                    </div>

                    <div className="text-center">
                      <div className="inline-block border-2 border-green-600 print:border-black p-2 bg-white rounded">
                        <img 
                          src={generateQRCode(wallet.address)} 
                          alt={`${wallet.currency} QR Code`}
                          className="w-20 h-20"
                        />
                      </div>
                      <p className="text-xs font-serif text-green-600 print:text-black mt-2">
                        QR Code for Address
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Security Notice - Premium Style */}
          <div className="border-4 border-double border-red-700 print:border-black bg-gradient-to-r from-red-50 to-yellow-50 print:bg-white p-6">
            <div className="text-center mb-4">
              <div className="inline-block bg-red-700 print:bg-black text-white p-3 rounded-full">
                <ShieldIcon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-serif font-bold text-red-800 print:text-black mt-2">
                CONFIDENTIAL SECURITY DIRECTIVE
              </h3>
            </div>
            
            <div className="grid grid-cols-2 gap-6 text-sm">
              <div>
                <h4 className="font-serif font-bold text-red-800 print:text-black mb-2">Mandatory Security Protocols:</h4>
                <ul className="space-y-1 text-red-700 print:text-black">
                  <li>• Store in fireproof, waterproof vault</li>
                  <li>• Create multiple authenticated copies</li>
                  <li>• Distribute across secure locations</li>
                  <li>• Never photograph or digitize</li>
                </ul>
              </div>
              <div>
                <h4 className="font-serif font-bold text-red-800 print:text-black mb-2">Liability Disclaimer:</h4>
                <ul className="space-y-1 text-red-700 print:text-black">
                  <li>• Holder assumes full responsibility</li>
                  <li>• Loss of document = loss of assets</li>
                  <li>• No recovery possible if compromised</li>
                  <li>• SecureVault bears no liability</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Footer with Official Seal */}
          <div className="mt-8 pt-6 border-t-4 border-double border-green-700 print:border-black">
            <div className="flex justify-between items-center">
              <div className="text-left">
                <p className="font-serif text-green-800 print:text-black font-bold">
                  SecureVault Digital Banking Consortium
                </p>
                <p className="text-sm font-serif text-green-600 print:text-black">
                  "Banking excellence since the digital age"
                </p>
              </div>
              
              <div className="text-center">
                <div className="inline-block border-4 border-green-700 print:border-black rounded-full p-4 bg-yellow-100 print:bg-white">
                  <div className="text-center">
                    <CrownIcon className="w-8 h-8 text-green-700 print:text-black mx-auto" />
                    <div className="text-xs font-serif font-bold text-green-800 print:text-black mt-1">
                      OFFICIAL
                    </div>
                    <div className="text-xs font-serif text-green-600 print:text-black">
                      SEAL
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <p className="text-sm font-serif text-green-600 print:text-black">
                  Document ID: {certificateId}
                </p>
                <p className="text-sm font-serif text-green-600 print:text-black">
                  Issued: {currentDate}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}