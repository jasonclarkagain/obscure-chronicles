import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { EyeOffIcon, RefreshCwIcon, PrinterIcon } from 'lucide-react';
import { type MnemonicPhrase } from '@/lib/crypto';

interface MnemonicGenerationStepProps {
  mnemonic: MnemonicPhrase;
  phraseLength: 12 | 18 | 24;
  onBack: () => void;
  onNext: () => void;
  onRegeneratePhrase: () => void;
  onShowPrintView: () => void;
}

export function MnemonicGenerationStep({ 
  mnemonic, 
  phraseLength, 
  onBack, 
  onNext, 
  onRegeneratePhrase,
  onShowPrintView 
}: MnemonicGenerationStepProps) {
  const [securityChecks, setSecurityChecks] = useState({
    written: false,
    stored: false,
    understand: false,
  });

  const allChecksComplete = Object.values(securityChecks).every(Boolean);

  const handleCheckChange = (check: keyof typeof securityChecks) => {
    setSecurityChecks(prev => ({ ...prev, [check]: !prev[check] }));
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-12">
        <div className="mb-6 flex justify-center">
          <MonopolyBanker size="lg" />
        </div>
        <h2 className="text-3xl font-bold text-green-800 mb-4 font-serif">Your Vault Master Keys</h2>
        <p className="text-xl text-green-700 max-w-3xl mx-auto">These sacred words are the keys to your digital fortune. Guard them as a banker guards his most precious assets.</p>
      </div>

      <div className="bg-gradient-to-r from-red-50 to-orange-50 border-2 border-red-200 rounded-2xl p-8 mb-12 shadow-xl">
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
            <EyeOffIcon className="text-red-600 w-6 h-6" />
          </div>
          <h4 className="text-xl font-bold text-red-800 font-serif">🛡️ Elite Security Protocol Active</h4>
        </div>
        <p className="text-red-700 text-base">Digital surveillance protection enabled. Transcribe these words by hand only - no screenshots permitted in the vault.</p>
      </div>

      <Card className="mb-12 bg-gradient-to-br from-green-50 to-emerald-100 border-4 border-green-200 shadow-2xl">
        <CardContent className="p-10">
          <div className="text-center mb-8">
            <span className="text-lg font-bold text-green-800 bg-yellow-200 px-6 py-2 rounded-full border-2 border-yellow-400 font-serif">
              🏦 {phraseLength} Word Vault Combination
            </span>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-8">
            {mnemonic.words.map((word, index) => (
              <div key={index} className="relative bg-white border-2 border-green-300 rounded-xl p-4 shadow-lg">
                <div className="absolute -top-3 -left-3 w-8 h-8 gold-accent rounded-full text-xs font-bold flex items-center justify-center text-green-800 border-2 border-yellow-400 shadow-lg">
                  {index + 1}
                </div>
                <div className="text-center pt-2">
                  <span className="font-mono text-xl font-bold text-green-800 select-text mnemonic-word">
                    {word}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center space-x-8">
            <Button variant="ghost" onClick={onRegeneratePhrase} className="text-green-700 hover:bg-green-100 px-6 py-3 border-2 border-green-300 rounded-xl font-medium">
              <RefreshCwIcon className="w-5 h-5 mr-2" />
              🎲 Generate New Keys
            </Button>
            <div className="w-px h-8 bg-green-300"></div>
            <Button variant="ghost" onClick={onShowPrintView} className="text-green-700 hover:bg-green-100 px-6 py-3 border-2 border-green-300 rounded-xl font-medium">
              <PrinterIcon className="w-5 h-5 mr-2" />
              📜 Print Bearer Bonds
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="bg-gradient-to-br from-emerald-50 to-green-100 border-2 border-emerald-200 rounded-2xl p-8 mb-12 shadow-xl">
        <h4 className="text-2xl font-bold text-green-800 mb-6 font-serif flex items-center">
          <span className="text-2xl mr-3">✅</span>
          Banker's Security Protocol
        </h4>
        <div className="space-y-5">
          <div className="flex items-center space-x-4">
            <Checkbox
              checked={securityChecks.written}
              onCheckedChange={() => handleCheckChange('written')}
              id="written"
              className="w-6 h-6"
            />
            <label htmlFor="written" className="text-green-800 cursor-pointer text-lg font-medium">
              📝 I have transcribed my vault keys to physical medium
            </label>
          </div>
          <div className="flex items-center space-x-4">
            <Checkbox
              checked={securityChecks.stored}
              onCheckedChange={() => handleCheckChange('stored')}
              id="stored"
              className="w-6 h-6"
            />
            <label htmlFor="stored" className="text-green-800 cursor-pointer text-lg font-medium">
              🏦 I have secured them in my private safety deposit box
            </label>
          </div>
          <div className="flex items-center space-x-4">
            <Checkbox
              checked={securityChecks.understand}
              onCheckedChange={() => handleCheckChange('understand')}
              id="understand"
              className="w-6 h-6"
            />
            <label htmlFor="understand" className="text-green-800 cursor-pointer text-lg font-medium">
              👑 I understand these keys grant complete access to my digital fortune
            </label>
          </div>
        </div>
      </div>

      <div className="flex justify-center space-x-8">
        <Button 
          variant="outline" 
          onClick={onBack} 
          className="px-8 py-4 text-lg border-2 border-green-300 text-green-700 hover:bg-green-50 font-medium"
        >
          ← Back to Security Level
        </Button>
        <Button 
          onClick={onNext} 
          className="money-gradient hover:bg-green-700 px-12 py-4 text-xl font-bold shadow-2xl border-2 border-yellow-400 hover:border-yellow-300 transition-all duration-300 transform hover:scale-105"
          disabled={!allChecksComplete}
        >
          🔐 Keys Secured - Proceed to Vault 🔐
        </Button>
      </div>
    </div>
  );
}
