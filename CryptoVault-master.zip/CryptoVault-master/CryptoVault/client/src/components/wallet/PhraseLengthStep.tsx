import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { MiniBankersTip } from '@/components/ui/mini-bankers-tip';
import { CheckIcon } from 'lucide-react';

interface PhraseLengthStepProps {
  selectedLength: 12 | 18 | 24;
  onLengthChange: (length: 12 | 18 | 24) => void;
  onNext: () => void;
  onBack: () => void;
}

export function PhraseLengthStep({ selectedLength, onLengthChange, onNext, onBack }: PhraseLengthStepProps) {
  const options = [
    {
      length: 12 as const,
      title: '12 Words',
      description: 'Standard vault security - Perfect for everyday banking',
      icon: '🏦',
      tier: 'Standard'
    },
    {
      length: 18 as const,
      title: '18 Words',
      description: 'Enhanced vault security - Premium protection',
      icon: '🏛️',
      tier: 'Premium'
    },
    {
      length: 24 as const,
      title: '24 Words',
      description: 'Maximum vault security - Elite banker protection',
      icon: '👑',
      tier: 'Elite'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <div className="mb-6 flex justify-center">
          <MonopolyBanker size="lg" />
        </div>
        <h2 className="text-3xl font-bold text-green-800 mb-4 font-serif">Select Your Vault Security Level</h2>
        <p className="text-xl text-green-700 max-w-2xl mx-auto">Choose the strength of your digital safety deposit box. Higher word counts provide enhanced protection for your fortune.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {options.map((option) => (
          <div
            key={option.length}
            className={`relative border-4 rounded-2xl p-8 cursor-pointer shadow-xl
              ${selectedLength === option.length
                ? 'border-yellow-400 bg-gradient-to-br from-green-50 to-emerald-100 shadow-2xl'
                : 'border-green-200 bg-gradient-to-br from-gray-50 to-white hover:border-green-400'
              }`}
            onClick={() => onLengthChange(option.length)}
          >
            {/* Tier Badge */}
            <div className={`absolute -top-3 left-4 px-3 py-1 rounded-full text-xs font-bold
              ${selectedLength === option.length 
                ? 'bg-yellow-400 text-yellow-900' 
                : 'bg-green-100 text-green-800'
              }`}>
              {option.tier}
            </div>
            
            <div className="text-center">
              <div className="text-4xl mb-4">{option.icon}</div>
              <h3 className="text-xl font-bold text-green-800 mb-2 font-serif">{option.title}</h3>
              <p className="text-green-700 text-sm leading-relaxed mb-6">{option.description}</p>
              
              <div 
                className={`w-8 h-8 border-3 rounded-full flex items-center justify-center mx-auto
                  ${selectedLength === option.length
                    ? 'bg-yellow-400 border-yellow-400'
                    : 'border-green-300'
                  }`}
              >
                {selectedLength === option.length && (
                  <CheckIcon className="w-5 h-5 text-green-800" />
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center space-x-6">
        <Button 
          variant="outline" 
          onClick={onBack} 
          className="px-8 py-4 text-lg border-2 border-green-300 text-green-700 hover:bg-green-50 font-medium"
        >
          ← Back to Welcome
        </Button>
        <Button 
          onClick={onNext} 
          className="money-gradient hover:bg-green-700 px-12 py-4 text-xl font-bold shadow-2xl border-2 border-yellow-400 hover:border-yellow-300 transition-all duration-300 transform hover:scale-105"
        >
          🔐 Generate Vault Keys 🔐
        </Button>
      </div>

      {/* Mini Banker's Tip */}
      <div className="mt-8">
        <MiniBankersTip />
      </div>
    </div>
  );
}
