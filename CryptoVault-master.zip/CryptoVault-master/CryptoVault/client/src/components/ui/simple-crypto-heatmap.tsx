import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BarChart3Icon, TrendingUpIcon, TrendingDownIcon } from 'lucide-react';

interface CryptoData {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume: number;
  marketCap: number;
  color: string;
}

export function SimpleCryptoHeatmap() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedMetric, setSelectedMetric] = useState<'change24h' | 'volume' | 'marketcap'>('change24h');
  const [selectedCrypto, setSelectedCrypto] = useState<CryptoData | null>(null);

  const cryptoData: CryptoData[] = [
    { symbol: 'BTC', name: 'Bitcoin', price: 43250, change24h: 2.3, volume: 28.5e9, marketCap: 850e9, color: '#F7931A' },
    { symbol: 'ETH', name: 'Ethereum', price: 2680, change24h: 1.8, volume: 15.2e9, marketCap: 320e9, color: '#627EEA' },
    { symbol: 'BNB', name: 'BNB', price: 315, change24h: -0.5, volume: 1.8e9, marketCap: 47e9, color: '#F3BA2F' },
    { symbol: 'XRP', name: 'XRP', price: 0.58, change24h: 3.2, volume: 2.1e9, marketCap: 32e9, color: '#23292F' },
    { symbol: 'ADA', name: 'Cardano', price: 0.52, change24h: -1.1, volume: 980e6, marketCap: 18e9, color: '#0033AD' },
    { symbol: 'SOL', name: 'Solana', price: 98.5, change24h: 4.7, volume: 2.8e9, marketCap: 42e9, color: '#9945FF' },
    { symbol: 'DOGE', name: 'Dogecoin', price: 0.082, change24h: -2.3, volume: 850e6, marketCap: 12e9, color: '#C2A633' },
    { symbol: 'MATIC', name: 'Polygon', price: 0.85, change24h: 1.9, volume: 420e6, marketCap: 8e9, color: '#8247E5' },
    { symbol: 'DOT', name: 'Polkadot', price: 7.45, change24h: -0.8, volume: 320e6, marketCap: 9e9, color: '#E6007A' },
    { symbol: 'AVAX', name: 'Avalanche', price: 36.8, change24h: 2.1, volume: 680e6, marketCap: 14e9, color: '#E84142' },
    { symbol: 'LINK', name: 'Chainlink', price: 14.2, change24h: 0.7, volume: 540e6, marketCap: 8e9, color: '#2A5ADA' },
    { symbol: 'UNI', name: 'Uniswap', price: 6.8, change24h: -1.5, volume: 280e6, marketCap: 5e9, color: '#FF007A' }
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size for mobile responsiveness
    const setCanvasSize = () => {
      const container = canvas.parentElement;
      if (container) {
        const width = Math.min(container.offsetWidth, 800);
        const height = Math.min(width * 0.6, 480);
        
        canvas.width = width;
        canvas.height = height;
        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;
      }
    };

    setCanvasSize();
    window.addEventListener('resize', setCanvasSize);

    const drawHeatmap = () => {
      const { width, height } = canvas;
      
      // Clear canvas
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, width, height);

      // Calculate grid
      const cols = 4;
      const rows = Math.ceil(cryptoData.length / cols);
      const cellWidth = width / cols;
      const cellHeight = height / rows;

      cryptoData.forEach((crypto, index) => {
        const col = index % cols;
        const row = Math.floor(index / cols);
        const x = col * cellWidth;
        const y = row * cellHeight;

        // Get metric value
        let value: number;
        let maxValue: number;
        
        switch (selectedMetric) {
          case 'change24h':
            value = crypto.change24h;
            maxValue = 5; // 5% max for color scaling
            break;
          case 'volume':
            value = crypto.volume / 1e9; // Convert to billions
            maxValue = 30; // 30B max for color scaling
            break;
          case 'marketcap':
            value = crypto.marketCap / 1e9; // Convert to billions
            maxValue = 1000; // 1T max for color scaling
            break;
          default:
            value = crypto.change24h;
            maxValue = 5;
        }

        // Calculate color intensity
        let color: string;
        if (selectedMetric === 'change24h') {
          if (value > 0) {
            const intensity = Math.min(Math.abs(value) / maxValue, 1);
            const green = Math.floor(50 + intensity * 155);
            color = `rgb(0, ${green}, 0)`;
          } else {
            const intensity = Math.min(Math.abs(value) / maxValue, 1);
            const red = Math.floor(50 + intensity * 155);
            color = `rgb(${red}, 0, 0)`;
          }
        } else {
          const intensity = Math.min(value / maxValue, 1);
          const blue = Math.floor(50 + intensity * 155);
          color = `rgb(0, ${Math.floor(blue * 0.5)}, ${blue})`;
        }

        // Draw cell
        ctx.fillStyle = color;
        ctx.fillRect(x + 2, y + 2, cellWidth - 4, cellHeight - 4);

        // Draw border
        ctx.strokeStyle = '#374151';
        ctx.lineWidth = 2;
        ctx.strokeRect(x + 2, y + 2, cellWidth - 4, cellHeight - 4);

        // Add pulse effect for high values
        if ((selectedMetric === 'change24h' && Math.abs(value) > 2) ||
            (selectedMetric === 'volume' && value > 10) ||
            (selectedMetric === 'marketcap' && value > 100)) {
          const pulse = 0.5 + 0.3 * Math.sin(Date.now() / 500 + index);
          ctx.strokeStyle = `rgba(255, 255, 255, ${pulse})`;
          ctx.lineWidth = 3;
          ctx.strokeRect(x + 1, y + 1, cellWidth - 2, cellHeight - 2);
        }

        // Draw text
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 16px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(crypto.symbol, x + cellWidth / 2, y + cellHeight / 2 - 10);

        ctx.font = '12px Arial';
        ctx.fillText(crypto.name, x + cellWidth / 2, y + cellHeight / 2 + 5);

        // Draw metric value
        ctx.font = 'bold 14px Arial';
        let displayValue = '';
        switch (selectedMetric) {
          case 'change24h':
            displayValue = `${value > 0 ? '+' : ''}${value.toFixed(1)}%`;
            break;
          case 'volume':
            displayValue = `$${value.toFixed(1)}B`;
            break;
          case 'marketcap':
            displayValue = `$${value.toFixed(0)}B`;
            break;
        }
        ctx.fillText(displayValue, x + cellWidth / 2, y + cellHeight / 2 + 20);
      });

      // Draw selection overlay
      if (selectedCrypto) {
        const index = cryptoData.indexOf(selectedCrypto);
        if (index !== -1) {
          const col = index % cols;
          const row = Math.floor(index / cols);
          const x = col * cellWidth;
          const y = row * cellHeight;

          ctx.strokeStyle = '#FEF08A';
          ctx.lineWidth = 4;
          ctx.strokeRect(x, y, cellWidth, cellHeight);
        }
      }
    };

    drawHeatmap();

    return () => {
      window.removeEventListener('resize', setCanvasSize);
    };
  }, [selectedMetric, selectedCrypto]);

  // Handle canvas clicks
  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    const cols = 4;
    const cellWidth = canvas.width / cols;
    const cellHeight = canvas.height / Math.ceil(cryptoData.length / cols);

    const col = Math.floor(x / cellWidth);
    const row = Math.floor(y / cellHeight);
    const index = row * cols + col;

    if (index < cryptoData.length) {
      setSelectedCrypto(cryptoData[index]);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-slate-900 to-gray-900 border-gray-700 text-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3Icon className="w-5 h-5 text-green-400" />
          Crypto Market Heatmap
        </CardTitle>
        <div className="flex gap-2 flex-wrap">
          <Button
            size="sm"
            variant={selectedMetric === 'change24h' ? 'default' : 'outline'}
            onClick={() => setSelectedMetric('change24h')}
            className={selectedMetric === 'change24h' ? 'bg-green-600 hover:bg-green-700' : 'text-white border-gray-600 hover:bg-gray-700'}
          >
            24h Change
          </Button>
          <Button
            size="sm"
            variant={selectedMetric === 'volume' ? 'default' : 'outline'}
            onClick={() => setSelectedMetric('volume')}
            className={selectedMetric === 'volume' ? 'bg-blue-600 hover:bg-blue-700' : 'text-white border-gray-600 hover:bg-gray-700'}
          >
            Volume
          </Button>
          <Button
            size="sm"
            variant={selectedMetric === 'marketcap' ? 'default' : 'outline'}
            onClick={() => setSelectedMetric('marketcap')}
            className={selectedMetric === 'marketcap' ? 'bg-purple-600 hover:bg-purple-700' : 'text-white border-gray-600 hover:bg-gray-700'}
          >
            Market Cap
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <canvas
            ref={canvasRef}
            onClick={handleCanvasClick}
            className="w-full border border-gray-600 rounded-lg cursor-pointer"
            style={{ maxHeight: '400px' }}
          />

          {/* Selected crypto details */}
          {selectedCrypto && (
            <div className="mt-4 p-4 bg-gray-800 rounded-lg border border-gray-600">
              <h3 className="text-lg font-bold mb-2">{selectedCrypto.name} ({selectedCrypto.symbol})</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">Price:</span>
                  <span className="ml-2 font-bold">${selectedCrypto.price.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-gray-400">24h Change:</span>
                  <span className={`ml-2 font-bold ${selectedCrypto.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {selectedCrypto.change24h >= 0 ? '+' : ''}{selectedCrypto.change24h.toFixed(1)}%
                  </span>
                </div>
                <div>
                  <span className="text-gray-400">Volume:</span>
                  <span className="ml-2 font-bold">${(selectedCrypto.volume / 1e9).toFixed(1)}B</span>
                </div>
                <div>
                  <span className="text-gray-400">Market Cap:</span>
                  <span className="ml-2 font-bold">${(selectedCrypto.marketCap / 1e9).toFixed(0)}B</span>
                </div>
              </div>
            </div>
          )}

          {/* Market summary */}
          <div className="mt-4 flex gap-4 flex-wrap">
            <Badge variant="secondary" className="bg-green-500/20 text-green-400">
              <TrendingUpIcon className="w-3 h-3 mr-1" />
              Gainers: {cryptoData.filter(c => c.change24h > 0).length}
            </Badge>
            <Badge variant="secondary" className="bg-red-500/20 text-red-400">
              <TrendingDownIcon className="w-3 h-3 mr-1" />
              Losers: {cryptoData.filter(c => c.change24h < 0).length}
            </Badge>
            <Badge variant="secondary" className="bg-blue-500/20 text-blue-400">
              Total Market Cap: ${(cryptoData.reduce((sum, c) => sum + c.marketCap, 0) / 1e12).toFixed(1)}T
            </Badge>
          </div>

          <p className="text-gray-400 text-sm mt-2">
            Click on cryptocurrency cells to view detailed information. Switch metrics using the buttons above.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}