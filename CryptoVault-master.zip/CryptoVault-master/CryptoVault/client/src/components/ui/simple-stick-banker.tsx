import React, { useState, useEffect } from 'react';

interface SimpleStickBankerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export function SimpleStickBanker({ size = 'md', className = '' }: SimpleStickBankerProps) {
  const [isWinking, setIsWinking] = useState(false);
  const [stepPosition, setStepPosition] = useState(0);

  const sizeClasses = {
    sm: 'w-12 h-16',
    md: 'w-16 h-20',
    lg: 'w-20 h-24',
    xl: 'w-24 h-28'
  };

  useEffect(() => {
    const interval = setInterval(() => {
      // Random wink
      if (Math.random() < 0.3) {
        setIsWinking(true);
        setTimeout(() => setIsWinking(false), 300);
      }
      
      // Random step
      if (Math.random() < 0.4) {
        setStepPosition(prev => prev === 0 ? (Math.random() > 0.5 ? 1 : -1) : 0);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`${sizeClasses[size]} ${className} relative`}>
      <svg
        viewBox="0 0 80 100"
        className="w-full h-full drop-shadow-lg animate-pulse"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <radialGradient id="glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#fbbf24" stopOpacity="0.3"/>
            <stop offset="100%" stopColor="#fbbf24" stopOpacity="0"/>
          </radialGradient>
        </defs>

        {/* Glow background */}
        <circle cx="40" cy="50" r="35" fill="url(#glow)"/>

        {/* Body with step animation */}
        <g transform={`translate(${stepPosition * 2}, 0)`}>
          
          {/* Top Hat */}
          <rect x="36" y="8" width="8" height="12" fill="#1f2937" stroke="#fbbf24" strokeWidth="0.5" rx="1"/>
          <ellipse cx="40" cy="20" rx="6" ry="2" fill="#1f2937"/>
          
          {/* Head */}
          <circle cx="40" cy="25" r="6" fill="none" stroke="#1f2937" strokeWidth="2"/>
          
          {/* Big Monocle */}
          <circle cx="37" cy="24" r="4" fill="rgba(251, 191, 36, 0.3)" stroke="#fbbf24" strokeWidth="2"/>
          <circle cx="37" cy="24" r="3" fill="rgba(255, 255, 255, 0.6)"/>
          <circle cx="38.5" cy="22.5" r="1" fill="rgba(255, 255, 255, 0.9)"/>
          
          {/* Monocle chain */}
          <path d="M33 24 Q30 22 28 20" stroke="#fbbf24" strokeWidth="1" fill="none"/>
          
          {/* Eyes */}
          {isWinking ? (
            <>
              <line x1="35" y1="23" x2="39" y2="23" stroke="#1f2937" strokeWidth="1"/>
              <circle cx="43" cy="24" r="0.5" fill="#1f2937"/>
            </>
          ) : (
            <>
              <circle cx="37" cy="23" r="0.5" fill="#1f2937"/>
              <circle cx="43" cy="24" r="0.5" fill="#1f2937"/>
            </>
          )}
          
          {/* Mustache */}
          <path d="M36 27 Q40 26 44 27" stroke="#1f2937" strokeWidth="1.5" fill="none"/>
          
          {/* Body */}
          <line x1="40" y1="31" x2="40" y2="55" stroke="#1f2937" strokeWidth="2"/>
          
          {/* Arms */}
          <line x1="40" y1="40" x2="30" y2="45" stroke="#1f2937" strokeWidth="2"/>
          <line x1="40" y1="40" x2="50" y2="45" stroke="#1f2937" strokeWidth="2"/>
          
          {/* Money bags */}
          <circle cx="29" cy="46" r="2" fill="#10b981"/>
          <text x="29" y="48" textAnchor="middle" fontSize="2" fill="#fbbf24">💰</text>
          <circle cx="51" cy="46" r="2" fill="#10b981"/>
          <text x="51" y="48" textAnchor="middle" fontSize="2" fill="#fbbf24">💵</text>
          
          {/* Bow Tie */}
          <polygon points="37,38 40,36 43,38 40,40" fill="#dc2626"/>
          
          {/* Legs */}
          <line x1="40" y1="55" x2={35 + stepPosition * 3} y2="70" stroke="#1f2937" strokeWidth="2"/>
          <line x1="40" y1="55" x2={45 - stepPosition * 3} y2="70" stroke="#1f2937" strokeWidth="2"/>
          
          {/* Feet */}
          <ellipse cx={35 + stepPosition * 3} cy="72" rx="3" ry="1.5" fill="#1f2937"/>
          <ellipse cx={45 - stepPosition * 3} cy="72" rx="3" ry="1.5" fill="#1f2937"/>
        </g>
      </svg>
    </div>
  );
}