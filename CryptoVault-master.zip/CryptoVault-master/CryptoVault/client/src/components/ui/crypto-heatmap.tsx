import { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { 
  TrendingUpIcon, 
  TrendingDownIcon,
  BarChart3Icon,
  RefreshCwIcon,
  FilterIcon,
  ZoomInIcon,
  ZoomOutIcon,
  InfoIcon
} from 'lucide-react';
import { type CryptoWallet } from '@/lib/crypto';

interface HeatmapData {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume: number;
  marketCap: number;
  volatility: number;
  performance7d: number;
  performance30d: number;
  dominance: number;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  intensity: number;
}

interface CryptoHeatmapProps {
  wallets: CryptoWallet[];
}

export function CryptoHeatmap({ wallets }: CryptoHeatmapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const [selectedMetric, setSelectedMetric] = useState<'change24h' | 'volume' | 'volatility' | 'performance7d' | 'performance30d'>('change24h');
  const [selectedCrypto, setSelectedCrypto] = useState<HeatmapData | null>(null);
  const [zoom, setZoom] = useState(1);
  const [heatmapData, setHeatmapData] = useState<HeatmapData[]>([]);
  const [isAnimating, setIsAnimating] = useState(true);

  // Generate realistic market data
  const generateHeatmapData = (): HeatmapData[] => {
    const cryptoData = [
      { symbol: 'BTC', name: 'Bitcoin', basePrice: 45000, baseCap: 850000000000 },
      { symbol: 'ETH', name: 'Ethereum', basePrice: 2800, baseCap: 340000000000 },
      { symbol: 'LTC', name: 'Litecoin', basePrice: 75, baseCap: 5500000000 },
      { symbol: 'BCH', name: 'Bitcoin Cash', basePrice: 125, baseCap: 2400000000 },
      { symbol: 'XRP', name: 'Ripple', basePrice: 0.52, baseCap: 28000000000 },
      { symbol: 'ADA', name: 'Cardano', basePrice: 0.38, baseCap: 13500000000 },
      { symbol: 'SOL', name: 'Solana', basePrice: 85, baseCap: 38000000000 },
      { symbol: 'MATIC', name: 'Polygon', basePrice: 0.85, baseCap: 8500000000 },
      { symbol: 'DOT', name: 'Polkadot', basePrice: 6.2, baseCap: 7800000000 },
      { symbol: 'LINK', name: 'Chainlink', basePrice: 14.5, baseCap: 8200000000 },
      { symbol: 'UNI', name: 'Uniswap', basePrice: 6.8, baseCap: 5100000000 },
      { symbol: 'AVAX', name: 'Avalanche', basePrice: 24, baseCap: 9600000000 },
      { symbol: 'ATOM', name: 'Cosmos', basePrice: 8.5, baseCap: 3300000000 },
      { symbol: 'ALGO', name: 'Algorand', basePrice: 0.18, baseCap: 1400000000 },
      { symbol: 'VET', name: 'VeChain', basePrice: 0.024, baseCap: 1900000000 },
      { symbol: 'ICP', name: 'Internet Computer', basePrice: 4.2, baseCap: 1900000000 },
      { symbol: 'FIL', name: 'Filecoin', basePrice: 4.1, baseCap: 1800000000 },
      { symbol: 'THETA', name: 'Theta Network', basePrice: 0.95, baseCap: 950000000 },
      { symbol: 'AAVE', name: 'Aave', basePrice: 78, baseCap: 1200000000 },
      { symbol: 'GRT', name: 'The Graph', basePrice: 0.12, baseCap: 1100000000 }
    ];

    const data: HeatmapData[] = [];
    const gridSize = Math.ceil(Math.sqrt(cryptoData.length));
    const cellWidth = 800 / gridSize;
    const cellHeight = 400 / gridSize;

    cryptoData.forEach((crypto, index) => {
      const row = Math.floor(index / gridSize);
      const col = index % gridSize;
      
      // Generate realistic fluctuations
      const change24h = (Math.random() - 0.5) * 20; // -10% to +10%
      const volatility = Math.random() * 50 + 10; // 10% to 60%
      const performance7d = (Math.random() - 0.5) * 30; // -15% to +15%
      const performance30d = (Math.random() - 0.5) * 80; // -40% to +40%
      
      const price = crypto.basePrice * (1 + change24h / 100);
      const marketCap = crypto.baseCap * (1 + change24h / 100);
      const volume = marketCap * (0.02 + Math.random() * 0.1); // 2-12% of market cap
      
      let metricValue: number;
      switch (selectedMetric) {
        case 'change24h':
          metricValue = change24h;
          break;
        case 'volume':
          metricValue = volume / 1000000000; // Normalize to billions
          break;
        case 'volatility':
          metricValue = volatility;
          break;
        case 'performance7d':
          metricValue = performance7d;
          break;
        case 'performance30d':
          metricValue = performance30d;
          break;
        default:
          metricValue = change24h;
      }

      // Calculate color based on metric
      const intensity = selectedMetric === 'volume' ? 
        Math.min(metricValue / 50, 1) : // Volume-based intensity
        Math.abs(metricValue) / 100; // Percentage-based intensity

      const getColor = (value: number, metric: string) => {
        if (metric === 'volume' || metric === 'volatility') {
          // Blue-green gradient for volume/volatility (higher = more intense)
          const normalizedValue = Math.min(Math.abs(value) / 50, 1);
          const red = Math.floor(0 + normalizedValue * 100);
          const green = Math.floor(100 + normalizedValue * 155);
          const blue = Math.floor(200 + normalizedValue * 55);
          return `rgb(${red}, ${green}, ${blue})`;
        } else {
          // Red-green gradient for performance metrics
          if (value > 0) {
            // Green for positive
            const normalizedValue = Math.min(value / 20, 1);
            const red = Math.floor(50 - normalizedValue * 50);
            const green = Math.floor(150 + normalizedValue * 105);
            const blue = Math.floor(50 - normalizedValue * 50);
            return `rgb(${red}, ${green}, ${blue})`;
          } else {
            // Red for negative
            const normalizedValue = Math.min(Math.abs(value) / 20, 1);
            const red = Math.floor(150 + normalizedValue * 105);
            const green = Math.floor(50 - normalizedValue * 50);
            const blue = Math.floor(50 - normalizedValue * 50);
            return `rgb(${red}, ${green}, ${blue})`;
          }
        }
      };

      data.push({
        symbol: crypto.symbol,
        name: crypto.name,
        price,
        change24h,
        volume,
        marketCap,
        volatility,
        performance7d,
        performance30d,
        dominance: (marketCap / 1500000000000) * 100, // Percentage of total crypto market
        x: col * cellWidth,
        y: row * cellHeight,
        width: cellWidth - 2,
        height: cellHeight - 2,
        color: getColor(metricValue, selectedMetric),
        intensity
      });
    });

    return data;
  };

  // Draw the heatmap
  const drawHeatmap = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Clear canvas with dark background
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(0, 0, width, height);

    // Draw heatmap cells
    heatmapData.forEach(crypto => {
      const x = crypto.x * zoom;
      const y = crypto.y * zoom;
      const cellWidth = crypto.width * zoom;
      const cellHeight = crypto.height * zoom;

      // Cell shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
      ctx.fillRect(x + 2, y + 2, cellWidth, cellHeight);

      // Main cell with animated intensity
      const animatedIntensity = crypto.intensity + Math.sin(Date.now() * 0.003 + crypto.x + crypto.y) * 0.1;
      const alpha = Math.max(0.3, Math.min(1, animatedIntensity));
      
      ctx.fillStyle = crypto.color.replace('rgb', 'rgba').replace(')', `, ${alpha})`);
      ctx.fillRect(x, y, cellWidth, cellHeight);

      // Cell border
      ctx.strokeStyle = selectedCrypto?.symbol === crypto.symbol ? '#FFFFFF' : 'rgba(255, 255, 255, 0.2)';
      ctx.lineWidth = selectedCrypto?.symbol === crypto.symbol ? 3 : 1;
      ctx.strokeRect(x, y, cellWidth, cellHeight);

      // Symbol text
      ctx.fillStyle = '#FFFFFF';
      ctx.font = `bold ${Math.max(10, cellWidth * 0.12)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(crypto.symbol, x + cellWidth / 2, y + cellHeight / 3);

      // Value text
      const getValue = () => {
        switch (selectedMetric) {
          case 'change24h':
          case 'performance7d':
          case 'performance30d':
            return `${crypto[selectedMetric] > 0 ? '+' : ''}${crypto[selectedMetric].toFixed(1)}%`;
          case 'volume':
            return `$${(crypto.volume / 1000000000).toFixed(1)}B`;
          case 'volatility':
            return `${crypto.volatility.toFixed(1)}%`;
          default:
            return '';
        }
      };

      ctx.font = `${Math.max(8, cellWidth * 0.08)}px sans-serif`;
      ctx.fillText(getValue(), x + cellWidth / 2, y + (cellHeight * 2) / 3);

      // Intensity indicator (small dot)
      const dotSize = Math.max(2, crypto.intensity * 8);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.beginPath();
      ctx.arc(x + cellWidth - 8, y + 8, dotSize, 0, 2 * Math.PI);
      ctx.fill();
    });
  };

  // Handle canvas click
  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = (event.clientX - rect.left) / zoom;
    const clickY = (event.clientY - rect.top) / zoom;

    const clickedCrypto = heatmapData.find(crypto => 
      clickX >= crypto.x && clickX <= crypto.x + crypto.width &&
      clickY >= crypto.y && clickY <= crypto.y + crypto.height
    );

    setSelectedCrypto(clickedCrypto || null);
  };

  // Animation loop
  const animate = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    drawHeatmap(ctx, canvas.width, canvas.height);
    
    if (isAnimating) {
      animationFrameRef.current = requestAnimationFrame(animate);
    }
  };

  // Update heatmap data when metric changes
  useEffect(() => {
    setHeatmapData(generateHeatmapData());
  }, [selectedMetric, wallets]);

  // Initialize canvas and animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      // Force canvas dimensions
      canvas.style.display = 'block';
      canvas.style.width = '100%';
      canvas.style.height = '384px';
      canvas.width = 800;
      canvas.height = 384;
      console.log('Heatmap canvas resized:', canvas.width, 'x', canvas.height);
    };

    resizeCanvas();
    
    // Small delay to ensure DOM is ready
    setTimeout(() => {
      animate();
    }, 100);
    
    window.addEventListener('resize', resizeCanvas);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [heatmapData, zoom, selectedCrypto, isAnimating]);

  const getMetricStats = () => {
    if (heatmapData.length === 0) return { highest: null, lowest: null, average: 0 };

    const values = heatmapData.map(crypto => {
      switch (selectedMetric) {
        case 'change24h':
        case 'performance7d':
        case 'performance30d':
        case 'volatility':
          return crypto[selectedMetric];
        case 'volume':
          return crypto.volume / 1000000000;
        default:
          return 0;
      }
    });

    const highest = heatmapData[values.indexOf(Math.max(...values))];
    const lowest = heatmapData[values.indexOf(Math.min(...values))];
    const average = values.reduce((sum, val) => sum + val, 0) / values.length;

    return { highest, lowest, average };
  };

  const stats = getMetricStats();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <MonopolyBanker size="md" />
          <div>
            <h2 className="text-2xl font-bold text-green-800 font-serif">Cryptocurrency Market Heatmap</h2>
            <p className="text-green-600">Real-time color-coded market performance visualization</p>
          </div>
        </div>
      </div>

      {/* Controls */}
      <Card className="border-2 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <BarChart3Icon className="w-4 h-4 text-green-700" />
                <select
                  value={selectedMetric}
                  onChange={(e) => setSelectedMetric(e.target.value as any)}
                  className="border border-green-300 rounded px-3 py-1 text-sm text-green-700 bg-white"
                >
                  <option value="change24h">24h Change %</option>
                  <option value="volume">Trading Volume</option>
                  <option value="volatility">Volatility %</option>
                  <option value="performance7d">7-Day Performance</option>
                  <option value="performance30d">30-Day Performance</option>
                </select>
              </div>
              
              <Button
                variant="outline"
                onClick={() => setHeatmapData(generateHeatmapData())}
                className="border-green-300 text-green-700 hover:bg-green-50"
              >
                <RefreshCwIcon className="w-4 h-4 mr-2" />
                Refresh Data
              </Button>
            </div>
            
            <div className="flex items-center space-x-1">
              <Button
                variant="outline"
                onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}
                className="border-green-300 text-green-700 hover:bg-green-50 p-2"
              >
                <ZoomOutIcon className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                onClick={() => setZoom(Math.min(2, zoom + 0.1))}
                className="border-green-300 text-green-700 hover:bg-green-50 p-2"
              >
                <ZoomInIcon className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Heatmap and Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Heatmap Visualization */}
        <div className="lg:col-span-2">
          <Card className="border-2 border-green-200">
            <CardContent className="p-0">
              <div className="relative w-full h-96 bg-gradient-to-br from-slate-900 to-slate-800 rounded-lg border-2 border-green-300">
                <canvas
                  ref={canvasRef}
                  onClick={handleCanvasClick}
                  width={800}
                  height={384}
                  className="absolute inset-0 w-full h-full cursor-pointer rounded-lg"
                  style={{ 
                    background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
                    display: 'block'
                  }}
                />
                <div className="absolute top-2 left-2 text-white text-xs bg-black bg-opacity-70 px-2 py-1 rounded">
                  Heatmap Active
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Statistics and Details */}
        <div className="space-y-4">
          {/* Market Statistics */}
          <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
            <CardContent className="p-4">
              <h3 className="font-bold text-green-800 font-serif mb-3">Market Statistics</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-green-700">Metric:</span>
                  <Badge className="bg-green-100 text-green-800">
                    {selectedMetric === 'change24h' ? '24h Change' :
                     selectedMetric === 'volume' ? 'Volume' :
                     selectedMetric === 'volatility' ? 'Volatility' :
                     selectedMetric === 'performance7d' ? '7-Day' : '30-Day'}
                  </Badge>
                </div>
                {stats.highest && (
                  <div className="flex items-center justify-between">
                    <span className="text-green-700">Best Performer:</span>
                    <div className="text-right">
                      <div className="font-bold text-green-800">{stats.highest.symbol}</div>
                      <div className="text-xs text-green-600">
                        {selectedMetric === 'volume' ? 
                          `$${(stats.highest.volume / 1000000000).toFixed(1)}B` :
                          `${stats.highest[selectedMetric].toFixed(1)}%`}
                      </div>
                    </div>
                  </div>
                )}
                {stats.lowest && (
                  <div className="flex items-center justify-between">
                    <span className="text-green-700">Worst Performer:</span>
                    <div className="text-right">
                      <div className="font-bold text-green-800">{stats.lowest.symbol}</div>
                      <div className="text-xs text-green-600">
                        {selectedMetric === 'volume' ? 
                          `$${(stats.lowest.volume / 1000000000).toFixed(1)}B` :
                          `${stats.lowest[selectedMetric].toFixed(1)}%`}
                      </div>
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-green-700">Average:</span>
                  <span className="font-bold text-green-800">
                    {selectedMetric === 'volume' ? 
                      `$${stats.average.toFixed(1)}B` :
                      `${stats.average.toFixed(1)}%`}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Color Legend */}
          <Card className="border-2 border-green-200">
            <CardContent className="p-4">
              <h3 className="font-bold text-green-800 font-serif mb-3">Color Legend</h3>
              <div className="space-y-2 text-sm">
                {selectedMetric === 'volume' || selectedMetric === 'volatility' ? (
                  <>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-blue-200 rounded"></div>
                      <span className="text-green-700">Low Activity</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-green-400 rounded"></div>
                      <span className="text-green-700">Medium Activity</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-green-600 rounded"></div>
                      <span className="text-green-700">High Activity</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-red-500 rounded"></div>
                      <span className="text-green-700">Negative Performance</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-gray-400 rounded"></div>
                      <span className="text-green-700">Neutral</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-green-500 rounded"></div>
                      <span className="text-green-700">Positive Performance</span>
                    </div>
                  </>
                )}
              </div>
              <div className="mt-3 pt-3 border-t border-green-200">
                <p className="text-xs text-green-600">• Intensity represents magnitude</p>
                <p className="text-xs text-green-600">• White dot shows relative strength</p>
              </div>
            </CardContent>
          </Card>

          {/* Selected Cryptocurrency */}
          {selectedCrypto && (
            <Card className="border-2 border-blue-400 bg-gradient-to-br from-blue-50 to-indigo-50">
              <CardContent className="p-4">
                <h3 className="font-bold text-blue-800 font-serif mb-3">{selectedCrypto.name} ({selectedCrypto.symbol})</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-blue-700">Price:</span>
                    <span className="font-bold text-blue-800">${selectedCrypto.price.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">24h Change:</span>
                    <span className={`font-bold ${selectedCrypto.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {selectedCrypto.change24h > 0 ? '+' : ''}{selectedCrypto.change24h.toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">Volume:</span>
                    <span className="font-bold text-blue-800">${(selectedCrypto.volume / 1000000000).toFixed(1)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">Market Cap:</span>
                    <span className="font-bold text-blue-800">${(selectedCrypto.marketCap / 1000000000).toFixed(1)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">Volatility:</span>
                    <span className="font-bold text-blue-800">{selectedCrypto.volatility.toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">7-Day:</span>
                    <span className={`font-bold ${selectedCrypto.performance7d >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {selectedCrypto.performance7d > 0 ? '+' : ''}{selectedCrypto.performance7d.toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">30-Day:</span>
                    <span className={`font-bold ${selectedCrypto.performance30d >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {selectedCrypto.performance30d > 0 ? '+' : ''}{selectedCrypto.performance30d.toFixed(2)}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Instructions */}
      <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
        <CardContent className="p-4">
          <h3 className="font-bold text-green-800 font-serif mb-2">How to Use the Heatmap</h3>
          <div className="text-sm text-green-700 space-y-1">
            <p>• Select different metrics to visualize various market aspects</p>
            <p>• Colors indicate performance: green = positive, red = negative, blue = volume/activity</p>
            <p>• Color intensity shows the magnitude of the metric value</p>
            <p>• Click on any cryptocurrency cell to view detailed information</p>
            <p>• Use zoom controls to get a closer look at the data</p>
            <p>• Refresh data to see updated market conditions</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}