import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { TipCategories } from '@/components/ui/tip-categories';
import { TrendingUpIcon, TrendingDownIcon, DollarSignIcon, AlertTriangleIcon, LightbulbIcon, RefreshCwIcon, FilterIcon } from 'lucide-react';

interface BankersTip {
  id: string;
  category: 'investment' | 'security' | 'strategy' | 'market' | 'education';
  title: string;
  content: string;
  actionable: string;
  riskLevel: 'low' | 'medium' | 'high';
  icon: string;
  banker_quote: string;
}

const cryptoTips: BankersTip[] = [
  {
    id: 'diversification-101',
    category: 'investment',
    title: 'The Golden Rule of Portfolio Diversification',
    content: 'Never allocate more than 5-10% of your total investment portfolio to cryptocurrency. While crypto offers excellent growth potential, traditional assets like stocks, bonds, and real estate provide stability.',
    actionable: 'Calculate your current crypto allocation as a percentage of total investments. If over 10%, consider rebalancing.',
    riskLevel: 'low',
    icon: '⚖️',
    banker_quote: 'A prudent banker never puts all his gold in one vault, my dear fellow!'
  },
  {
    id: 'dollar-cost-averaging',
    category: 'strategy',
    title: 'Dollar-Cost Averaging: The Gentleman\'s Approach',
    content: 'Instead of timing the market with large purchases, invest a fixed amount regularly (weekly or monthly). This strategy reduces the impact of volatility and removes emotional decision-making.',
    actionable: 'Set up automatic recurring purchases of $50-200 weekly rather than investing lump sums.',
    riskLevel: 'low',
    icon: '📈',
    banker_quote: 'Steady accumulation builds the greatest fortunes, just like compound interest!'
  },
  {
    id: 'research-fundamentals',
    category: 'education',
    title: 'Due Diligence: Know Your Assets',
    content: 'Before investing in any cryptocurrency, research its use case, development team, market cap, and real-world adoption. Read the whitepaper and understand the technology behind it.',
    actionable: 'Spend at least 2 hours researching any new crypto before investing. Check team backgrounds on LinkedIn.',
    riskLevel: 'medium',
    icon: '📚',
    banker_quote: 'Knowledge is the finest currency in any banker\'s vault!'
  },
  {
    id: 'security-first',
    category: 'security',
    title: 'Hardware Wallets: Your Digital Safe Deposit Box',
    content: 'For holdings over $1,000, use a hardware wallet like Ledger or Trezor. Keep your recovery phrase in multiple secure locations, never digitally stored.',
    actionable: 'If you have over $1,000 in crypto, purchase a hardware wallet within 30 days.',
    riskLevel: 'high',
    icon: '🔐',
    banker_quote: 'The most expensive security is the security you didn\'t buy!'
  },
  {
    id: 'market-cycles',
    category: 'market',
    title: 'Understanding Market Cycles',
    content: 'Crypto markets move in 4-year cycles, often correlated with Bitcoin halvings. Bear markets can last 1-2 years, while bull markets typically run 1-1.5 years.',
    actionable: 'Plan your investment timeline around these cycles. Best buying opportunities often occur during bear markets.',
    riskLevel: 'medium',
    icon: '🔄',
    banker_quote: 'Patience and timing separate the wealthy from the wishful!'
  },
  {
    id: 'taxation-awareness',
    category: 'education',
    title: 'Tax Implications: The Banker\'s Burden',
    content: 'In most jurisdictions, crypto gains are taxable events. Keep detailed records of all transactions including dates, amounts, and purposes. Consider tax-loss harvesting strategies.',
    actionable: 'Use crypto tax software like Koinly or CoinTracker to track all transactions for tax reporting.',
    riskLevel: 'high',
    icon: '📋',
    banker_quote: 'Even the finest banker must answer to the taxman, old chap!'
  },
  {
    id: 'altcoin-risks',
    category: 'investment',
    title: 'Altcoin Investment: Beyond Bitcoin',
    content: 'While Bitcoin and Ethereum are relatively stable, smaller altcoins carry significantly higher risk. Many projects fail within 2-3 years. Limit altcoin exposure to 20% of your crypto portfolio.',
    actionable: 'Focus 60% on Bitcoin, 20% on Ethereum, and maximum 20% on carefully researched altcoins.',
    riskLevel: 'high',
    icon: '⚠️',
    banker_quote: 'Exotic investments can yield exotic losses, proceed with aristocratic caution!'
  },
  {
    id: 'staking-income',
    category: 'strategy',
    title: 'Passive Income Through Staking',
    content: 'Proof-of-stake cryptocurrencies like Ethereum, Cardano, and Solana offer staking rewards of 4-12% annually. However, consider lock-up periods and slashing risks.',
    actionable: 'Research staking options for your holdings, but never stake more than 70% of any single asset.',
    riskLevel: 'medium',
    icon: '💰',
    banker_quote: 'Let your money work while you sip brandy by the fireplace!'
  },
  {
    id: 'defi-caution',
    category: 'security',
    title: 'DeFi: Proceed with Banker\'s Caution',
    content: 'Decentralized Finance offers high yields but carries smart contract risks, impermanent loss, and potential rug pulls. Start with established protocols and small amounts.',
    actionable: 'Begin with blue-chip DeFi protocols (Uniswap, Aave, Compound) with less than 5% of your portfolio.',
    riskLevel: 'high',
    icon: '🏛️',
    banker_quote: 'New financial instruments require the wisdom of experience!'
  },
  {
    id: 'emotional-discipline',
    category: 'strategy',
    title: 'Emotional Discipline: The Banker\'s Composure',
    content: 'Fear and greed drive most crypto losses. Set clear entry and exit strategies before investing. Never make decisions during extreme market movements.',
    actionable: 'Write down your investment thesis and review it monthly. Set stop-losses at -20% and take profits at predetermined levels.',
    riskLevel: 'medium',
    icon: '🧘',
    banker_quote: 'A composed mind manages money better than a brilliant one in panic!'
  },
  {
    id: 'regulatory-compliance',
    category: 'education',
    title: 'Regulatory Landscape Navigation',
    content: 'Cryptocurrency regulations vary by jurisdiction and change frequently. Stay informed about legal requirements in your country including licensing, reporting obligations, and permitted activities.',
    actionable: 'Subscribe to regulatory updates from your financial authority. Consult a crypto-savvy accountant for compliance guidance.',
    riskLevel: 'high',
    icon: '⚖️',
    banker_quote: 'The finest banker always operates within the bounds of the law!'
  },
  {
    id: 'yield-farming-risks',
    category: 'investment',
    title: 'Yield Farming: High Rewards, Higher Risks',
    content: 'Yield farming can offer 50-1000% APY but carries smart contract risks, impermanent loss, and potential for total loss. Many protocols are experimental and untested.',
    actionable: 'Never invest more than 2% of your portfolio in yield farming. Research protocol audits and team backgrounds thoroughly.',
    riskLevel: 'high',
    icon: '🌾',
    banker_quote: 'Extraordinary returns often hide extraordinary risks, dear fellow!'
  },
  {
    id: 'exchange-security',
    category: 'security',
    title: 'Exchange Selection and Security',
    content: 'Not all exchanges are created equal. Use established platforms with insurance coverage, regulatory compliance, and proven track records. Enable 2FA and withdrawal confirmations.',
    actionable: 'Research exchange insurance policies and regulatory status. Never keep large amounts on any exchange longer than necessary.',
    riskLevel: 'medium',
    icon: '🏛️',
    banker_quote: 'Choose your financial institutions as carefully as your finest wine!'
  },
  {
    id: 'nft-speculation',
    category: 'investment',
    title: 'NFT Investment: Art Meets Speculation',
    content: 'NFTs are highly speculative with minimal intrinsic value. Most lose 90% of value within 6 months. Only buy from established artists or projects with clear utility.',
    actionable: 'Limit NFT exposure to 1% of portfolio. Focus on utility-driven projects rather than pure art speculation.',
    riskLevel: 'high',
    icon: '🎨',
    banker_quote: 'Not every painted canvas becomes a masterpiece, my artistic friend!'
  },
  {
    id: 'layer2-scaling',
    category: 'education',
    title: 'Layer 2 Solutions: The Express Lanes',
    content: 'Layer 2 networks like Polygon, Arbitrum, and Optimism offer faster transactions and lower fees than Ethereum mainnet, but add complexity and bridge risks.',
    actionable: 'Start with small amounts on Layer 2. Understand bridge mechanisms and potential delays before moving large sums.',
    riskLevel: 'medium',
    icon: '⚡',
    banker_quote: 'Speed is valuable, but safety is priceless in banking!'
  },
  {
    id: 'mining-considerations',
    category: 'strategy',
    title: 'Mining and Staking Economics',
    content: 'Mining profitability depends on electricity costs, hardware efficiency, and network difficulty. Consider staking as an alternative with lower energy requirements but lockup periods.',
    actionable: 'Calculate mining ROI including electricity, hardware depreciation, and tax implications. Compare with staking rewards.',
    riskLevel: 'medium',
    icon: '⛏️',
    banker_quote: 'The goldmine that pays is better than the one that glitters!'
  },
  {
    id: 'institutional-adoption',
    category: 'market',
    title: 'Institutional Adoption Trends',
    content: 'Corporate treasury adoption, ETF approvals, and institutional custody solutions signal mainstream acceptance but also increase correlation with traditional markets.',
    actionable: 'Monitor institutional buying patterns through on-chain analytics. Consider how institutional flows might affect your strategy.',
    riskLevel: 'low',
    icon: '🏢',
    banker_quote: 'When institutions arrive, the wild west becomes wall street!'
  },
  {
    id: 'privacy-coins',
    category: 'security',
    title: 'Privacy Coins: Digital Swiss Accounts',
    content: 'Privacy-focused cryptocurrencies like Monero and Zcash offer enhanced anonymity but face increasing regulatory scrutiny and potential delisting from exchanges.',
    actionable: 'Understand local regulations regarding privacy coins. Consider privacy implications of your transaction history.',
    riskLevel: 'high',
    icon: '🕶️',
    banker_quote: 'Discretion is the better part of valor in financial matters!'
  },
  {
    id: 'social-sentiment',
    category: 'strategy',
    title: 'Social Media and Market Sentiment',
    content: 'Crypto markets are heavily influenced by social media sentiment, influencer opinions, and viral trends. This creates both opportunities and risks for investors.',
    actionable: 'Use sentiment analysis tools but make decisions based on fundamentals. Be wary of coordinated pump campaigns.',
    riskLevel: 'medium',
    icon: '📱',
    banker_quote: 'The crowd is often wrong when money is on the line!'
  },
  {
    id: 'inheritance-planning',
    category: 'education',
    title: 'Estate Planning for Digital Assets',
    content: 'Cryptocurrency inheritance requires special planning. Private keys, hardware wallets, and exchange accounts need secure succession plans to prevent permanent loss.',
    actionable: 'Create detailed instructions for crypto access. Consider multi-signature wallets or crypto-aware estate planning services.',
    riskLevel: 'high',
    icon: '📜',
    banker_quote: 'A banker\'s legacy should outlive his mortal coil!'
  },
  {
    id: 'market-manipulation',
    category: 'security',
    title: 'Recognizing Market Manipulation',
    content: 'Pump and dump schemes, wash trading, and coordinated attacks are common in crypto. Learn to identify suspicious price movements and volume patterns.',
    actionable: 'Research trading volume authenticity. Be suspicious of sudden price spikes without fundamental news.',
    riskLevel: 'high',
    icon: '🎭',
    banker_quote: 'Not all that glitters is gold, some is merely fool\'s gold!'
  },
  {
    id: 'technical-analysis',
    category: 'strategy',
    title: 'Technical Analysis: Charts Tell Stories',
    content: 'Technical analysis can help time entries and exits, but crypto markets are more volatile than traditional assets. Support and resistance levels break more frequently.',
    actionable: 'Learn basic chart patterns but always combine with fundamental analysis. Set alerts rather than watching charts constantly.',
    riskLevel: 'medium',
    icon: '📈',
    banker_quote: 'Charts reveal the market\'s mood, but fundamentals reveal its future!'
  },
  {
    id: 'cross-chain-bridges',
    category: 'security',
    title: 'Cross-Chain Bridge Risks',
    content: 'Bridges connecting different blockchains are frequent hack targets. Over $2 billion was stolen from bridges in 2022. They represent single points of failure.',
    actionable: 'Use established bridges with insurance. Minimize time spent with assets on bridges. Consider native tokens when possible.',
    riskLevel: 'high',
    icon: '🌉',
    banker_quote: 'The strongest vault has no unnecessary doors!'
  }
];

export function BankersTip() {
  const [currentTip, setCurrentTip] = useState<BankersTip>(cryptoTips[0]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [tipIndex, setTipIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showCategories, setShowCategories] = useState(false);
  const [filteredTips, setFilteredTips] = useState<BankersTip[]>(cryptoTips);

  // Filter tips by category
  useEffect(() => {
    const filtered = selectedCategory === 'all' 
      ? cryptoTips 
      : cryptoTips.filter(tip => tip.category === selectedCategory);
    setFilteredTips(filtered);
    
    // Change tip daily based on date and filtered tips
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
    const index = dayOfYear % filtered.length;
    setTipIndex(index);
    setCurrentTip(filtered[index]);
  }, [selectedCategory]);

  const getNextTip = () => {
    const nextIndex = (tipIndex + 1) % filteredTips.length;
    setTipIndex(nextIndex);
    setCurrentTip(filteredTips[nextIndex]);
    setIsExpanded(false);
  };

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setIsExpanded(false);
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'investment': return <TrendingUpIcon className="w-5 h-5" />;
      case 'security': return <AlertTriangleIcon className="w-5 h-5" />;
      case 'strategy': return <LightbulbIcon className="w-5 h-5" />;
      case 'market': return <TrendingDownIcon className="w-5 h-5" />;
      case 'education': return <DollarSignIcon className="w-5 h-5" />;
      default: return <LightbulbIcon className="w-5 h-5" />;
    }
  };

  return (
    <div>
      {/* Category Filters */}
      {showCategories && (
        <TipCategories 
          onCategorySelect={handleCategorySelect}
          selectedCategory={selectedCategory}
        />
      )}

      <Card className="bg-gradient-to-br from-green-50 to-emerald-100 border-2 border-green-200 shadow-xl hover:shadow-2xl transition-all duration-300">
        <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <MonopolyBanker size="sm" className="hover:animate-pulse" />
            <div>
              <h3 className="text-lg font-bold text-green-800 font-serif">Banker's Tip of the Day</h3>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRiskColor(currentTip.riskLevel)}`}>
                  Risk: {currentTip.riskLevel.toUpperCase()}
                </span>
                <span className="flex items-center text-green-600 text-sm">
                  {getCategoryIcon(currentTip.category)}
                  <span className="ml-1 capitalize">{currentTip.category}</span>
                </span>
              </div>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button
              variant="ghost"
              onClick={() => setShowCategories(!showCategories)}
              className="text-green-700 hover:bg-green-100 p-2"
              title="Filter by category"
            >
              <FilterIcon className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              onClick={getNextTip}
              className="text-green-700 hover:bg-green-100 p-2"
              title="Get new tip"
            >
              <RefreshCwIcon className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Tip Content */}
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <span className="text-2xl">{currentTip.icon}</span>
            <div className="flex-1">
              <h4 className="text-xl font-bold text-green-800 mb-2">{currentTip.title}</h4>
              <p className="text-green-700 leading-relaxed">{currentTip.content}</p>
            </div>
          </div>

          {/* Banker's Quote */}
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg">
            <p className="text-green-800 font-medium italic">
              "{currentTip.banker_quote}"
            </p>
            <p className="text-green-600 text-sm mt-1">— Your Trusted Digital Banker</p>
          </div>

          {/* Expandable Action Section */}
          <div className="border-t border-green-200 pt-4">
            <Button
              variant="ghost"
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-green-700 hover:bg-green-100 w-full justify-start"
            >
              <LightbulbIcon className="w-4 h-4 mr-2" />
              {isExpanded ? 'Hide' : 'Show'} Actionable Advice
            </Button>
            
            {isExpanded && (
              <div className="mt-4 p-4 bg-white border border-green-200 rounded-lg">
                <h5 className="font-bold text-green-800 mb-2">🎯 Take Action:</h5>
                <p className="text-green-700">{currentTip.actionable}</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-green-200 text-center">
          <p className="text-green-600 text-sm">
            Tip {tipIndex + 1} of {filteredTips.length} • {selectedCategory === 'all' ? 'All Categories' : selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} • Updates daily
          </p>
        </div>
        </CardContent>
      </Card>
    </div>
  );
}