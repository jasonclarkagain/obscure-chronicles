interface MonopolyBankerProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export function MonopolyBanker({ className = '', size = 'md' }: MonopolyBankerProps) {
  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24', 
    lg: 'w-32 h-32',
    xl: 'w-48 h-48'
  };

  return (
    <div className={`${sizeClasses[size]} ${className}`}>
      <svg
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        {/* Background Circle */}
        <circle cx="100" cy="100" r="90" fill="url(#bankerGradient)" stroke="#FCD34D" strokeWidth="4"/>
        
        {/* Hat */}
        <ellipse cx="100" cy="45" rx="35" ry="8" fill="#1F2937"/>
        <rect x="65" y="35" width="70" height="20" fill="#1F2937"/>
        <ellipse cx="100" cy="35" rx="35" ry="8" fill="#374151"/>
        
        {/* Face */}
        <circle cx="100" cy="100" r="35" fill="#FEF3C7"/>
        
        {/* Mustache */}
        <path d="M85 110 Q100 105 115 110" stroke="#1F2937" strokeWidth="4" fill="none" strokeLinecap="round"/>
        <path d="M80 108 Q95 103 110 108" stroke="#1F2937" strokeWidth="3" fill="none" strokeLinecap="round"/>
        
        {/* Eyes */}
        <circle cx="90" cy="90" r="3" fill="#1F2937"/>
        <circle cx="110" cy="90" r="3" fill="#1F2937"/>
        
        {/* Monocle */}
        <circle cx="110" cy="90" r="12" fill="none" stroke="#FCD34D" strokeWidth="3"/>
        <circle cx="110" cy="90" r="8" fill="rgba(255,255,255,0.3)"/>
        <path d="M122 90 Q130 85 135 80" stroke="#FCD34D" strokeWidth="2" fill="none"/>
        
        {/* Nose */}
        <ellipse cx="100" cy="95" rx="2" ry="4" fill="#F59E0B"/>
        
        {/* Suit */}
        <path d="M70 135 L70 180 Q70 190 80 190 L120 190 Q130 190 130 180 L130 135" fill="#1F2937"/>
        
        {/* Bow Tie */}
        <path d="M90 125 L110 125 L105 130 L110 135 L90 135 L95 130 Z" fill="#DC2626"/>
        
        {/* Collar */}
        <path d="M85 125 L100 135 L115 125" stroke="#FFFFFF" strokeWidth="3" fill="none"/>
        
        {/* Money symbols floating around */}
        <text x="40" y="60" fontSize="16" fill="#FCD34D" fontWeight="bold">$</text>
        <text x="160" y="70" fontSize="14" fill="#FCD34D" fontWeight="bold">£</text>
        <text x="50" y="150" fontSize="12" fill="#FCD34D" fontWeight="bold">€</text>
        <text x="150" y="140" fontSize="18" fill="#FCD34D" fontWeight="bold">¥</text>
        
        {/* Gradient Definitions */}
        <defs>
          <radialGradient id="bankerGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#059669" />
          </radialGradient>
        </defs>
      </svg>
    </div>
  );
}