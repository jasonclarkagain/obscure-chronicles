import { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface ThreeBackgroundProps {
  className?: string;
}

export function ThreeBackground({ className = '' }: ThreeBackgroundProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animationIdRef = useRef<number>();

  useEffect(() => {
    if (!mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0d2818); // Deep money green
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 5;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    rendererRef.current = renderer;
    mountRef.current.appendChild(renderer.domElement);

    // Create floating money particles
    const createMoneyParticles = () => {
      const particleCount = 50;
      const geometry = new THREE.BufferGeometry();
      const positions = new Float32Array(particleCount * 3);
      const velocities = new Float32Array(particleCount * 3);

      for (let i = 0; i < particleCount * 3; i += 3) {
        positions[i] = (Math.random() - 0.5) * 20;     // x
        positions[i + 1] = (Math.random() - 0.5) * 20; // y
        positions[i + 2] = (Math.random() - 0.5) * 20; // z
        
        velocities[i] = (Math.random() - 0.5) * 0.02;
        velocities[i + 1] = (Math.random() - 0.5) * 0.02;
        velocities[i + 2] = (Math.random() - 0.5) * 0.02;
      }

      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      geometry.userData = { velocities };

      const material = new THREE.PointsMaterial({
        color: 0x4ade80, // Bright green
        size: 0.1,
        transparent: true,
        opacity: 0.6,
      });

      return new THREE.Points(geometry, material);
    };

    // Create rotating coins
    const createCoins = () => {
      const coinGroup = new THREE.Group();
      
      for (let i = 0; i < 15; i++) {
        const geometry = new THREE.CylinderGeometry(0.2, 0.2, 0.02, 8);
        const material = new THREE.MeshPhongMaterial({ 
          color: 0xffd700, // Gold
          shininess: 100,
          transparent: true,
          opacity: 0.7
        });
        
        const coin = new THREE.Mesh(geometry, material);
        coin.position.set(
          (Math.random() - 0.5) * 15,
          (Math.random() - 0.5) * 15,
          (Math.random() - 0.5) * 15
        );
        coin.rotation.set(
          Math.random() * Math.PI,
          Math.random() * Math.PI,
          Math.random() * Math.PI
        );
        
        coinGroup.add(coin);
      }
      
      return coinGroup;
    };

    // Create banker's lamp glow
    const createBankersLamp = () => {
      const lampGroup = new THREE.Group();
      
      // Lamp base
      const baseGeometry = new THREE.CylinderGeometry(0.3, 0.5, 0.1, 8);
      const baseMaterial = new THREE.MeshPhongMaterial({ color: 0x8b4513 }); // Brown
      const base = new THREE.Mesh(baseGeometry, baseMaterial);
      base.position.y = -2;
      
      // Lamp shade (green)
      const shadeGeometry = new THREE.SphereGeometry(0.4, 8, 6, 0, Math.PI);
      const shadeMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2d5a3d, // Banker green
        transparent: true,
        opacity: 0.8
      });
      const shade = new THREE.Mesh(shadeGeometry, shadeMaterial);
      shade.position.y = -1.5;
      
      lampGroup.add(base, shade);
      lampGroup.position.set(-6, 2, -3);
      
      return lampGroup;
    };

    // Add lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.3);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0x22c55e, 0.8); // Green light
    directionalLight.position.set(-5, 5, 5);
    scene.add(directionalLight);

    // Point light for banker's lamp effect
    const pointLight = new THREE.PointLight(0x4ade80, 1, 10);
    pointLight.position.set(-6, 2, -3);
    scene.add(pointLight);

    // Add elements to scene
    const particles = createMoneyParticles();
    const coins = createCoins();
    const lamp = createBankersLamp();
    
    scene.add(particles);
    scene.add(coins);
    scene.add(lamp);

    // Animation loop
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);

      // Animate particles
      const positions = particles.geometry.attributes.position.array as Float32Array;
      const velocities = particles.geometry.userData.velocities as Float32Array;
      
      for (let i = 0; i < positions.length; i += 3) {
        positions[i] += velocities[i];
        positions[i + 1] += velocities[i + 1];
        positions[i + 2] += velocities[i + 2];
        
        // Reset particles that go too far
        if (Math.abs(positions[i]) > 10) velocities[i] *= -1;
        if (Math.abs(positions[i + 1]) > 10) velocities[i + 1] *= -1;
        if (Math.abs(positions[i + 2]) > 10) velocities[i + 2] *= -1;
      }
      particles.geometry.attributes.position.needsUpdate = true;

      // Rotate coins
      coins.children.forEach((coin, index) => {
        coin.rotation.x += 0.01 + index * 0.001;
        coin.rotation.y += 0.015 + index * 0.001;
      });

      // Pulse lamp light
      pointLight.intensity = 1 + Math.sin(Date.now() * 0.002) * 0.3;

      camera.position.x = Math.sin(Date.now() * 0.0005) * 0.5;
      camera.position.y = Math.cos(Date.now() * 0.0003) * 0.3;
      camera.lookAt(scene.position);

      renderer.render(scene, camera);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      if (!rendererRef.current) return;
      
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      rendererRef.current.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      
      if (mountRef.current && rendererRef.current) {
        mountRef.current.removeChild(rendererRef.current.domElement);
      }
      
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, []);

  return (
    <div 
      ref={mountRef} 
      className={`fixed inset-0 -z-10 ${className}`}
      style={{ pointerEvents: 'none', zIndex: -10 }}
    />
  );
}