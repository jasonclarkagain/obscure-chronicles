import { useState, useEffect, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { Badge } from '@/components/ui/badge';
import { 
  EyeIcon, 
  MicIcon, 
  VideoIcon, 
  TrendingUpIcon, 
  TrendingDownIcon,
  AlertTriangleIcon,
  CheckCircleIcon,
  XCircleIcon,
  CameraIcon,
  ScanIcon
} from 'lucide-react';

interface ARInsight {
  id: string;
  type: 'opportunity' | 'warning' | 'neutral' | 'positive';
  title: string;
  description: string;
  confidence: number;
  action: string;
  value?: string;
  trend?: 'up' | 'down' | 'stable';
}

interface MarketCondition {
  indicator: string;
  value: string;
  status: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  impact: string;
}

export function ARInvestmentAdvisor() {
  const [isARActive, setIsARActive] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [bankerMessage, setBankerMessage] = useState("Ready to provide investment guidance, esteemed client.");
  const [currentInsights, setCurrentInsights] = useState<ARInsight[]>([]);
  const [marketConditions, setMarketConditions] = useState<MarketCondition[]>([]);
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Simulated AR insights based on market analysis
  const generateARInsights = (): ARInsight[] => {
    const insights: ARInsight[] = [
      {
        id: '1',
        type: 'opportunity',
        title: 'DCA Opportunity Detected',
        description: 'Bitcoin showing 15% oversold condition - optimal for dollar cost averaging',
        confidence: 87,
        action: 'Consider increasing weekly DCA allocation',
        value: '$250-500',
        trend: 'down'
      },
      {
        id: '2',
        type: 'warning',
        title: 'High Volatility Alert',
        description: 'Ethereum showing unusual volume spikes - expect increased price swings',
        confidence: 92,
        action: 'Reduce position size or wait for stabilization',
        trend: 'up'
      },
      {
        id: '3',
        type: 'positive',
        title: 'Portfolio Diversification',
        description: 'Current allocation shows strong risk distribution across asset classes',
        confidence: 78,
        action: 'Maintain current strategy',
        value: '8.5/10 score'
      },
      {
        id: '4',
        type: 'neutral',
        title: 'Regulatory Sentiment',
        description: 'SEC clarity improving - institutional adoption likely to increase',
        confidence: 73,
        action: 'Monitor for entry opportunities in major assets',
        trend: 'stable'
      }
    ];

    return insights.slice(0, Math.floor(Math.random() * 3) + 2);
  };

  const generateMarketConditions = (): MarketCondition[] => {
    return [
      {
        indicator: 'Fear & Greed Index',
        value: '34 (Fear)',
        status: 'bullish',
        confidence: 82,
        impact: 'Contrarian buying opportunity'
      },
      {
        indicator: 'Bitcoin Dominance',
        value: '52.3%',
        status: 'neutral',
        confidence: 71,
        impact: 'Balanced altcoin season potential'
      },
      {
        indicator: 'Institutional Flow',
        value: '+$2.1B (7 days)',
        status: 'bullish',
        confidence: 89,
        impact: 'Strong institutional demand'
      },
      {
        indicator: 'Options Put/Call',
        value: '0.67',
        status: 'bearish',
        confidence: 65,
        impact: 'Short-term bearish sentiment'
      }
    ];
  };

  // Banker's AI responses based on market conditions
  const bankerResponses = [
    "Excellent timing, my astute investor. The market presents compelling opportunities.",
    "Prudent caution is advised - volatility suggests patience will be rewarded.",
    "Your portfolio positioning demonstrates remarkable financial acumen.",
    "The fundamentals remain strong despite temporary market turbulence.",
    "Institutional money flows indicate a strategic accumulation phase.",
    "Risk management protocols suggest reducing exposure in current conditions.",
    "Outstanding diversification strategy - you're positioned for multiple scenarios."
  ];

  const startARMode = async () => {
    setIsARActive(true);
    setCameraActive(true);
    setCurrentInsights(generateARInsights());
    setMarketConditions(generateMarketConditions());
    setBankerMessage(bankerResponses[Math.floor(Math.random() * bankerResponses.length)]);

    // Simulate camera access (in real implementation, would use getUserMedia)
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' },
          audio: false 
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }
    } catch (error) {
      console.log('Camera access not available in this environment');
      // Fallback to demonstration mode
    }
  };

  const stopARMode = () => {
    setIsARActive(false);
    setCameraActive(false);
    setIsListening(false);
    
    // Stop camera stream
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  const toggleVoiceCommand = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setBankerMessage("I'm listening for your investment questions...");
      // In real implementation, would start speech recognition
      setTimeout(() => {
        setBankerMessage("I understand you're asking about market timing. Based on current analysis...");
        setIsListening(false);
      }, 3000);
    }
  };

  const refreshInsights = () => {
    setCurrentInsights(generateARInsights());
    setMarketConditions(generateMarketConditions());
    setBankerMessage(bankerResponses[Math.floor(Math.random() * bankerResponses.length)]);
  };

  const getInsightIcon = (type: ARInsight['type']) => {
    switch (type) {
      case 'opportunity': return <TrendingUpIcon className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertTriangleIcon className="w-4 h-4 text-red-600" />;
      case 'positive': return <CheckCircleIcon className="w-4 h-4 text-blue-600" />;
      default: return <TrendingDownIcon className="w-4 h-4 text-gray-600" />;
    }
  };

  const getInsightColor = (type: ARInsight['type']) => {
    switch (type) {
      case 'opportunity': return 'border-green-300 bg-green-50';
      case 'warning': return 'border-red-300 bg-red-50';
      case 'positive': return 'border-blue-300 bg-blue-50';
      default: return 'border-gray-300 bg-gray-50';
    }
  };

  if (!isARActive) {
    return (
      <Card className="bg-gradient-to-br from-cyan-50 to-blue-100 border-2 border-cyan-200 shadow-xl">
        <CardContent className="p-6">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="relative">
                <MonopolyBanker size="xl" className="hover:animate-bounce" />
                <div className="absolute -top-2 -right-2 bg-cyan-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-xs font-bold animate-pulse">
                  AR
                </div>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-cyan-800 mb-2 font-serif">🚀 AR Investment Advisor</h3>
            <p className="text-cyan-700 mb-6">
              Activate augmented reality mode for real-time market analysis and personalized investment guidance
            </p>
          </div>

          {/* Features Preview */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white rounded-lg p-4 border border-cyan-200">
              <div className="flex items-center space-x-3 mb-3">
                <ScanIcon className="w-6 h-6 text-cyan-600" />
                <h4 className="font-bold text-cyan-800">Real-time Market Scanning</h4>
              </div>
              <p className="text-gray-700 text-sm">
                AI-powered analysis of market conditions with live opportunity detection and risk assessment
              </p>
            </div>

            <div className="bg-white rounded-lg p-4 border border-cyan-200">
              <div className="flex items-center space-x-3 mb-3">
                <MicIcon className="w-6 h-6 text-cyan-600" />
                <h4 className="font-bold text-cyan-800">Voice-Activated Guidance</h4>
              </div>
              <p className="text-gray-700 text-sm">
                Ask questions and receive personalized investment advice through natural conversation
              </p>
            </div>

            <div className="bg-white rounded-lg p-4 border border-cyan-200">
              <div className="flex items-center space-x-3 mb-3">
                <EyeIcon className="w-6 h-6 text-cyan-600" />
                <h4 className="font-bold text-cyan-800">Contextual Insights</h4>
              </div>
              <p className="text-gray-700 text-sm">
                Overlay investment opportunities and market analysis directly in your field of view
              </p>
            </div>

            <div className="bg-white rounded-lg p-4 border border-cyan-200">
              <div className="flex items-center space-x-3 mb-3">
                <TrendingUpIcon className="w-6 h-6 text-cyan-600" />
                <h4 className="font-bold text-cyan-800">Portfolio Optimization</h4>
              </div>
              <p className="text-gray-700 text-sm">
                Real-time portfolio analysis with actionable recommendations for optimization
              </p>
            </div>
          </div>

          {/* Activation Button */}
          <div className="text-center">
            <Button
              onClick={startARMode}
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white text-lg px-8 py-3 rounded-lg font-bold shadow-lg"
            >
              <CameraIcon className="w-5 h-5 mr-2" />
              Activate AR Investment Advisor
            </Button>
            <p className="text-xs text-cyan-600 mt-2">
              Requires camera access for optimal AR experience
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="relative">
      {/* AR Camera View */}
      <div className="relative bg-black rounded-lg overflow-hidden" style={{ height: '500px' }}>
        {cameraActive ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            <div className="text-center text-white">
              <CameraIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">AR Camera View</p>
              <p className="text-sm opacity-75">Demo Mode Active</p>
            </div>
          </div>
        )}

        {/* AR Overlay Elements */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Banker Avatar (Floating) */}
          <div className="absolute top-4 right-4 pointer-events-auto">
            <div className="bg-white bg-opacity-90 rounded-full p-3 shadow-lg border-2 border-cyan-300">
              <MonopolyBanker size="md" className={isListening ? 'animate-pulse' : ''} />
            </div>
          </div>

          {/* Banker's Speech Bubble */}
          <div className="absolute top-20 right-4 max-w-xs pointer-events-auto">
            <div className="bg-white bg-opacity-95 rounded-lg p-4 shadow-lg border border-cyan-200">
              <p className="text-sm text-cyan-800 font-medium">{bankerMessage}</p>
              <div className="absolute -top-2 right-8 w-4 h-4 bg-white transform rotate-45 border-l border-t border-cyan-200"></div>
            </div>
          </div>

          {/* Market Insights Overlay */}
          <div className="absolute left-4 top-4 space-y-2 pointer-events-auto max-w-sm">
            {currentInsights.map((insight, index) => (
              <div
                key={insight.id}
                className={`border-2 rounded-lg p-3 bg-white bg-opacity-90 ${getInsightColor(insight.type)} animate-fade-in`}
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="flex items-start space-x-2">
                  {getInsightIcon(insight.type)}
                  <div className="flex-1">
                    <h5 className="font-bold text-xs text-gray-800">{insight.title}</h5>
                    <p className="text-xs text-gray-600 mt-1">{insight.description}</p>
                    <div className="flex justify-between items-center mt-2">
                      <Badge variant="secondary" className="text-xs">
                        {insight.confidence}% confidence
                      </Badge>
                      {insight.value && (
                        <span className="text-xs font-bold text-cyan-700">{insight.value}</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Market Conditions Sidebar */}
          <div className="absolute right-4 bottom-20 space-y-2 pointer-events-auto max-w-xs">
            <div className="bg-white bg-opacity-90 rounded-lg p-3 border border-cyan-200">
              <h5 className="font-bold text-sm text-cyan-800 mb-2">Live Market Conditions</h5>
              {marketConditions.slice(0, 2).map((condition, index) => (
                <div key={index} className="flex justify-between items-center mb-1">
                  <span className="text-xs text-gray-700">{condition.indicator}</span>
                  <div className="flex items-center space-x-1">
                    <span className="text-xs font-bold">{condition.value}</span>
                    <div className={`w-2 h-2 rounded-full ${
                      condition.status === 'bullish' ? 'bg-green-500' :
                      condition.status === 'bearish' ? 'bg-red-500' : 'bg-yellow-500'
                    }`}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* AR Controls */}
      <div className="flex justify-center space-x-4 mt-4">
        <Button
          onClick={toggleVoiceCommand}
          className={`${isListening ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'} text-white`}
        >
          <MicIcon className="w-4 h-4 mr-2" />
          {isListening ? 'Stop Listening' : 'Voice Command'}
        </Button>

        <Button
          onClick={refreshInsights}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <ScanIcon className="w-4 h-4 mr-2" />
          Refresh Analysis
        </Button>

        <Button
          onClick={stopARMode}
          variant="outline"
          className="border-red-300 text-red-600 hover:bg-red-50"
        >
          <XCircleIcon className="w-4 h-4 mr-2" />
          Exit AR Mode
        </Button>
      </div>

      {/* Current Analysis Summary */}
      <Card className="mt-6 bg-gradient-to-r from-cyan-50 to-blue-50 border-cyan-200">
        <CardContent className="p-4">
          <h4 className="font-bold text-cyan-800 mb-3">Current Analysis Summary</h4>
          <div className="grid md:grid-cols-4 gap-4 text-center">
            {marketConditions.map((condition, index) => (
              <div key={index} className="bg-white rounded p-3 border border-cyan-200">
                <div className="text-xs text-gray-600">{condition.indicator}</div>
                <div className="font-bold text-sm text-cyan-800">{condition.value}</div>
                <div className="text-xs text-gray-500">{condition.impact}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}