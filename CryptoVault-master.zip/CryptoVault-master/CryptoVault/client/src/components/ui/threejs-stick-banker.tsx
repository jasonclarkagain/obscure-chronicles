import React, { useRef, useEffect, useState } from 'react';

interface ThreeJSStickBankerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export function ThreeJSStickBanker({ size = 'md', className = '' }: ThreeJSStickBankerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const [isWinking, setIsWinking] = useState(false);
  const [headDirection, setHeadDirection] = useState(0);
  const [walkCycle, setWalkCycle] = useState(0);

  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-20 h-20',
    lg: 'w-24 h-24',
    xl: 'w-32 h-32'
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const canvasSize = size === 'sm' ? 64 : size === 'md' ? 80 : size === 'lg' ? 96 : 128;
    canvas.width = canvasSize;
    canvas.height = canvasSize;
    
    let time = 0;

    const drawBanker = () => {
      ctx.clearRect(0, 0, canvasSize, canvasSize);
      
      // Background glow
      const gradient = ctx.createRadialGradient(canvasSize/2, canvasSize/2, 0, canvasSize/2, canvasSize/2, canvasSize/2);
      gradient.addColorStop(0, 'rgba(251, 191, 36, 0.1)');
      gradient.addColorStop(1, 'rgba(16, 185, 129, 0.05)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvasSize, canvasSize);
      
      const centerX = canvasSize / 2;
      const centerY = canvasSize / 2;
      const scale = canvasSize / 100;
      
      // Walking offset
      const walkOffset = Math.sin(time * 4) * 3 * scale;
      const stepBob = Math.abs(Math.sin(time * 4)) * 2 * scale;
      
      ctx.save();
      ctx.translate(centerX + walkOffset, centerY - stepBob);
      ctx.scale(scale, scale);
      
      // Top Hat
      ctx.fillStyle = '#1f2937';
      ctx.fillRect(-8, -35, 16, 15);
      ctx.beginPath();
      ctx.ellipse(0, -20, 12, 3, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Head with turn animation
      const headTurn = Math.sin(time * 0.8) * 0.3 + headDirection;
      ctx.save();
      ctx.rotate(headTurn);
      
      // Head circle
      ctx.strokeStyle = '#1f2937';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, -20, 8, 0, Math.PI * 2);
      ctx.stroke();
      
      // Big Monocle with glow
      ctx.save();
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 10;
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(-5, -20, 6, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      
      // Monocle lens with reflection
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.beginPath();
      ctx.arc(-5, -20, 5, 0, Math.PI * 2);
      ctx.fill();
      
      // Lens reflection
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.beginPath();
      ctx.arc(-3, -22, 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Monocle chain
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-11, -20);
      ctx.quadraticCurveTo(-15, -15, -18, -10);
      ctx.stroke();
      
      // Eyes (winking animation)
      if (isWinking) {
        // Winking left eye
        ctx.strokeStyle = '#1f2937';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-8, -22);
        ctx.lineTo(-2, -22);
        ctx.stroke();
        // Normal right eye
        ctx.fillStyle = '#1f2937';
        ctx.beginPath();
        ctx.arc(5, -20, 1.5, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Normal eyes
        ctx.fillStyle = '#1f2937';
        ctx.beginPath();
        ctx.arc(-5, -20, 1, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(5, -20, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
      
      // Elaborate mustache
      ctx.strokeStyle = '#1f2937';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-8, -15);
      ctx.quadraticCurveTo(0, -18, 8, -15);
      ctx.stroke();
      
      // Mustache curls
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-8, -15);
      ctx.quadraticCurveTo(-10, -12, -8, -10);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(8, -15);
      ctx.quadraticCurveTo(10, -12, 8, -10);
      ctx.stroke();
      
      ctx.restore(); // End head rotation
      
      // Body (stick)
      ctx.strokeStyle = '#1f2937';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, -10);
      ctx.lineTo(0, 15);
      ctx.stroke();
      
      // Arms with money bags
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, -5);
      ctx.lineTo(-12, 0);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, -5);
      ctx.lineTo(12, 0);
      ctx.stroke();
      
      // Money bags (bouncing)
      const bagBounce = Math.sin(time * 6) * 1;
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(-15, 2 + bagBounce, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(15, 2 - bagBounce, 3, 0, Math.PI * 2);
      ctx.fill();
      
      // $ symbols on bags
      ctx.fillStyle = '#fbbf24';
      ctx.font = '4px bold monospace';
      ctx.textAlign = 'center';
      ctx.fillText('$', -15, 4 + bagBounce);
      ctx.fillText('₿', 15, 4 - bagBounce);
      
      // Bow tie
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.moveTo(-4, -8);
      ctx.lineTo(0, -10);
      ctx.lineTo(4, -8);
      ctx.lineTo(0, -6);
      ctx.closePath();
      ctx.fill();
      
      // Collar
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-6, -8);
      ctx.lineTo(0, -6);
      ctx.lineTo(6, -8);
      ctx.stroke();
      
      // Legs with walking animation
      const legAngle = Math.sin(time * 4) * 0.3;
      ctx.strokeStyle = '#1f2937';
      ctx.lineWidth = 2;
      
      ctx.save();
      ctx.translate(-3, 15);
      ctx.rotate(-legAngle);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, 15);
      ctx.stroke();
      ctx.restore();
      
      ctx.save();
      ctx.translate(3, 15);
      ctx.rotate(legAngle);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, 15);
      ctx.stroke();
      ctx.restore();
      
      // Feet
      ctx.fillStyle = '#1f2937';
      ctx.fillRect(-6, 28, 4, 2);
      ctx.fillRect(2, 28, 4, 2);
      
      ctx.restore();
      
      // Floating money symbols
      ctx.font = `${6 * scale}px monospace`;
      ctx.fillStyle = 'rgba(251, 191, 36, 0.7)';
      ctx.fillText('💰', 10 * scale, 20 * scale + Math.sin(time * 2) * 5);
      ctx.fillText('💵', (canvasSize - 20) * scale, 30 * scale + Math.sin(time * 2.5) * 5);
      ctx.fillText('🪙', 15 * scale, (canvasSize - 20) * scale + Math.sin(time * 3) * 5);
    };

    const animate = () => {
      time += 0.016; // ~60fps
      drawBanker();
      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    // Random animations
    const animationInterval = setInterval(() => {
      if (Math.random() < 0.3) {
        setIsWinking(true);
        setTimeout(() => setIsWinking(false), 300);
      }
      if (Math.random() < 0.2) {
        setHeadDirection((Math.random() - 0.5) * 0.5);
      }
    }, 2000);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      clearInterval(animationInterval);
    };
  }, [size, isWinking, headDirection]);

  return (
    <div className={`${sizeClasses[size]} ${className} relative overflow-hidden rounded-lg`}>
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  );
}