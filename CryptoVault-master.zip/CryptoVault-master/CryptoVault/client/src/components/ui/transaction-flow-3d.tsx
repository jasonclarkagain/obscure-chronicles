import { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { 
  PlayIcon, 
  PauseIcon, 
  RotateCcwIcon,
  ZoomInIcon,
  ZoomOutIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  DollarSignIcon,
  TrendingUpIcon,
  FilterIcon
} from 'lucide-react';
import { type CryptoWallet } from '@/lib/crypto';

interface Transaction {
  id: string;
  fromWallet: string;
  toWallet: string;
  amount: number;
  currency: string;
  timestamp: Date;
  type: 'incoming' | 'outgoing' | 'internal';
  status: 'completed' | 'pending' | 'failed';
  fee: number;
  hash: string;
}

interface FlowParticle {
  id: string;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  progress: number;
  speed: number;
  size: number;
  color: string;
  transaction: Transaction;
  trail: { x: number; y: number; opacity: number }[];
}

interface WalletNode {
  id: string;
  name: string;
  symbol: string;
  x: number;
  y: number;
  radius: number;
  color: string;
  balance: number;
  pulsePhase: number;
  connections: number;
}

interface TransactionFlow3DProps {
  wallets: CryptoWallet[];
}

export function TransactionFlow3D({ wallets }: TransactionFlow3DProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const [isAnimating, setIsAnimating] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'incoming' | 'outgoing' | 'internal'>('all');
  const [particles, setParticles] = useState<FlowParticle[]>([]);
  const [walletNodes, setWalletNodes] = useState<WalletNode[]>([]);

  // Generate realistic transaction data
  const generateTransactions = (): Transaction[] => {
    const transactions: Transaction[] = [];
    const walletSymbols = wallets.map(w => w.symbol);
    const transactionTypes = ['incoming', 'outgoing', 'internal'] as const;
    const statuses = ['completed', 'pending', 'failed'] as const;

    for (let i = 0; i < 25; i++) {
      const fromWallet = walletSymbols[Math.floor(Math.random() * walletSymbols.length)];
      const toWallet = walletSymbols[Math.floor(Math.random() * walletSymbols.length)];
      const type = transactionTypes[Math.floor(Math.random() * transactionTypes.length)];
      const status = statuses[Math.floor(Math.random() * statuses.length)];
      
      transactions.push({
        id: `tx_${i}`,
        fromWallet,
        toWallet,
        amount: Math.random() * 5 + 0.001,
        currency: fromWallet,
        timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
        type,
        status,
        fee: Math.random() * 0.01,
        hash: `0x${Array.from({length: 64}, () => '0123456789abcdef'[Math.floor(Math.random() * 16)]).join('')}`
      });
    }

    return transactions.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  };

  const [transactions] = useState<Transaction[]>(generateTransactions());

  // Initialize wallet nodes in a circular pattern
  const initializeWalletNodes = () => {
    const nodes: WalletNode[] = [];
    const centerX = 400;
    const centerY = 200;
    const radius = 150;

    wallets.forEach((wallet, index) => {
      const angle = (index / wallets.length) * 2 * Math.PI;
      const x = centerX + Math.cos(angle) * radius;
      const y = centerY + Math.sin(angle) * radius;
      
      nodes.push({
        id: wallet.symbol,
        name: wallet.name,
        symbol: wallet.symbol,
        x,
        y,
        radius: 25 + (parseFloat(wallet.usdValue.replace('$', '').replace(',', '')) / 1000) * 10,
        color: wallet.color,
        balance: parseFloat(wallet.usdValue.replace('$', '').replace(',', '')),
        pulsePhase: Math.random() * Math.PI * 2,
        connections: transactions.filter(t => t.fromWallet === wallet.symbol || t.toWallet === wallet.symbol).length
      });
    });

    setWalletNodes(nodes);
  };

  // Create flow particles for transactions
  const createFlowParticles = () => {
    const newParticles: FlowParticle[] = [];
    const filteredTransactions = transactions.filter(t => {
      if (filterType === 'all') return true;
      return t.type === filterType;
    }).slice(0, 15); // Limit for performance

    filteredTransactions.forEach((transaction, index) => {
      const fromNode = walletNodes.find(n => n.id === transaction.fromWallet);
      const toNode = walletNodes.find(n => n.id === transaction.toWallet);
      
      if (fromNode && toNode && fromNode.id !== toNode.id) {
        const particleColor = transaction.status === 'completed' ? '#10B981' : 
                             transaction.status === 'pending' ? '#F59E0B' : '#EF4444';
        
        newParticles.push({
          id: `particle_${transaction.id}`,
          x: fromNode.x,
          y: fromNode.y,
          targetX: toNode.x,
          targetY: toNode.y,
          progress: (index * 0.1) % 1, // Stagger the animations
          speed: 0.005 + Math.random() * 0.01,
          size: 3 + (transaction.amount * 2),
          color: particleColor,
          transaction,
          trail: []
        });
      }
    });

    setParticles(newParticles);
  };

  // Draw the 3D transaction flow visualization
  const drawVisualization = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Clear canvas with gradient background
    const gradient = ctx.createRadialGradient(width/2, height/2, 0, width/2, height/2, Math.max(width, height));
    gradient.addColorStop(0, '#0F172A');
    gradient.addColorStop(1, '#1E293B');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Draw connection lines between active wallets
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.1)';
    ctx.lineWidth = 1;
    
    particles.forEach(particle => {
      const fromNode = walletNodes.find(n => n.id === particle.transaction.fromWallet);
      const toNode = walletNodes.find(n => n.id === particle.transaction.toWallet);
      
      if (fromNode && toNode) {
        ctx.beginPath();
        ctx.moveTo(fromNode.x * zoom, fromNode.y * zoom);
        ctx.lineTo(toNode.x * zoom, toNode.y * zoom);
        ctx.stroke();
      }
    });

    // Draw wallet nodes with 3D effect
    walletNodes.forEach(node => {
      const x = node.x * zoom;
      const y = node.y * zoom;
      const radius = node.radius * zoom;
      
      // Node shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
      ctx.beginPath();
      ctx.arc(x + 3, y + 3, radius, 0, 2 * Math.PI);
      ctx.fill();
      
      // Node gradient
      const nodeGradient = ctx.createRadialGradient(x - radius/3, y - radius/3, 0, x, y, radius);
      nodeGradient.addColorStop(0, node.color);
      nodeGradient.addColorStop(1, node.color + '80');
      
      ctx.fillStyle = nodeGradient;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, 2 * Math.PI);
      ctx.fill();
      
      // Node border with pulse effect
      const pulseIntensity = Math.sin(node.pulsePhase + Date.now() * 0.003) * 0.5 + 0.5;
      ctx.strokeStyle = `rgba(255, 255, 255, ${0.3 + pulseIntensity * 0.4})`;
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Currency symbol
      ctx.fillStyle = 'white';
      ctx.font = `bold ${Math.max(8, radius * 0.4)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(node.symbol, x, y);
      
      // Connection count indicator
      if (node.connections > 0) {
        ctx.fillStyle = '#F59E0B';
        ctx.beginPath();
        ctx.arc(x + radius * 0.7, y - radius * 0.7, 6, 0, 2 * Math.PI);
        ctx.fill();
        
        ctx.fillStyle = 'white';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText(node.connections.toString(), x + radius * 0.7, y - radius * 0.7);
      }
    });

    // Draw flow particles with trails
    particles.forEach(particle => {
      // Update particle trail
      particle.trail.push({ x: particle.x, y: particle.y, opacity: 1 });
      if (particle.trail.length > 10) {
        particle.trail.shift();
      }
      
      // Draw trail
      particle.trail.forEach((point, index) => {
        const trailOpacity = (index / particle.trail.length) * 0.5;
        const trailSize = particle.size * (index / particle.trail.length);
        
        ctx.fillStyle = particle.color.replace(')', `, ${trailOpacity})`).replace('rgb', 'rgba');
        ctx.beginPath();
        ctx.arc(point.x * zoom, point.y * zoom, trailSize * zoom, 0, 2 * Math.PI);
        ctx.fill();
      });
      
      // Draw main particle with glow effect
      const x = particle.x * zoom;
      const y = particle.y * zoom;
      const size = particle.size * zoom;
      
      // Glow effect
      const glowGradient = ctx.createRadialGradient(x, y, 0, x, y, size * 3);
      glowGradient.addColorStop(0, particle.color + '80');
      glowGradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = glowGradient;
      ctx.beginPath();
      ctx.arc(x, y, size * 3, 0, 2 * Math.PI);
      ctx.fill();
      
      // Main particle
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(x, y, size, 0, 2 * Math.PI);
      ctx.fill();
      
      // Particle highlight
      ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.beginPath();
      ctx.arc(x - size/3, y - size/3, size/3, 0, 2 * Math.PI);
      ctx.fill();
    });
  };

  // Animation loop
  const animate = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    drawVisualization(ctx, canvas.width, canvas.height);
    
    if (isAnimating) {
      // Update particle positions
      setParticles(prevParticles => 
        prevParticles.map(particle => {
          const newProgress = particle.progress + particle.speed;
          
          if (newProgress >= 1) {
            // Reset particle to start position
            const fromNode = walletNodes.find(n => n.id === particle.transaction.fromWallet);
            return fromNode ? {
              ...particle,
              x: fromNode.x,
              y: fromNode.y,
              progress: 0,
              trail: []
            } : particle;
          } else {
            // Interpolate position along bezier curve for smooth animation
            const t = newProgress;
            const fromNode = walletNodes.find(n => n.id === particle.transaction.fromWallet);
            const toNode = walletNodes.find(n => n.id === particle.transaction.toWallet);
            
            if (fromNode && toNode) {
              // Create curved path
              const midX = (fromNode.x + toNode.x) / 2 + Math.sin(t * Math.PI) * 30;
              const midY = (fromNode.y + toNode.y) / 2 + Math.cos(t * Math.PI) * 20;
              
              const x = (1 - t) * (1 - t) * fromNode.x + 2 * (1 - t) * t * midX + t * t * toNode.x;
              const y = (1 - t) * (1 - t) * fromNode.y + 2 * (1 - t) * t * midY + t * t * toNode.y;
              
              return { ...particle, x, y, progress: newProgress };
            }
          }
          
          return particle;
        })
      );
      
      // Update wallet node pulse phases
      setWalletNodes(prevNodes =>
        prevNodes.map(node => ({
          ...node,
          pulsePhase: node.pulsePhase + 0.02
        }))
      );
    }
    
    animationFrameRef.current = requestAnimationFrame(animate);
  };

  // Handle canvas click for transaction selection
  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = (event.clientX - rect.left) / zoom;
    const clickY = (event.clientY - rect.top) / zoom;

    // Check if click is near any particle
    const clickedParticle = particles.find(particle => {
      const distance = Math.sqrt((clickX - particle.x) ** 2 + (clickY - particle.y) ** 2);
      return distance < particle.size + 10;
    });

    if (clickedParticle) {
      setSelectedTransaction(clickedParticle.transaction);
    } else {
      setSelectedTransaction(null);
    }
  };

  // Initialize component
  useEffect(() => {
    initializeWalletNodes();
  }, [wallets]);

  useEffect(() => {
    if (walletNodes.length > 0) {
      createFlowParticles();
    }
  }, [walletNodes, filterType]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };

    resizeCanvas();
    animate();
    
    window.addEventListener('resize', resizeCanvas);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isAnimating, particles, walletNodes, zoom]);

  const getTransactionStats = () => {
    const completed = transactions.filter(t => t.status === 'completed').length;
    const pending = transactions.filter(t => t.status === 'pending').length;
    const totalVolume = transactions.reduce((sum, t) => sum + t.amount, 0);
    
    return { completed, pending, totalVolume };
  };

  const stats = getTransactionStats();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <MonopolyBanker size="md" />
          <div>
            <h2 className="text-2xl font-bold text-green-800 font-serif">3D Transaction Flow Visualization</h2>
            <p className="text-green-600">Real-time animated transaction flows between your wallets</p>
          </div>
        </div>
      </div>

      {/* Controls */}
      <Card className="border-2 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                onClick={() => setIsAnimating(!isAnimating)}
                className="border-green-300 text-green-700 hover:bg-green-50"
              >
                {isAnimating ? <PauseIcon className="w-4 h-4 mr-2" /> : <PlayIcon className="w-4 h-4 mr-2" />}
                {isAnimating ? 'Pause' : 'Play'}
              </Button>
              
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedTransaction(null);
                  createFlowParticles();
                }}
                className="border-green-300 text-green-700 hover:bg-green-50"
              >
                <RotateCcwIcon className="w-4 h-4 mr-2" />
                Reset
              </Button>
              
              <div className="flex items-center space-x-2">
                <FilterIcon className="w-4 h-4 text-green-700" />
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value as any)}
                  className="border border-green-300 rounded px-2 py-1 text-sm text-green-700"
                >
                  <option value="all">All Transactions</option>
                  <option value="incoming">Incoming</option>
                  <option value="outgoing">Outgoing</option>
                  <option value="internal">Internal</option>
                </select>
              </div>
            </div>
            
            <div className="flex items-center space-x-1">
              <Button
                variant="outline"
                onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}
                className="border-green-300 text-green-700 hover:bg-green-50 p-2"
              >
                <ZoomOutIcon className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                onClick={() => setZoom(Math.min(2, zoom + 0.1))}
                className="border-green-300 text-green-700 hover:bg-green-50 p-2"
              >
                <ZoomInIcon className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Visualization and Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 3D Visualization */}
        <div className="lg:col-span-2">
          <Card className="border-2 border-green-200">
            <CardContent className="p-0">
              <canvas
                ref={canvasRef}
                onClick={handleCanvasClick}
                className="w-full h-96 cursor-pointer rounded-lg"
                style={{ background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)' }}
              />
            </CardContent>
          </Card>
        </div>

        {/* Statistics and Transaction Details */}
        <div className="space-y-4">
          {/* Flow Statistics */}
          <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
            <CardContent className="p-4">
              <h3 className="font-bold text-green-800 font-serif mb-3">Flow Statistics</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-green-700">Total Transactions:</span>
                  <Badge className="bg-green-100 text-green-800">{transactions.length}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-green-700">Completed:</span>
                  <Badge className="bg-emerald-100 text-emerald-800">{stats.completed}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-green-700">Pending:</span>
                  <Badge className="bg-yellow-100 text-yellow-800">{stats.pending}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-green-700">Total Volume:</span>
                  <span className="font-bold text-green-800">{stats.totalVolume.toFixed(4)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Legend */}
          <Card className="border-2 border-green-200">
            <CardContent className="p-4">
              <h3 className="font-bold text-green-800 font-serif mb-3">Legend</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-green-700">Completed</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span className="text-green-700">Pending</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-green-700">Failed</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-green-200">
                <p className="text-xs text-green-600">• Particle size represents transaction amount</p>
                <p className="text-xs text-green-600">• Node size represents wallet balance</p>
                <p className="text-xs text-green-600">• Click particles for transaction details</p>
              </div>
            </CardContent>
          </Card>

          {/* Selected Transaction */}
          {selectedTransaction && (
            <Card className="border-2 border-blue-400 bg-gradient-to-br from-blue-50 to-indigo-50">
              <CardContent className="p-4">
                <h3 className="font-bold text-blue-800 font-serif mb-3">Transaction Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-blue-700">From:</span>
                    <Badge className="bg-blue-100 text-blue-800">{selectedTransaction.fromWallet}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">To:</span>
                    <Badge className="bg-blue-100 text-blue-800">{selectedTransaction.toWallet}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">Amount:</span>
                    <span className="font-bold text-blue-800">{selectedTransaction.amount.toFixed(6)} {selectedTransaction.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">Status:</span>
                    <Badge className={
                      selectedTransaction.status === 'completed' ? 'bg-green-100 text-green-800' :
                      selectedTransaction.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }>
                      {selectedTransaction.status.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">Fee:</span>
                    <span className="text-blue-800">{selectedTransaction.fee.toFixed(6)}</span>
                  </div>
                  <div className="mt-3 pt-3 border-t border-blue-200">
                    <span className="text-xs text-blue-600">Hash:</span>
                    <code className="text-xs text-blue-700 block font-mono mt-1 break-all">
                      {selectedTransaction.hash.slice(0, 20)}...
                    </code>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Instructions */}
      <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
        <CardContent className="p-4">
          <h3 className="font-bold text-green-800 font-serif mb-2">How to Use</h3>
          <div className="text-sm text-green-700 space-y-1">
            <p>• Watch animated particles flow between your wallet nodes representing transactions</p>
            <p>• Click on any flowing particle to view detailed transaction information</p>
            <p>• Use filters to focus on specific transaction types (incoming/outgoing/internal)</p>
            <p>• Zoom in/out to adjust the view and pause/resume animations as needed</p>
            <p>• Node sizes represent wallet balances, particle sizes represent transaction amounts</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}