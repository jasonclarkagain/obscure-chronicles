import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { type CryptoWallet } from '@/lib/crypto';
import { ChevronLeftIcon, ChevronRightIcon, CopyIcon, ArrowUpIcon, ArrowDownIcon, EyeIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface WalletNavigation3DProps {
  wallets: CryptoWallet[];
  onWalletSelect?: (wallet: CryptoWallet) => void;
}

interface WalletCard3D {
  wallet: CryptoWallet;
  x: number;
  y: number;
  z: number;
  rotationY: number;
  scale: number;
  opacity: number;
  isActive: boolean;
}

export function WalletNavigation3D({ wallets, onWalletSelect }: WalletNavigation3DProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [walletCards, setWalletCards] = useState<WalletCard3D[]>([]);
  const [selectedWallet, setSelectedWallet] = useState<CryptoWallet | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const { toast } = useToast();

  // 3D positioning parameters
  const centerX = 400;
  const centerY = 200;
  const cardWidth = 300;
  const cardHeight = 180;
  const spacing = 350;
  const perspective = 800;

  // Initialize wallet cards with 3D positions
  const initializeWalletCards = useCallback(() => {
    const cards: WalletCard3D[] = wallets.map((wallet, index) => {
      const offset = index - currentIndex;
      const x = centerX + (offset * spacing);
      const z = Math.abs(offset) * -100;
      const rotationY = offset * 15;
      const scale = 1 - (Math.abs(offset) * 0.15);
      const opacity = Math.max(0.3, 1 - (Math.abs(offset) * 0.2));
      
      return {
        wallet,
        x,
        y: centerY,
        z,
        rotationY,
        scale: Math.max(0.5, scale),
        opacity,
        isActive: index === currentIndex
      };
    });
    
    setWalletCards(cards);
  }, [wallets, currentIndex]);

  // Draw 3D wallet card
  const drawWalletCard = (ctx: CanvasRenderingContext2D, card: WalletCard3D) => {
    const { wallet, x, y, z, rotationY, scale, opacity, isActive } = card;
    
    ctx.save();
    
    // Apply 3D transformations
    const perspectiveScale = perspective / (perspective - z);
    const finalScale = scale * perspectiveScale;
    
    ctx.globalAlpha = opacity;
    ctx.translate(x, y);
    ctx.scale(finalScale, finalScale);
    
    // Apply rotation
    const skewX = Math.sin(rotationY * Math.PI / 180) * 0.3;
    ctx.transform(1, 0, skewX, 1, 0, 0);
    
    // Draw card background with banking theme
    const gradient = ctx.createLinearGradient(-cardWidth/2, -cardHeight/2, cardWidth/2, cardHeight/2);
    if (isActive) {
      gradient.addColorStop(0, '#10b981');
      gradient.addColorStop(1, '#047857');
    } else {
      gradient.addColorStop(0, '#f0fdf4');
      gradient.addColorStop(1, '#dcfce7');
    }
    
    // Card background
    ctx.fillStyle = gradient;
    ctx.fillRect(-cardWidth/2, -cardHeight/2, cardWidth, cardHeight);
    
    // Card border
    ctx.strokeStyle = isActive ? '#fbbf24' : '#10b981';
    ctx.lineWidth = isActive ? 4 : 2;
    ctx.strokeRect(-cardWidth/2, -cardHeight/2, cardWidth, cardHeight);
    
    // Wallet icon background
    const iconSize = 60;
    const iconBg = ctx.createRadialGradient(0, -40, 0, 0, -40, iconSize/2);
    iconBg.addColorStop(0, wallet.color.includes('orange') ? '#f97316' : 
                           wallet.color.includes('blue') ? '#3b82f6' :
                           wallet.color.includes('gray') ? '#6b7280' :
                           wallet.color.includes('green') ? '#10b981' :
                           wallet.color.includes('purple') ? '#8b5cf6' : '#6b7280');
    iconBg.addColorStop(1, wallet.color.includes('orange') ? '#ea580c' : 
                           wallet.color.includes('blue') ? '#2563eb' :
                           wallet.color.includes('gray') ? '#4b5563' :
                           wallet.color.includes('green') ? '#047857' :
                           wallet.color.includes('purple') ? '#7c3aed' : '#4b5563');
    
    ctx.fillStyle = iconBg;
    ctx.beginPath();
    ctx.arc(0, -40, iconSize/2, 0, Math.PI * 2);
    ctx.fill();
    
    // Wallet icon
    ctx.fillStyle = 'white';
    ctx.font = 'bold 32px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(wallet.icon, 0, -40);
    
    // Wallet name
    ctx.fillStyle = isActive ? 'white' : '#065f46';
    ctx.font = 'bold 18px serif';
    ctx.fillText(wallet.name, 0, 10);
    
    // Balance
    ctx.font = 'bold 16px monospace';
    ctx.fillText(`${wallet.balance} ${wallet.symbol}`, 0, 35);
    
    // USD value
    ctx.font = '14px sans-serif';
    ctx.fillText(wallet.usdValue, 0, 55);
    
    // Active indicator
    if (isActive) {
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(0, cardHeight/2 - 20, 8, 0, Math.PI * 2);
      ctx.fill();
      
      // Glow effect
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 20;
      ctx.fill();
    }
    
    ctx.restore();
  };

  // Animation loop
  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw background gradient
    const bgGradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bgGradient.addColorStop(0, '#0f172a');
    bgGradient.addColorStop(1, '#1e293b');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw perspective grid
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvas.width; i += 50) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + (canvas.height * 0.3), canvas.height);
      ctx.stroke();
    }
    
    // Draw wallet cards (back to front)
    const sortedCards = [...walletCards].sort((a, b) => a.z - b.z);
    sortedCards.forEach(card => drawWalletCard(ctx, card));
    
    animationFrameRef.current = requestAnimationFrame(animate);
  }, [walletCards]);

  // Navigation functions
  const navigateLeft = () => {
    if (isAnimating || currentIndex <= 0) return;
    setIsAnimating(true);
    setCurrentIndex(prev => prev - 1);
    setTimeout(() => setIsAnimating(false), 500);
  };

  const navigateRight = () => {
    if (isAnimating || currentIndex >= wallets.length - 1) return;
    setIsAnimating(true);
    setCurrentIndex(prev => prev + 1);
    setTimeout(() => setIsAnimating(false), 500);
  };

  const selectWallet = (wallet: CryptoWallet) => {
    setSelectedWallet(wallet);
    setShowDetails(true);
    onWalletSelect?.(wallet);
  };

  // Canvas click handler
  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    // Check if click is on the active card
    const activeCard = walletCards.find(card => card.isActive);
    if (activeCard) {
      const cardBounds = {
        left: activeCard.x - (cardWidth * activeCard.scale) / 2,
        right: activeCard.x + (cardWidth * activeCard.scale) / 2,
        top: activeCard.y - (cardHeight * activeCard.scale) / 2,
        bottom: activeCard.y + (cardHeight * activeCard.scale) / 2
      };
      
      if (x >= cardBounds.left && x <= cardBounds.right && 
          y >= cardBounds.top && y <= cardBounds.bottom) {
        selectWallet(activeCard.wallet);
      }
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      switch (event.key) {
        case 'ArrowLeft':
          event.preventDefault();
          navigateLeft();
          break;
        case 'ArrowRight':
          event.preventDefault();
          navigateRight();
          break;
        case 'Enter':
          event.preventDefault();
          if (wallets[currentIndex]) {
            selectWallet(wallets[currentIndex]);
          }
          break;
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentIndex, wallets, isAnimating]);

  // Initialize and animate
  useEffect(() => {
    initializeWalletCards();
  }, [initializeWalletCards]);

  useEffect(() => {
    animate();
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [animate]);

  // Copy to clipboard
  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Unable to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <MonopolyBanker size="md" />
          <div>
            <h2 className="text-2xl font-bold text-green-800 font-serif">3D Wallet Navigator</h2>
            <p className="text-green-600">Navigate your digital assets with smooth 3D transitions</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="border-green-300 text-green-700">
            {currentIndex + 1} of {wallets.length}
          </Badge>
        </div>
      </div>

      {/* 3D Navigation Canvas */}
      <Card className="border-2 border-green-200">
        <CardContent className="p-0">
          <div className="relative">
            <canvas
              ref={canvasRef}
              onClick={handleCanvasClick}
              width={800}
              height={400}
              className="w-full h-96 cursor-pointer rounded-lg"
              style={{ display: 'block' }}
            />
            
            {/* Navigation Controls */}
            <div className="absolute inset-0 flex items-center justify-between p-4 pointer-events-none">
              <Button
                variant="outline"
                onClick={navigateLeft}
                disabled={currentIndex <= 0 || isAnimating}
                className="pointer-events-auto border-green-300 text-green-700 hover:bg-green-50 bg-white bg-opacity-90"
              >
                <ChevronLeftIcon className="w-5 h-5" />
              </Button>
              
              <Button
                variant="outline"
                onClick={navigateRight}
                disabled={currentIndex >= wallets.length - 1 || isAnimating}
                className="pointer-events-auto border-green-300 text-green-700 hover:bg-green-50 bg-white bg-opacity-90"
              >
                <ChevronRightIcon className="w-5 h-5" />
              </Button>
            </div>
            
            {/* Instructions */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-center text-white text-sm bg-black bg-opacity-50 px-4 py-2 rounded-lg">
              Use arrow keys or buttons to navigate • Click card to view details
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current Wallet Info */}
      {wallets[currentIndex] && (
        <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`w-16 h-16 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg border-2 border-yellow-400 ${
                  wallets[currentIndex].color === 'orange-500' ? 'bg-orange-500' :
                  wallets[currentIndex].color === 'blue-500' ? 'bg-blue-500' :
                  wallets[currentIndex].color === 'gray-500' ? 'bg-gray-500' :
                  wallets[currentIndex].color === 'green-500' ? 'bg-green-500' :
                  wallets[currentIndex].color === 'blue-600' ? 'bg-blue-600' :
                  wallets[currentIndex].color === 'blue-700' ? 'bg-blue-700' :
                  wallets[currentIndex].color === 'purple-500' ? 'bg-purple-500' :
                  wallets[currentIndex].color === 'purple-600' ? 'bg-purple-600' :
                  'bg-gray-500'
                }`}>
                  <span>{wallets[currentIndex].icon}</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-green-800 font-serif">{wallets[currentIndex].name}</h3>
                  <p className="text-green-600">{wallets[currentIndex].symbol}</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <Badge className="bg-green-100 text-green-800">
                      {wallets[currentIndex].balance} {wallets[currentIndex].symbol}
                    </Badge>
                    <Badge variant="outline" className="border-green-300 text-green-700">
                      {wallets[currentIndex].usdValue}
                    </Badge>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  onClick={() => copyToClipboard(wallets[currentIndex].address, 'Wallet Address')}
                  className="border-green-300 text-green-700 hover:bg-green-50"
                >
                  <CopyIcon className="w-4 h-4 mr-2" />
                  Copy Address
                </Button>
                <Button
                  variant="outline"
                  onClick={() => selectWallet(wallets[currentIndex])}
                  className="border-green-300 text-green-700 hover:bg-green-50"
                >
                  <EyeIcon className="w-4 h-4 mr-2" />
                  View Details
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Wallet Details Modal */}
      {showDetails && selectedWallet && (
        <Card className="border-2 border-green-400 bg-gradient-to-br from-green-100 to-emerald-100">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-green-800 font-serif">Wallet Details</h3>
              <Button
                variant="outline"
                onClick={() => setShowDetails(false)}
                className="border-green-300 text-green-700 hover:bg-green-50"
              >
                Close
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-green-700">Wallet Address</label>
                  <div className="flex items-center space-x-2 mt-1">
                    <code className="bg-white p-2 rounded border text-sm font-mono flex-1">
                      {selectedWallet.address}
                    </code>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(selectedWallet.address, 'Address')}
                      className="border-green-300 text-green-700 hover:bg-green-50"
                    >
                      <CopyIcon className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-green-700">Public Key</label>
                  <div className="flex items-center space-x-2 mt-1">
                    <code className="bg-white p-2 rounded border text-sm font-mono flex-1 truncate">
                      {selectedWallet.publicKey}
                    </code>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(selectedWallet.publicKey || '', 'Public Key')}
                      className="border-green-300 text-green-700 hover:bg-green-50"
                    >
                      <CopyIcon className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="text-center p-6 bg-white rounded-lg border-2 border-green-200">
                  <div className="text-3xl font-bold text-green-800 mb-2">
                    {selectedWallet.balance} {selectedWallet.symbol}
                  </div>
                  <div className="text-xl text-green-600 mb-4">{selectedWallet.usdValue}</div>
                  
                  <div className="flex space-x-2">
                    <Button className="money-gradient hover:bg-green-700 flex-1">
                      <ArrowUpIcon className="w-4 h-4 mr-2" />
                      Send
                    </Button>
                    <Button variant="outline" className="border-green-300 text-green-700 hover:bg-green-50 flex-1">
                      <ArrowDownIcon className="w-4 h-4 mr-2" />
                      Receive
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}