import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TrendingUpIcon, ShieldIcon, LightbulbIcon, BarChart3Icon, GraduationCapIcon } from 'lucide-react';

interface TipCategoryProps {
  onCategorySelect: (category: string) => void;
  selectedCategory: string;
}

export function TipCategories({ onCategorySelect, selectedCategory }: TipCategoryProps) {
  const categories = [
    {
      id: 'all',
      name: 'All Tips',
      icon: <BarChart3Icon className="w-5 h-5" />,
      color: 'bg-gray-100 text-gray-800 border-gray-300',
      description: 'Complete investment wisdom'
    },
    {
      id: 'investment',
      name: 'Investment',
      icon: <TrendingUpIcon className="w-5 h-5" />,
      color: 'bg-green-100 text-green-800 border-green-300',
      description: 'Portfolio and asset strategies'
    },
    {
      id: 'security',
      name: 'Security',
      icon: <ShieldIcon className="w-5 h-5" />,
      color: 'bg-red-100 text-red-800 border-red-300',
      description: 'Wallet and exchange safety'
    },
    {
      id: 'strategy',
      name: 'Strategy',
      icon: <LightbulbIcon className="w-5 h-5" />,
      color: 'bg-blue-100 text-blue-800 border-blue-300',
      description: 'Trading and timing tactics'
    },
    {
      id: 'market',
      name: 'Market',
      icon: <BarChart3Icon className="w-5 h-5" />,
      color: 'bg-purple-100 text-purple-800 border-purple-300',
      description: 'Market trends and cycles'
    },
    {
      id: 'education',
      name: 'Education',
      icon: <GraduationCapIcon className="w-5 h-5" />,
      color: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      description: 'Learning and compliance'
    }
  ];

  return (
    <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 mb-6">
      <CardContent className="p-4">
        <h4 className="text-lg font-bold text-green-800 mb-4 font-serif">📚 Education Categories</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant="ghost"
              onClick={() => onCategorySelect(category.id)}
              className={`flex flex-col items-center p-3 h-auto space-y-2 border-2 transition-all duration-200 ${
                selectedCategory === category.id
                  ? category.color + ' shadow-lg transform scale-105'
                  : 'bg-white border-gray-200 hover:bg-gray-50'
              }`}
            >
              {category.icon}
              <span className="text-xs font-medium text-center">{category.name}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}