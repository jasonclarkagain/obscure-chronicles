import { Button } from '@/components/ui/button';
import { Link, useLocation } from 'wouter';
import { GlobeIcon, BarChart3Icon, WalletIcon, ClockIcon, MenuIcon, TrendingUpIcon } from 'lucide-react';
import { useState } from 'react';

interface HeaderNavigationProps {
  onShowPaperWallet?: () => void;
}

export function HeaderNavigation({ onShowPaperWallet }: HeaderNavigationProps) {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location === path;

  return (
    <header className="bg-gradient-to-r from-slate-900 via-gray-900 to-slate-900 border-b border-gray-700 shadow-lg sticky top-0 z-[100]">
      <div className="container mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-14 sm:h-16">
          {/* Logo */}
          <Link href="/wallet">
            <div className="flex items-center space-x-2 cursor-pointer">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center">
                <WalletIcon className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg sm:text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                  CryptoVault
                </h1>
                <p className="text-xs text-gray-400 hidden sm:block">Secure Banking</p>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            <Link href="/wallet">
              <Button 
                variant="ghost"
                size="sm"
                className={`px-3 py-2 font-medium transition-all ${
                  isActive('/wallet') || isActive('/') 
                    ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white' 
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <WalletIcon className="w-4 h-4 mr-1" />
                Wallet
              </Button>
            </Link>

            <Link href="/globe">
              <Button 
                variant="ghost"
                size="sm"
                className={`px-3 py-2 font-medium transition-all ${
                  isActive('/globe') 
                    ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white' 
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <GlobeIcon className="w-4 h-4 mr-1" />
                Globe
              </Button>
            </Link>

            <Link href="/heatmap">
              <Button 
                variant="ghost"
                size="sm"
                className={`px-3 py-2 font-medium transition-all ${
                  isActive('/heatmap') 
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' 
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <BarChart3Icon className="w-4 h-4 mr-1" />
                Heatmap
              </Button>
            </Link>

            <Link href="/timezone">
              <Button 
                variant="ghost"
                size="sm"
                className={`px-3 py-2 font-medium transition-all ${
                  isActive('/timezone') 
                    ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white' 
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <ClockIcon className="w-4 h-4 mr-1" />
                Timezone
              </Button>
            </Link>

            <Link href="/financial-time-machine">
              <Button 
                variant="ghost"
                size="sm"
                className={`px-3 py-2 font-medium transition-all ${
                  isActive('/financial-time-machine') 
                    ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-white' 
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <TrendingUpIcon className="w-4 h-4 mr-1" />
                Time Machine
              </Button>
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden text-gray-300"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <MenuIcon className="w-5 h-5" />
          </Button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-700 py-3">
            <nav className="flex flex-col space-y-2">
              <Link href="/wallet">
                <Button 
                  variant="ghost"
                  size="sm"
                  className={`w-full justify-start ${
                    isActive('/wallet') || isActive('/') 
                      ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white' 
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <WalletIcon className="w-4 h-4 mr-2" />
                  Wallet
                </Button>
              </Link>

              <Link href="/globe">
                <Button 
                  variant="ghost"
                  size="sm"
                  className={`w-full justify-start ${
                    isActive('/globe') 
                      ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white' 
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <GlobeIcon className="w-4 h-4 mr-2" />
                  Globe
                </Button>
              </Link>

              <Link href="/heatmap">
                <Button 
                  variant="ghost"
                  size="sm"
                  className={`w-full justify-start ${
                    isActive('/heatmap') 
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' 
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <BarChart3Icon className="w-4 h-4 mr-2" />
                  Heatmap
                </Button>
              </Link>

              <Link href="/timezone">
                <Button 
                  variant="ghost"
                  size="sm"
                  className={`w-full justify-start ${
                    isActive('/timezone') 
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white' 
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <ClockIcon className="w-4 h-4 mr-2" />
                  Timezone
                </Button>
              </Link>

              <Link href="/financial-time-machine">
                <Button 
                  variant="ghost"
                  size="sm"
                  className={`w-full justify-start ${
                    isActive('/financial-time-machine') 
                      ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-white' 
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <TrendingUpIcon className="w-4 h-4 mr-2" />
                  Time Machine
                </Button>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}