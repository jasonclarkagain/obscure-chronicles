import React, { useRef, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';

export function TestCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Force canvas dimensions
    canvas.width = 800;
    canvas.height = 400;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Test drawing
    const draw = () => {
      // Clear canvas
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 0, 800, 400);

      // Draw test elements
      ctx.fillStyle = '#10b981';
      ctx.fillRect(50, 50, 100, 100);

      ctx.fillStyle = '#ffffff';
      ctx.font = '16px serif';
      ctx.fillText('Canvas Test - If you see this, canvas is working!', 200, 100);

      // Draw moving circle
      const time = Date.now() / 1000;
      const x = 400 + Math.cos(time) * 100;
      const y = 200 + Math.sin(time) * 50;
      
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(x, y, 20, 0, Math.PI * 2);
      ctx.fill();

      requestAnimationFrame(draw);
    };

    draw();
  }, []);

  return (
    <Card className="border-2 border-green-200">
      <CardContent className="p-4">
        <h3 className="text-lg font-bold text-green-800 mb-4">Canvas Debug Test</h3>
        <div className="relative w-full h-96 bg-slate-900 rounded-lg">
          <canvas
            ref={canvasRef}
            width={800}
            height={400}
            className="absolute inset-0 w-full h-full rounded-lg border-2 border-red-500"
            style={{ 
              display: 'block',
              background: '#1e293b'
            }}
          />
          <div className="absolute top-2 left-2 text-white text-xs bg-red-600 px-2 py-1 rounded">
            TEST CANVAS
          </div>
        </div>
      </CardContent>
    </Card>
  );
}