import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeftIcon, ChevronRightIcon, CopyIcon, EyeIcon } from 'lucide-react';
import { type CryptoWallet } from '@/lib/crypto';
import { useToast } from '@/hooks/use-toast';

interface ThreeWalletViewerProps {
  wallets: CryptoWallet[];
  onWalletSelect?: (wallet: CryptoWallet) => void;
}

export function ThreeWalletViewer({ wallets, onWalletSelect }: ThreeWalletViewerProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene>();
  const rendererRef = useRef<THREE.WebGLRenderer>();
  const cameraRef = useRef<THREE.PerspectiveCamera>();
  const walletMeshesRef = useRef<THREE.Group[]>([]);
  const animationFrameRef = useRef<number>();
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [selectedWallet, setSelectedWallet] = useState<CryptoWallet | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const { toast } = useToast();

  // Initialize Three.js scene
  useEffect(() => {
    if (!mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(75, 800 / 400, 0.1, 1000);
    camera.position.set(0, 0, 5);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(800, 400);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;
    mountRef.current.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    // Create wallet cards
    createWalletCards();

    // Start animation loop
    animate();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [wallets]);

  const createWalletCards = () => {
    if (!sceneRef.current) return;

    // Clear existing wallet meshes
    walletMeshesRef.current.forEach(mesh => {
      sceneRef.current?.remove(mesh);
    });
    walletMeshesRef.current = [];

    wallets.forEach((wallet, index) => {
      // Create wallet card group
      const cardGroup = new THREE.Group();

      // Card background
      const cardGeometry = new THREE.PlaneGeometry(2, 1.2);
      const cardMaterial = new THREE.MeshLambertMaterial({ 
        color: index === currentIndex ? 0x10b981 : 0xf0fdf4,
        transparent: true,
        opacity: 0.9
      });
      const cardMesh = new THREE.Mesh(cardGeometry, cardMaterial);
      cardMesh.castShadow = true;
      cardMesh.receiveShadow = true;
      cardGroup.add(cardMesh);

      // Card border
      const borderGeometry = new THREE.RingGeometry(0.98, 1.02, 32);
      const borderMaterial = new THREE.MeshBasicMaterial({ 
        color: index === currentIndex ? 0xfbbf24 : 0x10b981,
        side: THREE.DoubleSide
      });
      const borderMesh = new THREE.Mesh(borderGeometry, borderMaterial);
      borderMesh.position.z = 0.001;
      cardGroup.add(borderMesh);

      // Wallet icon (3D cube)
      const iconGeometry = new THREE.BoxGeometry(0.3, 0.3, 0.1);
      const iconMaterial = new THREE.MeshLambertMaterial({ 
        color: getWalletColor(wallet.color)
      });
      const iconMesh = new THREE.Mesh(iconGeometry, iconMaterial);
      iconMesh.position.set(0, 0.3, 0.1);
      iconMesh.castShadow = true;
      cardGroup.add(iconMesh);

      // Position cards in carousel
      const offset = index - currentIndex;
      cardGroup.position.x = offset * 3;
      cardGroup.position.z = -Math.abs(offset) * 0.5;
      cardGroup.rotation.y = offset * 0.2;
      cardGroup.scale.setScalar(Math.max(0.6, 1 - Math.abs(offset) * 0.2));

      // Store wallet data
      cardGroup.userData = { wallet, index };

      sceneRef.current.add(cardGroup);
      walletMeshesRef.current.push(cardGroup);
    });
  };

  const getWalletColor = (colorName: string): number => {
    const colorMap: Record<string, number> = {
      'orange-500': 0xf97316,
      'blue-500': 0x3b82f6,
      'gray-500': 0x6b7280,
      'green-500': 0x10b981,
      'blue-600': 0x2563eb,
      'blue-700': 0x1d4ed8,
      'purple-500': 0x8b5cf6,
      'purple-600': 0x7c3aed
    };
    return colorMap[colorName] || 0x6b7280;
  };

  const animate = () => {
    if (!rendererRef.current || !sceneRef.current || !cameraRef.current) return;

    // Smooth rotation animation for active card
    walletMeshesRef.current.forEach((group, index) => {
      if (index === currentIndex) {
        group.children[2]?.rotateY(0.02); // Rotate icon
      }
    });

    rendererRef.current.render(sceneRef.current, cameraRef.current);
    animationFrameRef.current = requestAnimationFrame(animate);
  };

  const navigateLeft = () => {
    if (isAnimating || currentIndex <= 0) return;
    setIsAnimating(true);
    setCurrentIndex(prev => prev - 1);
    
    // Animate card positions
    animateCards(() => setIsAnimating(false));
  };

  const navigateRight = () => {
    if (isAnimating || currentIndex >= wallets.length - 1) return;
    setIsAnimating(true);
    setCurrentIndex(prev => prev + 1);
    
    // Animate card positions
    animateCards(() => setIsAnimating(false));
  };

  const animateCards = (onComplete: () => void) => {
    walletMeshesRef.current.forEach((group, index) => {
      const offset = index - currentIndex;
      const targetX = offset * 3;
      const targetZ = -Math.abs(offset) * 0.5;
      const targetRotY = offset * 0.2;
      const targetScale = Math.max(0.6, 1 - Math.abs(offset) * 0.2);

      // Smooth animation
      const startX = group.position.x;
      const startZ = group.position.z;
      const startRotY = group.rotation.y;
      const startScale = group.scale.x;

      let progress = 0;
      const animateStep = () => {
        progress += 0.05;
        if (progress >= 1) {
          group.position.x = targetX;
          group.position.z = targetZ;
          group.rotation.y = targetRotY;
          group.scale.setScalar(targetScale);
          
          // Update material color
          const cardMaterial = group.children[0].material as THREE.MeshLambertMaterial;
          cardMaterial.color.setHex(index === currentIndex ? 0x10b981 : 0xf0fdf4);
          
          const borderMaterial = group.children[1].material as THREE.MeshBasicMaterial;
          borderMaterial.color.setHex(index === currentIndex ? 0xfbbf24 : 0x10b981);
          
          if (index === 0) onComplete();
          return;
        }

        const easeProgress = 1 - Math.pow(1 - progress, 3); // Ease out cubic
        group.position.x = startX + (targetX - startX) * easeProgress;
        group.position.z = startZ + (targetZ - startZ) * easeProgress;
        group.rotation.y = startRotY + (targetRotY - startRotY) * easeProgress;
        group.scale.setScalar(startScale + (targetScale - startScale) * easeProgress);

        requestAnimationFrame(animateStep);
      };
      animateStep();
    });
  };

  // Update cards when currentIndex changes
  useEffect(() => {
    if (walletMeshesRef.current.length > 0) {
      createWalletCards();
    }
  }, [currentIndex]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      switch (event.key) {
        case 'ArrowLeft':
          event.preventDefault();
          navigateLeft();
          break;
        case 'ArrowRight':
          event.preventDefault();
          navigateRight();
          break;
        case 'Enter':
          event.preventDefault();
          if (wallets[currentIndex]) {
            selectWallet(wallets[currentIndex]);
          }
          break;
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentIndex, wallets, isAnimating]);

  const selectWallet = (wallet: CryptoWallet) => {
    setSelectedWallet(wallet);
    setShowDetails(true);
    onWalletSelect?.(wallet);
  };

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Unable to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">3D Wallet Navigator</h2>
          <p className="text-gray-600">Navigate your wallets with Three.js 3D visualization</p>
        </div>
        <Badge variant="outline" className="border-green-300 text-green-700">
          {currentIndex + 1} of {wallets.length}
        </Badge>
      </div>

      {/* 3D Viewer */}
      <Card className="border border-gray-200">
        <CardContent className="p-0">
          <div className="relative">
            <div ref={mountRef} className="w-full h-96" />
            
            {/* Navigation Controls */}
            <div className="absolute inset-0 flex items-center justify-between p-4 pointer-events-none">
              <Button
                variant="outline"
                onClick={navigateLeft}
                disabled={currentIndex <= 0 || isAnimating}
                className="pointer-events-auto bg-white bg-opacity-90"
              >
                <ChevronLeftIcon className="w-5 h-5" />
              </Button>
              
              <Button
                variant="outline"
                onClick={navigateRight}
                disabled={currentIndex >= wallets.length - 1 || isAnimating}
                className="pointer-events-auto bg-white bg-opacity-90"
              >
                <ChevronRightIcon className="w-5 h-5" />
              </Button>
            </div>
            
            {/* Instructions */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-center text-white text-sm bg-black bg-opacity-50 px-4 py-2 rounded-lg">
              Use arrow keys or buttons to navigate • Enter to view details
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current Wallet Info */}
      {wallets[currentIndex] && (
        <Card className="border border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-md ${
                  wallets[currentIndex].color === 'orange-500' ? 'bg-orange-500' :
                  wallets[currentIndex].color === 'blue-500' ? 'bg-blue-500' :
                  wallets[currentIndex].color === 'gray-500' ? 'bg-gray-500' :
                  wallets[currentIndex].color === 'green-500' ? 'bg-green-500' :
                  wallets[currentIndex].color === 'blue-600' ? 'bg-blue-600' :
                  wallets[currentIndex].color === 'blue-700' ? 'bg-blue-700' :
                  wallets[currentIndex].color === 'purple-500' ? 'bg-purple-500' :
                  wallets[currentIndex].color === 'purple-600' ? 'bg-purple-600' :
                  'bg-gray-500'
                }`}>
                  <span>{wallets[currentIndex].icon}</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{wallets[currentIndex].name}</h3>
                  <p className="text-gray-600">{wallets[currentIndex].symbol}</p>
                  <div className="flex items-center space-x-3 mt-1">
                    <Badge variant="secondary">
                      {wallets[currentIndex].balance} {wallets[currentIndex].symbol}
                    </Badge>
                    <Badge variant="outline">
                      {wallets[currentIndex].usdValue}
                    </Badge>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(wallets[currentIndex].address, 'Wallet Address')}
                >
                  <CopyIcon className="w-4 h-4 mr-1" />
                  Copy Address
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => selectWallet(wallets[currentIndex])}
                >
                  <EyeIcon className="w-4 h-4 mr-1" />
                  View Details
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Wallet Details Modal */}
      {showDetails && selectedWallet && (
        <Card className="border-2 border-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-gray-900">Wallet Details</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDetails(false)}
              >
                Close
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-gray-700">Wallet Address</label>
                  <div className="flex items-center space-x-2 mt-1">
                    <code className="bg-gray-100 p-2 rounded text-sm font-mono flex-1 break-all">
                      {selectedWallet.address}
                    </code>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(selectedWallet.address, 'Address')}
                    >
                      <CopyIcon className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                {selectedWallet.publicKey && (
                  <div>
                    <label className="text-sm font-medium text-gray-700">Public Key</label>
                    <div className="flex items-center space-x-2 mt-1">
                      <code className="bg-gray-100 p-2 rounded text-sm font-mono flex-1 truncate">
                        {selectedWallet.publicKey}
                      </code>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(selectedWallet.publicKey || '', 'Public Key')}
                      >
                        <CopyIcon className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-900 mb-1">
                  {selectedWallet.balance} {selectedWallet.symbol}
                </div>
                <div className="text-lg text-gray-600 mb-3">{selectedWallet.usdValue}</div>
                
                <div className="flex space-x-2">
                  <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white flex-1">
                    Send
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    Receive
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}