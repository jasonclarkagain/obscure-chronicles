import React, { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { GlobeIcon, PlayIcon, PauseIcon } from 'lucide-react';

interface MarketPin {
  id: string;
  city: string;
  country: string;
  lat: number;
  lng: number;
  activity: 'high' | 'medium' | 'low';
  volume: number;
  status: 'open' | 'closed';
  flag: string;
}

export function WorkingCryptoGlobe() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rotationRef = useRef(0);
  const animationRef = useRef<number>();
  const isRotatingRef = useRef(true);

  const marketPins: MarketPin[] = [
    { id: 'tokyo', city: 'Tokyo', country: 'Japan', lat: 35.68, lng: 139.65, activity: 'high', volume: 24.8, status: 'open', flag: '🇯🇵' },
    { id: 'london', city: 'London', country: 'UK', lat: 51.51, lng: -0.13, activity: 'high', volume: 31.4, status: 'open', flag: '🇬🇧' },
    { id: 'newyork', city: 'New York', country: 'USA', lat: 40.71, lng: -74.01, activity: 'high', volume: 42.3, status: 'closed', flag: '🇺🇸' },
    { id: 'singapore', city: 'Singapore', country: 'Singapore', lat: 1.35, lng: 103.82, activity: 'medium', volume: 12.5, status: 'open', flag: '🇸🇬' },
    { id: 'hongkong', city: 'Hong Kong', country: 'Hong Kong', lat: 22.32, lng: 114.17, activity: 'medium', volume: 15.3, status: 'open', flag: '🇭🇰' },
    { id: 'sydney', city: 'Sydney', country: 'Australia', lat: -33.87, lng: 151.21, activity: 'medium', volume: 6.7, status: 'open', flag: '🇦🇺' }
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 800;
    canvas.height = 500;

    const draw = () => {
      const centerX = 400;
      const centerY = 250;
      const radius = 200;

      // Clear canvas
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, 800, 500);

      // Draw globe
      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
      gradient.addColorStop(0, '#1E40AF');
      gradient.addColorStop(0.7, '#3730A3');
      gradient.addColorStop(1, '#1E1B4B');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.fill();

      // Draw grid lines
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.3)';
      ctx.lineWidth = 1;
      
      for (let i = 0; i < 12; i++) {
        const angle = (i * Math.PI) / 6 + rotationRef.current;
        ctx.beginPath();
        ctx.ellipse(centerX, centerY, radius * Math.abs(Math.cos(angle)), radius, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      for (let i = 1; i < 6; i++) {
        const latRadius = radius * Math.sin((i * Math.PI) / 6);
        const latY = centerY - radius * Math.cos((i * Math.PI) / 6);
        
        ctx.beginPath();
        ctx.arc(centerX, latY, latRadius, 0, Math.PI * 2);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.arc(centerX, centerY + (centerY - latY), latRadius, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Draw market pins
      marketPins.forEach(pin => {
        const pinAngle = (pin.lng * Math.PI) / 180 + rotationRef.current;
        const latAngle = (pin.lat * Math.PI) / 180;
        
        const x = centerX + Math.cos(pinAngle) * Math.cos(latAngle) * radius;
        const y = centerY - Math.sin(latAngle) * radius;
        const z = Math.sin(pinAngle) * Math.cos(latAngle);
        
        if (z > -0.1) {
          const size = pin.activity === 'high' ? 8 : pin.activity === 'medium' ? 6 : 4;
          
          ctx.fillStyle = pin.status === 'open' ? '#10B981' : '#EF4444';
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
          
          ctx.fillStyle = '#FFFFFF';
          ctx.font = '12px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(pin.flag, x, y - size - 5);
          
          if (pin.volume > 20) {
            ctx.fillStyle = '#FEF08A';
            ctx.font = '10px Arial';
            ctx.fillText(`$${pin.volume.toFixed(1)}B`, x, y + size + 15);
          }
        }
      });

      if (isRotatingRef.current) {
        rotationRef.current += 0.01;
      }

      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  const toggleRotation = () => {
    isRotatingRef.current = !isRotatingRef.current;
  };

  return (
    <Card className="bg-gradient-to-br from-slate-900 to-gray-900 border-gray-700 text-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GlobeIcon className="w-5 h-5 text-blue-400" />
          Global Crypto Markets
        </CardTitle>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={toggleRotation}
            className="text-white border-gray-600 hover:bg-gray-700"
          >
            {isRotatingRef.current ? <PauseIcon className="w-4 h-4" /> : <PlayIcon className="w-4 h-4" />}
            {isRotatingRef.current ? 'Pause' : 'Rotate'}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <canvas
          ref={canvasRef}
          className="w-full border border-gray-600 rounded-lg"
          style={{ maxWidth: '100%', height: 'auto' }}
        />
        
        <div className="mt-4 flex gap-4 flex-wrap">
          <Badge variant="secondary" className="bg-green-500/20 text-green-400">
            <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
            Markets Open: {marketPins.filter(p => p.status === 'open').length}
          </Badge>
          <Badge variant="secondary" className="bg-red-500/20 text-red-400">
            <div className="w-2 h-2 bg-red-400 rounded-full mr-2"></div>
            Markets Closed: {marketPins.filter(p => p.status === 'closed').length}
          </Badge>
          <Badge variant="secondary" className="bg-blue-500/20 text-blue-400">
            Total Volume: ${marketPins.reduce((sum, p) => sum + p.volume, 0).toFixed(1)}B
          </Badge>
        </div>

        <p className="text-gray-400 text-sm mt-2">
          Real-time global cryptocurrency market visualization. Green pins indicate open markets.
        </p>
      </CardContent>
    </Card>
  );
}