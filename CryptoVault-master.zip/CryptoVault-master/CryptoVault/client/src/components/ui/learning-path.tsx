import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { 
  BookOpenIcon,
  CheckCircleIcon,
  PlayCircleIcon,
  ClockIcon,
  StarIcon,
  TrendingUpIcon,
  ShieldIcon,
  BrainIcon,
  ArrowRightIcon,
  AwardIcon,
  TargetIcon,
  ZapIcon
} from 'lucide-react';
import { type CryptoWallet } from '@/lib/crypto';

interface LearningModule {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: number; // in minutes
  category: 'basics' | 'security' | 'trading' | 'defi' | 'analysis' | 'regulation';
  prerequisite?: string[];
  completed: boolean;
  progress: number;
  icon: string;
  oneClickAction?: string;
  keyTakeaways: string[];
  practicalExercise?: string;
}

interface LearningPath {
  id: string;
  name: string;
  description: string;
  totalModules: number;
  completedModules: number;
  estimatedHours: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  modules: LearningModule[];
  badge: string;
}

interface PersonalizedLearningProps {
  wallets: CryptoWallet[];
}

export function PersonalizedLearning({ wallets }: PersonalizedLearningProps) {
  const [selectedPath, setSelectedPath] = useState<string>('crypto-fundamentals');
  const [userLevel, setUserLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const [completedModules, setCompletedModules] = useState<Set<string>>(new Set());
  const [currentModule, setCurrentModule] = useState<LearningModule | null>(null);

  // Learning paths based on user's portfolio and experience
  const learningPaths: LearningPath[] = [
    {
      id: 'crypto-fundamentals',
      name: 'Cryptocurrency Fundamentals',
      description: 'Master the basics of cryptocurrency, blockchain, and digital finance',
      totalModules: 8,
      completedModules: 0,
      estimatedHours: 6,
      difficulty: 'beginner',
      badge: '🎓',
      modules: [
        {
          id: 'crypto-101',
          title: 'What is Cryptocurrency?',
          description: 'Understanding digital currencies, blockchain technology, and decentralization',
          difficulty: 'beginner',
          duration: 45,
          category: 'basics',
          completed: false,
          progress: 0,
          icon: '💰',
          oneClickAction: 'Start Learning',
          keyTakeaways: [
            'Understand what cryptocurrency is and how it works',
            'Learn about blockchain technology fundamentals',
            'Discover the advantages of decentralized systems'
          ]
        },
        {
          id: 'wallet-security',
          title: 'Wallet Security Essentials',
          description: 'Protecting your cryptocurrency with proper wallet management',
          difficulty: 'beginner',
          duration: 30,
          category: 'security',
          completed: false,
          progress: 0,
          icon: '🔐',
          oneClickAction: 'Secure Wallet',
          keyTakeaways: [
            'Create strong, unique passwords for crypto accounts',
            'Understand seed phrase importance and storage',
            'Learn about different wallet types and security features'
          ],
          practicalExercise: 'Set up 2FA on all crypto accounts'
        },
        {
          id: 'buying-first-crypto',
          title: 'Buying Your First Cryptocurrency',
          description: 'Step-by-step guide to purchasing and storing cryptocurrency safely',
          difficulty: 'beginner',
          duration: 40,
          category: 'basics',
          prerequisite: ['crypto-101'],
          completed: false,
          progress: 0,
          icon: '🛒',
          oneClickAction: 'Practice Buy',
          keyTakeaways: [
            'Choose reputable cryptocurrency exchanges',
            'Understand KYC (Know Your Customer) requirements',
            'Learn about transaction fees and processing times'
          ]
        },
        {
          id: 'portfolio-diversification',
          title: 'Building a Balanced Crypto Portfolio',
          description: 'Strategies for diversification and risk management in cryptocurrency investing',
          difficulty: 'intermediate',
          duration: 50,
          category: 'trading',
          prerequisite: ['buying-first-crypto'],
          completed: false,
          progress: 0,
          icon: '📊',
          oneClickAction: 'Analyze Portfolio',
          keyTakeaways: [
            'Learn portfolio allocation strategies',
            'Understand correlation between different cryptocurrencies',
            'Implement risk management techniques'
          ]
        },
        {
          id: 'technical-analysis',
          title: 'Reading Crypto Charts and Technical Analysis',
          description: 'Introduction to chart patterns, indicators, and market analysis',
          difficulty: 'intermediate',
          duration: 60,
          category: 'analysis',
          prerequisite: ['portfolio-diversification'],
          completed: false,
          progress: 0,
          icon: '📈',
          oneClickAction: 'Practice Analysis',
          keyTakeaways: [
            'Read and interpret cryptocurrency price charts',
            'Understand support and resistance levels',
            'Use technical indicators for decision making'
          ]
        },
        {
          id: 'defi-basics',
          title: 'Introduction to Decentralized Finance (DeFi)',
          description: 'Understanding lending, borrowing, and yield farming in DeFi protocols',
          difficulty: 'intermediate',
          duration: 55,
          category: 'defi',
          prerequisite: ['technical-analysis'],
          completed: false,
          progress: 0,
          icon: '🏦',
          oneClickAction: 'Explore DeFi',
          keyTakeaways: [
            'Understand DeFi protocols and smart contracts',
            'Learn about liquidity pools and yield farming',
            'Assess risks and rewards in DeFi investing'
          ]
        },
        {
          id: 'tax-compliance',
          title: 'Cryptocurrency Tax and Legal Compliance',
          description: 'Understanding tax obligations and regulatory requirements',
          difficulty: 'intermediate',
          duration: 45,
          category: 'regulation',
          completed: false,
          progress: 0,
          icon: '📋',
          oneClickAction: 'Check Compliance',
          keyTakeaways: [
            'Understand cryptocurrency tax implications',
            'Learn record-keeping requirements',
            'Stay compliant with local regulations'
          ]
        },
        {
          id: 'advanced-strategies',
          title: 'Advanced Investment Strategies',
          description: 'Professional-level trading techniques and institutional approaches',
          difficulty: 'advanced',
          duration: 75,
          category: 'trading',
          prerequisite: ['defi-basics', 'tax-compliance'],
          completed: false,
          progress: 0,
          icon: '🎯',
          oneClickAction: 'Master Strategies',
          keyTakeaways: [
            'Implement dollar-cost averaging and rebalancing',
            'Understand options and futures in crypto',
            'Learn institutional investment approaches'
          ]
        }
      ]
    },
    {
      id: 'security-expert',
      name: 'Cryptocurrency Security Expert',
      description: 'Become a security expert and protect your digital assets like a professional',
      totalModules: 6,
      completedModules: 0,
      estimatedHours: 4,
      difficulty: 'intermediate',
      badge: '🛡️',
      modules: [
        {
          id: 'threat-landscape',
          title: 'Understanding Crypto Threats',
          description: 'Identify and protect against common cryptocurrency security threats',
          difficulty: 'intermediate',
          duration: 40,
          category: 'security',
          completed: false,
          progress: 0,
          icon: '⚠️',
          oneClickAction: 'Security Audit',
          keyTakeaways: [
            'Recognize phishing and social engineering attacks',
            'Understand exchange hacks and exit scams',
            'Learn about malware and keyloggers'
          ]
        },
        {
          id: 'cold-storage',
          title: 'Cold Storage and Hardware Wallets',
          description: 'Master offline storage solutions for maximum security',
          difficulty: 'intermediate',
          duration: 45,
          category: 'security',
          completed: false,
          progress: 0,
          icon: '🧊',
          oneClickAction: 'Setup Cold Storage',
          keyTakeaways: [
            'Choose and configure hardware wallets',
            'Create secure backup strategies',
            'Understand air-gapped storage methods'
          ]
        }
      ]
    },
    {
      id: 'trading-pro',
      name: 'Professional Trader Path',
      description: 'Advanced trading strategies and market analysis for serious traders',
      totalModules: 10,
      completedModules: 0,
      estimatedHours: 12,
      difficulty: 'advanced',
      badge: '📈',
      modules: [
        {
          id: 'market-psychology',
          title: 'Market Psychology and Sentiment Analysis',
          description: 'Understanding market emotions and crowd behavior',
          difficulty: 'advanced',
          duration: 60,
          category: 'analysis',
          completed: false,
          progress: 0,
          icon: '🧠',
          oneClickAction: 'Analyze Sentiment',
          keyTakeaways: [
            'Read market sentiment indicators',
            'Understand fear and greed cycles',
            'Use social sentiment in trading decisions'
          ]
        }
      ]
    }
  ];

  // Personalize learning path based on user's wallets and experience
  const getPersonalizedRecommendations = () => {
    const portfolioValue = wallets.reduce((sum, wallet) => {
      const value = parseFloat(wallet.usdValue.replace('$', '').replace(',', ''));
      return sum + value;
    }, 0);

    const numWallets = wallets.length;
    
    // Determine user level based on portfolio
    let recommendedLevel: 'beginner' | 'intermediate' | 'advanced' = 'beginner';
    if (portfolioValue > 10000 && numWallets >= 5) {
      recommendedLevel = 'advanced';
    } else if (portfolioValue > 1000 && numWallets >= 3) {
      recommendedLevel = 'intermediate';
    }

    return {
      recommendedLevel,
      recommendedPaths: learningPaths.filter(path => path.difficulty === recommendedLevel),
      personalizedTips: [
        `Based on your ${numWallets} wallets, focus on portfolio management`,
        portfolioValue > 5000 ? 'Consider advanced security measures for your holdings' : 'Start with security fundamentals',
        numWallets >= 3 ? 'Learn about correlation and diversification' : 'Explore different cryptocurrency types'
      ]
    };
  };

  const recommendations = getPersonalizedRecommendations();
  const selectedPathData = learningPaths.find(p => p.id === selectedPath);

  const completeModule = (moduleId: string) => {
    setCompletedModules(prev => new Set([...prev, moduleId]));
    // Update progress in the learning path
    if (selectedPathData) {
      const updatedModules = selectedPathData.modules.map(module => 
        module.id === moduleId ? { ...module, completed: true, progress: 100 } : module
      );
      selectedPathData.modules = updatedModules;
      selectedPathData.completedModules = completedModules.size + 1;
    }
  };

  const startModule = (module: LearningModule) => {
    setCurrentModule(module);
    // Simulate starting the module
    const updatedModule = { ...module, progress: 25 };
    if (selectedPathData) {
      const moduleIndex = selectedPathData.modules.findIndex(m => m.id === module.id);
      if (moduleIndex !== -1) {
        selectedPathData.modules[moduleIndex] = updatedModule;
      }
    }
  };

  const getNextRecommendedModule = () => {
    if (!selectedPathData) return null;
    
    const availableModules = selectedPathData.modules.filter(module => {
      if (module.completed) return false;
      if (!module.prerequisite) return true;
      return module.prerequisite.every(prereq => completedModules.has(prereq));
    });

    return availableModules[0] || null;
  };

  const calculateOverallProgress = () => {
    if (!selectedPathData) return 0;
    return (selectedPathData.completedModules / selectedPathData.totalModules) * 100;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <MonopolyBanker size="md" />
          <div>
            <h2 className="text-2xl font-bold text-green-800 font-serif">Personalized Learning Path</h2>
            <p className="text-green-600">AI-curated cryptocurrency education tailored to your experience</p>
          </div>
        </div>
      </div>

      {/* Personalized Recommendations */}
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3 mb-4">
            <BrainIcon className="w-6 h-6 text-blue-600" />
            <h3 className="font-bold text-blue-800 font-serif">AI Recommendations for You</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <TargetIcon className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">Recommended Level:</span>
                <Badge className={`${
                  recommendations.recommendedLevel === 'beginner' ? 'bg-green-100 text-green-800' :
                  recommendations.recommendedLevel === 'intermediate' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {recommendations.recommendedLevel}
                </Badge>
              </div>
              <div className="space-y-1">
                {recommendations.personalizedTips.map((tip, index) => (
                  <p key={index} className="text-sm text-blue-600">• {tip}</p>
                ))}
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <StarIcon className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">Suggested Paths:</span>
              </div>
              <div className="space-y-1">
                {recommendations.recommendedPaths.slice(0, 2).map(path => (
                  <button
                    key={path.id}
                    onClick={() => setSelectedPath(path.id)}
                    className="text-sm text-blue-600 hover:text-blue-800 block"
                  >
                    {path.badge} {path.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Learning Path Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {learningPaths.map(path => (
          <Card 
            key={path.id}
            className={`cursor-pointer transition-all duration-200 ${
              selectedPath === path.id 
                ? 'border-2 border-green-400 bg-green-50' 
                : 'border-2 border-green-200 hover:border-green-300'
            }`}
            onClick={() => setSelectedPath(path.id)}
          >
            <CardContent className="p-4">
              <div className="flex items-center space-x-3 mb-3">
                <span className="text-2xl">{path.badge}</span>
                <div className="flex-1">
                  <h3 className="font-bold text-green-800">{path.name}</h3>
                  <Badge className={`text-xs ${
                    path.difficulty === 'beginner' ? 'bg-green-100 text-green-800' :
                    path.difficulty === 'intermediate' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {path.difficulty}
                  </Badge>
                </div>
              </div>
              <p className="text-sm text-green-600 mb-3">{path.description}</p>
              <div className="flex justify-between text-xs text-green-500">
                <span>{path.totalModules} modules</span>
                <span>{path.estimatedHours}h total</span>
              </div>
              <Progress value={(path.completedModules / path.totalModules) * 100} className="mt-2 h-2" />
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Selected Learning Path Details */}
      {selectedPathData && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Learning Modules */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="border-2 border-green-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-green-800 font-serif">
                    {selectedPathData.badge} {selectedPathData.name}
                  </h3>
                  <div className="text-right">
                    <div className="text-sm text-green-600">
                      {selectedPathData.completedModules} / {selectedPathData.totalModules} completed
                    </div>
                    <Progress value={calculateOverallProgress()} className="w-32 h-2" />
                  </div>
                </div>
                
                <div className="space-y-3">
                  {selectedPathData.modules.map((module, index) => {
                    const isAvailable = !module.prerequisite || 
                      module.prerequisite.every(prereq => completedModules.has(prereq));
                    const isNext = getNextRecommendedModule()?.id === module.id;

                    return (
                      <Card 
                        key={module.id}
                        className={`${
                          module.completed ? 'bg-green-50 border-green-300' :
                          isNext ? 'bg-blue-50 border-blue-300 border-2' :
                          isAvailable ? 'border-gray-200' : 'bg-gray-50 border-gray-300'
                        } transition-all duration-200`}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3 flex-1">
                              <span className="text-xl">{module.icon}</span>
                              <div className="flex-1">
                                <div className="flex items-center space-x-2">
                                  <h4 className="font-medium text-gray-800">{module.title}</h4>
                                  {module.completed && <CheckCircleIcon className="w-4 h-4 text-green-500" />}
                                  {isNext && <StarIcon className="w-4 h-4 text-blue-500" />}
                                </div>
                                <p className="text-sm text-gray-600 mt-1">{module.description}</p>
                                <div className="flex items-center space-x-3 mt-2">
                                  <div className="flex items-center space-x-1">
                                    <ClockIcon className="w-3 h-3 text-gray-400" />
                                    <span className="text-xs text-gray-500">{module.duration} min</span>
                                  </div>
                                  <Badge className="text-xs" variant="outline">
                                    {module.category}
                                  </Badge>
                                </div>
                                {module.progress > 0 && !module.completed && (
                                  <Progress value={module.progress} className="mt-2 h-1" />
                                )}
                              </div>
                            </div>
                            <div className="ml-4">
                              {module.completed ? (
                                <Button size="sm" variant="outline" disabled>
                                  <CheckCircleIcon className="w-4 h-4 mr-1" />
                                  Completed
                                </Button>
                              ) : isAvailable ? (
                                <Button 
                                  size="sm" 
                                  onClick={() => startModule(module)}
                                  className={isNext ? 'bg-blue-600 hover:bg-blue-700' : ''}
                                >
                                  <ZapIcon className="w-4 h-4 mr-1" />
                                  {module.oneClickAction || 'Start'}
                                </Button>
                              ) : (
                                <Button size="sm" variant="outline" disabled>
                                  <ClockIcon className="w-4 h-4 mr-1" />
                                  Locked
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Progress and Current Module */}
          <div className="space-y-4">
            {/* Overall Progress */}
            <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
              <CardContent className="p-4">
                <h3 className="font-bold text-green-800 font-serif mb-3">Your Progress</h3>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-green-700">Overall Completion</span>
                      <span className="text-green-800 font-medium">
                        {Math.round(calculateOverallProgress())}%
                      </span>
                    </div>
                    <Progress value={calculateOverallProgress()} className="h-3" />
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div className="bg-white p-2 rounded">
                      <div className="text-lg font-bold text-green-800">
                        {selectedPathData.completedModules}
                      </div>
                      <div className="text-xs text-green-600">Completed</div>
                    </div>
                    <div className="bg-white p-2 rounded">
                      <div className="text-lg font-bold text-green-800">
                        {Math.round(selectedPathData.estimatedHours * (selectedPathData.completedModules / selectedPathData.totalModules))}h
                      </div>
                      <div className="text-xs text-green-600">Time Invested</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Next Recommended Module */}
            {getNextRecommendedModule() && (
              <Card className="border-2 border-blue-400 bg-gradient-to-br from-blue-50 to-indigo-50">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <StarIcon className="w-5 h-5 text-blue-600" />
                    <h3 className="font-bold text-blue-800 font-serif">Recommended Next</h3>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium text-blue-800">
                        {getNextRecommendedModule()?.title}
                      </h4>
                      <p className="text-sm text-blue-600 mt-1">
                        {getNextRecommendedModule()?.description}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <ClockIcon className="w-4 h-4 text-blue-500" />
                      <span className="text-sm text-blue-600">
                        {getNextRecommendedModule()?.duration} minutes
                      </span>
                    </div>
                    <Button 
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => getNextRecommendedModule() && startModule(getNextRecommendedModule()!)}
                    >
                      <PlayCircleIcon className="w-4 h-4 mr-2" />
                      Start Learning
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Current Module Details */}
            {currentModule && (
              <Card className="border-2 border-purple-400 bg-gradient-to-br from-purple-50 to-pink-50">
                <CardContent className="p-4">
                  <h3 className="font-bold text-purple-800 font-serif mb-3">Currently Learning</h3>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium text-purple-800">{currentModule.title}</h4>
                      <Progress value={currentModule.progress} className="mt-2 h-2" />
                      <p className="text-xs text-purple-600 mt-1">
                        {currentModule.progress}% complete
                      </p>
                    </div>
                    <div>
                      <h5 className="text-sm font-medium text-purple-700 mb-2">Key Takeaways:</h5>
                      <ul className="text-xs text-purple-600 space-y-1">
                        {currentModule.keyTakeaways.map((takeaway, index) => (
                          <li key={index}>• {takeaway}</li>
                        ))}
                      </ul>
                    </div>
                    <Button 
                      size="sm" 
                      className="w-full"
                      onClick={() => completeModule(currentModule.id)}
                    >
                      <CheckCircleIcon className="w-4 h-4 mr-2" />
                      Mark Complete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Achievement Badges */}
            <Card className="border-2 border-yellow-200 bg-gradient-to-br from-yellow-50 to-orange-50">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2 mb-3">
                  <AwardIcon className="w-5 h-5 text-yellow-600" />
                  <h3 className="font-bold text-yellow-800 font-serif">Achievements</h3>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="text-center p-2 bg-white rounded">
                    <div className="text-lg">🏆</div>
                    <div className="text-xs text-yellow-600">First Module</div>
                  </div>
                  <div className="text-center p-2 bg-white rounded opacity-50">
                    <div className="text-lg">🎯</div>
                    <div className="text-xs text-yellow-600">50% Complete</div>
                  </div>
                  <div className="text-center p-2 bg-white rounded opacity-50">
                    <div className="text-lg">🎓</div>
                    <div className="text-xs text-yellow-600">Graduate</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
        <CardContent className="p-4">
          <h3 className="font-bold text-green-800 font-serif mb-3">One-Click Learning Actions</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button variant="outline" className="flex flex-col h-auto p-3">
              <ShieldIcon className="w-6 h-6 mb-2 text-green-600" />
              <span className="text-sm">Security Checkup</span>
            </Button>
            <Button variant="outline" className="flex flex-col h-auto p-3">
              <TrendingUpIcon className="w-6 h-6 mb-2 text-green-600" />
              <span className="text-sm">Portfolio Analysis</span>
            </Button>
            <Button variant="outline" className="flex flex-col h-auto p-3">
              <BookOpenIcon className="w-6 h-6 mb-2 text-green-600" />
              <span className="text-sm">Daily Tip</span>
            </Button>
            <Button variant="outline" className="flex flex-col h-auto p-3">
              <BrainIcon className="w-6 h-6 mb-2 text-green-600" />
              <span className="text-sm">Quiz Me</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}