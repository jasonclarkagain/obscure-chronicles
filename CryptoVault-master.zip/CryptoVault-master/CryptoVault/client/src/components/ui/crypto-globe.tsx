import { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { 
  GlobeIcon, 
  PlayIcon, 
  PauseIcon, 
  RotateCcwIcon,
  EyeIcon,
  EyeOffIcon,
  SettingsIcon,
  ZoomInIcon,
  ZoomOutIcon
} from 'lucide-react';

interface MarketPin {
  id: string;
  city: string;
  country: string;
  lat: number;
  lng: number;
  activity: 'high' | 'medium' | 'low';
  volume: number; // in billions
  status: 'open' | 'closed';
  color: string;
  height: number;
  flag: string;
}

export function CryptoGlobe() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const [isRotating, setIsRotating] = useState(false); // Start with manual control
  const [showPins, setShowPins] = useState(true);
  const [rotationSpeed, setRotationSpeed] = useState(0.005);
  const [zoom, setZoom] = useState(1);
  const [selectedMarket, setSelectedMarket] = useState<MarketPin | null>(null);

  // Google Earth-style movement controls
  const [isDragging, setIsDragging] = useState(false);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
  const [rotationX, setRotationX] = useState(0); // Vertical rotation (tilt)
  const [rotationY, setRotationY] = useState(0); // Horizontal rotation
  const [momentum, setMomentum] = useState({ x: 0, y: 0 });
  const [isDecelerating, setIsDecelerating] = useState(false);

  // Market locations with authentic geographic coordinates
  const marketPins: MarketPin[] = [
    {
      id: 'tokyo',
      city: 'Tokyo',
      country: 'Japan',
      lat: 35.6762,
      lng: 139.6503,
      activity: 'high',
      volume: 24.8,
      status: 'open',
      color: '#10B981', // green for high activity
      height: 0.8,
      flag: '🇯🇵'
    },
    {
      id: 'seoul',
      city: 'Seoul',
      country: 'South Korea',
      lat: 37.5665,
      lng: 126.9780,
      activity: 'high',
      volume: 18.2,
      status: 'open',
      color: '#10B981',
      height: 0.7,
      flag: '🇰🇷'
    },
    {
      id: 'singapore',
      city: 'Singapore',
      country: 'Singapore',
      lat: 1.3521,
      lng: 103.8198,
      activity: 'medium',
      volume: 12.5,
      status: 'open',
      color: '#F59E0B', // yellow for medium activity
      height: 0.5,
      flag: '🇸🇬'
    },
    {
      id: 'hongkong',
      city: 'Hong Kong',
      country: 'Hong Kong SAR',
      lat: 22.3193,
      lng: 114.1694,
      activity: 'high',
      volume: 15.3,
      status: 'open',
      color: '#10B981',
      height: 0.6,
      flag: '🇭🇰'
    },
    {
      id: 'sydney',
      city: 'Sydney',
      country: 'Australia',
      lat: -33.8688,
      lng: 151.2093,
      activity: 'medium',
      volume: 6.7,
      status: 'open',
      color: '#F59E0B',
      height: 0.3,
      flag: '🇦🇺'
    },
    {
      id: 'mumbai',
      city: 'Mumbai',
      country: 'India',
      lat: 19.0760,
      lng: 72.8777,
      activity: 'medium',
      volume: 9.2,
      status: 'open',
      color: '#F59E0B',
      height: 0.4,
      flag: '🇮🇳'
    },
    {
      id: 'london',
      city: 'London',
      country: 'United Kingdom',
      lat: 51.5074,
      lng: -0.1278,
      activity: 'high',
      volume: 31.4,
      status: 'open',
      color: '#10B981',
      height: 1.0,
      flag: '🇬🇧'
    },
    {
      id: 'frankfurt',
      city: 'Frankfurt',
      country: 'Germany',
      lat: 50.1109,
      lng: 8.6821,
      activity: 'medium',
      volume: 19.7,
      status: 'open',
      color: '#F59E0B',
      height: 0.7,
      flag: '🇩🇪'
    },
    {
      id: 'zurich',
      city: 'Zurich',
      country: 'Switzerland',
      lat: 47.3769,
      lng: 8.5417,
      activity: 'medium',
      volume: 8.9,
      status: 'open',
      color: '#F59E0B',
      height: 0.4,
      flag: '🇨🇭'
    },
    {
      id: 'amsterdam',
      city: 'Amsterdam',
      country: 'Netherlands',
      lat: 52.3676,
      lng: 4.9041,
      activity: 'medium',
      volume: 11.4,
      status: 'open',
      color: '#F59E0B',
      height: 0.5,
      flag: '🇳🇱'
    },
    {
      id: 'paris',
      city: 'Paris',
      country: 'France',
      lat: 48.8566,
      lng: 2.3522,
      activity: 'medium',
      volume: 13.8,
      status: 'open',
      color: '#F59E0B',
      height: 0.6,
      flag: '🇫🇷'
    },
    {
      id: 'dubai',
      city: 'Dubai',
      country: 'UAE',
      lat: 25.2048,
      lng: 55.2708,
      activity: 'medium',
      volume: 4.2,
      status: 'open',
      color: '#F59E0B',
      height: 0.2,
      flag: '🇦🇪'
    },
    {
      id: 'newyork',
      city: 'New York',
      country: 'United States',
      lat: 40.7128,
      lng: -74.0060,
      activity: 'high',
      volume: 42.6,
      status: 'open',
      color: '#10B981',
      height: 1.2,
      flag: '🇺🇸'
    },
    {
      id: 'toronto',
      city: 'Toronto',
      country: 'Canada',
      lat: 43.6532,
      lng: -79.3832,
      activity: 'medium',
      volume: 7.3,
      status: 'open',
      color: '#F59E0B',
      height: 0.3,
      flag: '🇨🇦'
    },
    {
      id: 'mexicocity',
      city: 'Mexico City',
      country: 'Mexico',
      lat: 19.4326,
      lng: -99.1332,
      activity: 'low',
      volume: 3.1,
      status: 'open',
      color: '#EF4444', // red for low activity
      height: 0.2,
      flag: '🇲🇽'
    },
    {
      id: 'saopaulo',
      city: 'São Paulo',
      country: 'Brazil',
      lat: -23.5505,
      lng: -46.6333,
      activity: 'low',
      volume: 5.8,
      status: 'closed',
      color: '#6B7280', // gray for closed
      height: 0.2,
      flag: '🇧🇷'
    }
  ];

  // Remove the global rotation variable - we'll use state instead

  // Convert lat/lng to 3D sphere coordinates with rotation matrices
  const latLngToXYZ = (lat: number, lng: number, radius: number) => {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lng + 180) * (Math.PI / 180);
    
    let x = -(radius * Math.sin(phi) * Math.cos(theta));
    let y = radius * Math.cos(phi);
    let z = radius * Math.sin(phi) * Math.sin(theta);

    // Apply Y-axis rotation (horizontal spinning)
    const cosY = Math.cos(rotationY);
    const sinY = Math.sin(rotationY);
    const newX = x * cosY - z * sinY;
    const newZ = x * sinY + z * cosY;
    x = newX;
    z = newZ;

    // Apply X-axis rotation (vertical tilting)
    const cosX = Math.cos(rotationX);
    const sinX = Math.sin(rotationX);
    const newY = y * cosX - z * sinX;
    const finalZ = y * sinX + z * cosX;
    y = newY;
    z = finalZ;

    return { x, y, z };
  };

  // Handle mouse events for Google Earth-style controls
  const handleMouseDown = (event: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setIsDecelerating(false);
    setLastMousePos({ x: event.clientX, y: event.clientY });
    setMomentum({ x: 0, y: 0 });
  };

  const handleMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return;

    const deltaX = event.clientX - lastMousePos.x;
    const deltaY = event.clientY - lastMousePos.y;

    // Calculate momentum for smooth deceleration
    setMomentum({ x: deltaX * 0.01, y: deltaY * 0.01 });

    // Update rotations based on mouse movement
    setRotationY(prev => prev + deltaX * 0.01);
    setRotationX(prev => Math.max(-Math.PI/3, Math.min(Math.PI/3, prev - deltaY * 0.01))); // Limit vertical rotation

    setLastMousePos({ x: event.clientX, y: event.clientY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    if (Math.abs(momentum.x) > 0.001 || Math.abs(momentum.y) > 0.001) {
      setIsDecelerating(true);
    }
  };

  const handleWheel = (event: React.WheelEvent<HTMLCanvasElement>) => {
    event.preventDefault();
    const zoomFactor = event.deltaY > 0 ? 0.9 : 1.1;
    setZoom(prev => Math.max(0.3, Math.min(3, prev * zoomFactor)));
  };

  // Draw the globe and market pins
  const drawGlobe = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    if (width <= 0 || height <= 0) {
      console.log('Invalid canvas dimensions:', width, 'x', height);
      return;
    }

    const centerX = width / 2;
    const centerY = height / 2;
    const globeRadius = Math.min(width, height) * 0.35 * zoom;

    // Clear canvas
    ctx.fillStyle = '#0F172A'; // dark background
    ctx.fillRect(0, 0, width, height);

    // Draw stars background
    for (let i = 0; i < 100; i++) {
      const x = Math.random() * width;
      const y = Math.random() * height;
      const opacity = Math.random();
      ctx.fillStyle = `rgba(255, 255, 255, ${opacity * 0.5})`;
      ctx.fillRect(x, y, 1, 1);
    }

    // Draw globe outline
    ctx.beginPath();
    ctx.arc(centerX, centerY, globeRadius, 0, 2 * Math.PI);
    ctx.fillStyle = 'rgba(16, 185, 129, 0.1)'; // subtle green fill
    ctx.fill();
    ctx.strokeStyle = '#10B981';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw latitude lines
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.3)';
    ctx.lineWidth = 1;
    for (let lat = -60; lat <= 60; lat += 30) {
      const y = centerY - (lat / 90) * globeRadius;
      const radius = Math.cos(lat * Math.PI / 180) * globeRadius;
      
      ctx.beginPath();
      ctx.ellipse(centerX, y, radius, radius * 0.3, 0, 0, 2 * Math.PI);
      ctx.stroke();
    }

    // Draw longitude lines (meridians)
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.2)';
    for (let lng = 0; lng < 360; lng += 30) {
      ctx.beginPath();
      for (let lat = -90; lat <= 90; lat += 5) {
        const coords = latLngToXYZ(lat, lng, globeRadius);
        if (coords.z > 0) { // Only draw visible parts
          const screenX = centerX + coords.x;
          const screenY = centerY - coords.y;
          if (lat === -90) {
            ctx.moveTo(screenX, screenY);
          } else {
            ctx.lineTo(screenX, screenY);
          }
        }
      }
      ctx.stroke();
    }

    // Draw market pins if enabled
    if (showPins) {
      // Sort pins by depth for proper rendering order
      const pinsWithDepth = marketPins.map(pin => {
        const coords = latLngToXYZ(pin.lat, pin.lng, globeRadius);
        return { pin, coords, depth: coords.z };
      }).sort((a, b) => a.depth - b.depth);

      pinsWithDepth.forEach(({ pin, coords }) => {
        // Only draw pins on the front side of the globe
        if (coords.z > 0) {
          const screenX = centerX + coords.x;
          const screenY = centerY - coords.y;
          
          // Draw pin base
          ctx.fillStyle = pin.color;
          ctx.beginPath();
          ctx.arc(screenX, screenY, 4, 0, 2 * Math.PI);
          ctx.fill();
          
          // Draw pin height (stick)
          const pinHeight = pin.height * 40; // scale height
          ctx.strokeStyle = pin.color;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(screenX, screenY);
          ctx.lineTo(screenX, screenY - pinHeight);
          ctx.stroke();
          
          // Draw pin top
          ctx.fillStyle = pin.color;
          ctx.beginPath();
          ctx.arc(screenX, screenY - pinHeight, 3, 0, 2 * Math.PI);
          ctx.fill();
          
          // Add glow effect for high activity
          if (pin.activity === 'high') {
            ctx.shadowColor = pin.color;
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(screenX, screenY - pinHeight, 5, 0, 2 * Math.PI);
            ctx.fill();
            ctx.shadowBlur = 0;
          }
          
          // Draw city label for selected market
          if (selectedMarket?.id === pin.id) {
            ctx.fillStyle = '#FFFFFF';
            ctx.font = '12px sans-serif';
            ctx.fillText(pin.city, screenX + 10, screenY - 10);
          }
        }
      });
    }
  };

  // Animation loop with momentum and deceleration
  const animate = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    
    drawGlobe(ctx, width, height);
    
    // Auto rotation mode
    if (isRotating && !isDragging) {
      setRotationY(prev => prev + rotationSpeed);
    }
    
    // Apply momentum deceleration
    if (isDecelerating && !isDragging) {
      setRotationY(prev => prev + momentum.x);
      setRotationX(prev => Math.max(-Math.PI/3, Math.min(Math.PI/3, prev + momentum.y)));
      
      // Reduce momentum
      setMomentum(prev => ({
        x: prev.x * 0.95,
        y: prev.y * 0.95
      }));
      
      // Stop deceleration when momentum is very small
      if (Math.abs(momentum.x) < 0.001 && Math.abs(momentum.y) < 0.001) {
        setIsDecelerating(false);
        setMomentum({ x: 0, y: 0 });
      }
    }
    
    animationFrameRef.current = requestAnimationFrame(animate);
  };

  // Handle canvas click for market selection (only if not dragging)
  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) return; // Don't select markets while dragging
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = event.clientX - rect.left;
    const clickY = event.clientY - rect.top;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const globeRadius = Math.min(canvas.width, canvas.height) * 0.35 * zoom;

    // Check if click is near any market pin
    let closestMarket: MarketPin | null = null;
    let closestDistance = Infinity;

    marketPins.forEach(pin => {
      const coords = latLngToXYZ(pin.lat, pin.lng, globeRadius);
      
      if (coords.z > 0) {
        const screenX = centerX + coords.x;
        const screenY = centerY - coords.y;
        
        const distance = Math.sqrt((clickX - screenX) ** 2 + (clickY - screenY) ** 2);
        if (distance < 20 && distance < closestDistance) {
          closestDistance = distance;
          closestMarket = pin;
        }
      }
    });

    setSelectedMarket(closestMarket);
  };

  // Initialize canvas and start animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.style.display = 'block';
      canvas.style.width = '100%';
      canvas.style.height = '384px';
      canvas.width = 800;
      canvas.height = 384;
    };

    // Immediate resize and start animation
    resizeCanvas();
    
    // Ensure animation starts after canvas is ready
    setTimeout(() => {
      animate();
    }, 100);
    
    window.addEventListener('resize', resizeCanvas);

    // Add global mouse event listeners for drag functionality
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        const deltaX = e.clientX - lastMousePos.x;
        const deltaY = e.clientY - lastMousePos.y;

        setMomentum({ x: deltaX * 0.01, y: deltaY * 0.01 });
        setRotationY(prev => prev + deltaX * 0.01);
        setRotationX(prev => Math.max(-Math.PI/3, Math.min(Math.PI/3, prev - deltaY * 0.01)));
        setLastMousePos({ x: e.clientX, y: e.clientY });
      }
    };

    const handleGlobalMouseUp = () => {
      if (isDragging) {
        setIsDragging(false);
        if (Math.abs(momentum.x) > 0.001 || Math.abs(momentum.y) > 0.001) {
          setIsDecelerating(true);
        }
      }
    };

    document.addEventListener('mousemove', handleGlobalMouseMove);
    document.addEventListener('mouseup', handleGlobalMouseUp);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      document.removeEventListener('mousemove', handleGlobalMouseMove);
      document.removeEventListener('mouseup', handleGlobalMouseUp);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isDragging, lastMousePos, momentum, isRotating, showPins, rotationSpeed, zoom, selectedMarket, rotationX, rotationY, isDecelerating]);

  // Ensure canvas is properly initialized
  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      // Force canvas to be visible and properly sized
      canvas.style.display = 'block';
      canvas.style.width = '100%';
      canvas.style.height = '384px';
      
      // Set actual canvas dimensions
      canvas.width = 800;
      canvas.height = 384;
      
      console.log('Globe canvas initialized:', canvas.width, 'x', canvas.height);
    }
  }, []);

  const totalVolume = marketPins.reduce((sum, pin) => sum + pin.volume, 0);
  const activeMarkets = marketPins.filter(pin => pin.status === 'open').length;
  const highActivityMarkets = marketPins.filter(pin => pin.activity === 'high').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <MonopolyBanker size="md" />
          <div>
            <h2 className="text-2xl font-bold text-green-800 font-serif">Global Crypto Markets Globe</h2>
            <p className="text-green-600">Interactive 3D visualization of worldwide trading activity</p>
          </div>
        </div>
      </div>

      {/* Globe Controls */}
      <Card className="border-2 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                onClick={() => setIsRotating(!isRotating)}
                className="border-green-300 text-green-700 hover:bg-green-50"
              >
                {isRotating ? <PauseIcon className="w-4 h-4 mr-2" /> : <PlayIcon className="w-4 h-4 mr-2" />}
                {isRotating ? 'Pause' : 'Rotate'}
              </Button>
              
              <Button
                variant="outline"
                onClick={() => setShowPins(!showPins)}
                className="border-green-300 text-green-700 hover:bg-green-50"
              >
                {showPins ? <EyeOffIcon className="w-4 h-4 mr-2" /> : <EyeIcon className="w-4 h-4 mr-2" />}
                {showPins ? 'Hide Pins' : 'Show Pins'}
              </Button>
              
              <Button
                variant="outline"
                onClick={() => {
                  setRotationX(0);
                  setRotationY(0);
                  setMomentum({ x: 0, y: 0 });
                  setIsDecelerating(false);
                  setSelectedMarket(null);
                }}
                className="border-green-300 text-green-700 hover:bg-green-50"
              >
                <RotateCcwIcon className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-green-700">Speed:</label>
                <input
                  type="range"
                  min="0.001"
                  max="0.02"
                  step="0.001"
                  value={rotationSpeed}
                  onChange={(e) => setRotationSpeed(parseFloat(e.target.value))}
                  className="w-20"
                />
              </div>
              
              <div className="flex items-center space-x-1">
                <Button
                  variant="outline"
                  onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}
                  className="border-green-300 text-green-700 hover:bg-green-50 p-2"
                >
                  <ZoomOutIcon className="w-4 h-4" />
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setZoom(Math.min(2, zoom + 0.1))}
                  className="border-green-300 text-green-700 hover:bg-green-50 p-2"
                >
                  <ZoomInIcon className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Globe and Market Info */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 3D Globe */}
        <div className="lg:col-span-2">
          <Card className="border-2 border-green-200">
            <CardContent className="p-0">
              <div className="relative w-full h-96 bg-gradient-to-br from-slate-900 to-slate-800 rounded-lg border-2 border-green-300">
                <canvas
                  ref={canvasRef}
                  onClick={handleCanvasClick}
                  onMouseDown={handleMouseDown}
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  onWheel={handleWheel}
                  width={800}
                  height={384}
                  className={`absolute inset-0 w-full h-full rounded-lg ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
                  style={{ 
                    background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
                    display: 'block'
                  }}
                />
                <div className="absolute top-2 left-2 text-white text-xs bg-black bg-opacity-70 px-2 py-1 rounded">
                  3D Globe Active
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Market Information */}
        <div className="space-y-4">
          {/* Global Stats */}
          <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
            <CardContent className="p-4">
              <h3 className="font-bold text-green-800 font-serif mb-3">Global Overview</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-green-700">Total Volume:</span>
                  <span className="font-bold text-green-800">${totalVolume.toFixed(1)}B</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700">Active Markets:</span>
                  <span className="font-bold text-green-800">{activeMarkets}/16</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700">High Activity:</span>
                  <span className="font-bold text-green-800">{highActivityMarkets}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Legend */}
          <Card className="border-2 border-green-200">
            <CardContent className="p-4">
              <h3 className="font-bold text-green-800 font-serif mb-3">Pin Legend</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-green-700">High Activity</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span className="text-green-700">Medium Activity</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-green-700">Low Activity</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                  <span className="text-green-700">Market Closed</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-green-200">
                <p className="text-xs text-green-600">Pin height represents trading volume</p>
              </div>
            </CardContent>
          </Card>

          {/* Selected Market Info */}
          {selectedMarket && (
            <Card className="border-2 border-green-400 bg-gradient-to-br from-green-100 to-emerald-100">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2 mb-3">
                  <span className="text-xl">{selectedMarket.flag}</span>
                  <h3 className="font-bold text-green-800 font-serif">{selectedMarket.city}</h3>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-green-700">Country:</span>
                    <span className="font-bold text-green-800">{selectedMarket.country}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-700">Volume:</span>
                    <span className="font-bold text-green-800">${selectedMarket.volume}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-700">Status:</span>
                    <Badge className={selectedMarket.status === 'open' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                      {selectedMarket.status.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-700">Activity:</span>
                    <Badge className={
                      selectedMarket.activity === 'high' ? 'bg-green-100 text-green-800' :
                      selectedMarket.activity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }>
                      {selectedMarket.activity.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Instructions */}
      <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
        <CardContent className="p-4">
          <h3 className="font-bold text-green-800 font-serif mb-2">Google Earth-Style Controls</h3>
          <div className="text-sm text-green-700 space-y-1">
            <p>• <strong>Drag:</strong> Click and drag to rotate the globe in any direction</p>
            <p>• <strong>Scroll:</strong> Mouse wheel to zoom in/out (0.3x to 3x)</p>
            <p>• <strong>Click:</strong> Select market pins to view detailed information</p>
            <p>• <strong>Momentum:</strong> Release mouse while dragging for smooth deceleration</p>
            <p>• Pin colors indicate activity levels, heights show trading volumes</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}