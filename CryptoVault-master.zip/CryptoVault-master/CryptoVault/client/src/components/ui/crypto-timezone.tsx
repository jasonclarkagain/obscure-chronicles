import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Globe, TrendingUp, TrendingDown, Activity, Zap, DollarSign, MapPin } from 'lucide-react';

interface MarketData {
  region: string;
  city: string;
  timezone: string;
  currentTime: string;
  marketStatus: 'open' | 'closed' | 'pre-market' | 'after-hours';
  volume24h: string;
  volumeRaw: number;
  change24h: number;
  dominantCrypto: string;
  participants: number;
  marketCap: string;
  topCrypto: { symbol: string; price: string; change: number }[];
  exchangeCount: number;
  flag: string;
  coordinates: { lat: number; lng: number };
}

const GLOBAL_MARKETS: MarketData[] = [
  {
    region: 'Asia Pacific',
    city: 'Tokyo',
    timezone: 'Asia/Tokyo',
    currentTime: '',
    marketStatus: 'open',
    volume24h: '$2.4B',
    volumeRaw: 2400000000,
    change24h: 2.3,
    dominantCrypto: 'BTC',
    participants: 1240000,
    marketCap: '$1.2T',
    topCrypto: [
      { symbol: 'BTC', price: '$43,250', change: 2.1 },
      { symbol: 'ETH', price: '$2,680', change: 1.8 },
      { symbol: 'ADA', price: '$0.52', change: 3.2 }
    ],
    exchangeCount: 12,
    flag: '🇯🇵',
    coordinates: { lat: 35.6762, lng: 139.6503 }
  },
  {
    region: 'Asia Pacific', 
    city: 'Singapore',
    timezone: 'Asia/Singapore',
    currentTime: '',
    marketStatus: 'open',
    volume24h: '$1.8B',
    volumeRaw: 1800000000,
    change24h: 1.7,
    dominantCrypto: 'ETH',
    participants: 890000,
    marketCap: '$890B',
    topCrypto: [
      { symbol: 'ETH', price: '$2,680', change: 1.7 },
      { symbol: 'BTC', price: '$43,250', change: 1.5 },
      { symbol: 'BNB', price: '$315', change: 2.8 }
    ],
    exchangeCount: 8,
    flag: '🇸🇬',
    coordinates: { lat: 1.3521, lng: 103.8198 }
  },
  {
    region: 'Asia Pacific',
    city: 'Hong Kong',
    timezone: 'Asia/Hong_Kong',
    currentTime: '',
    marketStatus: 'open',
    volume24h: '$1.5B',
    volumeRaw: 1500000000,
    change24h: 0.9,
    dominantCrypto: 'USDT',
    participants: 720000,
    marketCap: '$750B',
    topCrypto: [
      { symbol: 'USDT', price: '$1.00', change: 0.0 },
      { symbol: 'BTC', price: '$43,250', change: 0.9 },
      { symbol: 'ETH', price: '$2,680', change: 1.1 }
    ],
    exchangeCount: 6,
    flag: '🇭🇰',
    coordinates: { lat: 22.3193, lng: 114.1694 }
  },
  {
    region: 'Asia Pacific',
    city: 'Seoul',
    timezone: 'Asia/Seoul',
    currentTime: '',
    marketStatus: 'open',
    volume24h: '$1.1B',
    volumeRaw: 1100000000,
    change24h: 3.4,
    dominantCrypto: 'BTC',
    participants: 650000,
    marketCap: '$550B',
    topCrypto: [
      { symbol: 'BTC', price: '$43,250', change: 3.4 },
      { symbol: 'ETH', price: '$2,680', change: 2.9 },
      { symbol: 'XRP', price: '$0.58', change: 4.1 }
    ],
    exchangeCount: 5,
    flag: '🇰🇷',
    coordinates: { lat: 37.5665, lng: 126.9780 }
  },
  {
    region: 'Europe',
    city: 'London',
    timezone: 'Europe/London', 
    currentTime: '',
    marketStatus: 'closed',
    volume24h: '$3.2B',
    volumeRaw: 3200000000,
    change24h: -0.8,
    dominantCrypto: 'BTC',
    participants: 1560000,
    marketCap: '$1.6T',
    topCrypto: [
      { symbol: 'BTC', price: '$43,250', change: -0.8 },
      { symbol: 'ETH', price: '$2,680', change: -0.5 },
      { symbol: 'ADA', price: '$0.52', change: -1.2 }
    ],
    exchangeCount: 15,
    flag: '🇬🇧',
    coordinates: { lat: 51.5074, lng: -0.1278 }
  },
  {
    region: 'Europe',
    city: 'Frankfurt',
    timezone: 'Europe/Berlin',
    currentTime: '',
    marketStatus: 'closed',
    volume24h: '$2.1B',
    volumeRaw: 2100000000,
    change24h: -0.3,
    dominantCrypto: 'BTC',
    participants: 980000,
    marketCap: '$1.0T',
    topCrypto: [
      { symbol: 'BTC', price: '$43,250', change: -0.3 },
      { symbol: 'ETH', price: '$2,680', change: 0.1 },
      { symbol: 'DOT', price: '$7.45', change: -0.9 }
    ],
    exchangeCount: 9,
    flag: '🇩🇪',
    coordinates: { lat: 50.1109, lng: 8.6821 }
  },
  {
    region: 'Americas',
    city: 'New York',
    timezone: 'America/New_York',
    currentTime: '',
    marketStatus: 'closed',
    volume24h: '$4.7B', 
    volumeRaw: 4700000000,
    change24h: 1.2,
    dominantCrypto: 'BTC',
    participants: 2340000,
    marketCap: '$2.4T',
    topCrypto: [
      { symbol: 'BTC', price: '$43,250', change: 1.2 },
      { symbol: 'ETH', price: '$2,680', change: 0.9 },
      { symbol: 'SOL', price: '$98.50', change: 2.1 }
    ],
    exchangeCount: 18,
    flag: '🇺🇸',
    coordinates: { lat: 40.7128, lng: -74.0060 }
  },
  {
    region: 'Americas',
    city: 'San Francisco',
    timezone: 'America/Los_Angeles',
    currentTime: '',
    marketStatus: 'closed',
    volume24h: '$2.8B',
    volumeRaw: 2800000000,
    change24h: 1.8,
    dominantCrypto: 'ETH',
    participants: 1450000,
    marketCap: '$1.4T',
    topCrypto: [
      { symbol: 'ETH', price: '$2,680', change: 1.8 },
      { symbol: 'BTC', price: '$43,250', change: 1.5 },
      { symbol: 'MATIC', price: '$0.85', change: 3.2 }
    ],
    exchangeCount: 12,
    flag: '🇺🇸',
    coordinates: { lat: 37.7749, lng: -122.4194 }
  },
  {
    region: 'Middle East & Africa',
    city: 'Dubai',
    timezone: 'Asia/Dubai',
    currentTime: '',
    marketStatus: 'open',
    volume24h: '$950M',
    volumeRaw: 950000000,
    change24h: 1.9,
    dominantCrypto: 'BTC',
    participants: 420000,
    marketCap: '$475B',
    topCrypto: [
      { symbol: 'BTC', price: '$43,250', change: 1.9 },
      { symbol: 'ETH', price: '$2,680', change: 1.6 },
      { symbol: 'BNB', price: '$315', change: 2.3 }
    ],
    exchangeCount: 6,
    flag: '🇦🇪',
    coordinates: { lat: 25.2048, lng: 55.2708 }
  },
  {
    region: 'Oceania',
    city: 'Sydney',
    timezone: 'Australia/Sydney',
    currentTime: '',
    marketStatus: 'open',
    volume24h: '$850M',
    volumeRaw: 850000000,
    change24h: 1.1,
    dominantCrypto: 'BTC',
    participants: 380000,
    marketCap: '$425B',
    topCrypto: [
      { symbol: 'BTC', price: '$43,250', change: 1.1 },
      { symbol: 'ETH', price: '$2,680', change: 0.8 },
      { symbol: 'MATIC', price: '$0.85', change: 1.9 }
    ],
    exchangeCount: 5,
    flag: '🇦🇺',
    coordinates: { lat: -33.8688, lng: 151.2093 }
  }
];

export function CryptoTimezone() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Update times every second
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Calculate real-time market data
  const getMarketData = () => {
    return GLOBAL_MARKETS.map(market => {
      // Simulate real-time local time
      const now = new Date();
      const localTime = new Date(now.toLocaleString("en-US", { timeZone: market.timezone }));
      
      // Determine market status based on actual time
      const hour = localTime.getHours();
      let status: MarketData['marketStatus'] = 'closed';
      
      if (hour >= 9 && hour < 18) {
        status = 'open';
      } else if (hour >= 8 && hour < 9) {
        status = 'pre-market';
      } else if (hour >= 18 && hour < 20) {
        status = 'after-hours';
      }

      return {
        ...market,
        currentTime: localTime.toLocaleTimeString('en-US', { 
          hour12: true, 
          hour: '2-digit', 
          minute: '2-digit',
          second: '2-digit'
        }),
        marketStatus: status
      };
    });
  };

  const liveMarkets = getMarketData();
  const openMarkets = liveMarkets.filter(m => m.marketStatus === 'open');
  const totalVolume = liveMarkets.reduce((sum, market) => sum + market.volumeRaw, 0);

  const filteredMarkets = selectedRegion 
    ? liveMarkets.filter(market => market.region === selectedRegion)
    : liveMarkets;

  const regions = [...new Set(liveMarkets.map(market => market.region))];

  return (
    <div className="space-y-6">
      {/* Global Market Pulse */}
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-700 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-blue-400" />
            Global Crypto Market Pulse
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse ml-2"></div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="bg-white/10 rounded-lg p-4">
              <Activity className="w-6 h-6 text-green-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-400">{openMarkets.length}</p>
              <p className="text-sm text-gray-300">Active Markets</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <DollarSign className="w-6 h-6 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-400">${(totalVolume / 1e9).toFixed(1)}B</p>
              <p className="text-sm text-gray-300">24h Volume</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <TrendingUp className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-yellow-400">
                {liveMarkets.filter(m => m.change24h > 0).length}
              </p>
              <p className="text-sm text-gray-300">Bullish Regions</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <Zap className="w-6 h-6 text-orange-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-400">
                {liveMarkets.reduce((sum, m) => sum + m.participants, 0).toLocaleString()}
              </p>
              <p className="text-sm text-gray-300">Active Traders</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Region Filter */}
      <Card className="bg-gradient-to-r from-gray-900 to-slate-900 border-gray-700 text-white">
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-2 mb-4">
            <Button
              size="sm"
              variant={selectedRegion === null ? 'default' : 'outline'}
              onClick={() => setSelectedRegion(null)}
              className={selectedRegion === null ? 'bg-green-600 hover:bg-green-700' : 'text-white border-gray-600 hover:bg-gray-700'}
            >
              All Regions
            </Button>
            {regions.map(region => (
              <Button
                key={region}
                size="sm"
                variant={selectedRegion === region ? 'default' : 'outline'}
                onClick={() => setSelectedRegion(region)}
                className={selectedRegion === region ? 'bg-blue-600 hover:bg-blue-700' : 'text-white border-gray-600 hover:bg-gray-700'}
              >
                {region}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Market Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMarkets.map(market => (
          <Card key={market.city} className="bg-gradient-to-br from-gray-900 to-slate-900 border-gray-700 text-white hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{market.flag}</span>
                  <div>
                    <h3 className="font-bold text-lg">{market.city}</h3>
                    <p className="text-gray-400 text-sm">{market.region}</p>
                  </div>
                </div>
                <Badge 
                  variant={market.marketStatus === 'open' ? 'default' : 'secondary'}
                  className={`${
                    market.marketStatus === 'open' 
                      ? 'bg-green-600 hover:bg-green-700' 
                      : market.marketStatus === 'closed'
                      ? 'bg-red-600 hover:bg-red-700'
                      : 'bg-yellow-600 hover:bg-yellow-700'
                  } text-white`}
                >
                  <div className={`w-2 h-2 rounded-full mr-2 ${
                    market.marketStatus === 'open' ? 'bg-green-400 animate-pulse' : 'bg-gray-400'
                  }`}></div>
                  {market.marketStatus.toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Local Time */}
              <div className="flex items-center gap-2 text-center">
                <Clock className="w-4 h-4 text-blue-400" />
                <span className="text-xl font-mono font-bold text-blue-400">
                  {market.currentTime}
                </span>
                <span className="text-gray-400 text-sm">({market.timezone})</span>
              </div>

              {/* Market Stats */}
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-400">24h Volume</p>
                  <p className="font-bold text-lg">{market.volume24h}</p>
                </div>
                <div>
                  <p className="text-gray-400">Market Cap</p>
                  <p className="font-bold text-lg">{market.marketCap}</p>
                </div>
                <div>
                  <p className="text-gray-400">24h Change</p>
                  <p className={`font-bold text-lg ${market.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {market.change24h >= 0 ? '+' : ''}{market.change24h}%
                  </p>
                </div>
                <div>
                  <p className="text-gray-400">Exchanges</p>
                  <p className="font-bold text-lg">{market.exchangeCount}</p>
                </div>
              </div>

              {/* Top Cryptocurrencies */}
              <div>
                <p className="text-gray-400 text-sm mb-2">Top Cryptocurrencies</p>
                <div className="space-y-1">
                  {market.topCrypto.map(crypto => (
                    <div key={crypto.symbol} className="flex justify-between items-center text-xs">
                      <span className="font-mono">{crypto.symbol}</span>
                      <span>{crypto.price}</span>
                      <span className={crypto.change >= 0 ? 'text-green-400' : 'text-red-400'}>
                        {crypto.change >= 0 ? '+' : ''}{crypto.change}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Activity Indicator */}
              <div className="flex items-center justify-between pt-2 border-t border-gray-700">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-purple-400" />
                  <span className="text-sm text-gray-400">Dominant: {market.dominantCrypto}</span>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-400">{market.participants.toLocaleString()} traders</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Auto-refresh indicator */}
      <div className="text-center text-gray-400 text-sm">
        <p>Real-time data • Updates every second • {currentTime.toLocaleString()}</p>
      </div>
    </div>
  );
}