import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { GlobeIcon, PlayIcon, PauseIcon, ZoomInIcon, ZoomOutIcon } from 'lucide-react';

interface MarketPin {
  id: string;
  city: string;
  country: string;
  lat: number;
  lng: number;
  activity: 'high' | 'medium' | 'low';
  volume: number;
  status: 'open' | 'closed';
  flag: string;
}

export function SimpleCryptoGlobe() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rotationRef = useRef(0);
  const [isRotating, setIsRotating] = useState(true);
  const [selectedMarket, setSelectedMarket] = useState<MarketPin | null>(null);
  const [zoom, setZoom] = useState(1);

  const marketPins: MarketPin[] = [
    { id: 'tokyo', city: 'Tokyo', country: 'Japan', lat: 35.68, lng: 139.65, activity: 'high', volume: 24.8, status: 'open', flag: '🇯🇵' },
    { id: 'london', city: 'London', country: 'UK', lat: 51.51, lng: -0.13, activity: 'high', volume: 31.4, status: 'open', flag: '🇬🇧' },
    { id: 'newyork', city: 'New York', country: 'USA', lat: 40.71, lng: -74.01, activity: 'high', volume: 42.3, status: 'closed', flag: '🇺🇸' },
    { id: 'singapore', city: 'Singapore', country: 'Singapore', lat: 1.35, lng: 103.82, activity: 'medium', volume: 12.5, status: 'open', flag: '🇸🇬' },
    { id: 'hongkong', city: 'Hong Kong', country: 'Hong Kong', lat: 22.32, lng: 114.17, activity: 'medium', volume: 15.3, status: 'open', flag: '🇭🇰' },
    { id: 'sydney', city: 'Sydney', country: 'Australia', lat: -33.87, lng: 151.21, activity: 'medium', volume: 6.7, status: 'open', flag: '🇦🇺' }
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size for mobile responsiveness
    const setCanvasSize = () => {
      const container = canvas.parentElement;
      if (container) {
        const width = Math.min(container.offsetWidth, 800);
        const height = Math.min(width * 0.6, 480);
        
        canvas.width = width;
        canvas.height = height;
        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;
      }
    };

    setCanvasSize();
    window.addEventListener('resize', setCanvasSize);

    let animationFrame: number;

    const drawGlobe = () => {
      const { width, height } = canvas;
      const centerX = width / 2;
      const centerY = height / 2;
      const radius = Math.min(width, height) * 0.35 * zoom;

      // Clear canvas
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, width, height);

      // Draw globe outline with gradient
      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
      gradient.addColorStop(0, '#1E40AF');
      gradient.addColorStop(0.7, '#3730A3');
      gradient.addColorStop(1, '#1E1B4B');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.fill();

      // Draw grid lines
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.3)';
      ctx.lineWidth = 1;
      
      // Longitude lines
      for (let i = 0; i < 12; i++) {
        const angle = (i * Math.PI) / 6 + rotationRef.current;
        const x1 = centerX + Math.cos(angle) * radius;
        const y1 = centerY;
        const x2 = centerX - Math.cos(angle) * radius;
        const y2 = centerY;
        
        ctx.beginPath();
        ctx.ellipse(centerX, centerY, radius * Math.abs(Math.cos(angle)), radius, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Latitude lines
      for (let i = 1; i < 6; i++) {
        const latRadius = radius * Math.sin((i * Math.PI) / 6);
        const latY = centerY - radius * Math.cos((i * Math.PI) / 6);
        
        ctx.beginPath();
        ctx.arc(centerX, latY, latRadius, 0, Math.PI * 2);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.arc(centerX, centerY + (centerY - latY), latRadius, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Draw market pins
      marketPins.forEach(pin => {
        const pinAngle = (pin.lng * Math.PI) / 180 + rotationRef.current;
        const latAngle = (pin.lat * Math.PI) / 180;
        
        // 3D projection
        const x = centerX + Math.cos(pinAngle) * Math.cos(latAngle) * radius;
        const y = centerY - Math.sin(latAngle) * radius;
        const z = Math.sin(pinAngle) * Math.cos(latAngle);
        
        // Only draw pins on the visible side
        if (z > -0.1) {
          const size = pin.activity === 'high' ? 8 : pin.activity === 'medium' ? 6 : 4;
          const pulseSize = size + Math.sin(Date.now() / 500 + pin.lng) * 2;
          
          // Pin glow
          const pinGradient = ctx.createRadialGradient(x, y, 0, x, y, pulseSize * 2);
          pinGradient.addColorStop(0, pin.status === 'open' ? '#10B981' : '#EF4444');
          pinGradient.addColorStop(1, 'transparent');
          ctx.fillStyle = pinGradient;
          ctx.fillRect(x - pulseSize * 2, y - pulseSize * 2, pulseSize * 4, pulseSize * 4);
          
          // Pin dot
          ctx.fillStyle = pin.status === 'open' ? '#10B981' : '#EF4444';
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
          
          // City label
          ctx.fillStyle = '#FFFFFF';
          ctx.font = '12px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(pin.flag, x, y - size - 5);
          
          // Volume indicator
          if (pin.volume > 20) {
            ctx.fillStyle = '#FEF08A';
            ctx.font = '10px Arial';
            ctx.fillText(`$${pin.volume.toFixed(1)}B`, x, y + size + 15);
          }
        }
      });

      // Draw selection info
      if (selectedMarket) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        ctx.fillRect(10, 10, 200, 100);
        
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 14px Arial';
        ctx.textAlign = 'left';
        ctx.fillText(`${selectedMarket.city}, ${selectedMarket.country}`, 20, 30);
        
        ctx.font = '12px Arial';
        ctx.fillText(`Volume: $${selectedMarket.volume}B`, 20, 50);
        ctx.fillText(`Status: ${selectedMarket.status}`, 20, 70);
        ctx.fillText(`Activity: ${selectedMarket.activity}`, 20, 90);
      }
    };

    // Animation loop
    const animate = () => {
      if (isRotating) {
        rotationRef.current += 0.01;
      }
      drawGlobe();
      animationFrame = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', setCanvasSize);
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [selectedMarket, zoom]);

  // Handle canvas clicks
  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    // Simple click detection - find nearest market
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(canvas.width, canvas.height) * 0.35 * zoom;

    let closestMarket: MarketPin | null = null;
    let closestDistance = Infinity;

    marketPins.forEach(pin => {
      const pinAngle = (pin.lng * Math.PI) / 180 + rotationRef.current;
      const latAngle = (pin.lat * Math.PI) / 180;
      
      const pinX = centerX + Math.cos(pinAngle) * Math.cos(latAngle) * radius;
      const pinY = centerY - Math.sin(latAngle) * radius;
      
      const distance = Math.sqrt((x - pinX) ** 2 + (y - pinY) ** 2);
      
      if (distance < 30 && distance < closestDistance) {
        closestDistance = distance;
        closestMarket = pin;
      }
    });

    setSelectedMarket(closestMarket);
  };

  return (
    <Card className="bg-gradient-to-br from-slate-900 to-gray-900 border-gray-700 text-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GlobeIcon className="w-5 h-5 text-blue-400" />
          Global Crypto Markets
        </CardTitle>
        <div className="flex gap-2 flex-wrap">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setIsRotating(!isRotating)}
            className="text-white border-gray-600 hover:bg-gray-700"
          >
            {isRotating ? <PauseIcon className="w-4 h-4" /> : <PlayIcon className="w-4 h-4" />}
            {isRotating ? 'Pause' : 'Rotate'}
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setZoom(Math.min(zoom + 0.2, 2))}
            className="text-white border-gray-600 hover:bg-gray-700"
          >
            <ZoomInIcon className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setZoom(Math.max(zoom - 0.2, 0.5))}
            className="text-white border-gray-600 hover:bg-gray-700"
          >
            <ZoomOutIcon className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <canvas
            ref={canvasRef}
            onClick={handleCanvasClick}
            className="w-full border border-gray-600 rounded-lg cursor-pointer"
            style={{ maxHeight: '400px' }}
          />
          
          {/* Market status indicators */}
          <div className="mt-4 flex gap-4 flex-wrap">
            <Badge variant="secondary" className="bg-green-500/20 text-green-400">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
              Markets Open: {marketPins.filter(p => p.status === 'open').length}
            </Badge>
            <Badge variant="secondary" className="bg-red-500/20 text-red-400">
              <div className="w-2 h-2 bg-red-400 rounded-full mr-2"></div>
              Markets Closed: {marketPins.filter(p => p.status === 'closed').length}
            </Badge>
            <Badge variant="secondary" className="bg-blue-500/20 text-blue-400">
              Total Volume: ${marketPins.reduce((sum, p) => sum + p.volume, 0).toFixed(1)}B
            </Badge>
          </div>

          {/* Instructions */}
          <p className="text-gray-400 text-sm mt-2">
            Click on market pins to view details. Use controls to pause rotation and zoom.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}