import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { AdvancedScenarios } from '@/components/ui/advanced-scenarios';
import { CalendarIcon, TrendingUpIcon, DollarSignIcon, ClockIcon, BarChart3Icon, SettingsIcon } from 'lucide-react';

interface InvestmentScenario {
  cryptocurrency: string;
  symbol: string;
  icon: string;
  color: string;
  historicalAnnualReturns: number[];
  currentPrice: number;
  marketCap: string;
  description: string;
}

interface Timeframe {
  years: number;
  label: string;
  description: string;
}

const cryptoScenarios: InvestmentScenario[] = [
  {
    cryptocurrency: 'Bitcoin',
    symbol: 'BTC',
    icon: '₿',
    color: 'orange-500',
    historicalAnnualReturns: [3700, 1400, -73, 35, 95, 300, -15, 60, -65, 160, 300, -35, 55],
    currentPrice: 43500,
    marketCap: '$850B',
    description: 'Digital gold and store of value with proven long-term appreciation'
  },
  {
    cryptocurrency: 'Ethereum',
    symbol: 'ETH',
    icon: 'Ξ',
    color: 'blue-500',
    historicalAnnualReturns: [9200, 4900, -82, 130, -6, 470, -70, 85, -45, 380, 400, -55, 90],
    currentPrice: 2650,
    marketCap: '$320B',
    description: 'Smart contract platform powering decentralized finance and Web3'
  },
  {
    cryptocurrency: 'Binance Coin',
    symbol: 'BNB',
    icon: '🟡',
    color: 'yellow-500',
    historicalAnnualReturns: [200, 1300, -22, 85, 580, 1350, -65, 240, -55, 680, 180, -45, 35],
    currentPrice: 315,
    marketCap: '$48B',
    description: 'Exchange token and smart contract platform with strong utility'
  },
  {
    cryptocurrency: 'XRP',
    symbol: 'XRP',
    icon: '✕',
    color: 'blue-600',
    historicalAnnualReturns: [36000, 200, -92, 190, -57, 340, -75, 93, -84, 280, 120, -65, 25],
    currentPrice: 0.62,
    marketCap: '$35B',
    description: 'Cross-border payment solution for financial institutions'
  },
  {
    cryptocurrency: 'Solana',
    symbol: 'SOL',
    icon: '◎',
    color: 'purple-500',
    historicalAnnualReturns: [11800, 9300, -94, 480, -75, 9500, -85, 750, -90, 1200],
    currentPrice: 98,
    marketCap: '$45B',
    description: 'High-performance blockchain for DeFi and NFT applications'
  },
  {
    cryptocurrency: 'Cardano',
    symbol: 'ADA',
    icon: '₳',
    color: 'blue-700',
    historicalAnnualReturns: [2400, 800, -90, 750, -35, 1500, -75, 150, -80, 920, 200, -60, 45],
    currentPrice: 0.52,
    marketCap: '$18B',
    description: 'Research-driven blockchain with academic peer-review approach'
  },
  {
    cryptocurrency: 'Polygon',
    symbol: 'MATIC',
    icon: '▲',
    color: 'purple-600',
    historicalAnnualReturns: [8900, 6800, -90, 1200, -70, 14500, -85, 920, -75, 1600, 350, -65, 85],
    currentPrice: 0.85,
    marketCap: '$8B',
    description: 'Ethereum Layer 2 scaling solution with low fees and fast transactions'
  },
  {
    cryptocurrency: 'Chainlink',
    symbol: 'LINK',
    icon: '🔗',
    color: 'blue-400',
    historicalAnnualReturns: [1200, 600, -76, 350, 25, 520, -68, 180, -72, 840, 280, -58, 42],
    currentPrice: 14.50,
    marketCap: '$8.5B',
    description: 'Decentralized oracle network connecting smart contracts to real-world data'
  },
  {
    cryptocurrency: 'Litecoin',
    symbol: 'LTC',
    icon: 'Ł',
    color: 'gray-500',
    historicalAnnualReturns: [1200, 240, -82, 45, 180, 380, -68, 120, -55, 260, 150, -42, 28],
    currentPrice: 73,
    marketCap: '$5.4B',
    description: 'Digital silver with faster transactions and lower fees than Bitcoin'
  },
  {
    cryptocurrency: 'Avalanche',
    symbol: 'AVAX',
    icon: '🔺',
    color: 'red-500',
    historicalAnnualReturns: [2800, 1200, -88, 680, -65, 2900, -82, 450, -78, 1850],
    currentPrice: 37,
    marketCap: '$14B',
    description: 'High-throughput smart contract platform with sub-second finality'
  }
];

const timeframes: Timeframe[] = [
  { years: 1, label: '1 Year', description: 'Short-term speculation' },
  { years: 2, label: '2 Years', description: 'Market cycle awareness' },
  { years: 3, label: '3 Years', description: 'Medium-term growth' },
  { years: 5, label: '5 Years', description: 'Long-term investment' },
  { years: 10, label: '10 Years', description: 'Wealth building horizon' },
  { years: 15, label: '15 Years', description: 'Generational wealth' }
];

const investmentAmounts = [100, 500, 1000, 2500, 5000, 10000, 25000, 50000];

export function FinancialTimeMachine() {
  const [selectedCrypto, setSelectedCrypto] = useState<InvestmentScenario>(cryptoScenarios[0]);
  const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe>(timeframes[2]);
  const [investmentAmount, setInvestmentAmount] = useState(1000);
  const [scenarios, setScenarios] = useState<any[]>([]);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const calculateScenarios = () => {
    const returns = selectedCrypto.historicalAnnualReturns;
    const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    const volatility = Math.sqrt(returns.reduce((acc, ret) => acc + Math.pow(ret - avgReturn, 2), 0) / returns.length);
    
    // Conservative, Average, and Optimistic scenarios based on historical data
    const scenarios = [
      {
        name: 'Conservative',
        description: 'Lower quartile performance',
        annualReturn: Math.max(avgReturn - volatility * 0.5, -50),
        probability: '25%',
        color: 'red',
        risk: 'Lower risk, modest gains'
      },
      {
        name: 'Expected',
        description: 'Historical average performance',
        annualReturn: avgReturn * 0.7, // Tempered expectations
        probability: '50%', 
        color: 'blue',
        risk: 'Moderate risk, steady growth'
      },
      {
        name: 'Optimistic',
        description: 'Upper quartile performance',
        annualReturn: Math.min(avgReturn + volatility * 0.3, 500),
        probability: '25%',
        color: 'green',
        risk: 'Higher risk, significant gains'
      }
    ];

    const calculatedScenarios = scenarios.map(scenario => {
      const finalValue = investmentAmount * Math.pow(1 + scenario.annualReturn / 100, selectedTimeframe.years);
      const totalGain = finalValue - investmentAmount;
      const totalReturn = (totalGain / investmentAmount) * 100;

      return {
        ...scenario,
        finalValue,
        totalGain,
        totalReturn,
        monthlyContribution: investmentAmount / (selectedTimeframe.years * 12)
      };
    });

    setScenarios(calculatedScenarios);
  };

  useEffect(() => {
    calculateScenarios();
  }, [selectedCrypto, selectedTimeframe, investmentAmount]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatPercentage = (percentage: number) => {
    return `${percentage >= 0 ? '+' : ''}${percentage.toFixed(1)}%`;
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-purple-50 to-indigo-100 border-2 border-purple-200 shadow-xl">
        <CardContent className="p-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center items-center space-x-4 mb-4">
            <MonopolyBanker size="lg" />
            <Button
              onClick={() => setShowAdvanced(!showAdvanced)}
              variant="ghost"
              className="text-purple-700 hover:bg-purple-100"
            >
              <SettingsIcon className="w-5 h-5 mr-2" />
              {showAdvanced ? 'Basic' : 'Advanced'} Mode
            </Button>
          </div>
          <h3 className="text-2xl font-bold text-purple-800 mb-2 font-serif">⏰ Financial Time Machine</h3>
          <p className="text-purple-700">Explore potential investment growth scenarios based on historical performance</p>
        </div>

        {/* Investment Parameters */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Cryptocurrency Selection */}
          <div>
            <label className="block text-sm font-bold text-purple-800 mb-3">📊 Select Cryptocurrency</label>
            <div className="space-y-2">
              {cryptoScenarios.map((crypto) => (
                <button
                  key={crypto.symbol}
                  onClick={() => setSelectedCrypto(crypto)}
                  className={`w-full p-3 rounded-lg border-2 text-left ${
                    selectedCrypto.symbol === crypto.symbol
                      ? 'border-purple-400 bg-purple-100 shadow-lg'
                      : 'border-gray-200 bg-white hover:border-purple-200'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-xl">{crypto.icon}</span>
                    <div>
                      <div className="font-bold text-purple-800">{crypto.cryptocurrency}</div>
                      <div className="text-xs text-purple-600">{crypto.marketCap} • {crypto.symbol}</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Time Horizon */}
          <div>
            <label className="block text-sm font-bold text-purple-800 mb-3">📅 Investment Horizon</label>
            <div className="space-y-2">
              {timeframes.map((timeframe) => (
                <button
                  key={timeframe.years}
                  onClick={() => setSelectedTimeframe(timeframe)}
                  className={`w-full p-3 rounded-lg border-2 text-left ${
                    selectedTimeframe.years === timeframe.years
                      ? 'border-purple-400 bg-purple-100 shadow-lg'
                      : 'border-gray-200 bg-white hover:border-purple-200'
                  }`}
                >
                  <div className="font-bold text-purple-800">{timeframe.label}</div>
                  <div className="text-xs text-purple-600">{timeframe.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Investment Amount */}
          <div>
            <label className="block text-sm font-bold text-purple-800 mb-3">💰 Investment Amount</label>
            <div className="space-y-2">
              {investmentAmounts.map((amount) => (
                <button
                  key={amount}
                  onClick={() => setInvestmentAmount(amount)}
                  className={`w-full p-3 rounded-lg border-2 text-center ${
                    investmentAmount === amount
                      ? 'border-purple-400 bg-purple-100 shadow-lg'
                      : 'border-gray-200 bg-white hover:border-purple-200'
                  }`}
                >
                  <div className="font-bold text-purple-800">{formatCurrency(amount)}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Selected Investment Summary */}
        <div className="bg-gradient-to-r from-yellow-50 to-amber-50 border-2 border-yellow-200 rounded-lg p-4 mb-6">
          <div className="flex items-center space-x-3 mb-2">
            <ClockIcon className="w-5 h-5 text-yellow-600" />
            <h4 className="font-bold text-yellow-800">Investment Scenario</h4>
          </div>
          <p className="text-yellow-700 text-sm">
            Investing <strong>{formatCurrency(investmentAmount)}</strong> in <strong>{selectedCrypto.cryptocurrency}</strong> over <strong>{selectedTimeframe.years} year{selectedTimeframe.years > 1 ? 's' : ''}</strong>
          </p>
          <p className="text-yellow-600 text-xs mt-1">{selectedCrypto.description}</p>
        </div>

        {/* Growth Scenarios */}
        <div className="space-y-4 mb-6">
          <h4 className="text-lg font-bold text-purple-800 font-serif">📈 Potential Outcomes</h4>
          {scenarios.map((scenario, index) => (
            <div
              key={scenario.name}
              className={`border-2 rounded-lg p-4 bg-gradient-to-r ${
                scenario.color === 'red' ? 'from-red-50 to-pink-50 border-red-200' :
                scenario.color === 'blue' ? 'from-blue-50 to-cyan-50 border-blue-200' :
                'from-green-50 to-emerald-50 border-green-200'
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h5 className={`font-bold text-lg ${
                    scenario.color === 'red' ? 'text-red-800' :
                    scenario.color === 'blue' ? 'text-blue-800' :
                    'text-green-800'
                  }`}>
                    {scenario.name} Scenario
                  </h5>
                  <p className={`text-sm ${
                    scenario.color === 'red' ? 'text-red-600' :
                    scenario.color === 'blue' ? 'text-blue-600' :
                    'text-green-600'
                  }`}>
                    {scenario.description} • {scenario.probability} likelihood
                  </p>
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-bold ${
                    scenario.color === 'red' ? 'text-red-800' :
                    scenario.color === 'blue' ? 'text-blue-800' :
                    'text-green-800'
                  }`}>
                    {formatCurrency(scenario.finalValue)}
                  </div>
                  <div className={`text-sm ${
                    scenario.color === 'red' ? 'text-red-600' :
                    scenario.color === 'blue' ? 'text-blue-600' :
                    'text-green-600'
                  }`}>
                    {formatPercentage(scenario.totalReturn)} return
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Total Gain:</span>
                  <span className={`ml-2 ${scenario.totalGain >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {formatCurrency(scenario.totalGain)}
                  </span>
                </div>
                <div>
                  <span className="font-medium">Annual Return:</span>
                  <span className="ml-2">{formatPercentage(scenario.annualReturn)}</span>
                </div>
              </div>
              
              <div className={`mt-2 text-xs italic ${
                scenario.color === 'red' ? 'text-red-600' :
                scenario.color === 'blue' ? 'text-blue-600' :
                'text-green-600'
              }`}>
                {scenario.risk}
              </div>
            </div>
          ))}
        </div>

        {/* Banker's Wisdom */}
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg">
          <p className="text-purple-800 font-medium italic">
            "Past performance does not guarantee future results, but it provides valuable insights for the prudent investor."
          </p>
          <p className="text-purple-600 text-sm mt-1">— Your Trusted Digital Banker</p>
        </div>

        {/* Risk Disclaimer */}
        <div className="mt-4 text-xs text-purple-600 text-center">
          <p>⚠️ This is a projection tool based on historical data. Cryptocurrency investments carry high risk and extreme volatility.</p>
        </div>
        </CardContent>
      </Card>

      {/* Advanced Scenarios */}
      {showAdvanced && <AdvancedScenarios />}
    </div>
  );
}