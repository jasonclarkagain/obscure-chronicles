import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { LightbulbIcon, TrendingUpIcon } from 'lucide-react';

interface MiniTip {
  id: string;
  title: string;
  content: string;
  icon: string;
}

const quickTips: MiniTip[] = [
  {
    id: 'security-first',
    title: 'Security First',
    content: 'Never share your recovery phrase. It\'s your master key to digital wealth.',
    icon: '🔐'
  },
  {
    id: 'diversify',
    title: 'Diversify Wisely',
    content: 'Limit crypto to 5-10% of your total investment portfolio for balanced risk.',
    icon: '⚖️'
  },
  {
    id: 'dollar-cost',
    title: 'Dollar-Cost Average',
    content: 'Invest fixed amounts regularly rather than timing the market.',
    icon: '📈'
  },
  {
    id: 'research',
    title: 'Research Everything',
    content: 'Read whitepapers and understand the technology before investing.',
    icon: '📚'
  },
  {
    id: 'hardware-wallet',
    title: 'Hardware Wallets',
    content: 'Use hardware wallets for holdings over $1,000 for maximum security.',
    icon: '🏦'
  },
  {
    id: 'regulatory-awareness',
    title: 'Know the Rules',
    content: 'Stay informed about crypto regulations in your jurisdiction.',
    icon: '⚖️'
  },
  {
    id: 'exchange-selection',
    title: 'Choose Exchanges Wisely',
    content: 'Use regulated exchanges with insurance and strong security records.',
    icon: '🏛️'
  },
  {
    id: 'social-media-caution',
    title: 'Ignore the Hype',
    content: 'Make investment decisions based on research, not social media trends.',
    icon: '📱'
  },
  {
    id: 'estate-planning',
    title: 'Plan Your Legacy',
    content: 'Create inheritance plans for your crypto assets and private keys.',
    icon: '📜'
  },
  {
    id: 'bridge-risks',
    title: 'Bridge with Caution',
    content: 'Cross-chain bridges are hack targets. Use established ones sparingly.',
    icon: '🌉'
  }
];

export function MiniBankersTip() {
  const [currentTip, setCurrentTip] = useState<MiniTip>(quickTips[0]);

  useEffect(() => {
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
    const index = dayOfYear % quickTips.length;
    setCurrentTip(quickTips[index]);
  }, []);

  return (
    <Card className="bg-gradient-to-r from-yellow-50 to-amber-50 border-2 border-yellow-200 shadow-lg">
      <CardContent className="p-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
            <span className="text-lg">{currentTip.icon}</span>
          </div>
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-1">
              <LightbulbIcon className="w-4 h-4 text-yellow-600" />
              <h4 className="text-sm font-bold text-yellow-800">Quick Banker's Tip</h4>
            </div>
            <h5 className="font-semibold text-yellow-900 text-sm">{currentTip.title}</h5>
            <p className="text-yellow-700 text-xs mt-1">{currentTip.content}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}