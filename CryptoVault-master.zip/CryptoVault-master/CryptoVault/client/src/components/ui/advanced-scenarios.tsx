import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MonopolyBanker } from '@/components/ui/monopoly-banker';
import { TrendingUpIcon, TrendingDownIcon, BarChart3Icon, AlertTriangleIcon } from 'lucide-react';

interface AdvancedScenario {
  name: string;
  description: string;
  marketCondition: string;
  expectedReturn: number;
  volatility: number;
  probability: string;
  color: string;
  events: string[];
}

const marketScenarios: AdvancedScenario[] = [
  {
    name: 'Crypto Winter',
    description: 'Extended bear market with regulatory pressure',
    marketCondition: 'Bearish cycle with 70-90% drawdowns',
    expectedReturn: -65,
    volatility: 85,
    probability: '20%',
    color: 'red',
    events: [
      'Major exchange collapses or regulatory crackdowns',
      'Global economic recession reducing risk appetite',
      'Central bank digital currencies compete with crypto',
      'Environmental concerns limit mining operations'
    ]
  },
  {
    name: 'Sideways Consolidation',
    description: 'Range-bound market with moderate growth',
    marketCondition: 'Stable adoption with limited explosive growth',
    expectedReturn: 15,
    volatility: 40,
    probability: '40%',
    color: 'yellow',
    events: [
      'Steady institutional adoption without mass retail FOMO',
      'Balanced regulatory frameworks provide clarity',
      'Technology improvements but no major breakthroughs',
      'Traditional finance slowly integrates crypto products'
    ]
  },
  {
    name: 'Bull Market Rally',
    description: 'Strong growth driven by adoption and innovation',
    marketCondition: 'Sustained uptrend with periodic corrections',
    expectedReturn: 180,
    volatility: 65,
    probability: '30%',
    color: 'green',
    events: [
      'Major corporations add crypto to treasury reserves',
      'ETF approvals drive massive institutional inflows',
      'Breakthrough applications in DeFi and Web3',
      'Hyperinflation in major currencies drives crypto adoption'
    ]
  },
  {
    name: 'Hyperadoption Boom',
    description: 'Explosive growth from mainstream breakthrough',
    marketCondition: 'Parabolic rally with extreme volatility',
    expectedReturn: 450,
    volatility: 120,
    probability: '10%',
    color: 'purple',
    events: [
      'Central bank failures drive mass crypto adoption',
      'Major nation adopts Bitcoin as legal tender',
      'Revolutionary blockchain breakthrough changes everything',
      'Global financial system crisis creates crypto flight'
    ]
  }
];

interface DollarCostAveragingData {
  month: number;
  investment: number;
  price: number;
  tokensAccumulated: number;
  totalInvested: number;
  portfolioValue: number;
  gain: number;
}

export function AdvancedScenarios() {
  const [selectedScenario, setSelectedScenario] = useState<AdvancedScenario>(marketScenarios[1]);
  const [showDCA, setShowDCA] = useState(false);
  const [monthlyInvestment, setMonthlyInvestment] = useState(500);

  const generateDCAData = (): DollarCostAveragingData[] => {
    const data: DollarCostAveragingData[] = [];
    let totalTokens = 0;
    let totalInvested = 0;
    const startPrice = 1000; // Starting crypto price
    
    for (let month = 1; month <= 36; month++) {
      // Simulate price volatility based on selected scenario
      const volatilityFactor = selectedScenario.volatility / 100;
      const trendFactor = selectedScenario.expectedReturn / 100 / 36; // Monthly trend
      const randomness = (Math.random() - 0.5) * volatilityFactor * 2;
      
      const monthlyReturn = trendFactor + randomness;
      const currentPrice = month === 1 ? startPrice : data[month - 2].price * (1 + monthlyReturn);
      
      const tokensThisMonth = monthlyInvestment / currentPrice;
      totalTokens += tokensThisMonth;
      totalInvested += monthlyInvestment;
      
      const portfolioValue = totalTokens * currentPrice;
      const gain = portfolioValue - totalInvested;
      
      data.push({
        month,
        investment: monthlyInvestment,
        price: currentPrice,
        tokensAccumulated: totalTokens,
        totalInvested,
        portfolioValue,
        gain
      });
    }
    
    return data;
  };

  const dcaData = showDCA ? generateDCAData() : [];
  const finalDCAData = dcaData.length > 0 ? dcaData[dcaData.length - 1] : null;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatPercentage = (percentage: number) => {
    return `${percentage >= 0 ? '+' : ''}${percentage.toFixed(1)}%`;
  };

  return (
    <Card className="bg-gradient-to-br from-indigo-50 to-purple-100 border-2 border-indigo-200 shadow-xl">
      <CardContent className="p-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <MonopolyBanker size="lg" className="hover:animate-bounce" />
          </div>
          <h3 className="text-2xl font-bold text-indigo-800 mb-2 font-serif">🔮 Advanced Market Scenarios</h3>
          <p className="text-indigo-700">Explore potential market conditions and their impact on investments</p>
        </div>

        {/* Market Scenarios */}
        <div className="mb-8">
          <h4 className="text-lg font-bold text-indigo-800 mb-4 font-serif">Market Outlook Scenarios</h4>
          <div className="grid md:grid-cols-2 gap-4">
            {marketScenarios.map((scenario) => (
              <div
                key={scenario.name}
                onClick={() => setSelectedScenario(scenario)}
                className={`cursor-pointer border-2 rounded-lg p-4 transition-all duration-200 ${
                  selectedScenario.name === scenario.name
                    ? 'border-indigo-400 bg-indigo-100 shadow-lg'
                    : 'border-gray-200 bg-white hover:border-indigo-200'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h5 className={`font-bold text-lg ${
                    scenario.color === 'red' ? 'text-red-800' :
                    scenario.color === 'yellow' ? 'text-yellow-800' :
                    scenario.color === 'green' ? 'text-green-800' :
                    'text-purple-800'
                  }`}>
                    {scenario.name}
                  </h5>
                  <span className={`px-2 py-1 rounded text-xs font-bold ${
                    scenario.color === 'red' ? 'bg-red-100 text-red-800' :
                    scenario.color === 'yellow' ? 'bg-yellow-100 text-yellow-800' :
                    scenario.color === 'green' ? 'bg-green-100 text-green-800' :
                    'bg-purple-100 text-purple-800'
                  }`}>
                    {scenario.probability}
                  </span>
                </div>
                <p className="text-gray-700 text-sm mb-2">{scenario.description}</p>
                <div className="text-xs text-gray-600">
                  <div>Expected Return: {formatPercentage(scenario.expectedReturn)}</div>
                  <div>Volatility: {scenario.volatility}%</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Scenario Details */}
        <div className={`border-2 rounded-lg p-6 mb-8 bg-gradient-to-r ${
          selectedScenario.color === 'red' ? 'from-red-50 to-pink-50 border-red-200' :
          selectedScenario.color === 'yellow' ? 'from-yellow-50 to-amber-50 border-yellow-200' :
          selectedScenario.color === 'green' ? 'from-green-50 to-emerald-50 border-green-200' :
          'from-purple-50 to-violet-50 border-purple-200'
        }`}>
          <h4 className={`text-xl font-bold mb-3 ${
            selectedScenario.color === 'red' ? 'text-red-800' :
            selectedScenario.color === 'yellow' ? 'text-yellow-800' :
            selectedScenario.color === 'green' ? 'text-green-800' :
            'text-purple-800'
          }`}>
            {selectedScenario.name} Scenario Analysis
          </h4>
          <p className="text-gray-700 mb-4">{selectedScenario.marketCondition}</p>
          
          <div className="mb-4">
            <h5 className="font-bold text-gray-800 mb-2">Potential Trigger Events:</h5>
            <ul className="space-y-1">
              {selectedScenario.events.map((event, index) => (
                <li key={index} className="text-sm text-gray-700 flex items-start">
                  <span className="mr-2">•</span>
                  <span>{event}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-gray-800">{formatPercentage(selectedScenario.expectedReturn)}</div>
              <div className="text-sm text-gray-600">Expected Return</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-800">{selectedScenario.volatility}%</div>
              <div className="text-sm text-gray-600">Volatility</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-800">{selectedScenario.probability}</div>
              <div className="text-sm text-gray-600">Probability</div>
            </div>
          </div>
        </div>

        {/* Dollar Cost Averaging Simulator */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-lg font-bold text-indigo-800 font-serif">💰 Dollar Cost Averaging Simulator</h4>
            <Button
              onClick={() => setShowDCA(!showDCA)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
            >
              {showDCA ? 'Hide' : 'Show'} DCA Analysis
            </Button>
          </div>

          {showDCA && (
            <div className="space-y-4">
              <div className="flex items-center space-x-4 mb-4">
                <label className="font-medium text-indigo-800">Monthly Investment:</label>
                <select
                  value={monthlyInvestment}
                  onChange={(e) => setMonthlyInvestment(Number(e.target.value))}
                  className="border border-indigo-200 rounded p-2"
                >
                  <option value={100}>$100</option>
                  <option value={250}>$250</option>
                  <option value={500}>$500</option>
                  <option value={1000}>$1,000</option>
                  <option value={2000}>$2,000</option>
                </select>
              </div>

              {finalDCAData && (
                <div className="bg-white border border-indigo-200 rounded-lg p-4">
                  <h5 className="font-bold text-indigo-800 mb-3">3-Year DCA Results in {selectedScenario.name} Scenario</h5>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div>
                      <div className="text-xl font-bold text-indigo-800">{formatCurrency(finalDCAData.totalInvested)}</div>
                      <div className="text-sm text-gray-600">Total Invested</div>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-indigo-800">{formatCurrency(finalDCAData.portfolioValue)}</div>
                      <div className="text-sm text-gray-600">Portfolio Value</div>
                    </div>
                    <div>
                      <div className={`text-xl font-bold ${finalDCAData.gain >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(finalDCAData.gain)}
                      </div>
                      <div className="text-sm text-gray-600">Total Gain/Loss</div>
                    </div>
                    <div>
                      <div className={`text-xl font-bold ${finalDCAData.gain >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatPercentage((finalDCAData.gain / finalDCAData.totalInvested) * 100)}
                      </div>
                      <div className="text-sm text-gray-600">Return %</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Banker's Advanced Wisdom */}
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg">
          <p className="text-indigo-800 font-medium italic">
            "The future is unknowable, but the wise banker prepares for multiple scenarios. Diversification across time, assets, and strategies is the hallmark of prudent wealth management."
          </p>
          <p className="text-indigo-600 text-sm mt-1">— Your Trusted Digital Banker</p>
        </div>

        {/* Disclaimer */}
        <div className="mt-4 text-xs text-indigo-600 text-center">
          <p>⚠️ These scenarios are educational models. Real market conditions may differ significantly from projections.</p>
        </div>
      </CardContent>
    </Card>
  );
}