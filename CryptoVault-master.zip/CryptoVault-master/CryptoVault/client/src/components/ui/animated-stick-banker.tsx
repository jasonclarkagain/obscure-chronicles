import React, { useState, useEffect } from 'react';

interface AnimatedStickBankerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export function AnimatedStickBanker({ size = 'md', className = '' }: AnimatedStickBankerProps) {
  const [isBlinking, setIsBlinking] = useState(false);
  const [headDirection, setHeadDirection] = useState(0); // -1 left, 0 center, 1 right
  const [stepPosition, setStepPosition] = useState(0); // 0 center, -1 left step, 1 right step

  const sizeClasses = {
    sm: 'w-12 h-16',
    md: 'w-16 h-20',
    lg: 'w-20 h-24',
    xl: 'w-24 h-28'
  };

  // Animation cycle
  useEffect(() => {
    const animationCycle = () => {
      // Step animation (every 1-2 seconds)
      const stepInterval = setInterval(() => {
        setStepPosition(prev => {
          if (prev === 0) return Math.random() > 0.5 ? 1 : -1;
          return 0;
        });
      }, 1000 + Math.random() * 1000);

      // Head turn animation (every 3-5 seconds)
      const headInterval = setInterval(() => {
        setHeadDirection(prev => {
          const rand = Math.random();
          if (rand < 0.33) return -1; // left
          if (rand < 0.66) return 1;  // right
          return 0; // center
        });
      }, 3000 + Math.random() * 2000);

      // Blink animation (every 2-4 seconds)
      const blinkInterval = setInterval(() => {
        setIsBlinking(true);
        setTimeout(() => setIsBlinking(false), 200);
      }, 2000 + Math.random() * 2000);

      return () => {
        clearInterval(stepInterval);
        clearInterval(headInterval);
        clearInterval(blinkInterval);
      };
    };

    return animationCycle();
  }, []);

  return (
    <div className={`${sizeClasses[size]} ${className} relative`}>
      <svg
        viewBox="0 0 80 100"
        className="w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* Body with step animation */}
        <g transform={`translate(${stepPosition * 2}, 0)`}>
          
          {/* Top Hat */}
          <rect 
            x="36" 
            y="8" 
            width="8" 
            height="12" 
            fill="#1f2937" 
            stroke="#fbbf24" 
            strokeWidth="0.5"
            rx="1"
          />
          <ellipse cx="40" cy="20" rx="6" ry="2" fill="#1f2937"/>
          
          {/* Head with turn animation */}
          <g transform={`translate(${headDirection * 1}, 0) rotate(${headDirection * 5} 40 25)`}>
            {/* Head */}
            <circle cx="40" cy="25" r="6" fill="none" stroke="#1f2937" strokeWidth="2"/>
            
            {/* Big Monocle */}
            <circle 
              cx="37" 
              cy="24" 
              r="4" 
              fill="rgba(229, 231, 235, 0.8)" 
              stroke="#1f2937" 
              strokeWidth="1.5"
              filter="url(#glow)"
            />
            <circle cx="37" cy="24" r="3" fill="rgba(255, 255, 255, 0.6)"/>
            <circle cx="38.5" cy="22.5" r="1" fill="rgba(255, 255, 255, 0.9)"/>
            
            {/* Monocle chain */}
            <path d="M33 24 Q30 22 28 20" stroke="#1f2937" strokeWidth="1" fill="none"/>
            
            {/* Eyes */}
            {isBlinking ? (
              <>
                <line x1="35" y1="23" x2="39" y2="23" stroke="#1f2937" strokeWidth="1"/>
                <line x1="42" y1="24" x2="44" y2="24" stroke="#1f2937" strokeWidth="1"/>
              </>
            ) : (
              <>
                <circle cx="37" cy="23" r="0.5" fill="#1f2937"/>
                <circle cx="43" cy="24" r="0.5" fill="#1f2937"/>
              </>
            )}
            
            {/* Mustache */}
            <path d="M36 27 Q40 26 44 27" stroke="#1f2937" strokeWidth="1.5" fill="none"/>
            
            {/* Smile */}
            <path d="M37 29 Q40 31 43 29" stroke="#1f2937" strokeWidth="1" fill="none"/>
          </g>
          
          {/* Neck */}
          <line x1="40" y1="31" x2="40" y2="35" stroke="#1f2937" strokeWidth="2"/>
          
          {/* Body */}
          <line x1="40" y1="35" x2="40" y2="55" stroke="#1f2937" strokeWidth="2"/>
          
          {/* Arms */}
          <line x1="40" y1="40" x2="30" y2="45" stroke="#1f2937" strokeWidth="2"/>
          <line x1="40" y1="40" x2="50" y2="45" stroke="#1f2937" strokeWidth="2"/>
          
          {/* Hands with money bags */}
          <circle cx="29" cy="46" r="2" fill="#10b981"/>
          <text x="29" y="49" textAnchor="middle" fontSize="3" fill="#1f2937">💰</text>
          <circle cx="51" cy="46" r="2" fill="#10b981"/>
          <text x="51" y="49" textAnchor="middle" fontSize="3" fill="#1f2937">💵</text>
          
          {/* Bow Tie */}
          <polygon points="37,38 40,36 43,38 40,40" fill="#dc2626"/>
          <rect x="39.5" y="37" width="1" height="2" fill="#1f2937"/>
          
          {/* Legs with step animation */}
          <g>
            <line 
              x1="40" 
              y1="55" 
              x2={35 + stepPosition * 3} 
              y2="70" 
              stroke="#1f2937" 
              strokeWidth="2"
            />
            <line 
              x1="40" 
              y1="55" 
              x2={45 - stepPosition * 3} 
              y2="70" 
              stroke="#1f2937" 
              strokeWidth="2"
            />
          </g>
          
          {/* Feet */}
          <ellipse cx={35 + stepPosition * 3} cy="72" rx="3" ry="1.5" fill="#1f2937"/>
          <ellipse cx={45 - stepPosition * 3} cy="72" rx="3" ry="1.5" fill="#1f2937"/>
          
          {/* Walking dust clouds */}
          {stepPosition !== 0 && (
            <>
              <circle cx={32 + stepPosition * 4} cy="74" r="1" fill="#d1d5db" opacity="0.5"/>
              <circle cx={30 + stepPosition * 5} cy="75" r="0.5" fill="#d1d5db" opacity="0.3"/>
              <circle cx={48 - stepPosition * 4} cy="74" r="1" fill="#d1d5db" opacity="0.5"/>
              <circle cx={50 - stepPosition * 5} cy="75" r="0.5" fill="#d1d5db" opacity="0.3"/>
            </>
          )}
          
          {/* Money symbols floating around */}
          <text x="20" y="30" fontSize="4" fill="#fbbf24" opacity="0.7" className="animate-bounce">💰</text>
          <text x="60" y="25" fontSize="4" fill="#10b981" opacity="0.7" className="animate-pulse">💵</text>
          <text x="25" y="60" fontSize="4" fill="#f59e0b" opacity="0.7" className="animate-bounce animation-delay-1000">🪙</text>
        </g>
      </svg>
    </div>
  );
}