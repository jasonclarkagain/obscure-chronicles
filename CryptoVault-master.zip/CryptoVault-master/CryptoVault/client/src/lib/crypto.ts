// Browser-compatible crypto implementation without Node.js dependencies

// BIP39 word list (expanded for demo purposes - in production use full 2048 word list)
const BIP39_WORDLIST = [
  'abandon', 'ability', 'able', 'about', 'above', 'absent', 'absorb', 'abstract', 'absurd', 'abuse',
  'access', 'accident', 'account', 'accuse', 'achieve', 'acid', 'acoustic', 'acquire', 'across', 'act',
  'action', 'actor', 'actress', 'actual', 'adapt', 'add', 'addict', 'address', 'adjust', 'admit',
  'adult', 'advance', 'advice', 'aerobic', 'affair', 'afford', 'afraid', 'again', 'age', 'agent',
  'agree', 'ahead', 'aim', 'air', 'airport', 'aisle', 'alarm', 'album', 'alcohol', 'alert',
  'alien', 'all', 'alley', 'allow', 'almost', 'alone', 'alpha', 'already', 'also', 'alter',
  'always', 'amateur', 'amazing', 'among', 'amount', 'amused', 'analyst', 'anchor', 'ancient', 'anger',
  'angle', 'angry', 'animal', 'ankle', 'announce', 'annual', 'another', 'answer', 'antenna', 'antique',
  'anxiety', 'any', 'apart', 'apology', 'appear', 'apple', 'approve', 'april', 'arch', 'arctic',
  'area', 'arena', 'argue', 'arm', 'armed', 'armor', 'army', 'around', 'arrange', 'arrest',
  'arrive', 'arrow', 'art', 'artefact', 'artist', 'artwork', 'ask', 'aspect', 'assault', 'asset',
  'assist', 'assume', 'asthma', 'athlete', 'atom', 'attack', 'attend', 'attitude', 'attract', 'auction',
  'audit', 'august', 'aunt', 'author', 'auto', 'autumn', 'average', 'avocado', 'avoid', 'awake',
  'aware', 'away', 'awesome', 'awful', 'awkward', 'axis', 'baby', 'bachelor', 'bacon', 'badge',
  'bag', 'balance', 'balcony', 'ball', 'bamboo', 'banana', 'banner', 'bar', 'barely', 'bargain',
  'barrel', 'base', 'basic', 'basket', 'battle', 'beach', 'bean', 'beauty', 'because', 'become',
  'beef', 'before', 'begin', 'behave', 'behind', 'believe', 'below', 'belt', 'bench', 'benefit',
  'best', 'betray', 'better', 'between', 'beyond', 'bicycle', 'bid', 'bike', 'bind', 'biology',
  'bird', 'birth', 'bitter', 'black', 'blade', 'blame', 'blanket', 'blast', 'bleak', 'bless',
  'blind', 'blood', 'blossom', 'blow', 'blue', 'blur', 'blush', 'board', 'boat', 'body'
];

export interface CryptoWallet {
  currency: string;
  name: string;
  symbol: string;
  address: string;
  privateKey: string;
  publicKey?: string;
  balance: string;
  usdValue: string;
  icon: string;
  color: string;
}

export interface MnemonicPhrase {
  words: string[];
  entropy: string;
}

// Generate cryptographically secure mnemonic phrase
export function generateMnemonic(length: 12 | 18 | 24 = 12): MnemonicPhrase {
  const entropyBits = length === 12 ? 128 : length === 18 ? 192 : 256;
  const entropyBytes = entropyBits / 8;
  
  // Generate secure random entropy
  const entropy = new Uint8Array(entropyBytes);
  crypto.getRandomValues(entropy);
  
  // Convert entropy to mnemonic words (simplified implementation)
  const words: string[] = [];
  for (let i = 0; i < length; i++) {
    const index = entropy[i % entropy.length] % BIP39_WORDLIST.length;
    words.push(BIP39_WORDLIST[index]);
  }
  
  return {
    words,
    entropy: Array.from(entropy).map(b => b.toString(16).padStart(2, '0')).join('')
  };
}

// Validate mnemonic phrase
export function validateMnemonic(words: string[]): boolean {
  return words.every(word => BIP39_WORDLIST.includes(word.toLowerCase()));
}

// Generate Bitcoin wallet from mnemonic (browser-compatible implementation)
export function generateBitcoinWallet(mnemonic: string[]): CryptoWallet {
  try {
    // Browser-compatible implementation - simplified for demo
    const seed = mnemonic.join(' ');
    const hash = btoa(seed).replace(/=/g, '').slice(0, 34);
    
    // Generate a demo Bitcoin address (starts with 1 or 3)
    const address = '1' + hash;
    const privateKey = 'L' + btoa(seed + 'bitcoin').replace(/[^A-Za-z0-9]/g, '').slice(0, 51);
    
    return {
      currency: 'bitcoin',
      name: 'Bitcoin',
      symbol: 'BTC',
      address,
      privateKey,
      publicKey: btoa(seed + 'pub').slice(0, 66),
      balance: '0.00000000',
      usdValue: '$0.00',
      icon: '₿',
      color: 'orange-500'
    };
  } catch (error) {
    console.error('Bitcoin wallet generation failed:', error);
    throw new Error('Failed to generate Bitcoin wallet');
  }
}

// Generate Ethereum wallet from mnemonic (browser-compatible implementation)
export function generateEthereumWallet(mnemonic: string[]): CryptoWallet {
  try {
    // Browser-compatible implementation - simplified for demo
    const seed = mnemonic.join(' ');
    const hash = btoa(seed + 'ethereum').replace(/[^A-Za-z0-9]/g, '').slice(0, 40);
    
    // Generate a demo Ethereum address (starts with 0x)
    const address = '0x' + hash;
    const privateKey = '0x' + btoa(seed + 'eth-private').replace(/[^A-Za-z0-9]/g, '').slice(0, 64);
    
    return {
      currency: 'ethereum',
      name: 'Ethereum',
      symbol: 'ETH',
      address,
      privateKey,
      publicKey: '0x' + btoa(seed + 'eth-public').replace(/[^A-Za-z0-9]/g, '').slice(0, 128),
      balance: '0.000000000000000000',
      usdValue: '$0.00',
      icon: 'Ξ',
      color: 'blue-500'
    };
  } catch (error) {
    console.error('Ethereum wallet generation failed:', error);
    throw new Error('Failed to generate Ethereum wallet');
  }
}

// Generate Litecoin wallet from mnemonic (browser-compatible implementation)
export function generateLitecoinWallet(mnemonic: string[]): CryptoWallet {
  try {
    // Browser-compatible implementation - simplified for demo
    const seed = mnemonic.join(' ');
    const hash = btoa(seed + 'litecoin').replace(/[^A-Za-z0-9]/g, '').slice(0, 34);
    
    // Generate a demo Litecoin address (starts with L or M)
    const address = 'L' + hash;
    const privateKey = 'T' + btoa(seed + 'ltc-private').replace(/[^A-Za-z0-9]/g, '').slice(0, 51);
    
    return {
      currency: 'litecoin',
      name: 'Litecoin',
      symbol: 'LTC',
      address,
      privateKey,
      publicKey: btoa(seed + 'ltc-public').slice(0, 66),
      balance: '0.00000000',
      usdValue: '$0.00',
      icon: 'Ł',
      color: 'gray-500'
    };
  } catch (error) {
    console.error('Litecoin wallet generation failed:', error);
    throw new Error('Failed to generate Litecoin wallet');
  }
}

// Generate additional cryptocurrency wallets
export function generateBitcoinCashWallet(mnemonic: string[]): CryptoWallet {
  try {
    const seed = mnemonic.join(' ');
    const hash = btoa(seed + 'bitcoincash').replace(/[^A-Za-z0-9]/g, '').slice(0, 34);
    const address = 'bitcoincash:q' + hash.toLowerCase();
    const privateKey = 'L' + btoa(seed + 'bch-private').replace(/[^A-Za-z0-9]/g, '').slice(0, 51);
    
    return {
      currency: 'bitcoin-cash',
      name: 'Bitcoin Cash',
      symbol: 'BCH',
      address,
      privateKey,
      publicKey: btoa(seed + 'bch-public').slice(0, 66),
      balance: '0.00000000',
      usdValue: '$0.00',
      icon: '₿',
      color: 'green-500'
    };
  } catch (error) {
    console.error('Bitcoin Cash wallet generation failed:', error);
    throw new Error('Failed to generate Bitcoin Cash wallet');
  }
}

export function generateRippleWallet(mnemonic: string[]): CryptoWallet {
  try {
    const seed = mnemonic.join(' ');
    const hash = btoa(seed + 'ripple').replace(/[^A-Za-z0-9]/g, '').slice(0, 25);
    const address = 'r' + hash;
    const privateKey = 's' + btoa(seed + 'xrp-private').replace(/[^A-Za-z0-9]/g, '').slice(0, 28);
    
    return {
      currency: 'ripple',
      name: 'XRP',
      symbol: 'XRP',
      address,
      privateKey,
      publicKey: btoa(seed + 'xrp-public').slice(0, 66),
      balance: '0.000000',
      usdValue: '$0.00',
      icon: '✕',
      color: 'blue-600'
    };
  } catch (error) {
    console.error('XRP wallet generation failed:', error);
    throw new Error('Failed to generate XRP wallet');
  }
}

export function generateCardanoWallet(mnemonic: string[]): CryptoWallet {
  try {
    const seed = mnemonic.join(' ');
    const hash = btoa(seed + 'cardano').replace(/[^A-Za-z0-9]/g, '').slice(0, 56);
    const address = 'addr1' + hash.toLowerCase();
    const privateKey = 'ed25519_sk1' + btoa(seed + 'ada-private').replace(/[^A-Za-z0-9]/g, '').slice(0, 52);
    
    return {
      currency: 'cardano',
      name: 'Cardano',
      symbol: 'ADA',
      address,
      privateKey,
      publicKey: btoa(seed + 'ada-public').slice(0, 64),
      balance: '0.000000',
      usdValue: '$0.00',
      icon: '₳',
      color: 'blue-700'
    };
  } catch (error) {
    console.error('Cardano wallet generation failed:', error);
    throw new Error('Failed to generate Cardano wallet');
  }
}

export function generateSolanaWallet(mnemonic: string[]): CryptoWallet {
  try {
    const seed = mnemonic.join(' ');
    const hash = btoa(seed + 'solana').replace(/[^A-Za-z0-9]/g, '').slice(0, 44);
    const address = hash;
    const privateKey = btoa(seed + 'sol-private').replace(/[^A-Za-z0-9]/g, '').slice(0, 88);
    
    return {
      currency: 'solana',
      name: 'Solana',
      symbol: 'SOL',
      address,
      privateKey,
      publicKey: btoa(seed + 'sol-public').slice(0, 44),
      balance: '0.000000000',
      usdValue: '$0.00',
      icon: '◎',
      color: 'purple-500'
    };
  } catch (error) {
    console.error('Solana wallet generation failed:', error);
    throw new Error('Failed to generate Solana wallet');
  }
}

export function generatePolygonWallet(mnemonic: string[]): CryptoWallet {
  try {
    const seed = mnemonic.join(' ');
    const hash = btoa(seed + 'polygon').replace(/[^A-Za-z0-9]/g, '').slice(0, 40);
    const address = '0x' + hash;
    const privateKey = '0x' + btoa(seed + 'matic-private').replace(/[^A-Za-z0-9]/g, '').slice(0, 64);
    
    return {
      currency: 'polygon',
      name: 'Polygon',
      symbol: 'MATIC',
      address,
      privateKey,
      publicKey: '0x' + btoa(seed + 'matic-public').replace(/[^A-Za-z0-9]/g, '').slice(0, 128),
      balance: '0.000000000000000000',
      usdValue: '$0.00',
      icon: '⬟',
      color: 'purple-600'
    };
  } catch (error) {
    console.error('Polygon wallet generation failed:', error);
    throw new Error('Failed to generate Polygon wallet');
  }
}

// Generate all supported wallets from mnemonic (expanded to cover top cryptocurrencies)
export function generateWalletsFromMnemonic(mnemonic: string[]): CryptoWallet[] {
  if (!validateMnemonic(mnemonic)) {
    throw new Error('Invalid mnemonic phrase');
  }
  
  return [
    generateBitcoinWallet(mnemonic),
    generateEthereumWallet(mnemonic),
    generateLitecoinWallet(mnemonic),
    generateBitcoinCashWallet(mnemonic),
    generateRippleWallet(mnemonic),
    generateCardanoWallet(mnemonic),
    generateSolanaWallet(mnemonic),
    generatePolygonWallet(mnemonic)
  ];
}

// Generate QR code data URL (placeholder - in production use actual QR library)
export function generateQRCode(data: string): string {
  // In production, use qrcode library
  return `data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100" fill="white"/><text x="50%" y="50%" text-anchor="middle" dy=".3em" font-size="8">QR: ${data.slice(0, 10)}...</text></svg>`)}`;
}

// Shuffle array for mnemonic confirmation
export function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
