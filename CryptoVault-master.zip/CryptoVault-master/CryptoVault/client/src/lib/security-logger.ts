// Client-side security logging integration
import { apiRequest } from './queryClient';

interface LogContext {
  userId?: number;
  walletId?: number;
}

class ClientSecurityLogger {
  // Log mnemonic generation
  async logMnemonicGeneration(context: LogContext, mnemonicLength: number, entropy?: string) {
    try {
      await apiRequest({
        url: '/api/security/log-mnemonic',
        method: 'POST',
        body: {
          ...context,
          mnemonicLength,
          entropy
        }
      });
    } catch (error) {
      console.error('Failed to log mnemonic generation:', error);
    }
  }

  // Log key generation
  async logKeyGeneration(context: LogContext, currency: string, publicKey: string, privateKeyHash: string) {
    try {
      await apiRequest({
        url: '/api/security/log-keys',
        method: 'POST',
        body: {
          ...context,
          currency,
          publicKey,
          privateKeyHash
        }
      });
    } catch (error) {
      console.error('Failed to log key generation:', error);
    }
  }

  // Log address generation
  async logAddressGeneration(context: LogContext, currency: string, address: string, derivationPath?: string) {
    try {
      await apiRequest({
        url: '/api/security/log-address',
        method: 'POST',
        body: {
          ...context,
          currency,
          address,
          derivationPath
        }
      });
    } catch (error) {
      console.error('Failed to log address generation:', error);
    }
  }

  // Log generic security event
  async logSecurityEvent(
    context: LogContext, 
    action: string, 
    category: 'wallet' | 'security' | 'transaction' | 'authentication' = 'security',
    severity: 'info' | 'warning' | 'critical' = 'info',
    details: any = {},
    success: boolean = true
  ) {
    try {
      await apiRequest({
        url: '/api/security/log',
        method: 'POST',
        body: {
          ...context,
          action,
          category,
          severity,
          details,
          success
        }
      });
    } catch (error) {
      console.error('Failed to log security event:', error);
    }
  }

  // Get security logs (for admin/debugging)
  async getSecurityLogs(userId?: number, limit: number = 100) {
    try {
      const endpoint = userId ? `/api/security/logs/${userId}` : '/api/security/logs';
      return await apiRequest({
        url: `${endpoint}?limit=${limit}`,
        method: 'GET'
      });
    } catch (error) {
      console.error('Failed to fetch security logs:', error);
      return [];
    }
  }

  // Get security summary
  async getSecuritySummary(userId?: number) {
    try {
      const endpoint = userId ? `/api/security/summary/${userId}` : '/api/security/summary';
      return await apiRequest({
        url: endpoint,
        method: 'GET'
      });
    } catch (error) {
      console.error('Failed to fetch security summary:', error);
      return null;
    }
  }
}

export const clientSecurityLogger = new ClientSecurityLogger();
export default clientSecurityLogger;