import { useState, useCallback } from 'react';
import { 
  generateMnemonic, 
  generateWalletsFromMnemonic, 
  type CryptoWallet, 
  type MnemonicPhrase 
} from '@/lib/crypto';

export interface WalletState {
  mnemonic: MnemonicPhrase | null;
  wallets: CryptoWallet[];
  currentStep: 'welcome' | 'phrase-length' | 'mnemonic' | 'confirm' | 'wallet' | 'paper-wallet';
  selectedPhraseLength: 12 | 18 | 24;
  isWalletCreated: boolean;
}

export function useWallet() {
  const [state, setState] = useState<WalletState>({
    mnemonic: null,
    wallets: [],
    currentStep: 'welcome',
    selectedPhraseLength: 12,
    isWalletCreated: false,
  });

  const setPhraseLength = useCallback((length: 12 | 18 | 24) => {
    setState(prev => ({ ...prev, selectedPhraseLength: length }));
  }, []);

  const generateNewMnemonic = useCallback(() => {
    try {
      const newMnemonic = generateMnemonic(state.selectedPhraseLength);
      setState(prev => ({ ...prev, mnemonic: newMnemonic }));
      return newMnemonic;
    } catch (error) {
      console.error('Failed to generate mnemonic:', error);
      throw error;
    }
  }, [state.selectedPhraseLength]);

  const createWalletFromMnemonic = useCallback((mnemonicWords: string[]) => {
    try {
      const wallets = generateWalletsFromMnemonic(mnemonicWords);
      setState(prev => ({ 
        ...prev, 
        wallets, 
        isWalletCreated: true,
        currentStep: 'wallet'
      }));
      return wallets;
    } catch (error) {
      console.error('Failed to create wallet:', error);
      throw error;
    }
  }, []);

  const setCurrentStep = useCallback((step: WalletState['currentStep']) => {
    setState(prev => ({ ...prev, currentStep: step }));
  }, []);

  const resetWallet = useCallback(() => {
    setState({
      mnemonic: null,
      wallets: [],
      currentStep: 'welcome',
      selectedPhraseLength: 12,
      isWalletCreated: false,
    });
  }, []);

  return {
    ...state,
    setPhraseLength,
    generateNewMnemonic,
    createWalletFromMnemonic,
    setCurrentStep,
    resetWallet,
  };
}
