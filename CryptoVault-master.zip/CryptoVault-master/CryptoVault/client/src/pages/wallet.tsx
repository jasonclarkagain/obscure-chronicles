import { useEffect } from 'react';
import { useWallet } from '@/hooks/use-wallet';
import { HeaderNavigation } from '@/components/ui/header-navigation';

import { ScreenshotProtection } from '@/components/wallet/ScreenshotProtection';
import { ProgressIndicator } from '@/components/wallet/ProgressIndicator';
import { WelcomeStep } from '@/components/wallet/WelcomeStep';
import { PhraseLengthStep } from '@/components/wallet/PhraseLengthStep';
import { MnemonicGenerationStep } from '@/components/wallet/MnemonicGenerationStep';
import { MnemonicConfirmationStep } from '@/components/wallet/MnemonicConfirmationStep';
import { WalletDashboard } from '@/components/wallet/WalletDashboard';
import { PaperWalletView } from '@/components/wallet/PaperWalletView';
import { ThreeBackground } from '@/components/ui/three-background';
import { WalletIcon, SettingsIcon, CrownIcon, DollarSignIcon } from 'lucide-react';

export default function WalletPage() {
  const {
    currentStep,
    selectedPhraseLength,
    mnemonic,
    wallets,
    isWalletCreated,
    setPhraseLength,
    generateNewMnemonic,
    createWalletFromMnemonic,
    setCurrentStep,
  } = useWallet();

  const handleGeneratePhrase = () => {
    try {
      generateNewMnemonic();
      setCurrentStep('mnemonic');
    } catch (error) {
      console.error('Failed to generate mnemonic:', error);
    }
  };

  const handleConfirmPhrase = () => {
    if (!mnemonic) return;
    
    try {
      createWalletFromMnemonic(mnemonic.words);
    } catch (error) {
      console.error('Failed to create wallet:', error);
    }
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'welcome':
        return (
          <WelcomeStep onNext={() => setCurrentStep('phrase-length')} />
        );

      case 'phrase-length':
        return (
          <PhraseLengthStep
            selectedLength={selectedPhraseLength}
            onLengthChange={setPhraseLength}
            onNext={handleGeneratePhrase}
            onBack={() => setCurrentStep('welcome')}
          />
        );

      case 'mnemonic':
        return mnemonic ? (
          <MnemonicGenerationStep
            mnemonic={mnemonic}
            phraseLength={selectedPhraseLength}
            onBack={() => setCurrentStep('phrase-length')}
            onNext={() => setCurrentStep('confirm')}
            onRegeneratePhrase={handleGeneratePhrase}
            onShowPrintView={() => setCurrentStep('paper-wallet')}
          />
        ) : null;

      case 'confirm':
        return mnemonic ? (
          <MnemonicConfirmationStep
            mnemonicWords={mnemonic.words}
            onBack={() => setCurrentStep('mnemonic')}
            onConfirmed={handleConfirmPhrase}
          />
        ) : null;

      case 'wallet':
        return (
          <WalletDashboard
            wallets={wallets}
            onShowPaperWallet={() => setCurrentStep('paper-wallet')}
          />
        );

      case 'paper-wallet':
        return mnemonic ? (
          <PaperWalletView
            wallets={wallets}
            mnemonicWords={mnemonic.words}
            onBack={() => setCurrentStep(isWalletCreated ? 'wallet' : 'mnemonic')}
          />
        ) : null;

      default:
        return <WelcomeStep onNext={() => setCurrentStep('phrase-length')} />;
    }
  };

  return (
    <ScreenshotProtection enabled={currentStep === 'mnemonic' || currentStep === 'confirm'}>
      <div className="min-h-screen relative">
        <ThreeBackground />
        
        {/* Clean Header Navigation */}
        <div className="relative z-[100]">
          <HeaderNavigation onShowPaperWallet={() => setCurrentStep('paper-wallet')} />
        </div>

        {/* Main Content */}
        <main className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-2xl border-2 border-green-200 p-8">
            {renderCurrentStep()}
          </div>
        </main>

        {/* Progress Indicator */}
        <div className="relative z-10">
          <ProgressIndicator currentStep={currentStep} />
        </div>

        {/* Footer */}
        <footer className="relative z-10 bg-gradient-to-r from-green-900/90 to-emerald-800/90 backdrop-blur-md border-t-4 border-yellow-400 mt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center">
              <p className="text-green-200 text-lg font-medium">
                Made with <span className="text-red-400 text-xl">❤️</span> by{' '}
                <a 
                  href="https://jason-clark.org" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-yellow-400 hover:text-yellow-300 font-bold underline transition-colors"
                >
                  Jason Clark
                </a>
              </p>
              <div className="mt-2 text-green-300 text-sm">
                🏦 Elite Digital Banking Solutions
              </div>
            </div>
          </div>
        </footer>
      </div>
    </ScreenshotProtection>
  );
}
