import { SimpleCryptoHeatmap } from '@/components/ui/simple-crypto-heatmap';

import { HeaderNavigation } from '@/components/ui/header-navigation';

import { useWallet } from '@/hooks/use-wallet';

export default function HeatmapPage() {
  const { wallets } = useWallet();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-gray-900">
      <HeaderNavigation onShowPaperWallet={() => {}} />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-green-800 font-serif">Crypto Market Heatmap</h1>
          <p className="text-green-600 mt-2">Real-time cryptocurrency market performance visualization</p>
        </div>



        {/* Main Heatmap Component */}
        <div className="mb-8">
          <SimpleCryptoHeatmap />
        </div>
      </div>
    </div>
  );
}