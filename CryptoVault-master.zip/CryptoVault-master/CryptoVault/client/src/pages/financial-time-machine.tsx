import { FinancialTimeMachine } from '@/components/ui/financial-time-machine';
import { HeaderNavigation } from '@/components/ui/header-navigation';

export default function FinancialTimeMachinePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-gray-900">
      <HeaderNavigation />
      
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-green-800 font-serif">Financial Time Machine</h1>
          <p className="text-green-600 mt-2">Simulate cryptocurrency investments across different time periods and market scenarios</p>
        </div>

        {/* Financial Time Machine Component */}
        <div className="mb-8">
          <FinancialTimeMachine />
        </div>
      </div>
    </div>
  );
}