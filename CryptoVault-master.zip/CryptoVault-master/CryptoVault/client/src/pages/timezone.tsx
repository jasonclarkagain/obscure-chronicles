import { CryptoTimezone } from '@/components/ui/crypto-timezone';
import { HeaderNavigation } from '@/components/ui/header-navigation';


export default function TimezonePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-gray-900">
      <HeaderNavigation />

      
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-4">
            🌍 Global Crypto Timezone Dashboard
          </h1>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto">
            Track real-time cryptocurrency market activity across global financial centers. 
            Monitor trading volumes, market status, and regional performance as markets open and close around the world.
          </p>
        </div>

        {/* Main Timezone Component */}
        <CryptoTimezone />
      </div>
    </div>
  );
}