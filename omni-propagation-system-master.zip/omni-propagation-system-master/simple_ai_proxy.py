from fastapi import FastAPI
import uvicorn
import os

app = FastAPI()

@app.get("/")
def root():
    return {
        "status": "AI Proxy Working",
        "port": 8345,
        "apis_configured": [
            "Google: " + ("✅" if os.getenv("GOOGLE_API_KEY") else "❌"),
            "HuggingFace: " + ("✅" if os.getenv("HUGGINGFACE_TOKEN") else "❌"),
            "Groq: " + ("✅" if os.getenv("GROQ_API_KEY") else "❌")
        ]
    }

@app.get("/health")
def health():
    return {"healthy": True, "service": "ai_proxy"}

@app.get("/test")
def test():
    return {"message": "✅ AI Proxy is running correctly!"}

print("🤖 AI Proxy starting on port 8345...")
print("✅ Access: http://localhost:8345")
print("✅ Health: http://localhost:8345/health")
uvicorn.run(app, host="0.0.0.0", port=8345)
