#!/usr/bin/env python3
"""
ULTIMATE AI SYSTEM
Combines: Cloud APIs + Local models + Response synthesis + Task breakdown
"""

import os
import sys
import asyncio
import aiohttp
import json
import time
import subprocess
from datetime import datetime
from typing import List, Dict, Optional, Tuple
import re

# ==================== CONFIGURATION ====================
API_KEYS = {
    'OPENROUTER_API_KEY': ANTHROPIC_API_KEY_PLACEHOLDER,
    'GROQ_API_KEY': "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"
}

# Set environment for subprocesses
os.environ.update(API_KEYS)

# ==================== TASK ANALYZER ====================
class TaskAnalyzer:
    @staticmethod
    def analyze_complexity(query: str) -> Tuple[int, List[str]]:
        """Analyze query complexity and break into subtasks if needed"""
        word_count = len(query.split())
        char_count = len(query)
        
        # Simple: under 50 words, 1 subtask
        if word_count < 50:
            return 1, [query]
        
        # Medium: 50-150 words, break into 2-3 parts
        elif word_count < 150:
            # Break by sentences
            sentences = re.split(r'[.!?]+', query)
            sentences = [s.strip() for s in sentences if len(s.strip()) > 10]
            
            if len(sentences) <= 2:
                return 2, [query]
            else:
                # Group sentences into 2-3 subtasks
                groups = []
                current = ""
                target_length = len(query) // min(3, len(sentences))
                
                for sentence in sentences:
                    if len(current) + len(sentence) < target_length or len(groups) >= 3:
                        current += sentence + ". "
                    else:
                        if current:
                            groups.append(current.strip())
                        current = sentence + ". "
                
                if current:
                    groups.append(current.strip())
                
                return min(3, len(groups)), groups[:3]
        
        # Complex: over 150 words, break into 3-4 parts
        else:
            # Break by paragraphs or major sections
            paragraphs = query.split('\n\n')
            if len(paragraphs) > 1:
                return min(4, len(paragraphs)), paragraphs[:4]
            else:
                # Break by "and", "or", "but"
                parts = re.split(r'\s+(?:and|or|but)\s+', query, flags=re.IGNORECASE)
                return min(4, len(parts)), parts[:4]

# ==================== CLOUD PROCESSOR ====================
class CloudProcessor:
    def __init__(self):
        self.apis = {
            "openrouter": {
                "url": "https://openrouter.ai/api/v1/chat/completions",
                "models": ["mistralai/mistral-7b-instruct:free", "google/gemma-7b-it:free"]
            }
        }
    
    async def process_subtask(self, subtask: str, api_priority: List[str] = None) -> Optional[Dict]:
        """Process a subtask using cloud APIs"""
        if api_priority is None:
            api_priority = ["openrouter"]  # Default to OpenRouter since it works
        
        for api_name in api_priority:
            if api_name in self.apis:
                config = self.apis[api_name]
                headers = {
                    "Authorization": f"Bearer {API_KEYS.get(f'{api_name.upper()}_API_KEY', '')}",
                    "Content-Type": "application/json"
                }
                
                for model in config["models"]:
                    data = {
                        "model": model,
                        "messages": [{"role": "user", "content": subtask}],
                        "max_tokens": 400,
                        "temperature": 0.7
                    }
                    
                    try:
                        timeout = aiohttp.ClientTimeout(total=20)
                        async with aiohttp.ClientSession(timeout=timeout) as session:
                            async with session.post(config["url"], headers=headers, json=data) as response:
                                if response.status == 200:
                                    result = await response.json()
                                    return {
                                        "api": api_name,
                                        "model": model,
                                        "content": result["choices"][0]["message"]["content"],
                                        "tokens": result.get("usage", {}).get("total_tokens", 0)
                                    }
                    except:
                        continue
        
        return None

# ==================== LOCAL PROCESSOR ====================
class LocalProcessor:
    @staticmethod
    def process_with_model(query: str, model: str = "tinyllama") -> Optional[str]:
        """Process query using local model"""
        try:
            cmd = ["python3", "ultimate_orchestrator.py", model, query]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=180
            )
            
            if result.returncode == 0:
                # Extract answer from output
                lines = result.stdout.split('\n')
                for i, line in enumerate(lines):
                    if "FINAL ANSWER" in line or "🎯 FINAL ANSWER" in line:
                        # Find the answer section
                        answer_lines = []
                        for j in range(i+1, min(i+20, len(lines))):
                            if lines[j].strip() and "====" not in lines[j]:
                                answer_lines.append(lines[j].strip())
                            elif len(answer_lines) > 0:
                                break
                        if answer_lines:
                            return '\n'.join(answer_lines)
                # Fallback: last meaningful line
                for line in reversed(lines):
                    if line.strip() and len(line.strip()) > 20 and "====" not in line:
                        return line.strip()
        except:
            pass
        return None

# ==================== RESPONSE SYNTHESIZER ====================
class ResponseSynthesizer:
    @staticmethod
    def synthesize(responses: List[Dict], original_query: str) -> str:
        """Synthesize multiple responses into a coherent answer"""
        if not responses:
            return "Unable to generate a response. Please try again or rephrase your query."
        
        if len(responses) == 1:
            return responses[0]["content"]
        
        # Multiple responses - create a comprehensive answer
        synthesis = f"# Answer to: {original_query[:100]}...\n\n"
        synthesis += f"*Generated from {len(responses)} sources*\n\n"
        
        # Add each response as a section
        for i, resp in enumerate(responses, 1):
            source = f"{resp.get('api', 'unknown').upper()}"
            if resp.get('model'):
                source += f" ({resp['model']})"
            
            synthesis += f"## Source {i}: {source}\n\n"
            synthesis += f"{resp['content'][:500]}...\n\n"
        
        # Add executive summary
        synthesis += "## Executive Summary\n\n"
        # Take key points from first response
        first_response = responses[0]["content"]
        sentences = first_response.split('. ')
        summary = '. '.join(sentences[:3]) + '.' if len(sentences) > 3 else first_response[:300]
        synthesis += summary
        
        return synthesis

# ==================== MAIN ORCHESTRATOR ====================
class UltimateAIOrchestrator:
    def __init__(self):
        self.task_analyzer = TaskAnalyzer()
        self.cloud_processor = CloudProcessor()
        self.local_processor = LocalProcessor()
        self.synthesizer = ResponseSynthesizer()
    
    async def orchestrate(self, query: str, strategy: str = "auto") -> Dict:
        """Main orchestration method"""
        print(f"\n🤖 ULTIMATE AI ORCHESTRATION")
        print("="*60)
        print(f"Query: {query[:80]}...")
        print(f"Strategy: {strategy}")
        print("="*60)
        
        start_time = time.time()
        
        # Step 1: Analyze task
        print("\n🔍 Step 1: Analyzing task complexity...")
        complexity, subtasks = self.task_analyzer.analyze_complexity(query)
        print(f"   Complexity: {complexity}/4")
        print(f"   Subtasks: {len(subtasks)}")
        
        # Step 2: Determine processing strategy
        if strategy == "cloud":
            processor = "cloud"
        elif strategy == "local":
            processor = "local"
        else:  # auto
            # Decide based on complexity and subtask count
            if complexity <= 2 and len(subtasks) == 1:
                processor = "cloud"  # Simple tasks to cloud
            else:
                processor = "hybrid"  # Complex tasks use both
        
        print(f"\n📊 Step 2: Selected processor: {processor}")
        
        # Step 3: Process subtasks
        print(f"\n⚡ Step 3: Processing {len(subtasks)} subtask(s)...")
        
        responses = []
        
        if processor in ["cloud", "hybrid"]:
            # Try cloud first
            cloud_tasks = []
            for subtask in subtasks:
                task = self.cloud_processor.process_subtask(subtask)
                cloud_tasks.append(task)
            
            cloud_results = await asyncio.gather(*cloud_tasks)
            
            for i, result in enumerate(cloud_results):
                if result:
                    print(f"   ✅ Subtask {i+1}: Cloud success")
                    responses.append(result)
                elif processor == "hybrid":
                    # Fallback to local
                    print(f"   ⚠️  Subtask {i+1}: Cloud failed, trying local...")
                    for model in ["tinyllama", "llama2", "mistral"]:
                        local_result = self.local_processor.process_with_model(subtasks[i], model)
                        if local_result:
                            responses.append({
                                "api": "local",
                                "model": model,
                                "content": local_result,
                                "tokens": 0
                            })
                            print(f"   ✅ Subtask {i+1}: Local success ({model})")
                            break
        
        elif processor == "local":
            # Local only
            for i, subtask in enumerate(subtasks):
                for model in ["mistral", "llama2", "tinyllama"]:  # Try best first
                    result = self.local_processor.process_with_model(subtask, model)
                    if result:
                        responses.append({
                            "api": "local",
                            "model": model,
                            "content": result,
                            "tokens": 0
                        })
                        print(f"   ✅ Subtask {i+1}: Local success ({model})")
                        break
        
        # Step 4: Synthesize
        print("\n🧩 Step 4: Synthesizing final answer...")
        final_answer = self.synthesizer.synthesize(responses, query)
        
        elapsed = time.time() - start_time
        
        # Compile results
        result = {
            "query": query,
            "strategy": strategy,
            "complexity": complexity,
            "subtasks": subtasks,
            "responses": responses,
            "final_answer": final_answer,
            "apis_used": list(set(r["api"] for r in responses)),
            "models_used": list(set(r.get("model", "unknown") for r in responses)),
            "response_count": len(responses),
            "time_elapsed": elapsed,
            "timestamp": datetime.now().isoformat()
        }
        
        return result

# ==================== MAIN ====================
async def main():
    if len(sys.argv) < 2:
        print("Usage: python ultimate_ai_system.py \"Your query\"")
        print("       python ultimate_ai_system.py --strategy [auto|cloud|local] \"Query\"")
        sys.exit(1)
    
    # Parse arguments
    strategy = "auto"
    query_start = 1
    
    if sys.argv[1] == "--strategy" and len(sys.argv) > 3:
        strategy = sys.argv[2]
        query_start = 3
    elif sys.argv[1].startswith("--"):
        print(f"Unknown option: {sys.argv[1]}")
        sys.exit(1)
    
    query = " ".join(sys.argv[query_start:])
    
    # Run orchestration
    orchestrator = UltimateAIOrchestrator()
    result = await orchestrator.orchestrate(query, strategy)
    
    # Display results
    print("\n" + "="*60)
    print("✅ ORCHESTRATION COMPLETE")
    print("="*60)
    print(f"Query: {result['query'][:80]}...")
    print(f"Strategy: {result['strategy']}")
    print(f"Complexity: {result['complexity']}/4")
    print(f"Subtasks: {len(result['subtasks'])}")
    print(f"Responses: {result['response_count']}")
    print(f"APIs: {', '.join(result['apis_used']) if result['apis_used'] else 'None'}")
    print(f"Time: {result['time_elapsed']:.1f}s")
    
    print("\n🎯 FINAL ANSWER:")
    print("="*60)
    print(result['final_answer'])
    print("="*60)
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"ultimate_result_{timestamp}"
    
    # JSON
    with open(f"{filename}.json", "w") as f:
        json.dump(result, f, indent=2)
    
    # Text
    with open(f"{filename}.txt", "w") as f:
        f.write(f"QUERY: {result['query']}\n")
        f.write(f"TIME: {result['time_elapsed']:.1f}s\n")
        f.write(f"STRATEGY: {result['strategy']}\n")
        f.write(f"COMPLEXITY: {result['complexity']}/4\n")
        f.write(f"RESPONSES: {result['response_count']}\n")
        f.write(f"APIS: {', '.join(result['apis_used'])}\n")
        f.write("\n" + "="*60 + "\n")
        f.write("ANSWER:\n")
        f.write("="*60 + "\n")
        f.write(result['final_answer'])
    
    print(f"\n💾 Results saved:")
    print(f"  📊 JSON: {filename}.json")
    print(f"  📝 Text: {filename}.txt")
    print("="*60)

if __name__ == "__main__":
    asyncio.run(main())
