from fastapi import FastAPI
import uvicorn

app = FastAPI()

@app.get("/")
def root():
    return {
        "name": "AI Proxy v2.0",
        "port": 8345,
        "status": "running",
        "apis": ["Google", "HuggingFace", "Groq"],
        "endpoints": {
            "/": "this info",
            "/health": "health check",
            "/query/{text}": "AI query endpoint",
            "/status": "detailed status"
        }
    }

@app.get("/health")
def health():
    return {"status": "healthy", "service": "ai_proxy"}

@app.get("/status")
def status():
    return {
        "port": 8345,
        "process_id": "running",
        "other_services": {
            "pineapple": "http://localhost:8380",
            "decentralized": "http://localhost:8390"
        }
    }

@app.get("/query/{prompt}")
def query(prompt: str):
    return {
        "prompt": prompt,
        "response": f"Processing: {prompt}",
        "model": "AI Proxy",
        "timestamp": "now"
    }

if __name__ == "__main__":
    print("🤖 ENHANCED AI PROXY STARTING...")
    print("=" * 50)
    print("✅ Web Interface: http://localhost:8345")
    print("✅ Health Check:  http://localhost:8345/health")
    print("✅ Test Query:    http://localhost:8345/query/test")
    print("")
    print("🔗 Connected Systems:")
    print("   • 🍍 Pineapple:     http://localhost:8380")
    print("   • 🌐 Decentralized: http://localhost:8390")
    print("=" * 50)
    
    uvicorn.run(app, host="0.0.0.0", port=8345, log_level="info")
