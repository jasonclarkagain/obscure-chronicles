#!/usr/bin/env python3
"""
AI FREEDOM ORCHESTRATOR v3.0
With OpenAI integration and all free APIs
"""

import os
import sys
import json
import asyncio
import aiohttp
import random
import time
from datetime import datetime
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ========== CONFIGURATION ==========
class APISource(Enum):
    OPENAI = "openai"        # Paid, most powerful
    TOGETHER = "together"    # $25 free credits, uncensored
    GROQ = "groq"            # Fast inference, free
    GOOGLE = "google"        # 1M tokens/month free (Using Gemini API)
    OPENROUTER = "openrouter" # Uncensored models, free tier
    HUGGINGFACE = "huggingface" # 30K tokens/month free
    DEEPSEEK = "deepseek"    # Completely free
    LOCAL = "local"          # Uncensored, 100% free (Placeholder for local LLM e.g. Ollama)

# API rate limits (requests per minute)
RATE_LIMITS = {
    APISource.OPENAI: 3500,    # Tokens per minute for gpt-3.5-turbo
    APISource.TOGETHER: 30,
    APISource.GROQ: 30,
    APISource.GOOGLE: 60,
    APISource.OPENROUTER: 20,
    APISource.HUGGINGFACE: 10,
    APISource.DEEPSEEK: 30,
    APISource.LOCAL: 100,      # High local limit
}

# Model configurations with ALL models
# NOTE: The HuggingFace URL is usually specific to the model. Using the Mixtral one as default.
MODEL_CONFIGS = {
    APISource.OPENAI: {
        "models": [
            "gpt-3.5-turbo",     # Fast, cheap
            "gpt-4",             # Most powerful
            "gpt-4-turbo-preview", # Latest
            "gpt-4-32k",         # Large context
        ],
        "default_model": "gpt-3.5-turbo",
        "url": "https://api.openai.com/v1/chat/completions",
        "headers_template": {"Authorization": "Bearer {key}"}
    },
    APISource.TOGETHER: {
        "models": [
            "mistralai/Mixtral-8x7B-Instruct-v0.1",
            "meta-llama/Llama-2-70b-chat-hf",
            "NousResearch/Nous-Hermes-2-Mixtral-8x7B-DPO",
            "Qwen/Qwen1.5-72B-Chat",
            "codellama/CodeLlama-70b-Instruct-hf",
        ],
        "default_model": "mistralai/Mixtral-8x7B-Instruct-v0.1",
        "url": "https://api.together.xyz/v1/chat/completions",
        "headers_template": {"Authorization": "Bearer {key}"}
    },
    APISource.GROQ: {
        "models": ["mixtral-8x7b-32768", "llama2-70b-4096"],
        "default_model": "mixtral-8x7b-32768",
        # Groq uses OpenAI-compatible API
        "url": "https://api.groq.com/openai/v1/chat/completions", 
        "headers_template": {"Authorization": "Bearer {key}"}
    },
    APISource.GOOGLE: {
        "models": ["gemini-pro"],
        "default_model": "gemini-pro",
        # Gemini uses API key in URL, not Header
        "url": "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={key}", 
        "headers_template": {}
    },
    APISource.OPENROUTER: {
        "models": [
            "mistralai/mistral-7b-instruct:free",
            "google/gemini-pro:free",
            "anthropic/claude-3-haiku:beta",
        ],
        "default_model": "mistralai/mistral-7b-instruct:free",
        # OpenRouter uses OpenAI-compatible API
        "url": "https://openrouter.ai/api/v1/chat/completions", 
        "headers_template": {
            "Authorization": "Bearer {key}",
            "HTTP-Referer": "https://github.com/user/repo",
            "X-Title": "AI Freedom Orchestrator"
        }
    },
    APISource.HUGGINGFACE: {
        "models": [
            "mistralai/Mixtral-8x7B-Instruct-v0.1",
            "google/flan-t5-xxl",
            "bigscience/bloom",
        ],
        "default_model": "mistralai/Mixtral-8x7B-Instruct-v0.1",
        # HuggingFace API URL should be dynamic based on model, but is hardcoded for simplicity.
        "url": "https://api-inference.huggingface.co/models/{model}", 
        "headers_template": {"Authorization": "Bearer {key}"}
    },
    APISource.DEEPSEEK: {
        "models": ["deepseek-chat"],
        "default_model": "deepseek-chat",
        # Deepseek uses OpenAI-compatible API
        "url": "https://api.deepseek.com/v1/chat/completions", 
        "headers_template": {"Authorization": "Bearer {key}"}
    },
    APISource.LOCAL: {
        "models": ["llama2-7b-chat"], # Example Ollama model
        "default_model": "llama2-7b-chat",
        # Placeholder for local API like Ollama or LM Studio
        "url": "http://localhost:11434/v1/chat/completions", 
        "headers_template": {} 
    }
}

# ========== DATA CLASSES ==========
@dataclass
class APIKey:
    source: APISource
    key: str
    enabled: bool = True
    last_used: float = 0
    failure_count: int = 0
    credits_remaining: Optional[float] = None
    
    # Allow Enum in asdict/JSON serialization
    def to_dict(self):
        return {**asdict(self), 'source': self.source.value}

@dataclass
class APIResponse:
    source: APISource
    content: str
    latency: float
    success: bool
    error: Optional[str] = None
    tokens_used: int = 0
    cost: float = 0
    model: str = ""
    
    # Allow Enum in asdict/JSON serialization
    def to_dict(self):
        return {**asdict(self), 'source': self.source.value}

@dataclass
class QueryResult:
    query: str
    responses: List[APIResponse]
    best_response: Optional[APIResponse] = None
    synthesis: Optional[str] = None
    processing_time: float = 0
    total_cost: float = 0
    
    # Allow nested Enum/Dataclass in JSON serialization
    def to_dict(self):
        data = asdict(self)
        data['responses'] = [r.to_dict() for r in self.responses]
        if self.best_response:
            data['best_response'] = self.best_response.to_dict()
        return data

# ========== RATE LIMITER ==========
class RateLimiter:
    """Manages API rate limits with exponential backoff"""
    
    def __init__(self):
        self.requests = {}
        self.semaphores = {}
       
        # Initialize semaphores based on rate limits
        for source, limit in RATE_LIMITS.items():
            # Use 1 request per 60 seconds for the semaphore, actual rate limiting 
            # is done with the `requests` list for per-minute granularity
            self.semaphores[source] = asyncio.Semaphore(limit) 
            self.requests[source] = []
    
    async def acquire(self, source: APISource):
        """Acquire permission to make a request with rate limiting"""
        semaphore = self.semaphores.get(source)
        if semaphore:
            await semaphore.acquire()
       
        # Clean old requests
        now = time.time()
        self.requests[source] = [req_time for req_time in self.requests[source] 
                                 if now - req_time < 60]
       
        # Check if we need to wait for per-minute limit
        limit = RATE_LIMITS.get(source)
        if limit is not None and len(self.requests[source]) >= limit:
            # Wait for the oldest request to age out of the 60-second window
            wait_time = 60 - (now - min(self.requests[source]))
            if wait_time > 0:
                # Add a small random jitter to avoid thundering herd problem
                await asyncio.sleep(wait_time + random.uniform(0, 1)) 
                
        # Update timestamp after wait
        self.requests[source].append(time.time())

    def release(self, source: APISource):
        """Release the semaphore after request completes"""
        semaphore = self.semaphores.get(source)
        if semaphore:
            semaphore.release()

# ========== API MANAGER ==========
class APIManager:
    """Manages all API connections with intelligent routing"""
    
    def __init__(self):
        self.keys = self._load_api_keys()
        self.rate_limiter = RateLimiter()
        self.session: Optional[aiohttp.ClientSession] = None
        self.circuit_breakers: Dict[APISource, List[Any]] = {}
       
    def _load_api_keys(self) -> Dict[APISource, APIKey]:
        """Load API keys from environment variables and hardcoded defaults"""
        keys = {}
       
        # OpenAI (from environment)
        openai_key = os.getenv("OPENAI_API_KEY")
        if openai_key:
            keys[APISource.OPENAI] = APIKey(
                APISource.OPENAI,
                openai_key,
                credits_remaining=None  # OpenAI is pay-as-you-go
            )
       
        # Other API Keys (Placeholder values)
        # NOTE: REPLACE THESE PLACEHOLDERS WITH YOUR ACTUAL KEYS!
        keys[APISource.TOGETHER] = APIKey(
            APISource.TOGETHER,
            "TOGETHER_API_KEY_PLACEHOLDER",
            credits_remaining=25.0
        )
       
        keys[APISource.GROQ] = APIKey(
            APISource.GROQ,
            "GROQ_API_KEY_PLACEHOLDER"
        )
       
        keys[APISource.GOOGLE] = APIKey(
            APISource.GOOGLE,
            "GOOGLE_API_KEY_PLACEHOLDER"
        )
       
        keys[APISource.HUGGINGFACE] = APIKey(
            APISource.HUGGINGFACE,
            "HUGGINGFACE_API_KEY_PLACEHOLDER"
        )
       
        keys[APISource.OPENROUTER] = APIKey(
            APISource.OPENROUTER,
            "OPENROUTER_API_KEY_PLACEHOLDER"
        )
       
        # Check for other keys from environment variables
        env_keys = {
            APISource.DEEPSEEK: os.getenv("DEEPSEEK_API_KEY"),
            APISource.LOCAL: os.getenv("LOCAL_API_KEY") # Or check if local server is running
        }
       
        for source, key in env_keys.items():
            if key:
                keys[source] = APIKey(source, key)
       
        # Add a default key for LOCAL if not found (assuming an Ollama-like local setup)
        if APISource.LOCAL not in keys:
             # In a real setup, you'd check for a running local server instead of an environment key
             keys[APISource.LOCAL] = APIKey(
                APISource.LOCAL,
                "LOCAL_SERVER_KEY", # This key might not be strictly needed for a local server
                enabled=False # Disable by default unless a real key/check is implemented
            )


        logger.info(f"Loaded {len(keys)} API sources")
       
        # Log status
        for source, key in keys.items():
            status = "💰 Paid" if source == APISource.OPENAI else "🆓 Free"
            status = f"{status} | {'ENABLED' if key.enabled else 'DISABLED'}"
            if key.credits_remaining is not None:
                status += f" (${key.credits_remaining:.2f} credits)"
            
            # Use 'Found' for keys that came from the environment or are explicitly enabled
            key_status = "FOUND" if key.enabled and source != APISource.LOCAL else "SKIPPED/DISABLED"
            
            logger.info(f"[{key_status}] {status}: {source.value.upper()}")
       
        return keys
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            connector=aiohttp.TCPConnector(limit=100)
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    def _is_circuit_open(self, source: APISource) -> bool:
        """Check if circuit breaker is open for an API"""
        if source not in self.circuit_breakers:
            return False
       
        # [failures, last_failure_time]
        failures, last_failure = self.circuit_breakers[source] 
        # Open circuit if > 5 consecutive failures in the last 5 minutes (300 seconds)
        if failures > 5 and time.time() - last_failure < 300: 
            return True
       
        return False
    
    def _record_failure(self, source: APISource):
        """Record API failure for circuit breaker"""
        if source not in self.circuit_breakers or time.time() - self.circuit_breakers[source][1] > 300:
            # Start new count if first failure or last failure was long ago
            self.circuit_breakers[source] = [1, time.time()] 
        else:
            failures, _ = self.circuit_breakers[source]
            self.circuit_breakers[source] = [failures + 1, time.time()]
    
    def _record_success(self, source: APISource):
        """Reset circuit breaker on success"""
        if source in self.circuit_breakers:
            self.circuit_breakers[source] = [0, time.time()]
    
    def _calculate_cost(self, source: APISource, tokens: int, model: str = "") -> float:
        """Calculate approximate cost for API call"""
        # Costs per 1K tokens (USD) - simplified, assuming all tokens are output tokens
        # In a real app, you'd track prompt_tokens and completion_tokens separately
        cost_per_1k = {
            APISource.OPENAI: {
                "gpt-3.5-turbo": 0.0015,     # $1.5 per 1M tokens
                "gpt-4": 0.03,               # $30 per 1M tokens
                "gpt-4-turbo-preview": 0.01, # $10 per 1M tokens
                "gpt-4-32k": 0.06,           # $60 per 1M tokens
                "default": 0.0015
            },
            APISource.TOGETHER: 0.0006,        # Example: $0.60 per 1M tokens
            APISource.GROQ: 0.0000,            # Free tier
            APISource.GOOGLE: 0.0000,          # Free tier
            APISource.OPENROUTER: 0.0000,      # Free tier
            APISource.HUGGINGFACE: 0.0000,     # Free tier
            APISource.DEEPSEEK: 0.0000,        # Free tier
            APISource.LOCAL: 0.0000,           # Free
        }
       
        if source == APISource.OPENAI:
            cost_map = cost_per_1k[source]
            cost_per_token = cost_map.get(model, cost_map["default"]) / 1000
        else:
            cost_per_1k_rate = cost_per_1k.get(source, 0.001)
            cost_per_token = cost_per_1k_rate / 1000
       
        return tokens * cost_per_token
    
    async def query_api(self, source: APISource, prompt: str, 
                         max_retries: int = 3, model_override: str = None) -> APIResponse:
        """Query a specific API with retry logic"""
       
        api_key = self.keys.get(source)
        if not api_key or not api_key.enabled:
            return APIResponse(
                source=source,
                content="",
                latency=0,
                success=False,
                error=f"API {source.value} not available or disabled"
            )
        
        if self._is_circuit_open(source):
            return APIResponse(
                source=source,
                content="",
                latency=0,
                success=False,
                error=f"Circuit breaker open for {source.value}"
            )
       
        config = MODEL_CONFIGS.get(source)
        if not config:
            return APIResponse(
                source=source,
                content="",
                latency=0,
                success=False,
                error=f"No configuration for {source.value}"
            )
       
        # Select model
        if model_override and model_override in config["models"]:
            model = model_override
        else:
            model = config["default_model"]
       
        start_time = time.time()
       
        for attempt in range(max_retries):
            try:
                await self.rate_limiter.acquire(source)
               
                headers = {"Content-Type": "application/json"}
                for key, value in config["headers_template"].items():
                    headers[key] = value.format(key=api_key.key)
               
                payload = self._prepare_payload(source, prompt, model)
                
                # Replace model placeholder in URL for HuggingFace (and others if needed)
                url = config["url"].format(key=api_key.key, model=model) if "{key}" in config["url"] or "{model}" in config["url"] else config["url"]
               
                # Ensure we have a session (should be guaranteed by __aenter__)
                if not self.session:
                    raise Exception("AIOHTTP session not initialized.") 
                    
                async with self.session.post(url, json=payload, headers=headers) as response:
                    response_text = await response.text()
                   
                    if response.status == 200:
                        content, tokens_out = self._extract_response(source, response_text)
                        latency = time.time() - start_time
                       
                        # Crude token calculation if API doesn't return usage
                        tokens_used = tokens_out if tokens_out > 0 else len(prompt.split()) + len(content.split()) 
                        # Use a 1.3 factor for a slightly more accurate token estimate (if no usage data)
                        tokens_used = int(tokens_used * 1.3)
                        
                        cost = self._calculate_cost(source, tokens_used, model)
                       
                        # Update credits
                        if source == APISource.TOGETHER and api_key.credits_remaining is not None:
                            api_key.credits_remaining = max(0, api_key.credits_remaining - cost)
                       
                        self._record_success(source)
                        api_key.last_used = time.time()
                       
                        return APIResponse(
                            source=source,
                            content=content,
                            latency=latency,
                            success=True,
                            tokens_used=tokens_used,
                            cost=cost,
                            model=model
                        )
                    else:
                        if response.status == 429:
                            wait_time = (2 ** attempt) + random.random()
                            logger.warning(f"Rate limited by {source.value}, waiting {wait_time:.1f}s")
                            await asyncio.sleep(wait_time)
                            continue
                        elif response.status in [401, 403]: # Unauthorized/Forbidden
                            api_key.enabled = False
                            return APIResponse(
                                source=source,
                                content="",
                                latency=time.time() - start_time,
                                success=False,
                                error=f"Invalid/Expired API key for {source.value} (Status: {response.status})"
                            )
                        else:
                            self._record_failure(source)
                            error_msg = f"HTTP {response.status}: {response_text[:100]}"
                           
                            if attempt < max_retries - 1:
                                await asyncio.sleep((2 ** attempt) + random.random())
                                continue
                            else:
                                return APIResponse(
                                    source=source,
                                    content="",
                                    latency=time.time() - start_time,
                                    success=False,
                                    error=error_msg
                                )
               
            except asyncio.TimeoutError:
                logger.warning(f"Timeout for {source.value}, attempt {attempt + 1}")
                if attempt < max_retries - 1:
                    await asyncio.sleep((2 ** attempt) + random.random())
                    continue
               
            except Exception as e:
                logger.error(f"Error querying {source.value}: {str(e)}")
                self._record_failure(source)
               
                if attempt < max_retries - 1:
                    await asyncio.sleep((2 ** attempt) + random.random())
                    continue
                else:
                    return APIResponse(
                        source=source,
                        content="",
                        latency=time.time() - start_time,
                        success=False,
                        error=str(e)
                    )
               
            finally:
                # Release the semaphore even if the request failed for a non-retryable reason
                self.rate_limiter.release(source)
       
        return APIResponse(
            source=source,
            content="",
            latency=time.time() - start_time,
            success=False,
            error="All retries failed"
        )
    
    def _prepare_payload(self, source: APISource, prompt: str, model: str) -> dict:
        """Prepare API-specific payload"""
        if source == APISource.GOOGLE:
            return {
                "contents": [{
                    "parts": [{"text": prompt}]
                }],
                "config": { # Changed from generationConfig to config for modern usage
                    "maxOutputTokens": 2000,
                    "temperature": 0.7
                }
            }
        elif source == APISource.HUGGINGFACE:
            return {
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": 1000,
                    "temperature": 0.7,
                    "return_full_text": False
                }
            }
        else:
            # OpenAI-compatible format (OpenAI, Together, Groq, OpenRouter, Deepseek, Local)
            return {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 2000,
                "temperature": 0.7
            }
    
    def _extract_response(self, source: APISource, response_text: str) -> tuple[str, int]:
        """Extract content and tokens_used from API response"""
        try:
            data = json.loads(response_text)
            tokens_used = 0
           
            if source == APISource.GOOGLE:
                # Fixed deep nesting access for Gemini API
                content = data.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
                
                # Gemini usage is usually under usageMetadata
                usage = data.get("usageMetadata", {})
                tokens_used = usage.get("totalTokenCount", 0)
                return content, tokens_used
                
            elif source == APISource.HUGGINGFACE:
                if isinstance(data, list) and data:
                    content = data[0].get("generated_text", "")
                else:
                    content = data.get("generated_text", str(data))
                # HuggingFace doesn't always return token count in the standard inference API
                return content, 0
            
            # OpenAI-compatible APIs (OpenAI, Together, Groq, OpenRouter, Deepseek, Local)
            else: 
                content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
                
                # Standard OpenAI usage object extraction
                usage = data.get("usage", {})
                tokens_used = usage.get("total_tokens", 0)
                return content, tokens_used
       
        except json.JSONDecodeError:
            logger.error(f"Failed to decode JSON from {source.value}: {response_text[:100]}...")
            return response_text, 0
        except Exception as e:
            logger.error(f"Error during response extraction for {source.value}: {e}")
            return "", 0

# ========== INTELLIGENT ORCHESTRATOR ==========
class AIFreedomOrchestrator:
    """Intelligent orchestrator with cost-aware routing"""
    
    def __init__(self, strategy: str = "balanced"):
        """
        strategy options:
        - "balanced": Mix of free and paid
        - "free_only": Only use free APIs
        - "premium": Prefer paid APIs (OpenAI) when available
        - "uncensored": Prefer uncensored models (Together, Local, OpenRouter)
        """
        # api_manager will be set in main() using async context manager
        self.api_manager: APIManager
        self.strategy = strategy
        self.results_cache = {}
       
    async def process_query(self, query: str, budget: float = 0.10) -> QueryResult:
        """Process query with intelligent routing based on strategy"""
       
        start_time = time.time()
       
        # Check cache
        cache_key = f"{query}_{self.strategy}_{budget}"
        if cache_key in self.results_cache:
            cached = self.results_cache[cache_key]
            if time.time() - cached["timestamp"] < 300: # Cache lifetime of 5 minutes
                logger.info(f"Cache hit for query: {query[:50]}...")
                return cached["result"]
       
        logger.info(f"Processing query with strategy: {self.strategy}")
       
        # Select APIs based on strategy
        enabled_apis = self._select_apis_for_strategy(budget)
       
        if not enabled_apis:
            logger.warning("No APIs available for selected strategy!")
            return QueryResult(
                query=query,
                responses=[],
                processing_time=time.time() - start_time
            )
       
        # Process query
        all_responses = await self._parallel_query_apis(enabled_apis, query)
       
        # Select best response
        best_response = self._select_best_response(all_responses)
       
        # Synthesize if multiple good responses
        synthesis = None
        good_responses = [r for r in all_responses if r.success and r.content]
        if len(good_responses) > 1:
            synthesis = await self._synthesize_responses(query, good_responses)
       
        total_cost = sum(r.cost for r in all_responses if r.success)
       
        result = QueryResult(
            query=query,
            responses=all_responses,
            best_response=best_response,
            synthesis=synthesis,
            processing_time=time.time() - start_time,
            total_cost=total_cost
        )
       
        self.results_cache[cache_key] = {
            "result": result,
            "timestamp": time.time()
        }
       
        return result
    
    def _select_apis_for_strategy(self, budget: float) -> List[APISource]:
        """Select APIs based on strategy and budget"""
       
        all_apis = list(self.api_manager.keys.keys())
        
        # Filter out disabled keys first
        available_apis = [api for api in all_apis if self.api_manager.keys[api].enabled]

        if self.strategy == "free_only":
            # Remove OpenAI (paid)
            return [api for api in available_apis if api != APISource.OPENAI]
       
        elif self.strategy == "premium":
            # Start with OpenAI, then add free as fallback
            enabled = []
            if APISource.OPENAI in available_apis:
                enabled.append(APISource.OPENAI)
            enabled.extend([api for api in available_apis if api != APISource.OPENAI])
            return enabled
       
        elif self.strategy == "uncensored":
            # Prefer uncensored models
            uncensored_order = [
                APISource.TOGETHER,    # Uncensored
                APISource.LOCAL,       # Uncensored
                APISource.OPENROUTER,  # Uncensored models
                APISource.OPENAI,      # Sometimes censored
                APISource.GROQ,        # Sometimes censored
                APISource.DEEPSEEK,    # Sometimes censored
                APISource.HUGGINGFACE, # Sometimes censored
                APISource.GOOGLE,      # Heavily censored
            ]
            return [api for api in uncensored_order if api in available_apis]
       
        else:  # "balanced" - default
            # Mix of paid and free
            balanced_order = [
                APISource.OPENAI,      # Paid but powerful
                APISource.TOGETHER,    # Free credits
                APISource.GROQ,        # Free and fast
                APISource.GOOGLE,      # Free
                APISource.OPENROUTER,  # Free
                APISource.HUGGINGFACE, # Free
                APISource.DEEPSEEK,    # Free
                APISource.LOCAL,       # Free
            ]
            return [api for api in balanced_order if api in available_apis]
    
    async def _parallel_query_apis(self, apis: List[APISource], query: str) -> List[APIResponse]:
        """Query multiple APIs in parallel"""
       
        # Ensure we don't query the same API key if it's disabled globally (already filtered)
        tasks = [self.api_manager.query_api(api, query) for api in apis]
       
        try:
            # Execute all tasks concurrently
            responses = await asyncio.gather(*tasks, return_exceptions=True)
           
            processed = []
            for response in responses:
                if isinstance(response, Exception):
                    # Exception during task execution (e.g., in _load_api_keys)
                    logger.error(f"Task failed during execution: {response}")
                    continue
                if response:
                    processed.append(response)
           
            return processed
       
        except Exception as e:
            logger.error(f"Parallel query failed: {e}")
            return []
    
    async def _synthesize_responses(self, query: str, responses: List[APIResponse]) -> str:
        """Synthesize multiple responses"""
       
        # The list is filtered for good responses already, but check again
        if not responses:
            return ""
       
        # Prepare synthesis prompt
        sources_text = "\n\n".join([
            f"SOURCE: {resp.source.value.upper()} ({resp.model})\n"
            f"CONTENT: {resp.content[:500]}..."
            for resp in responses
        ])
       
        synthesis_prompt = f"""Combine these responses into one comprehensive answer:

QUESTION: {query}

RESPONSES:
{sources_text}

Instructions:
1. Merge the best information from all sources
2. Resolve contradictions
3. Create a well-structured, comprehensive answer
4. Include practical insights

ANSWER:"""
       
        # Use the most powerful available API for synthesis
        synthesis_priority = [
            APISource.OPENAI,      # Best for synthesis
            APISource.TOGETHER,    # Good alternative
            APISource.GROQ,        # Fast
            APISource.GOOGLE,      # Reliable
        ]
       
        for api in synthesis_priority:
            api_key_obj = self.api_manager.keys.get(api)
            if api_key_obj and api_key_obj.enabled:
                # Use a more powerful model if available (e.g. gpt-4 for OpenAI)
                model_for_synthesis = "gpt-4" if api == APISource.OPENAI and "gpt-4" in MODEL_CONFIGS[api]["models"] else None
                response = await self.api_manager.query_api(api, synthesis_prompt, model_override=model_for_synthesis)
                if response.success:
                    logger.info(f"Synthesis successful using {api.value.upper()}.")
                    return response.content
       
        # Fallback to a simple concatenation if synthesis fails entirely
        logger.warning("Synthesis failed, returning best single response.")
        return self._select_best_response(responses).content if self._select_best_response(responses) else ""
    
    def _select_best_response(self, responses: List[APIResponse]) -> Optional[APIResponse]:
        """Select best response based on quality and cost"""
       
        # Filter for successful, non-empty responses first
        successful_responses = [resp for resp in responses if resp.success and resp.content.strip()]

        if not successful_responses:
            return responses[0] if responses else None
       
        # Score each response
        scored = []
        for resp in successful_responses:
            score = 0
           
            # Content quality: penalize short/empty and reward reasonable length
            content_len = len(resp.content.strip())
            score += min(content_len / 100, 20) # Max 20 points for content length
           
            # Speed: reward fast responses (fastest scores max 15)
            if resp.latency < 2:
                score += 15
            elif resp.latency < 5:
                score += 10
            elif resp.latency < 10:
                score += 5
           
            # Source quality: based on model perceived power/reliability
            source_scores = {
                APISource.OPENAI: 25,      # Highest quality
                APISource.TOGETHER: 20,    # Uncensored, powerful
                APISource.LOCAL: 18,       # Uncensored, fast if running well
                APISource.GOOGLE: 16,      # Reliable
                APISource.GROQ: 14,        # Fast
                APISource.OPENROUTER: 12,  # Uncensored
                APISource.DEEPSEEK: 10,
                APISource.HUGGINGFACE: 8,
            }
            score += source_scores.get(resp.source, 5)
           
            # Cost efficiency: prioritize free/cheap
            if resp.cost == 0:
                score += 10
            elif resp.cost < 0.001:
                score += 5
            elif resp.cost > 0.01: # Penalize very expensive calls
                score -= 10
           
            scored.append((score, resp))
       
        if not scored:
            return responses[0] if responses else None
       
        # Sort by score (descending)
        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[0][1]

# ========== UTILITIES ==========
def display_results(result: QueryResult):
    """Display results beautifully"""
   
    print("\n" + "=" * 80)
    print("🤖 AI FREEDOM ORCHESTRATOR v3.0")
    print("=" * 80)
    print(f"Query: {result.query}")
    print(f"Processing time: {result.processing_time:.2f}s")
    print(f"Total cost: ${result.total_cost:.6f}")
    print(f"Successful responses: {len([r for r in result.responses if r.success])}")
    print("=" * 80)
   
    best_is_synthesis = False
    if result.synthesis:
        # Check if synthesis is truly unique or just a copy of the best response
        if result.best_response and result.synthesis.strip() == result.best_response.content.strip():
            best_is_synthesis = False
        else:
            best_is_synthesis = True

    if result.synthesis and best_is_synthesis:
        print(f"\n🏆 SYNTHESIZED BEST ANSWER:")
        print("-" * 40)
        print(result.synthesis)
        print("-" * 40)
    
    if result.best_response and not best_is_synthesis:
        print(f"\n🏆 BEST SINGLE RESPONSE:")
        print("-" * 40)
        print(f"Source: {result.best_response.source.value.upper()}")
        print(f"Model: {result.best_response.model}")
        print(f"Latency: {result.best_response.latency:.2f}s")
        print(f"Cost: ${result.best_response.cost:.6f}")
        print("-" * 40)
        print(result.best_response.content)
        print("-" * 40)
    
   
    print(f"\n📊 ALL RESPONSES:")
    print("-" * 80)
    # Print header for table
    print(f"{'Status'.ljust(8)} | {'Source'.ljust(12)} | {'Model'.ljust(20)} | {'Latency'.ljust(8)} | {'Cost'.ljust(12)} | {'Tokens'.ljust(15)} | {'Error/Content Snippet'}")
    print("-" * 80)
    
    for resp in result.responses:
        status = "✅" if resp.success else "❌"
        source = resp.source.value.ljust(12)
        model = resp.model[:20].ljust(20)
        latency = f"{resp.latency:.2f}s".ljust(8)
        cost = f"${resp.cost:.6f}".ljust(12)
        tokens = f"{resp.tokens_used} tokens".ljust(15)
        
        if resp.success:
            snippet = resp.content.strip().split('\n')[0][:30] + '...'
        else:
            snippet = resp.error[:30] if resp.error else 'No response/Unknown error'

        print(f"{status.ljust(8)} | {source} | {model} | {latency} | {cost} | {tokens} | {snippet}")
   
    print("=" * 80)

async def main():
    """Main entry point"""
   
    print("\n" + "=" * 80)
    print("🚀 AI FREEDOM ORCHESTRATOR v3.0")
    print("=" * 80)
    print("Now with OpenAI and 7 other AI services!")
    print("=" * 80)
   
    print("\nAvailable strategies:")
    print("1. balanced    - Mix of free and paid (default)")
    print("2. free_only   - Only free APIs")
    print("3. premium     - Prefer OpenAI when available")
    print("4. uncensored  - Prefer uncensored models")
   
    # Get query and strategy
    if len(sys.argv) > 1:
        # Use first argument as strategy if it matches, rest as query
        possible_strategy = sys.argv[1].lower().strip()
        if possible_strategy in ["balanced", "free_only", "premium", "uncensored"]:
            strategy = possible_strategy
            query = " ".join(sys.argv[2:])
        else:
            strategy = "balanced"
            query = " ".join(sys.argv[1:])
        
        if not query:
             query = "Explain advanced AI concepts and their practical applications"
    else:
        print("\nEnter your query:")
        query = input("> ").strip()
        if not query:
            query = "Explain advanced AI concepts and their practical applications"
       
        print("\nSelect strategy (balanced/free_only/premium/uncensored):")
        strategy = input("> ").strip().lower()
        if strategy not in ["balanced", "free_only", "premium", "uncensored"]:
            strategy = "balanced"
   
    # Initialize orchestrator
    async with APIManager() as api_manager:
        orchestrator = AIFreedomOrchestrator(strategy=strategy)
        orchestrator.api_manager = api_manager
       
        try:
            # Process query
            print(f"\nProcessing with '{strategy}' strategy...")
            result = await orchestrator.process_query(query, budget=0.10)
           
            # Display results
            display_results(result)
           
            # Save results (FIXED: incomplete JSON serialization)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"ai_result_{timestamp}.json"
           
            with open(filename, 'w', encoding='utf-8') as f:
                # Use to_dict method from QueryResult for clean serialization
                json.dump(result.to_dict(), f, indent=4, ensure_ascii=False)
                
            print(f"\nResults saved to {filename}")
           
        except KeyboardInterrupt:
            print("\nOrchestrator stopped by user.")
        except Exception as e:
            logger.critical(f"A fatal error occurred in main: {e}")

if __name__ == "__main__":
    try:
        # The main entry point for an asyncio program
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nProgram exit.")
