import subprocess
import os

def create_video_script(video_path, script_type="summary"):
    """Generate different types of scripts from video"""
    
    # First get basic video info
    cmd = f"ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 '{video_path}'"
    duration = subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout.strip()
    
    prompt = f"""Create a {script_type} for this video:
    
    VIDEO: {os.path.basename(video_path)}
    DURATION: {duration} seconds (if available)
    
    Generate a {script_type} that includes:
    """
    
    if script_type == "summary":
        prompt += """1. Brief overview of content
    2. Key points/topics covered
    3. Main takeaways
    4. Suggested uses for the content"""
    
    elif script_type == "transcript":
        prompt += """1. Time-stamped transcript structure
    2. Speaker identification format
    3. Key dialogue or narration
    4. Scene descriptions if applicable"""
    
    elif script_type == "analysis":
        prompt += """1. Content analysis
    2. Production quality notes
    3. Target audience identification
    4. Effectiveness assessment"""
    
    elif script_type == "social_media":
        prompt += """1. Attention-grabbing headline
    2. 3-5 key bullet points
    3. Hashtag suggestions
    4. Call-to-action"""
    
    print(f"📝 Generating {script_type} for video...")
    result = subprocess.run(
        ['ollama', 'run', 'tinyllama', prompt],
        capture_output=True,
        text=True,
        timeout=60
    )
    
    if result.returncode == 0:
        return result.stdout
    else:
        return f"Failed to generate {script_type}"

# Find and analyze a video
find_cmd = "find '/run/media/unknown/ADATA HD710 PRO' -name '*.mp4' -o -name '*.avi' -o -name '*.mov' 2>/dev/null | head -3"
videos = subprocess.run(find_cmd, shell=True, capture_output=True, text=True).stdout.strip().split('\n')

for video in videos:
    if video and os.path.exists(video):
        print(f"\n🎥 Processing: {os.path.basename(video)}")
        
        for script_type in ["summary", "analysis", "social_media"]:
            script = create_video_script(video, script_type)
            print(f"\n📄 {script_type.upper()}:")
            print("-"*40)
            print(script[:300] + "..." if len(script) > 300 else script)
        
        # Save to file
        with open(f"video_analysis_{os.path.basename(video)}.txt", "w") as f:
            f.write(f"Video: {video}\n")
            for script_type in ["summary", "analysis", "social_media"]:
                f.write(f"\n{'='*60}\n")
                f.write(f"{script_type.upper()}:\n")
                f.write(create_video_script(video, script_type))
                f.write("\n")
        
        print(f"\n💾 Saved analysis to: video_analysis_{os.path.basename(video)}.txt")
        break  # Just process first video
