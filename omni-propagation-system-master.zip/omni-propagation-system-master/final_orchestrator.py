#!/usr/bin/env python3
"""
FINAL WORKING ORCHESTRATOR for Kali Linux
"""

import urllib.request
import json
import sys
from datetime import datetime

# API Keys
GEMINI_KEY = "AIzaSyC9g4B4sY9xeaUntjNmN2MeWFyp5gL3_EM"
GROQ_KEY = "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"

def call_api(api_name, prompt):
    """Call API using urllib (works on Kali)"""
    
    if api_name == "gemini":
        # Working Gemini endpoint
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key={GEMINI_KEY}"
        
        data = json.dumps({
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"maxOutputTokens": 300}
        })
        
        try:
            req = urllib.request.Request(
                url,
                data=data.encode('utf-8'),
                headers={'Content-Type': 'application/json'}
            )
            
            with urllib.request.urlopen(req, timeout=15) as response:
                result = json.loads(response.read().decode('utf-8'))
                return result['candidates'][0]['content']['parts'][0]['text']
        
        except Exception as e:
            return f"Error: {str(e)[:100]}"
    
    elif api_name == "groq":
        # Groq API
        url = "https://api.groq.com/openai/v1/chat/completions"
        
        data = json.dumps({
            "model": "llama3-8b-8192",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 300,
            "temperature": 0.7
        })
        
        try:
            req = urllib.request.Request(
                url,
                data=data.encode('utf-8'),
                headers={
                    'Authorization': f'Bearer {GROQ_KEY}',
                    'Content-Type': 'application/json'
                }
            )
            
            with urllib.request.urlopen(req, timeout=15) as response:
                result = json.loads(response.read().decode('utf-8'))
                return result['choices'][0]['message']['content']
        
        except Exception as e:
            return f"Error: {str(e)[:100]}"
    
    return "API not available"

def main():
    print("🚀 AI ORCHESTRATOR - KALI EDITION")
    print("="*50)
    
    # Get question
    if len(sys.argv) > 1:
        question = " ".join(sys.argv[1:])
    else:
        print("\nWhat would you like to know?")
        print("Example: 'Explain quantum computing'")
        question = sys.stdin.readline().strip() or "What is artificial intelligence?"
    
    print(f"\n🤔 Question: {question}")
    print("\n🔍 Getting answers from multiple AIs...")
    
    # Query both APIs
    print("\n1. Querying Google Gemini...")
    gemini_response = call_api("gemini", question)
    
    print("2. Querying Groq (Llama 3)...")
    groq_response = call_api("groq", question)
    
    # Display results
    print("\n" + "="*50)
    print("📊 AI RESPONSES")
    print("="*50)
    
    print(f"\n🤖 GOOGLE GEMINI:")
    print("-"*30)
    print(gemini_response[:500] + ("..." if len(gemini_response) > 500 else ""))
    
    print(f"\n⚡ GROQ (LLAMA 3):")
    print("-"*30)
    print(groq_response[:500] + ("..." if len(groq_response) > 500 else ""))
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"ai_comparison_{timestamp}.txt"
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(f"Question: {question}\n")
        f.write(f"Time: {datetime.now()}\n\n")
        f.write("GOOGLE GEMINI:\n")
        f.write(gemini_response + "\n\n")
        f.write("GROQ (LLAMA 3):\n")
        f.write(groq_response + "\n\n")
    
    print(f"\n💾 Saved to: {filename}")
    print("="*50)

if __name__ == "__main__":
    main()
