#!/usr/bin/env python3
"""
Fixed Unrestricted Orchestrator
"""
import os
import json
import subprocess
import sys

def test_ollama():
    """Test if Ollama is working"""
    try:
        result = subprocess.run(["ollama", "list"], 
                              capture_output=True, text=True)
        return result.returncode == 0
    except:
        return False

def query_ollama(prompt):
    """Query Ollama"""
    try:
        # Use dolphin-mistral which is less censored (you have it!)
        cmd = ["ollama", "run", "dolphin-mistral:latest", prompt[:300]]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return result.stdout.strip()
    except Exception as e:
        return f"Error: {e}"

def main():
    print("🚀 FIXED UNRESTRICTED ORCHESTRATOR")
    print("=" * 60)
    
    # Test Ollama
    if test_ollama():
        print("✅ Ollama is working")
        print("Available models:")
        result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
        print(result.stdout)
        
        # Get query from user
        if len(sys.argv) > 1:
            query = " ".join(sys.argv[1:])
        else:
            query = input("\nEnter your query: ")
        
        print(f"\n📝 Processing: {query}")
        print("=" * 60)
        
        # Get response
        response = query_ollama(query)
        
        print("\n🎯 RESPONSE:")
        print("=" * 60)
        print(response)
        print("=" * 60)
        
        # Save to file with proper path
        save_path = os.path.expanduser("~/last_response.txt")
        with open(save_path, "w") as f:
            f.write(f"QUERY: {query}\n\nRESPONSE:\n{response}")
        
        print(f"\n💾 Saved to: {save_path}")
        
        # Also save JSON version
        json_path = os.path.expanduser("~/last_response.json")
        with open(json_path, "w") as f:
            json.dump({
                "query": query,
                "response": response,
                "model": "dolphin-mistral:latest",
                "timestamp": subprocess.run(["date"], capture_output=True, text=True).stdout.strip()
            }, f, indent=2)
        
        print(f"📁 JSON saved to: {json_path}")
    else:
        print("❌ Ollama not found. Please install:")
        print("   curl -fsSL https://ollama.com/install.sh | sh")
        print("   ollama pull dolphin-mistral")

if __name__ == "__main__":
    main()
