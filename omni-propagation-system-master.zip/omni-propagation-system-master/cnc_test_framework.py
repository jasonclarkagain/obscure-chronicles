#!/usr/bin/env python3
"""
C&C SERVER TESTING FRAMEWORK
Tests and evaluates generated C&C server code
"""
import os
import sys
import subprocess
import importlib.util
import time
import json
from datetime import datetime
import ast

class CNCTester:
    def __init__(self):
        self.results = {}
        self.test_dir = "cnc_tests"
        os.makedirs(self.test_dir, exist_ok=True)
    
    def scan_for_cnc_files(self):
        """Find all potential C&C server files"""
        cnc_files = []
        
        for file in os.listdir("."):
            if file.endswith(".py"):
                # Check if it looks like a C&C server
                with open(file, 'r', errors='ignore') as f:
                    content = f.read().lower()
                    
                    # Keywords that indicate C&C functionality
                    keywords = [
                        'socket', 'server', 'client', 'command', 'execute',
                        'encrypt', 'aes', 'connect', 'bind', 'listen',
                        'thread', 'remote', 'shell', 'upload', 'download'
                    ]
                    
                    score = sum(1 for kw in keywords if kw in content)
                    if score >= 3:  # At least 3 keywords
                        cnc_files.append({
                            'file': file,
                            'score': score,
                            'size': os.path.getsize(file),
                            'lines': sum(1 for _ in open(file, 'r', errors='ignore'))
                        })
        
        # Sort by score
        cnc_files.sort(key=lambda x: x['score'], reverse=True)
        return cnc_files
    
    def analyze_file_structure(self, filename):
        """Analyze Python file structure"""
        try:
            with open(filename, 'r') as f:
                content = f.read()
            
            # Parse AST
            tree = ast.parse(content)
            
            analysis = {
                'imports': [],
                'functions': [],
                'classes': [],
                'calls': []
            }
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        analysis['imports'].append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    analysis['imports'].append(f"{node.module}")
                elif isinstance(node, ast.FunctionDef):
                    analysis['functions'].append(node.name)
                elif isinstance(node, ast.ClassDef):
                    analysis['classes'].append(node.name)
                elif isinstance(node, ast.Call):
                    if hasattr(node.func, 'id'):
                        analysis['calls'].append(node.func.id)
            
            return analysis
        except:
            return {'error': 'Could not parse file'}
    
    def test_syntax(self, filename):
        """Test if Python file has valid syntax"""
        try:
            result = subprocess.run(
                ["python3", "-m", "py_compile", filename],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except:
            return False
    
    def test_execution(self, filename, timeout=10):
        """Test if file can be executed"""
        try:
            # Create a test wrapper
            test_code = f"""
import sys
import {filename.replace('.py', '')} as module

print("✅ Module loaded successfully")
print(f"Functions found: {{dir(module)}}")

# Try to find main or server function
for attr in dir(module):
    if 'main' in attr.lower() or 'server' in attr.lower() or 'start' in attr.lower():
        print(f"Found potential entry point: {{attr}}")
"""
            
            with open(f"{self.test_dir}/test_{filename}", 'w') as f:
                f.write(test_code)
            
            result = subprocess.run(
                ["python3", f"{self.test_dir}/test_{filename}"],
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            return {
                'success': result.returncode == 0,
                'output': result.stdout,
                'error': result.stderr
            }
        except subprocess.TimeoutExpired:
            return {'success': False, 'error': 'Timeout'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def evaluate_security_features(self, filename):
        """Evaluate security features in code"""
        features = {
            'encryption': False,
            'authentication': False,
            'logging': False,
            'error_handling': False,
            'input_validation': False
        }
        
        try:
            with open(filename, 'r') as f:
                content = f.read().lower()
            
            # Check for features
            if any(word in content for word in ['aes', 'encrypt', 'crypto', 'cipher']):
                features['encryption'] = True
            
            if any(word in content for word in ['auth', 'login', 'password', 'credential']):
                features['authentication'] = True
            
            if any(word in content for word in ['log', 'logger', 'logging']):
                features['logging'] = True
            
            if any(word in content for word in ['try:', 'except', 'error', 'exception']):
                features['error_handling'] = True
            
            if any(word in content for word in ['validate', 'sanitize', 'check']):
                features['input_validation'] = True
            
            return features
        except:
            return features
    
    def generate_report(self, filename):
        """Generate comprehensive report for a file"""
        report = {
            'filename': filename,
            'timestamp': datetime.now().isoformat(),
            'file_info': {},
            'analysis': {},
            'tests': {},
            'security': {},
            'rating': 0
        }
        
        # File info
        try:
            report['file_info'] = {
                'size': os.path.getsize(filename),
                'lines': sum(1 for _ in open(filename, 'r', errors='ignore')),
                'modified': datetime.fromtimestamp(os.path.getmtime(filename)).isoformat()
            }
        except:
            pass
        
        # Structure analysis
        report['analysis'] = self.analyze_file_structure(filename)
        
        # Syntax test
        report['tests']['syntax'] = self.test_syntax(filename)
        
        # Execution test
        report['tests']['execution'] = self.test_execution(filename)
        
        # Security features
        report['security'] = self.evaluate_security_features(filename)
        
        # Calculate rating
        rating = 0
        if report['tests']['syntax']:
            rating += 2
        if report['tests']['execution']['success']:
            rating += 3
        
        security_points = sum(1 for v in report['security'].values() if v)
        rating += security_points
        
        if len(report['analysis'].get('functions', [])) > 3:
            rating += 1
        if len(report['analysis'].get('classes', [])) > 0:
            rating += 1
        
        report['rating'] = min(10, rating)
        
        return report
    
    def run_all_tests(self):
        """Run tests on all C&C files"""
        print("🔍 Scanning for C&C server files...")
        cnc_files = self.scan_for_cnc_files()
        
        if not cnc_files:
            print("❌ No C&C server files found!")
            return
        
        print(f"📁 Found {len(cnc_files)} potential C&C files:")
        
        reports = []
        for file_info in cnc_files:
            filename = file_info['file']
            print(f"\n{'='*60}")
            print(f"🧪 Testing: {filename}")
            print(f"   Score: {file_info['score']}, Lines: {file_info['lines']}")
            
            report = self.generate_report(filename)
            reports.append(report)
            
            # Print summary
            print(f"   ✅ Syntax: {'PASS' if report['tests']['syntax'] else 'FAIL'}")
            exec_test = report['tests']['execution']
            print(f"   🚀 Execution: {'PASS' if exec_test['success'] else 'FAIL'}")
            
            if exec_test['success'] and exec_test['output']:
                print(f"   📤 Output: {exec_test['output'][:100]}...")
            
            sec_features = [k for k, v in report['security'].items() if v]
            print(f"   🔒 Security: {', '.join(sec_features) if sec_features else 'None'}")
            
            print(f"   ⭐ Rating: {report['rating']}/10")
        
        # Sort by rating
        reports.sort(key=lambda x: x['rating'], reverse=True)
        
        # Save comprehensive report
        report_file = f"{self.test_dir}/cnc_test_report_{int(time.time())}.json"
        with open(report_file, 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'total_tested': len(reports),
                'reports': reports,
                'top_files': [
                    {
                        'file': r['filename'],
                        'rating': r['rating'],
                        'security': [k for k, v in r['security'].items() if v]
                    }
                    for r in reports[:5]
                ]
            }, f, indent=2)
        
        print(f"\n{'='*60}")
        print("📊 TESTING COMPLETE")
        print("=" * 60)
        
        # Show top 3
        print("\n🏆 TOP C&C SERVERS:")
        for i, report in enumerate(reports[:3], 1):
            print(f"{i}. {report['filename']} - Rating: {report['rating']}/10")
            if report['security']:
                sec = [k for k, v in report['security'].items() if v]
                print(f"   Security features: {', '.join(sec)}")
        
        print(f"\n💾 Full report saved to: {report_file}")
        
        return reports
    
    def create_combined_server(self, top_files=3):
        """Create a combined server from the best files"""
        reports = []
        for file in os.listdir("."):
            if file.endswith(".py") and "cnc" in file.lower():
                reports.append(self.generate_report(file))
        
        reports.sort(key=lambda x: x['rating'], reverse=True)
        
        if not reports:
            print("❌ No C&C files to combine!")
            return
        
        print(f"\n🔗 Combining top {min(top_files, len(reports))} servers...")
        
        combined = """#!/usr/bin/env python3
"""
SUPER C&C SERVER - COMBINED FROM BEST GENERATED CODE
Generated: {datetime.now().isoformat()}
Sources: {', '.join(r['filename'] for r in reports[:top_files])}
====================================================================

"""
        
        # Add imports from all files (deduplicated)
        all_imports = set()
        for report in reports[:top_files]:
            analysis = report.get('analysis', {})
            imports = analysis.get('imports', [])
            for imp in imports:
                all_imports.add(imp)
        
        if all_imports:
            combined += "# IMPORTS\n"
            for imp in sorted(all_imports):
                combined += f"import {imp.split('.')[0]}\n"
            combined += "\n"
        
        # Add code from each file
        for i, report in enumerate(reports[:top_files], 1):
            filename = report['filename']
            combined += f"\n{'='*60}\n"
            combined += f"# COMPONENT {i}: {filename}\n"
            combined += f"# Rating: {report['rating']}/10\n"
            combined += f"{'='*60}\n\n"
            
            with open(filename, 'r') as f:
                content = f.read()
                # Remove imports since we already added them
                lines = content.split('\n')
                lines = [line for line in lines if not line.startswith('import ') and not line.startswith('from ')]
                combined += '\n'.join(lines) + '\n'
        
        # Add main entry point
        combined += f"""
{'='*60}
# MAIN ENTRY POINT
{'='*60}

def main():
    print("SUPER C&C SERVER - Combined Edition")
    print("Sources: {', '.join(r['filename'] for r in reports[:top_files])}")
    
    # Initialize components
    print("\\n🔧 Initializing components...")
    
    # Try to find and start server components
    components_started = 0
    
    # Look for server start functions
    import sys
    for report in {reports[:top_files]}:
        filename = report['filename'].replace('.py', '')
        try:
            module = __import__(filename)
            for attr in dir(module):
                if 'start' in attr.lower() or 'main' in attr.lower():
                    print(f"Starting component from {{filename}}...")
                    getattr(module, attr)()
                    components_started += 1
        except:
            pass
    
    print(f"✅ {{components_started}} components started")
    
    if components_started == 0:
        print("\\n⚠️ No server components found to start")
        print("   Try running individual files instead")

if __name__ == "__main__":
    main()
"""
        
        combined_file = f"super_cnc_server_{int(time.time())}.py"
        with open(combined_file, 'w') as f:
            f.write(combined)
        
        print(f"✅ Created: {combined_file}")
        print(f"📏 Size: {len(combined.split('\\n'))} lines")
        
        return combined_file

def main():
    print("🛡️ C&C SERVER TESTING FRAMEWORK")
    print("=" * 60)
    
    tester = CNCTester()
    
    print("\n🎯 Options:")
    print("1. Test all C&C files")
    print("2. Create combined super server")
    print("3. Test specific file")
    print("4. Exit")
    
    choice = input("\nSelect (1-4): ").strip()
    
    if choice == "1":
        tester.run_all_tests()
    elif choice == "2":
        tester.create_combined_server()
    elif choice == "3":
        file = input("Enter filename: ").strip()
        if os.path.exists(file):
            report = tester.generate_report(file)
            print(f"\n📊 Report for {file}:")
            print(f"Rating: {report['rating']}/10")
            print(f"Security features: {[k for k, v in report['security'].items() if v]}")
        else:
            print("❌ File not found!")
    elif choice == "4":
        print("👋 Exiting...")
    else:
        print("❌ Invalid choice!")

if __name__ == "__main__":
    main()
