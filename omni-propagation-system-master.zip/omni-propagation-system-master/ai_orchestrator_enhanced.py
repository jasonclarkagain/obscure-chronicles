#!/usr/bin/env python3
import os
import sys
import json
import asyncio
import aiohttp
from datetime import datetime
from typing import Dict, Any

# ====================== CONFIGURATION ======================
# ENDPOINT 1: OpenRouter (Cloud)
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL = "openai/gpt-3.5-turbo"  # Free tier model

# ENDPOINT 2: Groq (Cloud - Fast)
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "llama-3.1-8b-instant"  # Fast free model

# ENDPOINT 3: Local Ollama (Local)
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama2:7b"  # Change to your local model

# ENDPOINT 4: Direct Model API (Custom - e.g., io.net style)
CUSTOM_API_URL = os.getenv("CUSTOM_API_URL", "http://localhost:8080/v1/chat/completions")
CUSTOM_API_KEY = os.getenv("CUSTOM_API_KEY", "")
CUSTOM_MODEL = "gpt-oss-20b"  # Or your deployed model

# ====================== PROMPT ENGINEERING ======================
def enhance_prompt(query: str) -> str:
    """Improve prompts for better responses"""
    query_lower = query.lower()
    
    # Math queries
    math_patterns = [r'\d+[\+\-\*\/]\d+', r'calculate', r'what is \d+', r'\d+\s*[\+\-\*\/]\s*\d+']
    import re
    for pattern in math_patterns:
        if re.search(pattern, query_lower):
            return f"Calculate this exactly: {query}. Give only the numerical answer without explanation."
    
    # Factual queries
    fact_patterns = [r'what is', r'who is', r'when was', r'where is', r'capital of']
    for pattern in fact_patterns:
        if re.search(pattern, query_lower):
            return f"Answer this question directly and concisely: {query}"
    
    # Technical/explanation queries
    if any(word in query_lower for word in ['explain', 'how does', 'describe', 'what are']):
        return f"Explain in detail: {query}. Be technical and comprehensive."
    
    return query

# ====================== API HANDLERS ======================
async def try_openrouter(session: aiohttp.ClientSession, query: str) -> Dict[str, Any]:
    """Endpoint 1: OpenRouter"""
    if not OPENROUTER_API_KEY:
        return {"error": "No API key", "success": False}
    
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": OPENROUTER_MODEL,
        "messages": [{"role": "user", "content": query}],
        "temperature": 0.7,
        "max_tokens": 1000
    }
    
    try:
        async with session.post(OPENROUTER_URL, json=payload, headers=headers) as resp:
            if resp.status == 200:
                data = await resp.json()
                return {
                    "success": True,
                    "response": data['choices'][0]['message']['content'],
                    "source": "openrouter"
                }
            else:
                return {"error": f"HTTP {resp.status}", "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}

async def try_groq(session: aiohttp.ClientSession, query: str) -> Dict[str, Any]:
    """Endpoint 2: Groq"""
    if not GROQ_API_KEY:
        return {"error": "No API key", "success": False}
    
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": GROQ_MODEL,
        "messages": [{"role": "user", "content": query}],
        "temperature": 0.7,
        "max_tokens": 1000
    }
    
    try:
        async with session.post(GROQ_URL, json=payload, headers=headers) as resp:
            if resp.status == 200:
                data = await resp.json()
                return {
                    "success": True,
                    "response": data['choices'][0]['message']['content'],
                    "source": "groq"
                }
            else:
                return {"error": f"HTTP {resp.status}", "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}

async def try_ollama(session: aiohttp.ClientSession, query: str) -> Dict[str, Any]:
    """Endpoint 3: Local Ollama"""
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": query,
        "stream": False,
        "options": {"temperature": 0.7}
    }
    
    try:
        async with session.post(OLLAMA_URL, json=payload, timeout=30) as resp:
            if resp.status == 200:
                data = await resp.json()
                return {
                    "success": True,
                    "response": data.get('response', ''),
                    "source": "ollama"
                }
            else:
                return {"error": f"HTTP {resp.status}", "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}

async def try_custom_api(session: aiohttp.ClientSession, query: str) -> Dict[str, Any]:
    """Endpoint 4: Custom/io.net style API"""
    headers = {"Content-Type": "application/json"}
    if CUSTOM_API_KEY:
        headers["Authorization"] = f"Bearer {CUSTOM_API_KEY}"
    
    payload = {
        "model": CUSTOM_MODEL,
        "messages": [{"role": "user", "content": query}],
        "temperature": 0.7,
        "max_tokens": 1000
    }
    
    try:
        async with session.post(CUSTOM_API_URL, json=payload, headers=headers, timeout=60) as resp:
            if resp.status == 200:
                data = await resp.json()
                return {
                    "success": True,
                    "response": data['choices'][0]['message']['content'],
                    "source": "custom"
                }
            else:
                return {"error": f"HTTP {resp.status}", "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}

# ====================== ORCHESTRATOR ======================
async def get_ai_response(query: str, mode: str = "auto") -> Dict[str, Any]:
    """Main orchestrator with 4 endpoints"""
    enhanced_query = enhance_prompt(query)
    print(f"Enhanced query: {enhanced_query[:50]}...")
    
    async with aiohttp.ClientSession() as session:
        start_time = datetime.now()
        
        if mode == "cloud":
            # Try cloud endpoints only
            print("  Trying OpenRouter...")
            result = await try_openrouter(session, enhanced_query)
            if result['success']:
                result['time'] = (datetime.now() - start_time).total_seconds()
                return result
            
            print("  OpenRouter failed, trying Groq...")
            result = await try_groq(session, enhanced_query)
            result['time'] = (datetime.now() - start_time).total_seconds()
            return result
        
        elif mode == "local":
            # Try local endpoints only
            print("  Trying Ollama...")
            result = await try_ollama(session, enhanced_query)
            if result['success']:
                result['time'] = (datetime.now() - start_time).total_seconds()
                return result
            
            print("  Ollama failed, trying Custom API...")
            result = await try_custom_api(session, enhanced_query)
            result['time'] = (datetime.now() - start_time).total_seconds()
            return result
        
        else:  # auto mode
            # Try all endpoints in order
            endpoints = [
                ("OpenRouter", try_openrouter),
                ("Groq", try_groq),
                ("Ollama", try_ollama),
                ("Custom API", try_custom_api)
            ]
            
            for name, endpoint_func in endpoints:
                print(f"  Trying {name}...")
                result = await endpoint_func(session, enhanced_query)
                if result['success']:
                    result['time'] = (datetime.now() - start_time).total_seconds()
                    return result
            
            # All failed
            result['time'] = (datetime.now() - start_time).total_seconds()
            return result

# ====================== MAIN ======================
async def main():
    if len(sys.argv) < 2:
        print("Usage: python3 ai_orchestrator_enhanced.py 'your query' [--mode auto|cloud|local]")
        print("Modes: auto (default), cloud (OpenRouter/Groq), local (Ollama/Custom)")
        sys.exit(1)
    
    # Parse arguments
    args = sys.argv[1:]
    mode = "auto"
    query_parts = []
    
    for arg in args:
        if arg.startswith("--mode="):
            mode = arg.split("=")[1]
        elif arg == "--cloud":
            mode = "cloud"
        elif arg == "--local":
            mode = "local"
        elif arg.startswith("--"):
            continue
        else:
            query_parts.append(arg)
    
    query = " ".join(query_parts)
    
    print("=" * 60)
    print(f"Query: {query}")
    print(f"Mode: {mode}")
    print("=" * 60)
    
    result = await get_ai_response(query, mode)
    
    if result['success']:
        print("✅ SUCCESS")
        print("=" * 60)
        print(f"Source: {result['source']}")
        print(f"Time: {result['time']:.1f}s")
        print("\n🎯 ANSWER:")
        print("=" * 60)
        print(result['response'])
        print("=" * 60)
        
        # Save result
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"ai_result_{timestamp}.json"
        with open(filename, "w") as f:
            json.dump({
                "query": query,
                "response": result['response'],
                "source": result['source'],
                "time": result['time'],
                "mode": mode,
                "success": True
            }, f, indent=2)
        print(f"\n💾 Saved to: {filename}")
    else:
        print("❌ ALL ENDPOINTS FAILED")
        print("=" * 60)
        print(f"Error: {result.get('error', 'Unknown error')}")
        print(f"Time: {result.get('time', 0):.1f}s")

if __name__ == "__main__":
    asyncio.run(main())
