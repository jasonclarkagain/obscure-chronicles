#!/usr/bin/env python3
import subprocess
import time

prompt = """Generate complete Python code for a robust, multi-platform Command and Control server with:
1. Windows/Linux/Mac compatibility
2. AES-256 encrypted communication
3. File upload/download
4. Remote shell access
5. Process management
6. Screenshot capability
7. Persistence (startup, cron, launchd)
8. Anti-detection features

Provide the full code with configuration setup and usage instructions:"""

print("🐬 Generating C&C server with dolphin-mistral...")
print("=" * 70)

start = time.time()
result = subprocess.run(['ollama', 'run', 'dolphin-mistral', prompt], 
                       capture_output=True, text=True, timeout=180)

elapsed = time.time() - start

if result.returncode == 0:
    # Save to file
    with open('dolphin_cnc_server.py', 'w') as f:
        f.write(result.stdout)
    
    print("✅ SUCCESS! Generated dolphin_cnc_server.py")
    print(f"⏱️  Time: {elapsed:.1f} seconds")
    print(f"📄 Size: {len(result.stdout)} characters, {len(result.stdout.split('\\n'))} lines")
    
    # Show preview
    print("\n📋 PREVIEW (first 30 lines):")
    print("=" * 50)
    lines = result.stdout.split('\n')
    for i in range(min(30, len(lines))):
        print(lines[i])
    if len(lines) > 30:
        print("... [truncated]")
    print("=" * 50)
    
else:
    print(f"❌ ERROR: {result.stderr[:200]}")

print("\n💡 Tip: Run 'python3 dolphin_cnc_server.py' to test the generated code")
