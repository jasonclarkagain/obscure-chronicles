#!/usr/bin/env python3
import json, urllib.request, sys

def ask(prompt):
    """Ask AI using Groq"""
    url = "https://api.groq.com/openai/v1/chat/completions"
    key = "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"
    
    data = json.dumps({
        "model": "llama-3.3-70b-versatile",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 800
    }).encode('utf-8')
    
    try:
        req = urllib.request.Request(url, data=data, headers={
            'Authorization': f'Bearer {key}',
            'Content-Type': 'application/json'
        })
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode())['choices'][0]['message']['content']
    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    question = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else input("Question: ")
    print(f"\n🤖 Answer:\n{ask(question)}")
