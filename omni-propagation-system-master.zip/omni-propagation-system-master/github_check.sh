#!/bin/bash
echo "🔍 GitHub Repository Health Check"
echo "================================="

# Check for sensitive file patterns
echo "[1] Checking for sensitive patterns..."
SENSITIVE_PATTERNS=("password\|secret\|key\|token\|credential\|.pem\|.key")
if grep -r -i "$SENSITIVE_PATTERNS" --include="*.py" --include="*.sh" --include="*.md" . 2>/dev/null; then
    echo "⚠️  WARNING: Potential sensitive data found!"
else
    echo "✅ No obvious sensitive data found"
fi

# Check file sizes
echo ""
echo "[2] Checking file sizes..."
find . -type f -size +1M 2>/dev/null | while read file; do
    echo "⚠️  Large file: $file ($(du -h "$file" | cut -f1))"
done

# Check .gitignore effectiveness
echo ""
echo "[3] Checking .gitignore..."
if [ -f .gitignore ]; then
    echo "✅ .gitignore exists"
    grep -v "^#" .gitignore | grep -v "^$" | wc -l | xargs echo "  Rules:"
else
    echo "❌ .gitignore missing!"
fi

# Check remote
echo ""
echo "[4] Checking Git remote..."
git remote -v

echo ""
echo "================================="
echo "📋 Next Steps:"
echo "1. Verify repo is PRIVATE on GitHub"
echo "2. Review all files before pushing"
echo "3. Never push actual payloads/credentials"
echo "================================="
