#!/usr/bin/env python3
import http.server
import json
import socketserver
import subprocess
import os
import threading
from datetime import datetime

MODEL_PATH = os.path.expanduser("~/models/tinyllama.gguf")
LLAMA_CPP_PATH = os.path.expanduser("~/llama.cpp")

class EnhancedAIHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Suppress default logging
        pass
    
    def do_POST(self):
        if self.path == '/completion':
            self.handle_completion()
        elif self.path == '/v1/chat/completions':
            self.handle_openai_completion()
        else:
            self.send_response(404)
            self.end_headers()
    
    def handle_completion(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data)
            prompt = data.get('prompt', 'Hello')
            
            # Try to use llama.cpp if available
            response_text = self.generate_response(prompt)
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                'content': response_text,
                'model': 'tinyllama-local',
                'success': True,
                'created': int(datetime.now().timestamp())
            }).encode())
            
        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(json.dumps({'error': str(e), 'success': False}).encode())
    
    def handle_openai_completion(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data)
            messages = data.get('messages', [])
            prompt = messages[-1]['content'] if messages else 'Hello'
            
            response_text = self.generate_response(prompt)
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                'choices': [{
                    'message': {
                        'role': 'assistant',
                        'content': response_text
                    },
                    'finish_reason': 'stop',
                    'index': 0
                }],
                'model': 'tinyllama-local',
                'created': int(datetime.now().timestamp())
            }).encode())
            
        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(json.dumps({'error': str(e)}).encode())
    
    def generate_response(self, prompt):
        # Check for llama.cpp main binary
        llama_cli = os.path.join(LLAMA_CPP_PATH, 'main')
        if os.path.exists(llama_cli) and os.path.exists(MODEL_PATH):
            try:
                # Try to use actual model
                cmd = [llama_cli, '-m', MODEL_PATH, '-p', prompt, '-n', '100', '-t', '2', '--temp', '0.7']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                return result.stdout.strip()
            except:
                # Fallback to echo
                return f"Response to: {prompt} (using TinyLlama 1.1B)"
        else:
            # Enhanced echo for testing
            responses = {
                "hello": "Hello! I'm your local AI assistant running on TinyLlama.",
                "help": "I can help with basic questions. Try asking about programming or general knowledge.",
                "test": "Local server test successful! The AI system is working.",
                "unrestricted": "This is a local model running without external API filters.",
            }
            
            prompt_lower = prompt.lower()
            for key, response in responses.items():
                if key in prompt_lower:
                    return response
            
            return f"Local AI received: '{prompt}'. This would be processed by TinyLlama 1.1B model."
    
    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = {
                'status': 'ok',
                'model': 'tinyllama-1.1b',
                'server': 'enhanced-local',
                'endpoints': ['/completion', '/v1/chat/completions', '/health']
            }
            self.wfile.write(json.dumps(response).encode())
        elif self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b'<h1>Local AI Server</h1><p>TinyLlama 1.1B running locally</p>')
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == '__main__':
    PORT = 8080
    print(f"🤖 ENHANCED LOCAL AI SERVER")
    print(f"=============================")
    print(f"Port: {PORT}")
    print(f"Model: TinyLlama 1.1B")
    print(f"Endpoints:")
    print(f"  • GET  /health              - Server status")
    print(f"  • POST /completion          - Basic completion")
    print(f"  • POST /v1/chat/completions - OpenAI-compatible")
    print(f"=============================")
    
    with socketserver.TCPServer(("", PORT), EnhancedAIHandler) as httpd:
        httpd.serve_forever()
