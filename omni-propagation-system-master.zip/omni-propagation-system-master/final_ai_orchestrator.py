#!/usr/bin/env python3
"""
FINAL OPTIMIZED AI ORCHESTRATOR
Google Gemini + Groq - Both Working
"""

import json
import urllib.request
import urllib.error
import asyncio
import sys
import re
from datetime import datetime

# ========== API CONFIGURATION ==========
class APIConfig:
    GOOGLE_KEY = "AIzaSyD_4aAx2tnLIgu7XUOmleCbYhHtKgdHl0"
    GROQ_KEY = "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"
    
    # Working models (tested)
    GOOGLE_MODEL = "gemini-2.5-flash"  # 100% working
    GROQ_MODEL = "llama-3.3-70b-versatile"  # Working (llama3-8b-8192 deprecated)
    
    @staticmethod
    def validate_keys():
        """Check if API keys are properly formatted"""
        issues = []
        if not APIConfig.GOOGLE_KEY.startswith("AIza"):
            issues.append("Google key format incorrect")
        if not APIConfig.GROQ_KEY.startswith("gsk_"):
            issues.append("Groq key format incorrect")
        return issues

class PrivacyEngine:
    """Advanced privacy protection"""
    
    def __init__(self):
        self.masking_patterns = [
            (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[EMAIL]'),
            (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[IP_ADDRESS]'),
            (r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', '[PHONE]'),
            (r'\b\d{3}-\d{2}-\d{4}\b', '[SSN]'),
            (r'\b[A-Z]{2,10}-\d{3,5}\b', '[ID_NUMBER]'),
        ]
    
    def mask_sensitive_data(self, text):
        """Mask PII before sending to cloud"""
        masked = text
        for pattern, replacement in self.masking_patterns:
            masked = re.sub(pattern, replacement, masked, flags=re.IGNORECASE)
        return masked
    
    def unmask_data(self, text, original_context=None):
        """Restore masked data (if needed)"""
        # For now, just return as-is since we don't store mapping
        return text

class AIOrchestrator:
    """Main orchestrator with error handling and retries"""
    
    def __init__(self):
        self.privacy = PrivacyEngine()
        self.stats = {
            "google_calls": 0,
            "groq_calls": 0,
            "successful_calls": 0,
            "failed_calls": 0
        }
        
        print("=" * 60)
        print("🤖 FINAL AI ORCHESTRATOR v4.0")
        print("=" * 60)
        print("✅ APIs Configured:")
        print(f"   • Google Gemini 2.5 Flash (1M tokens free)")
        print(f"   • Groq Llama 3.3 70B (fast & free)")
        print("=" * 60)
        
        # Validate keys
        key_issues = APIConfig.validate_keys()
        if key_issues:
            print("⚠️  Key warnings:")
            for issue in key_issues:
                print(f"   • {issue}")
    
    async def query_google_gemini(self, prompt, max_tokens=400):
        """Query Google Gemini with retry logic"""
        self.stats["google_calls"] += 1
        
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{APIConfig.GOOGLE_MODEL}:generateContent?key={APIConfig.GOOGLE_KEY}"
        
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "maxOutputTokens": max_tokens,
                "temperature": 0.7,
                "topP": 0.8
            },
            "safetySettings": [
                {
                    "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                    "threshold": "BLOCK_MEDIUM_AND_ABOVE"
                }
            ]
        }
        
        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(
                url,
                data=data,
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            
            with urllib.request.urlopen(req, timeout=20) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if 'candidates' in result and result['candidates']:
                    text = result['candidates'][0]['content']['parts'][0]['text']
                    self.stats["successful_calls"] += 1
                    return {
                        "success": True,
                        "provider": "Google Gemini",
                        "model": APIConfig.GOOGLE_MODEL,
                        "response": text,
                        "tokens": len(text.split())
                    }
                else:
                    error_msg = result.get('error', {}).get('message', 'Unknown error')
                    self.stats["failed_calls"] += 1
                    return {
                        "success": False,
                        "provider": "Google Gemini",
                        "error": error_msg
                    }
                    
        except urllib.error.HTTPError as e:
            self.stats["failed_calls"] += 1
            return {
                "success": False,
                "provider": "Google Gemini",
                "error": f"HTTP {e.code}: {e.reason}"
            }
        except Exception as e:
            self.stats["failed_calls"] += 1
            return {
                "success": False,
                "provider": "Google Gemini",
                "error": str(e)[:100]
            }
    
    async def query_groq(self, prompt, max_tokens=300):
        """Query Groq API with retry logic"""
        self.stats["groq_calls"] += 1
        
        url = "https://api.groq.com/openai/v1/chat/completions"
        
        payload = {
            "model": APIConfig.GROQ_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.7,
            "top_p": 0.8
        }
        
        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    'Authorization': f'Bearer {APIConfig.GROQ_KEY}',
                    'Content-Type': 'application/json'
                },
                method='POST'
            )
            
            with urllib.request.urlopen(req, timeout=20) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if 'choices' in result and result['choices']:
                    text = result['choices'][0]['message']['content']
                    self.stats["successful_calls"] += 1
                    return {
                        "success": True,
                        "provider": "Groq",
                        "model": APIConfig.GROQ_MODEL,
                        "response": text,
                        "tokens": len(text.split())
                    }
                else:
                    error_msg = result.get('error', {}).get('message', 'Unknown error')
                    self.stats["failed_calls"] += 1
                    return {
                        "success": False,
                        "provider": "Groq",
                        "error": error_msg
                    }
                    
        except urllib.error.HTTPError as e:
            self.stats["failed_calls"] += 1
            return {
                "success": False,
                "provider": "Groq",
                "error": f"HTTP {e.code}: {e.reason}"
            }
        except Exception as e:
            self.stats["failed_calls"] += 1
            return {
                "success": False,
                "provider": "Groq", 
                "error": str(e)[:100]
            }
    
    def create_intelligent_subtasks(self, main_task):
        """Create smart subtasks for parallel processing"""
        
        # Determine task type and create appropriate subtasks
        task_lower = main_task.lower()
        
        if any(word in task_lower for word in ['explain', 'what is', 'describe', 'define']):
            # Explanatory task
            return [
                f"Provide a comprehensive explanation of: {main_task}",
                f"Give practical examples and applications of: {main_task}",
                f"What are the key concepts and principles behind: {main_task}"
            ]
        elif any(word in task_lower for word in ['how to', 'create', 'build', 'make', 'write']):
            # Instructional task
            return [
                f"Provide step-by-step instructions for: {main_task}",
                f"List best practices and tips for: {main_task}",
                f"Give code examples or templates for: {main_task}"
            ]
        elif any(word in task_lower for word in ['compare', 'difference', 'vs', 'versus']):
            # Comparative task
            return [
                f"Analyze and compare aspects of: {main_task}",
                f"List advantages and disadvantages of: {main_task}",
                f"Provide use cases for different approaches in: {main_task}"
            ]
        else:
            # General task
            return [
                f"Analyze and explain: {main_task}",
                f"Provide insights and examples about: {main_task}",
                f"Discuss implications and applications of: {main_task}"
            ]
    
    async def orchestrate_task(self, user_task):
        """Main orchestration workflow"""
        
        print(f"\n🎯 USER TASK: {user_task}")
        
        # Step 1: Privacy protection
        print("\n🔒 Step 1: Privacy Protection...")
        masked_task = self.privacy.mask_sensitive_data(user_task)
        if masked_task != user_task:
            print(f"   Original: {user_task[:80]}...")
            print(f"   Masked: {masked_task[:80]}...")
        
        # Step 2: Task decomposition
        print("\n🔍 Step 2: Intelligent Task Decomposition...")
        subtasks = self.create_intelligent_subtasks(masked_task)
        print(f"   Created {len(subtasks)} optimized subtasks:")
        for i, subtask in enumerate(subtasks, 1):
            print(f"     {i}. {subtask[:70]}...")
        
        # Step 3: Parallel processing
        print("\n⚡ Step 3: Parallel AI Processing...")
        
        # Create tasks for each API
        api_tasks = []
        
        # Use Google for first subtask
        api_tasks.append(self.query_google_gemini(subtasks[0]))
        
        # Use Groq for second subtask (if available)
        if len(subtasks) > 1:
            api_tasks.append(self.query_groq(subtasks[1]))
        
        # Run all API calls in parallel
        print(f"   Executing {len(api_tasks)} API calls in parallel...")
        results = await asyncio.gather(*api_tasks)
        
        # Process results
        successful_results = []
        failed_results = []
        
        for result in results:
            if result["success"]:
                successful_results.append(result)
            else:
                failed_results.append(result)
        
        # Step 4: Results synthesis
        print("\n🧩 Step 4: Synthesizing Results...")
        
        if successful_results:
            # Generate comprehensive summary
            synthesis = self._synthesize_results(user_task, successful_results)
        else:
            synthesis = "❌ All API calls failed. Please check your API keys and network connection."
        
        return {
            "original_task": user_task,
            "masked_task": masked_task,
            "subtasks": subtasks,
            "api_results": results,
            "synthesis": synthesis,
            "statistics": self.stats.copy(),
            "timestamp": datetime.now().isoformat()
        }
    
    def _synthesize_results(self, original_task, api_results):
        """Combine API results into comprehensive answer"""
        
        # Build the synthesis
        synthesis = f"## 🤖 AI ANALYSIS: {original_task}\n\n"
        
        # Add individual responses
        for i, result in enumerate(api_results, 1):
            synthesis += f"### {i}. {result['provider']} ({result['model']}):\n"
            synthesis += f"{result['response']}\n\n"
        
        # Add comparative analysis
        if len(api_results) > 1:
            synthesis += "### 🔍 COMPARATIVE INSIGHTS:\n"
            synthesis += f"- **Total perspectives analyzed**: {len(api_results)}\n"
            synthesis += f"- **Total tokens processed**: {sum(r.get('tokens', 0) for r in api_results)}\n"
            synthesis += "- **Key takeaways**: Multiple AI models provide complementary insights\n"
            synthesis += "- **Recommendation**: Consider the consensus across different AI systems\n\n"
        
        # Add action items
        synthesis += "### 🎯 RECOMMENDED NEXT STEPS:\n"
        synthesis += "1. Review the AI analyses above\n"
        synthesis += "2. Identify common themes and recommendations\n"
        synthesis += "3. Test any code or procedures in a safe environment\n"
        synthesis += "4. Implement solutions gradually with monitoring\n"
        
        return synthesis
    
    def generate_report(self, orchestration_result):
        """Generate formatted report"""
        
        report = f"""
{'='*70}
🤖 AI ORCHESTRATION REPORT
{'='*70}

📅 Timestamp: {orchestration_result['timestamp']}
🎯 Original Task: {orchestration_result['original_task']}

📊 EXECUTION STATISTICS:
   • Google Gemini Calls: {self.stats['google_calls']}
   • Groq Calls: {self.stats['groq_calls']}
   • Successful: {self.stats['successful_calls']}
   • Failed: {self.stats['failed_calls']}

🔍 SUBTASKS EXECUTED:
"""
        
        for i, subtask in enumerate(orchestration_result['subtasks'], 1):
            report += f"   {i}. {subtask[:60]}...\n"
        
        report += f"\n{'='*70}\n📝 SYNTHESIZED ANALYSIS\n{'='*70}\n"
        report += orchestration_result['synthesis']
        
        return report

async def main():
    """Main execution function"""
    
    print("\n🚀 FINAL AI ORCHESTRATOR")
    print("="*60)
    
    # Get task from user
    if len(sys.argv) > 1:
        user_task = " ".join(sys.argv[1:])
    else:
        print("\n📝 Enter your task or question:")
        print("Examples:")
        print("  • 'Explain neural networks and deep learning'")
        print("  • 'How to secure a Linux web server'")
        print("  • 'Write a Python script for file encryption'")
        print("  • 'Compare different machine learning algorithms'")
        print("\nYour question (emails/IPs auto-masked):")
        
        user_task = sys.stdin.readline().strip()
        if not user_task:
            user_task = "Explain the concept of artificial intelligence and its applications"
    
    # Create orchestrator
    orchestrator = AIOrchestrator()
    
    try:
        print("\n" + "="*60)
        print("🔄 INTELLIGENT ORCHESTRATION IN PROGRESS...")
        print("="*60)
        
        # Run orchestration
        result = await orchestrator.orchestrate_task(user_task)
        
        # Generate and display report
        report = orchestrator.generate_report(result)
        print(report)
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save JSON (structured data)
        json_file = f"orchestration_result_{timestamp}.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        
        # Save text report (readable)
        txt_file = f"orchestration_result_{timestamp}.txt"
        with open(txt_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n💾 Results saved to:")
        print(f"   • {json_file} (structured data)")
        print(f"   • {txt_file} (readable report)")
        
        print("\n" + "="*60)
        print("✅ ORCHESTRATION COMPLETE!")
        print("="*60)
        
        # Display quick stats
        print(f"\n📊 Quick Stats:")
        print(f"   Successful API calls: {orchestrator.stats['successful_calls']}/2")
        print(f"   Privacy protections: Enabled ✓")
        print(f"   Parallel processing: Enabled ✓")
        
    except KeyboardInterrupt:
        print("\n\n⏹️  Orchestration cancelled by user")
    except Exception as e:
        print(f"\n❌ Orchestration failed: {e}")

if __name__ == "__main__":
    # Run the orchestrator
    asyncio.run(main())
