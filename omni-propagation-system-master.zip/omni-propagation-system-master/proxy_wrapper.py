import socks
import socket
import requests

# Configure the Chain: Tor (9050) -> Private SOCKS5 -> Target
def setup_ghost_chain():
    # Tunneling all socket traffic through the chain
    socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 9050)
    socket.socket = socks.socksocket
    
    # Test the chain
    try:
        ip = requests.get('https://api.ipify.org').text
        print(f"[*] [GHOST] Traffic Tunneled. Exit Node IP: {ip}")
    except:
        print("[-] [GHOST] Chain broken. Entering silence mode.")

if __name__ == "__main__":
    setup_ghost_chain()
