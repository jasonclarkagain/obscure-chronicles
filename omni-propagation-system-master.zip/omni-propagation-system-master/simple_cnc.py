import socket

def main():
    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Bind the socket to the port
    server_address = ('localhost', 12345)
    print('starting up on {} port {}'.format(*server_address))
    sock.bind(server_address)

    # Listen for incoming connections
    sock.listen(1)
    
    while True:
        # Wait for a connection, then concurrently process the request on a new thread
        print('waiting for a connection')
        client, address = sock.accept()
        print('connection from', address)
        
        # Execute command on client's request
        while True:
            try:
                data = client.recv(1024).decode("utf-8")
                if not data:
                    break
                print