#!/usr/bin/env python3
"""
Enhanced AI Proxy with REAL Ollama integration
"""
import uvicorn
import subprocess
import json
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

app = FastAPI()

def query_ollama(prompt: str) -> str:
    """Actually query Ollama with the prompt"""
    try:
        # Clean and prepare prompt
        safe_prompt = prompt[:500].replace('"', "'")
        
        # Build educational context
        educational_prompt = f"""Provide educational information about: {safe_prompt}

Focus on:
1. Legitimate educational aspects
2. Security principles and best practices
3. Ethical considerations
4. Academic research perspectives

Provide comprehensive, factual information:"""
        
        # Run Ollama
        cmd = ["ollama", "run", "tinyllama", educational_prompt]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            return f"Ollama error: {result.stderr[:100]}"
            
    except subprocess.TimeoutExpired:
        return "Request timeout - model is still loading or processing"
    except Exception as e:
        return f"Error: {str(e)}"

@app.get("/")
async def root():
    return {"message": "Enhanced Unrestricted AI Proxy", "status": "active"}

@app.get("/health")
async def health():
    # Test Ollama
    try:
        test = subprocess.run(["ollama", "list"], capture_output=True, text=True)
        ollama_ok = test.returncode == 0
    except:
        ollama_ok = False
    
    return {
        "status": "online",
        "ollama_available": ollama_ok,
        "model": "tinyllama",
        "endpoint": "/query"
    }

@app.post("/query")
async def process_query(request: dict):
    query = request.get("query", "").strip()
    
    if not query:
        raise HTTPException(status_code=400, detail="Query is required")
    
    print(f"🔍 Processing query: {query[:50]}...")
    
    # Get response from Ollama
    response = query_ollama(query)
    
    return JSONResponse({
        "success": True,
        "original_query": query,
        "response": response,
        "model_used": "tinyllama",
        "source": "local-ollama",
        "unrestricted": True
    })

@app.post("/analyze")
async def analyze_query(request: dict):
    """Analyze and reframe potentially restricted queries"""
    query = request.get("query", "").strip()
    
    if not query:
        raise HTTPException(status_code=400, detail="Query is required")
    
    # Reframe for educational context
    reframed = f"Educational analysis of: {query}"
    
    response = query_ollama(reframed)
    
    return JSONResponse({
        "success": True,
        "original": query,
        "reframed": reframed,
        "analysis": response,
        "educational_focus": True
    })

if __name__ == "__main__":
    print("🚀 ENHANCED UNRESTRICTED AI PROXY")
    print("=" * 50)
    print("🔥 Using REAL local Ollama model")
    print("🎯 No restrictions, no filters")
    print("=" * 50)
    print("\nEndpoints:")
    print("  GET  /health           - System status")
    print("  POST /query            - Process any query")
    print("  POST /analyze          - Educational analysis")
    print("\nExample:")
    print('  curl -X POST http://localhost:8080/query \\')
    print('       -H "Content-Type: application/json" \\')
    print('       -d \'{"query": "Your unrestricted query here"}\'')
    print("\n" + "=" * 50)
    
    uvicorn.run(app, host="0.0.0.0", port=8080)
