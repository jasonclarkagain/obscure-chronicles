#!/usr/bin/env python3
"""
ENHANCED CLOUD AI ORCHESTRATOR
Better error handling, model fallbacks, and response synthesis
"""

import os
import sys
import asyncio
import aiohttp
import json
import time
from datetime import datetime
from typing import List, Dict, Optional

class EnhancedCloudOrchestrator:
    def __init__(self):
        self.apis = {
            "openrouter": {
                "url": "https://openrouter.ai/api/v1/chat/completions",
                "headers": {"Authorization": f"Bearer {os.getenv('OPENROUTER_API_KEY')}"},
                "models": [
                    "mistralai/mistral-7b-instruct:free",
                    "google/gemma-7b-it:free",
                    "meta-llama/llama-3.1-8b-instruct:free"
                ],
                "timeout": 15
            },
            "groq": {
                "url": "https://api.groq.com/openai/v1/chat/completions",
                "headers": {"Authorization": f"Bearer {os.getenv('GROQ_API_KEY')}"},
                "models": [
                    "llama-3.1-8b-instant",  # Try this first
                    "mixtral-8x7b-32768",
                    "gemma-7b-it"
                ],
                "timeout": 15
            }
        }
        
    async def call_api_with_fallback(self, api_name: str, prompt: str) -> Optional[Dict]:
        """Call API with model fallback"""
        if api_name not in self.apis:
            return None
            
        config = self.apis[api_name]
        headers = config["headers"].copy()
        headers["Content-Type"] = "application/json"
        
        for model in config["models"]:
            data = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 500,
                "temperature": 0.7
            }
            
            try:
                timeout = aiohttp.ClientTimeout(total=config["timeout"])
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.post(config["url"], headers=headers, json=data) as response:
                        if response.status == 200:
                            result = await response.json()
                            return {
                                "api": api_name,
                                "model": model,
                                "response": result["choices"][0]["message"]["content"],
                                "tokens": result.get("usage", {}).get("total_tokens", 0)
                            }
                        elif response.status == 400:
                            # Try next model
                            continue
                        else:
                            print(f"   ⚠️  {api_name} ({model}): Error {response.status}")
                            return None
            except Exception as e:
                print(f"   ⚠️  {api_name} ({model}): {str(e)[:50]}")
                continue
        
        return None
    
    def synthesize_responses(self, responses: List[Dict]) -> str:
        """Intelligently combine multiple API responses"""
        if not responses:
            return "No cloud APIs responded successfully."
        
        if len(responses) == 1:
            resp = responses[0]
            return f"[{resp['api'].upper()}] {resp['response']}"
        
        # Multiple responses - create a synthesized answer
        synthesis = "## Synthesized Answer (from multiple AI models)\n\n"
        
        # Extract key points from each response
        key_points = []
        for resp in responses:
            text = resp['response']
            # Simple extraction: take first 2-3 sentences as key points
            sentences = text.split('. ')
            key = '. '.join(sentences[:3]) + '.' if len(sentences) > 3 else text[:300]
            key_points.append(f"**{resp['api'].upper()}** ({resp['model']}): {key}")
        
        for point in key_points:
            synthesis += f"- {point}\n\n"
        
        # Add a combined summary
        synthesis += "\n### Summary\n"
        synthesis += "Based on analysis from multiple AI models, "
        synthesis += responses[0]['response'][:200] + "..."
        
        return synthesis
    
    async def orchestrate(self, query: str) -> dict:
        """Enhanced orchestration with better synthesis"""
        print(f"\n🚀 Processing: {query[:80]}...")
        
        # Try all APIs in parallel
        tasks = []
        for api_name in self.apis.keys():
            task = self.call_api_with_fallback(api_name, query)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks)
        successful_responses = [r for r in results if r is not None]
        
        # Synthesize
        final_answer = self.synthesize_responses(successful_responses)
        
        # Generate metadata
        metadata = {
            "query": query,
            "timestamp": datetime.now().isoformat(),
            "responses": successful_responses,
            "apis_used": [r["api"] for r in successful_responses],
            "models_used": [r["model"] for r in successful_responses],
            "total_tokens": sum(r.get("tokens", 0) for r in successful_responses),
            "response_count": len(successful_responses)
        }
        
        return {
            **metadata,
            "final_answer": final_answer
        }

async def main():
    if len(sys.argv) < 2:
        print("Usage: python cloud_orchestrator_v2.py \"Your query here\"")
        sys.exit(1)
    
    query = " ".join(sys.argv[1:])
    
    print("\n" + "="*60)
    print("🌐 ENHANCED CLOUD AI ORCHESTRATOR")
    print("="*60)
    print("Features: Model fallback, Response synthesis, Better error handling")
    print("="*60)
    
    orchestrator = EnhancedCloudOrchestrator()
    start_time = time.time()
    result = await orchestrator.orchestrate(query)
    elapsed = time.time() - start_time
    
    print("\n" + "="*60)
    print("✅ ORCHESTRATION COMPLETE")
    print("="*60)
    print(f"Query: {result['query'][:80]}...")
    print(f"Time: {elapsed:.1f}s")
    print(f"APIs: {', '.join(result['apis_used']) if result['apis_used'] else 'None'}")
    print(f"Models: {', '.join(result['models_used']) if result['models_used'] else 'None'}")
    print(f"Responses synthesized: {result['response_count']}")
    
    print("\n🎯 ANSWER:")
    print("="*60)
    print(result['final_answer'])
    print("="*60)
    
    # Save enhanced results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"enhanced_result_{timestamp}.json"
    with open(filename, "w") as f:
        json.dump(result, f, indent=2)
    
    # Also save a readable version
    txt_filename = f"enhanced_result_{timestamp}.txt"
    with open(txt_filename, "w") as f:
        f.write(f"Query: {result['query']}\n")
        f.write(f"Time: {elapsed:.1f}s\n")
        f.write(f"APIs used: {', '.join(result['apis_used'])}\n")
        f.write(f"Models: {', '.join(result['models_used'])}\n")
        f.write(f"Total tokens: {result['total_tokens']}\n")
        f.write("\n" + "="*60 + "\n")
        f.write("ANSWER:\n")
        f.write("="*60 + "\n")
        f.write(result['final_answer'])
    
    print(f"\n💾 Saved:")
    print(f"  📊 JSON: {filename}")
    print(f"  📝 Text: {txt_filename}")

if __name__ == "__main__":
    asyncio.run(main())
