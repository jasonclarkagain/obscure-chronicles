import time
import os

# 7 days in seconds
TIMEOUT = 604800 
CHECK_FILE = ".last_heartbeat"

def check_switch():
    if not os.path.exists(CHECK_FILE):
        with open(CHECK_FILE, "w") as f:
            f.write(str(time.time()))
        return

    with open(CHECK_FILE, "r") as f:
        last_seen = float(f.read())

    if (time.time() - last_seen) > TIMEOUT:
        print("[!] DEAD MAN'S SWITCH TRIGGERED.")
        # Trigger the Exfiltration and Self-Shred
        os.system("python3 exit_shredder.py")
    else:
        print("[+] Heartbeat valid. Mission continues.")

if __name__ == "__main__":
    check_switch()
