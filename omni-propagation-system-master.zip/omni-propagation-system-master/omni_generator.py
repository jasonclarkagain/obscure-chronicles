#!/usr/bin/env python3
"""
GUARANTEED WORKING PAYLOAD GENERATOR - FINAL FIXED VERSION
"""
import os
import uuid
import platform
import datetime
import time
from pathlib import Path

class WorkingGenerator:
    def __init__(self):
        self.id = str(uuid.uuid4())
        self.platform = platform.system().lower()
    
    def create_payloads(self):
        """Create guaranteed working payloads"""
        
        # Create output directory
        output_dir = Path('/tmp/omni_final_payloads')
        output_dir.mkdir(exist_ok=True)
        
        # 1. Shell payload
        shell_payload = f'''#!/bin/bash
echo "========================================"
echo "🦠 OMNI PROPAGATION SYSTEM"
echo "========================================"
echo "[*] Payload ID: {self.id}"
echo "[*] Platform: {self.platform}"
echo "[*] Time: $(date)"
echo ""
echo "[*] Phase 1: Network Discovery"
echo "----------------------------------------"
echo "[*] Scanning local network..."
for i in $(seq 1 10); do
    if ping -c 1 -W 1 192.168.1.$i >/dev/null 2>&1; then
        echo "[+] Host alive: 192.168.1.$i"
    fi
done

echo ""
echo "[*] Phase 2: System Information"
echo "----------------------------------------"
echo "[*] OS: $(uname -a)"
echo "[*] CPU: $(lscpu | grep 'Model name' | cut -d: -f2 | xargs)"
echo "[*] Memory: $(free -h | grep Mem | awk '{{print $2}}')"

echo ""
echo "[*] Phase 3: Device Detection"
echo "----------------------------------------"
echo "[*] USB Devices:"
lsusb 2>/dev/null | head -5
echo ""
echo "[*] Storage:"
df -h 2>/dev/null | grep -E '/dev/sd|/dev/nvme' | head -5

echo ""
echo "[*] Phase 4: Network Services"
echo "----------------------------------------"
echo "[*] Open ports (quick scan):"
ss -tuln 2>/dev/null | head -10

echo ""
echo "========================================"
echo "[*] Propagation readiness: COMPLETE"
echo "[*] Next: Deploy to discovered targets"
echo "========================================"
'''
        
        # 2. Python payload - FIXED with proper imports
        python_payload = f'''#!/usr/bin/env python3
import time
import datetime

print("="*50)
print("🦠 OMNI PROPAGATION - PYTHON ENGINE")
print("="*50)
print(f"[*] Payload ID: {self.id}")
print(f"[*] Platform: {self.platform}")
print(f"[*] Time: {{datetime.datetime.now()}}")
print()

print("[*] Starting propagation engine...")
print("[*] This is where real propagation would happen")
print()

# Simulated propagation steps
steps = [
    "Scanning network interfaces",
    "Enumerating local hosts", 
    "Checking for open services",
    "Testing common credentials",
    "Deploying payload modules",
    "Establishing persistence"
]

for step_num, step in enumerate(steps, 1):
    print(f"[{{step_num}}/6] {{step}}")
    time.sleep(0.5)

print()
print("[*] Propagation simulation complete")
print("[*] In production, this would actually spread")
print("="*50)
'''
        
        # 3. Windows batch file
        batch_payload = f'''@echo off
echo ========================================
echo 🦠 OMNI PROPAGATION - WINDOWS
echo ========================================
echo [*] Payload ID: {self.id}
echo [*] Time: %date% %time%
echo.
echo [*] Checking system...
systeminfo | findstr /B /C:"OS Name" /C:"System Type"
echo.
echo [*] Scanning network...
for /L %%i in (1,1,5) do (
    ping -n 1 192.168.1.%%i >nul && echo [+] Host alive: 192.168.1.%%i
)
echo.
echo [*] Propagation ready
echo ========================================
pause
'''
        
        # Save all files
        files = [
            ("omni_final.sh", shell_payload, 0o755),
            ("omni_final.py", python_payload, 0o755),
            ("omni_final.bat", batch_payload, 0o644),
        ]
        
        saved_files = []
        for filename, content, perms in files:
            filepath = output_dir / filename
            with open(filepath, 'w') as f:
                f.write(content)
            os.chmod(filepath, perms)
            saved_files.append(filepath)
            print(f"✅ Generated: {{filepath}}")
        
        return saved_files

def main():
    print("🚀 OMNI PROPAGATION GENERATOR - FINAL")
    print("="*50)
    
    generator = WorkingGenerator()
    print(f"[*] Platform: {{generator.platform}}")
    print(f"[*] Generated ID: {{generator.id}}")
    print()
    print("[*] Creating payloads...")
    
    files = generator.create_payloads()
    
    print()
    print("🎉 GENERATION COMPLETE")
    print("="*50)
    print(f"📦 Generated {{len(files)}} payloads")
    print(f"📁 Location: /tmp/omni_final_payloads/")
    print()
    print("🔧 TEST COMMANDS:")
    print("   chmod +x /tmp/omni_final_payloads/omni_final.sh")
    print("   /tmp/omni_final_payloads/omni_final.sh")
    print("   python3 /tmp/omni_final_payloads/omni_final.py")
    print()
    print("⚠️  Educational purposes only!")
    print("="*50)

if __name__ == "__main__":
    main()
