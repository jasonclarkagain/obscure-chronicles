import os
import base64
from cryptography.fernet import Fernet

def reassemble_shards(output_file):
    print("[+] Weaver Active. Initializing RAM Reassembly...")
    
    # Load the key - in the real 'Unstoppable' version, this is passed via memory, not a file
    with open("shards/master.key", "rb") as key_file:
        key = key_file.read()
    
    f = Fernet(key)
    full_encoded_data = b""
    
    # Identify and sort shards to ensure correct sequence
    shard_files = sorted([f for f in os.listdir('shards') if f.endswith('.shard')], 
                         key=lambda x: int(x.split('_')[-1].split('.')[0]))
    
    print(f"[*] Found {len(shard_files)} shards. Extracting from Noise...")
    
    for filename in shard_files:
        with open(f"shards/{filename}", 'rb') as shard_file:
            content = shard_file.read()
            # Extract only the data after the 'DATA: ' tag (The Recirculation)
            chunk = content.split(b"DATA: ")[1]
            full_encoded_data += chunk
            
    # Decrypt and reassemble the 'Muscle'
    try:
        decrypted_data = f.decrypt(base64.b64decode(full_encoded_data))
        
        with open(output_file, 'wb') as f_out:
            f_out.write(decrypted_data)
            
        print(f"[!] Reassembly Complete. {output_file} is live in the Shadow.")
    except Exception as e:
        print(f"[-] Reassembly Failed: {e}")

if __name__ == "__main__":
    reassemble_shards("recovered_payload.bin")
