#!/usr/bin/env python3
import http.server
import json
import socketserver
import subprocess
import os

MODEL_PATH = os.path.expanduser("~/models/tinyllama.gguf")
LLAMA_CPP_PATH = os.path.expanduser("~/llama.cpp")

class AIHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data)
            prompt = data.get('prompt', 'Hello')
            
            # Use llama.cpp CLI if available
            llama_cli = os.path.join(LLAMA_CPP_PATH, 'main')
            if os.path.exists(llama_cli):
                cmd = [llama_cli, '-m', MODEL_PATH, '-p', prompt, '-n', '50', '-t', '2']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                response = result.stdout.strip()
            else:
                response = f"Local AI: {prompt} (echo response - model not loaded)"
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                'content': response,
                'model': 'tinyllama-local',
                'success': True
            }).encode())
            
        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(json.dumps({'error': str(e)}).encode())
    
    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'status': 'ok', 'model': 'tinyllama'}).encode())
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == '__main__':
    PORT = 8080
    with socketserver.TCPServer(("", PORT), AIHandler) as httpd:
        print(f"Serving local AI on port {PORT}")
        print(f"Model: {MODEL_PATH}")
        httpd.serve_forever()
