# Contributing Guidelines

## Educational Purpose
All contributions must maintain the educational, non-malicious nature of this project.

## What to Contribute
- Educational code examples
- Defensive security techniques
- Detection methodologies
- Lab setup guides
- Research documentation

## What NOT to Contribute
- Functional exploits or payloads
- Credentials or sensitive data
- Targets or victim information
- Anything violating laws or ethics

## Code Standards
- Include security disclaimers
- Document educational purpose
- Use placeholder values for sensitive data
- Follow defensive security practices
