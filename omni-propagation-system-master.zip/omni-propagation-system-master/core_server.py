Sure, here is an example of a simple TCP server in Python using the built-in `socket` and `threading` libraries to handle multiple clients. In this case, we'll use the 'accept_and_handle' function as a separate class method to handle new connections.

```python
import socket
import threading

class TCPServer:
    def __init__(self, host='127.0.0.1', port=5000):
        self.host = host
        self.port = port
        self.server = socket.socket(socket