import os

SHARD_DIR = "./shards"
KEY_PATH = "/mnt/12th_vault/keys/master.key"
OUTPUT_FILE = "reconstructed_production.log"

def reassemble():
    print(f"[*] Accessing Vault for key: {KEY_PATH}")
    if not os.path.exists(KEY_PATH):
        print("[!] ERROR: Vault not mounted or key missing.")
        return

    # In a real scenario, you'd use the key to decrypt here
    # For now, we are merging the segments
    with open(OUTPUT_FILE, "wb") as outfile:
        for i in range(10):
            shard_path = f"{SHARD_DIR}/sys_log_part_{i}.shard"
            if os.path.exists(shard_path):
                with open(shard_path, "rb") as infile:
                    outfile.write(infile.read())
    
    print(f"[+] Success. Data reconstructed: {OUTPUT_FILE}")

if __name__ == "__main__":
    reassemble()
