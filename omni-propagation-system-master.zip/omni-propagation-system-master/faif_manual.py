#!/usr/bin/env python3
print("FAIF Working")
import sys
if len(sys.argv) > 1:
    print("Processing:", sys.argv[1])
    print("Result: Use metaphorical transformation")
