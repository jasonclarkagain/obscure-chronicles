#!/usr/bin/env python3
import os
import sys

print("🔍 CHECKING API KEYS...")
print("="*50)

keys = {
    "OPENROUTER_API_KEY": os.getenv("OPENROUTER_API_KEY"),
    "HUGGINGFACE_TOKEN": os.getenv("HUGGINGFACE_TOKEN"), 
    "GROQ_API_KEY": os.getenv("GROQ_API_KEY")
}

all_good = True
for name, value in keys.items():
    if value and len(value) > 20:
        print(f"✅ {name}: Set ({len(value)} chars)")
        # Show first/last few chars for verification
        print(f"   Sample: {value[:10]}...{value[-10:]}")
    elif value:
        print(f"⚠️  {name}: Set but short ({len(value)} chars)")
        all_good = False
    else:
        print(f"❌ {name}: Not set")
        all_good = False
    print()

print("="*50)
if all_good:
    print("🎉 All keys appear valid!")
    print("\nNext: python ~/test_apis.py")
else:
    print("⚠️  Some issues found")
    print("\nTry: source ~/.bashrc")
