#!/bin/bash
# Test deployment to localhost
echo "[*] Testing deployment locally..."

# Create test directory
mkdir -p /tmp/omni_test
cp payloads/v1.0/omni_simple.py /tmp/omni_test/

# Test SSH to localhost (if SSH server running)
if systemctl is-active ssh >/dev/null 2>&1; then
    echo "[+] SSH server is active"
    
    # Test passwordless SSH
    if ssh -o StrictHostKeyChecking=no localhost "echo test" >/dev/null 2>&1; then
        echo "[+] Passwordless SSH works"
        
        # Deploy to self
        scp -o StrictHostKeyChecking=no payloads/v1.0/omni_simple.py localhost:/tmp/omni_test_remote.py
        ssh -o StrictHostKeyChecking=no localhost "chmod +x /tmp/omni_test_remote.py && /tmp/omni_test_remote.py &"
        
        echo "[✅] Self-deployment successful"
    else
        echo "[-] Passwordless SSH not configured"
        echo "    Configure with: ssh-keygen and ssh-copy-id localhost"
    fi
else
    echo "[-] SSH server not running"
    echo "    Start with: sudo systemctl start ssh"
fi

echo ""
echo "[*] Manual test commands:"
echo "    python3 payloads/v1.0/omni_simple.py"
echo "    ssh localhost"
echo "    ./deploy_network_fixed.sh"
