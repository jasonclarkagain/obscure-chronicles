#!/usr/bin/env python3
"""
IMPROVED HYBRID ORCHESTRATOR
Better response cleaning and error handling
"""

import os
import sys
import asyncio
import aiohttp
import json
import subprocess
import time
import re
from datetime import datetime

def clean_ai_response(text: str) -> str:
    """Clean and normalize AI responses"""
    if not text or not isinstance(text, str):
        return "No valid response generated."
    
    # Remove common AI formatting tags
    tags_to_remove = [
        r'<s>', r'</s>', r'\[OUT\]', r'\[/OUT\]', r'\[/s\]',
        r'<\|.*?\|>', r'\[.*?\]', r'\(.*?\)'
    ]
    
    cleaned = text
    for pattern in tags_to_remove:
        cleaned = re.sub(pattern, '', cleaned)
    
    # Remove extra whitespace
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    
    # Capitalize first letter if needed
    if cleaned and cleaned[0].islower():
        cleaned = cleaned[0].upper() + cleaned[1:]
    
    # Ensure it ends with proper punctuation
    if cleaned and cleaned[-1] not in '.!?':
        cleaned += '.'
    
    return cleaned if len(cleaned) > 10 else "Response was too brief. Please try rephrasing your question."

class ImprovedHybridOrchestrator:
    def __init__(self):
        self.openrouter_key = os.getenv('OPENROUTER_API_KEY')
        self.groq_key = os.getenv('GROQ_API_KEY')
        
        # Updated Groq models based on deprecation info
        self.groq_models = [
            "llama-3.3-70b-versatile",
            "llama-3.2-90b-vision-preview",
            "gemma2-9b-it",
            "mixtral-8x7b-32768"  # Keep as last fallback
        ]
    
    async def call_openrouter(self, query: str) -> dict:
        """Call OpenRouter with better prompting"""
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.openrouter_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/your-repo",  # Optional but good practice
            "X-Title": "AI Orchestrator"
        }
        
        # Better system prompt for cleaner responses
        messages = [
            {"role": "system", "content": "You are a helpful AI assistant. Provide clear, concise answers without markdown formatting, XML tags, or special tokens. Just give the plain text answer."},
            {"role": "user", "content": query}
        ]
        
        data = {
            "model": "mistralai/mistral-7b-instruct:free",
            "messages": messages,
            "max_tokens": 300,
            "temperature": 0.7
        }
        
        try:
            timeout = aiohttp.ClientTimeout(total=15)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        raw_text = result['choices'][0]['message']['content']
                        cleaned_text = clean_ai_response(raw_text)
                        
                        return {
                            "success": True,
                            "api": "openrouter",
                            "raw_response": raw_text,
                            "response": cleaned_text,
                            "tokens": result.get('usage', {}).get('total_tokens', 0)
                        }
                    else:
                        error_text = await response.text()
                        return {"success": False, "error": f"HTTP {response.status}: {error_text[:100]}"}
        except Exception as e:
            return {"success": False, "error": str(e)[:100]}
    
    async def call_groq(self, query: str) -> dict:
        """Call Groq API with updated models"""
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.groq_key}",
            "Content-Type": "application/json"
        }
        
        for model in self.groq_models:
            messages = [
                {"role": "system", "content": "Provide clear, direct answers without special formatting or tokens."},
                {"role": "user", "content": query}
            ]
            
            data = {
                "model": model,
                "messages": messages,
                "max_tokens": 300,
                "temperature": 0.7
            }
            
            try:
                timeout = aiohttp.ClientTimeout(total=15)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.post(url, headers=headers, json=data) as response:
                        if response.status == 200:
                            result = await response.json()
                            raw_text = result['choices'][0]['message']['content']
                            cleaned_text = clean_ai_response(raw_text)
                            
                            return {
                                "success": True,
                                "api": "groq",
                                "model": model,
                                "raw_response": raw_text,
                                "response": cleaned_text,
                                "tokens": result.get('usage', {}).get('total_tokens', 0)
                            }
                        elif response.status == 400:
                            # Try next model
                            continue
            except:
                continue
        
        return {"success": False, "error": "All Groq models failed"}
    
    def call_local(self, query: str, model: str = "tinyllama") -> dict:
        """Call local model with improved parsing"""
        try:
            cmd = ["python3", "ultimate_orchestrator.py", model, query]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=180
            )
            
            if result.returncode == 0:
                # Improved answer extraction
                lines = result.stdout.split('\n')
                answer_lines = []
                capture = False
                
                for line in lines:
                    if "FINAL ANSWER" in line or "🎯 FINAL ANSWER" in line:
                        capture = True
                        continue
                    if capture and ("====" in line or "ORCHESTRATION COMPLETE" in line):
                        break
                    if capture and line.strip():
                        answer_lines.append(line.strip())
                
                raw_text = ' '.join(answer_lines) if answer_lines else result.stdout[-500:]
                cleaned_text = clean_ai_response(raw_text)
                
                return {
                    "success": True,
                    "api": "local",
                    "model": model,
                    "raw_response": raw_text,
                    "response": cleaned_text,
                    "tokens": 0
                }
            else:
                return {"success": False, "error": f"Exit code {result.returncode}"}
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Timeout (3 minutes)"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def orchestrate(self, query: str, strategy: str = "auto") -> dict:
        """Improved orchestration with strategy selection"""
        print(f"\n🤖 IMPROVED HYBRID ORCHESTRATOR")
        print("="*60)
        print(f"Query: {query[:80]}...")
        print(f"Strategy: {strategy}")
        print("="*60)
        
        start_time = time.time()
        results = []
        
        if strategy == "local":
            print("\n🔧 Local-only strategy")
            for model in ["mistral", "llama2", "tinyllama"]:
                print(f"  Trying {model}...")
                result = self.call_local(query, model)
                if result["success"]:
                    results.append(result)
                    print(f"  ✅ {model}: Success")
                    break
                else:
                    print(f"  ❌ {model}: {result['error'][:30]}")
        
        elif strategy == "cloud":
            print("\n☁️  Cloud-only strategy")
            cloud_tasks = []
            cloud_tasks.append(self.call_openrouter(query))
            cloud_tasks.append(self.call_groq(query))
            
            cloud_results = await asyncio.gather(*cloud_tasks)
            
            for result in cloud_results:
                if result["success"]:
                    results.append(result)
                    print(f"  ✅ {result['api']}: Success")
            
            if not results:
                print("  ⚠️  All cloud APIs failed")
        
        else:  # auto (hybrid)
            print("\n🤝 Auto strategy (Cloud first → Local fallback)")
            
            # Try cloud first
            cloud_tasks = []
            cloud_tasks.append(self.call_openrouter(query))
            cloud_tasks.append(self.call_groq(query))
            
            cloud_results = await asyncio.gather(*cloud_tasks)
            cloud_success = False
            
            for result in cloud_results:
                if result["success"]:
                    results.append(result)
                    cloud_success = True
                    print(f"  ☁️  {result['api']}: Success")
            
            if not cloud_success:
                print("  ⚠️  Cloud APIs failed, trying local...")
                for model in ["tinyllama", "llama2", "mistral"]:
                    print(f"    🤖 Trying {model}...")
                    result = self.call_local(query, model)
                    if result["success"]:
                        results.append(result)
                        print(f"    ✅ {model}: Success")
                        break
        
        # Process results
        elapsed = time.time() - start_time
        
        if results:
            best_result = results[0]
            return {
                "success": True,
                "query": query,
                "strategy": strategy,
                "response": best_result["response"],
                "raw_response": best_result.get("raw_response", ""),
                "source": best_result["api"],
                "model": best_result.get("model", ""),
                "tokens": best_result.get("tokens", 0),
                "time": elapsed,
                "responses_tried": len(results),
                "timestamp": datetime.now().isoformat()
            }
        else:
            return {
                "success": False,
                "query": query,
                "strategy": strategy,
                "error": "All orchestration methods failed",
                "time": elapsed,
                "timestamp": datetime.now().isoformat()
            }

async def main():
    if len(sys.argv) < 2:
        print("Usage: python hybrid_orchestrator_v2.py \"Your query\"")
        print("       python hybrid_orchestrator_v2.py --strategy [auto|cloud|local] \"Query\"")
        sys.exit(1)
    
    # Parse arguments
    strategy = "auto"
    query_start = 1
    
    if sys.argv[1] == "--strategy" and len(sys.argv) > 3:
        strategy = sys.argv[2]
        query_start = 3
    
    query = " ".join(sys.argv[query_start:])
    
    orchestrator = ImprovedHybridOrchestrator()
    result = await orchestrator.orchestrate(query, strategy)
    
    print("\n" + "="*60)
    if result["success"]:
        print("✅ ORCHESTRATION SUCCESSFUL")
        print("="*60)
        print(f"Strategy: {result['strategy']}")
        print(f"Source: {result['source']}")
        if result.get('model'):
            print(f"Model: {result['model']}")
        print(f"Time: {result['time']:.1f}s")
        print(f"Responses tried: {result['responses_tried']}")
        if result.get('tokens', 0) > 0:
            print(f"Tokens: {result['tokens']}")
        
        print("\n🎯 ANSWER:")
        print("="*60)
        print(result['response'])
        print("="*60)
        
        # Save both raw and cleaned
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"improved_result_{timestamp}.json"
        with open(filename, "w") as f:
            json.dump(result, f, indent=2)
        print(f"\n💾 Saved to: {filename}")
    else:
        print("❌ ORCHESTRATION FAILED")
        print("="*60)
        print(f"Error: {result['error']}")
        print(f"Strategy: {result['strategy']}")
        print(f"Time: {result['time']:.1f}s")

if __name__ == "__main__":
    asyncio.run(main())
