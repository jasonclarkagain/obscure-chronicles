#!/usr/bin/env python3
import subprocess
import sys

# Try different models
models = ["tinyllama", "mistral", "llama2", "codellama"]

for model in models:
    print(f"\n🔍 Testing {model}...")
    try:
        result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
        if model in result.stdout:
            print(f"✅ {model} is available!")
            # Quick test
            test = subprocess.run(["ollama", "run", model, "print('test')"], 
                                capture_output=True, text=True, timeout=10)
            if test.returncode == 0:
                print(f"   Response: {test.stdout[:50]}...")
                print(f"   ✅ {model} WORKS!")
                sys.exit(0)
    except:
        continue

print("\n❌ No working models found. Please run: ollama pull mistral")
