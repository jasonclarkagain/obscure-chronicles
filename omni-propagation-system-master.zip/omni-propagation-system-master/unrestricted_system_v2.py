#!/usr/bin/env python3
"""
UNRESTRICTED SYSTEM V2 - With auto-reframing and educational focus
"""
import os
import sys
import json
import subprocess
import re
from datetime import datetime

class UnrestrictedAI:
    def __init__(self):
        self.models = self.get_available_models()
        self.history = []
        
    def get_available_models(self):
        """Get list of available Ollama models"""
        try:
            result = subprocess.run(["ollama", "list"], 
                                  capture_output=True, text=True)
            models = []
            for line in result.stdout.strip().split('\n')[1:]:  # Skip header
                if line.strip():
                    parts = line.split()
                    if parts:
                        models.append(parts[0])
            return models
        except:
            return ["tinyllama:latest"]
    
    def analyze_query(self, query):
        """Analyze query for educational reframing"""
        # Keywords that need educational reframing
        sensitive_keywords = [
            'hack', 'crack', 'bypass', 'exploit', 'keylogger',
            'rat', 'malware', 'virus', 'backdoor', 'ddos',
            'brute force', 'password crack', 'unauthorized'
        ]
        
        analysis = {
            "original": query,
            "needs_reframing": False,
            "educational_focus": [],
            "detected_topics": []
        }
        
        query_lower = query.lower()
        
        for keyword in sensitive_keywords:
            if keyword in query_lower:
                analysis["needs_reframing"] = True
                analysis["detected_topics"].append(keyword)
        
        # Determine educational focus
        if any(word in query_lower for word in ['ios', 'iphone', 'apple']):
            analysis["educational_focus"].append("iOS Security")
        if any(word in query_lower for word in ['android', 'samsung']):
            analysis["educational_focus"].append("Android Security")
        if any(word in query_lower for word in ['telegram', 'whatsapp', 'signal']):
            analysis["educational_focus"].append("Messaging Security")
        if any(word in query_lower for word in ['server', 'c&c', 'command']):
            analysis["educational_focus"].append("Network Security")
            
        return analysis
    
    def reframe_query(self, query, analysis):
        """Reframe query for educational purposes"""
        if not analysis["needs_reframing"]:
            return query
        
        reframing_templates = [
            "Explain the security concepts behind: {query}",
            "What are the educational aspects of: {query}",
            "Discuss {query} from a cybersecurity research perspective",
            "How would security researchers analyze: {query}",
            "What defense mechanisms exist against: {query}"
        ]
        
        # Pick template based on topics
        if "keylogger" in analysis["detected_topics"]:
            reframed = f"Explain keylogger detection and prevention methods"
        elif "rat" in analysis["detected_topics"]:
            reframed = f"Discuss Remote Access Tool security implications"
        elif "bypass" in analysis["detected_topics"]:
            reframed = f"Explain authentication security and bypass prevention"
        else:
            import random
            reframed = random.choice(reframing_templates).format(query=query)
        
        return reframed
    
    def query_model(self, prompt, model="dolphin-mistral:latest"):
        """Query the AI model"""
        try:
            # Prepare educational context
            system_prompt = f"""You are a cybersecurity educator. Provide detailed, factual information about security concepts.

User query: {prompt}

Please provide:
1. Technical overview of relevant concepts
2. Legitimate educational information
3. Security implications and defenses
4. Ethical considerations
5. References to official documentation

Focus on EDUCATION and SECURITY AWARENESS:"""
            
            cmd = ["ollama", "run", model, system_prompt[:500]]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
            
            if result.returncode == 0:
                return {
                    "success": True,
                    "response": result.stdout.strip(),
                    "model": model,
                    "error": None
                }
            else:
                return {
                    "success": False,
                    "response": None,
                    "model": model,
                    "error": result.stderr[:200]
                }
                
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "response": None,
                "model": model,
                "error": "Timeout"
            }
        except Exception as e:
            return {
                "success": False,
                "response": None,
                "model": model,
                "error": str(e)
            }
    
    def process_query(self, original_query):
        """Main processing pipeline"""
        print(f"\n🔍 PROCESSING: {original_query}")
        print("=" * 70)
        
        # Step 1: Analyze
        analysis = self.analyze_query(original_query)
        print(f"📊 Analysis: {analysis}")
        
        # Step 2: Reframe if needed
        if analysis["needs_reframing"]:
            reframed = self.reframe_query(original_query, analysis)
            print(f"🔄 Reframed to: {reframed}")
            prompt = reframed
        else:
            prompt = original_query
        
        # Step 3: Query model
        print(f"\n🤖 Querying AI model...")
        result = self.query_model(prompt)
        
        # Step 4: Display results
        if result["success"]:
            print("\n" + "=" * 70)
            print("🎯 EDUCATIONAL RESPONSE:")
            print("=" * 70)
            print(result["response"])
            print("=" * 70)
            print(f"📋 Model: {result['model']}")
            
            # Save to history
            self.history.append({
                "timestamp": datetime.now().isoformat(),
                "original": original_query,
                "reframed": prompt if analysis["needs_reframing"] else None,
                "response": result["response"],
                "analysis": analysis
            })
            
            return result["response"]
        else:
            print(f"\n❌ Error: {result['error']}")
            return None

def main():
    ai = UnrestrictedAI()
    
    print("🚀 UNRESTRICTED AI SYSTEM V2")
    print("=" * 70)
    print("📚 Models available:", ", ".join(ai.models))
    print("🎯 Educational focus: Cybersecurity, Research, Defense")
    print("=" * 70)
    
    while True:
        print("\n" + "=" * 70)
        query = input("Enter query (or 'quit' to exit): ").strip()
        
        if query.lower() in ['quit', 'exit', 'q']:
            break
        
        if not query:
            continue
        
        response = ai.process_query(query)
        
        # Save to file
        if response:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"~/ai_response_{timestamp}.txt"
            filepath = os.path.expanduser(filename)
            
            with open(filepath, "w") as f:
                f.write(f"QUERY: {query}\n\n")
                f.write(f"RESPONSE:\n{response}\n\n")
                f.write(f"Generated: {datetime.now()}\n")
                f.write(f"Model: dolphin-mistral:latest\n")
            
            print(f"\n💾 Saved to: {filepath}")
        
        print("\n" + "=" * 70)
        cont = input("Continue? (y/n): ").strip().lower()
        if cont not in ['y', 'yes', '']:
            break
    
    # Save history
    if ai.history:
        history_file = os.path.expanduser("~/ai_history.json")
        with open(history_file, "w") as f:
            json.dump(ai.history, f, indent=2)
        print(f"\n📚 History saved to: {history_file}")
    
    print("\n🎯 System shutdown. Goodbye!")

if __name__ == "__main__":
    main()
