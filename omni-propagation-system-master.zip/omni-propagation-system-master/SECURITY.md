# Security Policy

## Supported Versions
This is educational software for controlled lab use only.

## Reporting Vulnerabilities
If you discover security issues during authorized research:
1. Do not disclose publicly
2. Document in your research notes
3. Follow responsible disclosure if testing third-party systems

## Responsible Use
- Only test on systems you own or have written permission to test
- Isolate test environments from production networks
- Document all testing activities
- Comply with all applicable laws and regulations
