#!/usr/bin/env python3
"""
NO-INSTALL SWARM ORCHESTRATOR
Works on Kali without installing packages
"""

import subprocess
import sys
import json
import os
from datetime import datetime

# API Keys (already have)
GEMINI_KEY = "AIzaSyC9g4B4sY9xeaUntjNmN2MeWFyp5gL3_EM"
GROQ_KEY = "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"

def query_with_curl(api_name, prompt):
    """Use curl to call APIs (no Python packages needed)"""
    
    if api_name == "gemini":
        # Try multiple Gemini endpoints
        endpoints = [
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent",
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent",
            "https://generativelanguage.googleapis.com/v1/models/gemini-1.0-pro:generateContent"
        ]
        
        for endpoint in endpoints:
            url = f"{endpoint}?key={GEMINI_KEY}"
            cmd = [
                'curl', '-s', '-X', 'POST',
                '-H', 'Content-Type: application/json',
                '-d', json.dumps({
                    "contents": [{
                        "parts": [{"text": prompt}]
                    }],
                    "generationConfig": {
                        "maxOutputTokens": 200,
                        "temperature": 0.7
                    }
                }),
                url
            ]
            
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                if result.returncode == 0 and '"text":' in result.stdout:
                    data = json.loads(result.stdout)
                    text = data.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
                    if text:
                        return f"[Gemini] {text[:200]}..."
            except:
                continue
        
        return "[Gemini: No working endpoint]"
    
    elif api_name == "groq":
        # Groq API via curl
        cmd = [
            'curl', '-s', '-X', 'POST',
            'https://api.groq.com/openai/v1/chat/completions',
            '-H', f'Authorization: Bearer {GROQ_KEY}',
            '-H', 'Content-Type: application/json',
            '-d', json.dumps({
                "model": "llama3-8b-8192",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 200,
                "temperature": 0.7
            })
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                data = json.loads(result.stdout)
                text = data.get('choices', [{}])[0].get('message', {}).get('content', '')
                return f"[Groq] {text[:200]}..."
        except:
            return "[Groq: Error]"
    
    return f"[{api_name}: Not implemented]"

def main():
    print("🤖 NO-INSTALL AI ORCHESTRATOR")
    print("=" * 50)
    
    # Get task
    if len(sys.argv) > 1:
        task = " ".join(sys.argv[1:])
    else:
        print("\nEnter your question:")
        task = sys.stdin.readline().strip() or "Explain AI in simple terms"
    
    print(f"\n📝 Task: {task}")
    print("\n🔄 Querying AI services...")
    
    # Create subtasks
    subtasks = [
        f"Explain: {task}",
        f"Give examples of: {task}",
        f"List key points about: {task}"
    ]
    
    results = []
    
    # Query each service
    print("\n1. Querying Google Gemini...")
    results.append(query_with_curl("gemini", subtasks[0]))
    
    print("2. Querying Groq...")
    results.append(query_with_curl("groq", subtasks[1]))
    
    print("3. Querying Hugging Face...")
    # Hugging Face via simple model
    try:
        hf_cmd = [
            'curl', '-s', '-X', 'POST',
            'https://api-inference.huggingface.co/models/gpt2',
            '-H', f'Authorization: Bearer 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',
            '-H', 'Content-Type: application/json',
            '-d', json.dumps({
                "inputs": subtasks[2],
                "parameters": {"max_new_tokens": 100}
            })
        ]
        hf_result = subprocess.run(hf_cmd, capture_output=True, text=True, timeout=10)
        if hf_result.returncode == 0:
            data = json.loads(hf_result.stdout)
            if isinstance(data, list):
                hf_text = data[0].get('generated_text', '')[:200]
                results.append(f"[Hugging Face] {hf_text}...")
            else:
                results.append("[Hugging Face: Model loading]")
        else:
            results.append("[Hugging Face: Error]")
    except:
        results.append("[Hugging Face: Failed]")
    
    # Display results
    print("\n" + "=" * 50)
    print("📊 AI RESPONSES")
    print("=" * 50)
    
    for i, result in enumerate(results, 1):
        print(f"\n{i}. {result}")
    
    # Save to file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"ai_results_{timestamp}.txt"
    
    with open(filename, 'w') as f:
        f.write(f"Task: {task}\n")
        f.write(f"Time: {datetime.now()}\n\n")
        for i, result in enumerate(results, 1):
            f.write(f"{i}. {result}\n\n")
    
    print(f"\n💾 Results saved to: {filename}")
    print("=" * 50)

if __name__ == "__main__":
    main()
