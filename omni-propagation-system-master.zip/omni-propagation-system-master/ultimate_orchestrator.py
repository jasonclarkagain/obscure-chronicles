#!/usr/bin/env python3
"""
ULTIMATE SWARM ORCHESTRATOR - DEC 2025
Uses all your working APIs with correct models
"""

import os
import sys
import json
import re
import asyncio
import urllib.request
import urllib.error
from datetime import datetime
from typing import List, Dict, Any

# ========== API CONFIGURATION ==========
class APIConfig:
    """API configurations with working models"""
    
    GOOGLE_MODELS = [
        "gemini-2.0-flash-001",      # Stable, fast, free
        "gemini-2.0-flash-lite-001", # Even faster, free
        "gemini-2.5-flash",         # Latest, 1M context
        "gemini-flash-latest",      # Always latest
    ]
    
    GROQ_MODELS = [
        "llama3-8b-8192",           # Free tier
        "mixtral-8x7b-32768",       # Fast, accurate
        "gemma-7b-it",              # Google's model
    ]
    
    HF_MODELS = [
        "microsoft/DialoGPT-small", # Fast, always available
        "gpt2",                     # Basic but reliable
        "google/flan-t5-base",      # Good for instructions
    ]

class PrivacyEngine:
    """Advanced privacy protection"""
    
    def __init__(self):
        self.masking_rules = [
            (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[EMAIL]'),
            (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[IP]'),
            (r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', '[PHONE]'),
            (r'\b[A-Z]{2,10}-\d{3,5}\b', '[ID]'),
        ]
    
    def mask(self, text: str) -> str:
        """Mask sensitive information"""
        masked = text
        for pattern, replacement in self.masking_rules:
            masked = re.sub(pattern, replacement, masked, flags=re.IGNORECASE)
        return masked

class AIProvider:
    """Base class for AI providers"""
    
    def __init__(self, name: str, api_key: str):
        self.name = name
        self.api_key = api_key
    
    async def query(self, prompt: str) -> str:
        """Query the AI provider"""
        raise NotImplementedError

class GoogleProvider(AIProvider):
    """Google Gemini API"""
    
    def __init__(self, api_key: str):
        super().__init__("Google Gemini", api_key)
        self.models = APIConfig.GOOGLE_MODELS
        self.current_model_index = 0
    
    def get_next_model(self) -> str:
        """Rotate through available models"""
        model = self.models[self.current_model_index]
        self.current_model_index = (self.current_model_index + 1) % len(self.models)
        return model
    
    async def query(self, prompt: str) -> str:
        """Query Google Gemini"""
        model = self.get_next_model()
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={self.api_key}"
        
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "maxOutputTokens": 500,
                "temperature": 0.7,
                "topP": 0.8,
                "topK": 40
            },
            "safetySettings": [
                {
                    "category": "HARM_CATEGORY_HARASSMENT",
                    "threshold": "BLOCK_MEDIUM_AND_ABOVE"
                }
            ]
        }
        
        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(
                url,
                data=data,
                headers={'Content-Type': 'application/json'}
            )
            
            with urllib.request.urlopen(req, timeout=20) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                # Extract response
                if 'candidates' in result and result['candidates']:
                    text = result['candidates'][0]['content']['parts'][0]['text']
                    return f"🤖 {self.name} ({model}):\n{text}"
                else:
                    return f"❌ {self.name}: No response from model {model}"
                    
        except urllib.error.HTTPError as e:
            return f"❌ {self.name} HTTP {e.code}: {e.reason}"
        except Exception as e:
            return f"❌ {self.name}: {str(e)[:100]}"

class GroqProvider(AIProvider):
    """Groq API"""
    
    def __init__(self, api_key: str):
        super().__init__("Groq", api_key)
        self.models = APIConfig.GROQ_MODELS
        self.current_model_index = 0
    
    def get_next_model(self) -> str:
        """Rotate through available models"""
        model = self.models[self.current_model_index]
        self.current_model_index = (self.current_model_index + 1) % len(self.models)
        return model
    
    async def query(self, prompt: str) -> str:
        """Query Groq API"""
        model = self.get_next_model()
        url = "https://api.groq.com/openai/v1/chat/completions"
        
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 500,
            "temperature": 0.7,
            "top_p": 0.8
        }
        
        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    'Authorization': f'Bearer {self.api_key}',
                    'Content-Type': 'application/json'
                }
            )
            
            with urllib.request.urlopen(req, timeout=20) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if 'choices' in result and result['choices']:
                    text = result['choices'][0]['message']['content']
                    return f"⚡ {self.name} ({model}):\n{text}"
                else:
                    return f"❌ {self.name}: No response from model {model}"
                    
        except urllib.error.HTTPError as e:
            return f"❌ {self.name} HTTP {e.code}: {e.reason}"
        except Exception as e:
            return f"❌ {self.name}: {str(e)[:100]}"

class HuggingFaceProvider(AIProvider):
    """Hugging Face Inference API"""
    
    def __init__(self, api_key: str):
        super().__init__("Hugging Face", api_key)
        self.models = APIConfig.HF_MODELS
        self.current_model_index = 0
    
    def get_next_model(self) -> str:
        """Rotate through available models"""
        model = self.models[self.current_model_index]
        self.current_model_index = (self.current_model_index + 1) % len(self.models)
        return model
    
    async def query(self, prompt: str) -> str:
        """Query Hugging Face"""
        model = self.get_next_model()
        url = f"https://api-inference.huggingface.co/models/{model}"
        
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": 300,
                "temperature": 0.7,
                "return_full_text": False
            }
        }
        
        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    'Authorization': f'Bearer {self.api_key}',
                    'Content-Type': 'application/json'
                }
            )
            
            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if isinstance(result, list) and len(result) > 0:
                    if 'generated_text' in result[0]:
                        text = result[0]['generated_text']
                    else:
                        text = str(result[0])
                    return f"🤗 {self.name} ({model}):\n{text[:500]}..."
                else:
                    return f"❌ {self.name}: Model {model} is loading or unavailable"
                    
        except urllib.error.HTTPError as e:
            return f"❌ {self.name} HTTP {e.code}: {e.reason}"
        except Exception as e:
            return f"❌ {self.name}: {str(e)[:100]}"

class TaskOrchestrator:
    """Main orchestrator with intelligent task decomposition"""
    
    def __init__(self):
        self.privacy = PrivacyEngine()
        
        # Initialize all available providers
        self.providers = []
        
        # Google Gemini
        google_key = "AIzaSyD_4aAx2tnLIguX7XUOmleCbYhHtKgdHl0"
        if google_key and google_key != "YOUR_KEY_HERE":
            self.providers.append(GoogleProvider(google_key))
        
        # Groq
        groq_key = "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"
        if groq_key and groq_key != "YOUR_KEY_HERE":
            self.providers.append(GroqProvider(groq_key))
        
        # Hugging Face
        hf_key = "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"
        if hf_key and hf_key != "YOUR_KEY_HERE":
            self.providers.append(HuggingFaceProvider(hf_key))
        
        print("=" * 70)
        print("🚀 ULTIMATE AI ORCHESTRATOR - DEC 2025")
        print("=" * 70)
        print(f"✅ Loaded {len(self.providers)} AI Providers:")
        for provider in self.providers:
            print(f"   • {provider.name}")
        print("=" * 70)
    
    def decompose_task(self, task: str) -> List[str]:
        """Intelligently break down complex tasks"""
        
        # Simple decomposition based on task type
        if len(task) < 100:
            # Short task - create different perspectives
            return [
                f"Explain: {task}",
                f"Provide examples of: {task}",
                f"Discuss applications of: {task}",
                f"Give key points about: {task}"
            ]
        else:
            # Long task - break into logical parts
            return [
                f"Summarize the main idea: {task[:100]}...",
                f"Explain technical aspects: {task[:100]}...",
                f"Discuss practical implications: {task[:100]}...",
                f"Provide analysis: {task[:100]}..."
            ]
    
    async def orchestrate(self, user_task: str) -> Dict[str, Any]:
        """Main orchestration workflow"""
        
        print(f"\n🎯 USER TASK: {user_task}")
        
        # Step 1: Privacy Protection
        print("\n🔒 Step 1: Privacy Protection...")
        masked_task = self.privacy.mask(user_task)
        if masked_task != user_task:
            print(f"   Masked sensitive data: {masked_task}")
        
        # Step 2: Task Decomposition
        print("\n🔍 Step 2: Task Analysis & Decomposition...")
        subtasks = self.decompose_task(masked_task)
        print(f"   Created {len(subtasks)} intelligent subtasks")
        
        # Step 3: Parallel Processing
        print(f"\n⚡ Step 3: Parallel AI Processing ({len(self.providers)} providers)...")
        
        # Distribute subtasks to providers
        provider_tasks = []
        for i, provider in enumerate(self.providers):
            if i < len(subtasks):
                subtask = subtasks[i]
                print(f"   {provider.name}: {subtask[:60]}...")
                provider_tasks.append(provider.query(subtask))
            else:
                # If more providers than subtasks, use first subtask
                print(f"   {provider.name}: {subtasks[0][:60]}...")
                provider_tasks.append(provider.query(subtasks[0]))
        
        # Run all queries in parallel
        results = await asyncio.gather(*provider_tasks)
        
        # Step 4: Results Compilation
        print("\n📊 Step 4: Results Compilation...")
        
        return {
            "original_task": user_task,
            "masked_task": masked_task,
            "subtasks": subtasks,
            "providers": [p.name for p in self.providers],
            "responses": results,
            "timestamp": datetime.now().isoformat()
        }
    
    def generate_report(self, results: Dict[str, Any]) -> str:
        """Generate comprehensive report"""
        
        report = f"""
{'='*70}
🤖 AI ORCHESTRATION REPORT
{'='*70}

📅 Timestamp: {results['timestamp']}
🎯 Original Task: {results['original_task']}

📊 EXECUTED SUBTASKS:
"""
        
        for i, subtask in enumerate(results['subtasks'], 1):
            report += f"\n{i}. {subtask[:80]}..."
        
        report += f"\n\n{'='*70}\n📈 AI RESPONSES:\n{'='*70}\n"
        
        for i, (provider, response) in enumerate(zip(results['providers'], results['responses']), 1):
            report += f"\n{i}. {provider}:\n"
            report += "-" * 40 + "\n"
            report += response + "\n"
        
        # Add summary
        report += f"\n{'='*70}\n✨ EXECUTIVE SUMMARY\n{'='*70}\n"
        report += f"""
• Processed using {len(results['providers'])} AI providers in parallel
• Privacy: All sensitive data was masked before processing
• Models used: Google Gemini 2.0/2.5, Groq (Llama/Mixtral), Hugging Face
• Total queries: {len(results['responses'])}
• Successful responses: {sum(1 for r in results['responses'] if '❌' not in r)}

💡 RECOMMENDATIONS:
1. Compare insights from different AI models above
2. Look for consensus among providers
3. Implement actionable advice
4. Test solutions in safe environment
"""
        
        return report

async def main():
    """Main execution"""
    
    print("\n" + "="*70)
    print("🚀 ULTIMATE AI ORCHESTRATOR")
    print("="*70)
    
    # Get task from user
    if len(sys.argv) > 1:
        user_task = " ".join(sys.argv[1:])
    else:
        print("\n📝 Enter your task or question:")
        print("Examples:")
        print("  • 'Explain quantum computing for beginners'")
        print("  • 'Create a Python script for file encryption'")
        print("  • 'How to secure a Linux web server'")
        print("  • 'Analyze the impact of AI on cybersecurity'")
        print("\nYour task (can include emails/IPs - they'll be masked):")
        
        user_task = sys.stdin.readline().strip()
        if not user_task:
            user_task = "Explain artificial intelligence and its applications in modern technology"
    
    # Initialize orchestrator
    orchestrator = TaskOrchestrator()
    
    if len(orchestrator.providers) == 0:
        print("\n❌ No API keys configured!")
        print("\nPlease set your API keys in the script:")
        print("1. Google Gemini: AIzaSyD_4aAx2tnLIguX7XUOmleCbYhHtKgdHl0")
        print("2. Groq: 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")
        print("3. Hugging Face: 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")
        return
    
    try:
        print("\n" + "="*70)
        print("🔄 PROCESSING WITH INTELLIGENT ORCHESTRATION...")
        print("="*70)
        
        # Run orchestration
        results = await orchestrator.orchestrate(user_task)
        
        # Generate and display report
        report = orchestrator.generate_report(results)
        print(report)
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save JSON (structured data)
        json_file = f"orchestration_{timestamp}.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        # Save text report (readable)
        txt_file = f"orchestration_{timestamp}.txt"
        with open(txt_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n💾 Results saved to:")
        print(f"   • {json_file} (structured JSON)")
        print(f"   • {txt_file} (readable report)")
        
        print("\n" + "="*70)
        print("✅ ORCHESTRATION COMPLETE!")
        print("="*70)
        
    except KeyboardInterrupt:
        print("\n\n⏹️  Orchestration cancelled by user")
    except Exception as e:
        print(f"\n❌ Error during orchestration: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Run the orchestrator
    asyncio.run(main())
