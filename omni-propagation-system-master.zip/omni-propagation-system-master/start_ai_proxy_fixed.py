#!/usr/bin/env python3
"""
FIXED AI PROXY - No port conflicts
"""

import os
import sys
from fastapi import FastAPI
import uvicorn

# Kill anything on port 8345 first
os.system("fuser -k 8345/tcp 2>/dev/null")
os.system("pkill -f 'python.*8345' 2>/dev/null")

app = FastAPI()

@app.get("/")
def root():
    return {
        "service": "AI Proxy Orchestrator", 
        "port": 8345,
        "status": "running",
        "endpoints": {
            "/": "this page",
            "/health": "health check",
            "/orchestrate/{text}": "orchestrate AI query",
            "/test": "test endpoint"
        }
    }

@app.get("/health")
def health():
    return {"healthy": True, "timestamp": "now"}

@app.get("/test")
def test():
    return {"message": "✅ AI Proxy is working!"}

@app.get("/orchestrate/{prompt}")
def orchestrate(prompt: str):
    return {
        "prompt": prompt,
        "response": f"AI Response to: {prompt}",
        "source": "AI Proxy v2.0"
    }

if __name__ == "__main__":
    print("=" * 50)
    print("🤖 AI PROXY STARTING ON PORT 8345")
    print("=" * 50)
    print("✅ Web UI: http://localhost:8345")
    print("✅ Health: http://localhost:8345/health")
    print("✅ Test:   http://localhost:8345/test")
    print("=" * 50)
    
    try:
        uvicorn.run(app, host="0.0.0.0", port=8345, log_level="info")
    except OSError as e:
        if "address already in use" in str(e):
            print(f"❌ ERROR: Port 8345 is already in use!")
            print("Run this command to fix:")
            print("  sudo lsof -ti:8345 | xargs kill -9")
            sys.exit(1)
        else:
            raise
