#!/usr/bin/env python3
"""
Simple AI Proxy - Working version
"""
import uvicorn
from fastapi import FastAPI
import json

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "AI Proxy System is working!"}

@app.get("/health")
async def health():
    return {"status": "online", "service": "AI Proxy"}

@app.post("/query")
async def query(request: dict):
    return {
        "success": True,
        "query": request.get("query", ""),
        "response": "This is a test response from the unrestricted AI proxy."
    }

if __name__ == "__main__":
    print("🚀 Starting AI Proxy System on http://0.0.0.0:8000")
    print("   Endpoints:")
    print("   - GET  /health    - Health check")
    print("   - POST /query     - Process a query")
    print("")
    print("📚 Example usage:")
    print('curl -X POST http://localhost:8000/query -H "Content-Type: application/json" -d \'{"query": "test"}\'')
    print("")
    uvicorn.run(app, host="0.0.0.0", port=8000)
