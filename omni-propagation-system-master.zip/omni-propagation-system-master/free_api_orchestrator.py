#!/usr/bin/env python3
"""
AI ORCHESTRATOR WITH FREE APIS
Uses completely free LLM APIs where possible
"""

import os
import sys
import json
import asyncio
import aiohttp
from datetime import datetime
from typing import List, Dict

class FreeAPIManager:
    """Manages free LLM APIs"""
    
    def __init__(self):
        # Check for free API keys
        self.apis = {
            "google": os.getenv("GOOGLE_API_KEY"),
            "huggingface": os.getenv("HUGGINGFACE_TOKEN"),
            "together": os.getenv("TOGETHER_API_KEY"),
            "groq": os.getenv("GROQ_API_KEY")
        }
        
        self.available_apis = {k: v for k, v in self.apis.items() if v}
        
        print("🔍 Checking free APIs...")
        for api, key in self.available_apis.items():
            print(f"   ✓ {api.upper()}: Available")
        
        if not self.available_apis:
            print("   ⚠️  No free API keys found")
            print("\n   Get free API keys from:")
            print("   1. Google AI Studio: https://makersuite.google.com/app/apikey")
            print("   2. Hugging Face: https://huggingface.co/settings/tokens")
            print("   3. Together AI: https://together.ai (free $25 credits)")
            print("   4. Groq: https://console.groq.com")
    
    async def query_google_gemini(self, prompt: str) -> str:
        """Query Google Gemini API (FREE: 60 RPM, 1M tokens/month)"""
        api_key = self.available_apis.get("google")
        if not api_key:
            return "[Google API key not set]"
        
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={api_key}"
        
        payload = {
            "contents": [{
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "maxOutputTokens": 500,
                "temperature": 0.7
            }
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "No response")
                    else:
                        error = await response.text()
                        return f"[Google Error {response.status}: {error[:100]}]"
        except Exception as e:
            return f"[Google Error: {str(e)}]"
    
    async def query_huggingface(self, prompt: str, model: str = "mistralai/Mixtral-8x7B-Instruct-v0.1") -> str:
        """Query Hugging Face Inference API (FREE: 30K tokens/month)"""
        token = self.available_apis.get("huggingface")
        if not token:
            return "[Hugging Face token not set]"
        
        url = f"https://api-inference.huggingface.co/models/{model}"
        headers = {"Authorization": f"Bearer {token}"}
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": 300,
                "temperature": 0.7,
                "return_full_text": False
            }
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()
                        if isinstance(data, list) and len(data) > 0:
                            return data[0].get("generated_text", "No response")
                        return str(data)
                    else:
                        error = await response.text()
                        return f"[HF Error {response.status}: {error[:100]}]"
        except Exception as e:
            return f"[HF Error: {str(e)}]"
    
    async def query_together(self, prompt: str, model: str = "mistralai/Mixtral-8x7B-Instruct-v0.1") -> str:
        """Query Together AI (FREE: $25 credits)"""
        api_key = self.available_apis.get("together")
        if not api_key:
            return "[Together API key not set]"
        
        url = "https://api.together.xyz/v1/chat/completions"
        headers = {"Authorization": f"Bearer {api_key}"}
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 500,
            "temperature": 0.7
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("choices", [{}])[0].get("message", {}).get("content", "No response")
                    else:
                        error = await response.text()
                        return f"[Together Error {response.status}: {error[:100]}]"
        except Exception as e:
            return f"[Together Error: {str(e)}]"
    
    async def query_groq(self, prompt: str, model: str = "mixtral-8x7b-32768") -> str:
        """Query Groq API (FREE: Limited but generous)"""
        api_key = self.available_apis.get("groq")
        if not api_key:
            return "[Groq API key not set]"
        
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {"Authorization": f"Bearer {api_key}"}
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 500,
            "temperature": 0.7
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("choices", [{}])[0].get("message", {}).get("content", "No response")
                    else:
                        error = await response.text()
                        return f"[Groq Error {response.status}: {error[:100]}]"
        except Exception as e:
            return f"[Groq Error: {str(e)}]"
    
    async def query_all_free_apis(self, prompt: str) -> List[Dict]:
        """Query all available free APIs in parallel"""
        tasks = []
        
        if "google" in self.available_apis:
            tasks.append(self.query_google_gemini(prompt))
        if "huggingface" in self.available_apis:
            tasks.append(self.query_huggingface(prompt))
        if "together" in self.available_apis:
            tasks.append(self.query_together(prompt))
        if "groq" in self.available_apis:
            tasks.append(self.query_groq(prompt))
        
        if not tasks:
            return []
        
        print(f"  Querying {len(tasks)} free API(s) in parallel...")
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        processed = []
        api_names = list(self.available_apis.keys())[:len(tasks)]
        
        for i, (api_name, result) in enumerate(zip(api_names, results)):
            if isinstance(result, Exception):
                processed.append({
                    "api": api_name,
                    "response": f"[{api_name} Error: {str(result)}]",
                    "success": False
                })
            else:
                processed.append({
                    "api": api_name,
                    "response": result,
                    "success": True
                })
        
        return processed

class LocalModelManager:
    """Fallback to local models"""
    
    def __init__(self, model_path: str = None):
        self.llama_path = os.path.expanduser("~/llama.cpp/build/bin/llama-cli")
        
        # Try to find a model
        models_dir = os.path.expanduser("~/models")
        possible_models = [
            "mistral-7b-instruct-v0.2.Q4_K_M.gguf",
            "llama-2-7b-chat.Q4_K_M.gguf", 
            "tinyllama.gguf"
        ]
        
        if model_path and os.path.exists(model_path):
            self.model_path = model_path
        else:
            for model in possible_models:
                path = os.path.join(models_dir, model)
                if os.path.exists(path):
                    self.model_path = path
                    break
            else:
                self.model_path = None
        
        if self.model_path:
            print(f"🤖 Local model: {os.path.basename(self.model_path)}")
        else:
            print("⚠️  No local model found")
    
    def query(self, prompt: str, max_tokens: int = 200) -> str:
        """Query local model as fallback"""
        if not self.model_path or not os.path.exists(self.llama_path):
            return "[Local model not available]"
        
        cmd = [
            self.llama_path,
            "-m", self.model_path,
            "-p", prompt,
            "-n", str(max_tokens),
            "--temp", "0.7",
            "-no-cnv",
            "--threads", "4"
        ]
        
        try:
            import subprocess
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            # Extract response
            for line in result.stdout.split('\n'):
                if prompt in line:
                    response = line[line.find(prompt) + len(prompt):].strip()
                    response = response.lstrip(':').strip()
                    if response:
                        return response
            
            return "[Local: No response]"
            
        except Exception as e:
            return f"[Local Error: {str(e)}]"

class FreeAPIOrchestrator:
    """Orchestrator using free APIs with local fallback"""
    
    def __init__(self):
        self.free_api = FreeAPIManager()
        self.local_model = LocalModelManager()
        
        self.total_apis = len(self.free_api.available_apis)
        self.has_local = self.local_model.model_path is not None
        
        print(f"\n📊 SYSTEM STATUS:")
        print(f"   Free APIs available: {self.total_apis}")
        print(f"   Local model available: {self.has_local}")
        print(f"   Total processing capacity: {self.total_apis + (1 if self.has_local else 0)}")
    
    async def orchestrate_complex_task(self, task: str) -> Dict:
        """Orchestrate a complex task using all available resources"""
        print(f"\n{'='*60}")
        print(f"🚀 Processing: {task}")
        print(f"{'='*60}")
        
        # Step 1: Break down task
        print("\n🔍 Step 1: Analyzing task...")
        subtasks = self._create_subtasks(task)
        print(f"   Created {len(subtasks)} subtasks")
        
        # Step 2: Process in parallel
        print(f"\n⚡ Step 2: Parallel processing ({self.total_apis} APIs + local)...")
        all_results = []
        
        for i, subtask in enumerate(subtasks):
            print(f"   Subtask {i+1}: {subtask[:50]}...")
            
            # Try free APIs first
            if self.total_apis > 0:
                api_results = await self.free_api.query_all_free_apis(subtask)
                for api_result in api_results:
                    if api_result["success"]:
                        all_results.append(f"[{api_result['api'].upper()}]: {api_result['response'][:100]}...")
                        break
                else:
                    # All APIs failed, try local
                    if self.has_local:
                        local_result = self.local_model.query(subtask)
                        all_results.append(f"[LOCAL]: {local_result[:100]}...")
            else:
                # No APIs, use local
                if self.has_local:
                    local_result = self.local_model.query(subtask)
                    all_results.append(f"[LOCAL]: {local_result[:100]}...")
        
        # Step 3: Synthesize
        print(f"\n🧩 Step 3: Synthesizing {len(all_results)} results...")
        
        if self.has_local:
            synthesis_prompt = f"""Combine these analyses into a comprehensive answer:
            
            Task: {task}
            
            Analyses:
            {' | '.join(all_results)}
            
            Provide a well-structured, comprehensive answer:"""
            
            final_answer = self.local_model.query(synthesis_prompt, max_tokens=400)
        else:
            final_answer = " | ".join(all_results)
        
        # Compile results
        results = {
            "task": task,
            "timestamp": datetime.now().isoformat(),
            "free_apis_used": self.total_apis,
            "local_model_used": self.has_local,
            "subtasks": subtasks,
            "all_results": all_results,
            "final_answer": final_answer
        }
        
        return results
    
    def _create_subtasks(self, task: str) -> List[str]:
        """Create subtasks from main task"""
        # Simple decomposition - can be enhanced
        return [
            f"Background and history of {task}",
            f"Core concepts and principles of {task}",
            f"Real-world applications of {task}",
            f"Future developments in {task}"
        ]
    
    def save_results(self, results: Dict):
        """Save results to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"free_api_orchestrator_{timestamp}.txt"
        
        with open(filename, 'w') as f:
            f.write(f"{'='*60}\n")
            f.write(f"FREE API ORCHESTRATOR RESULTS\n")
            f.write(f"{'='*60}\n\n")
            
            f.write(f"Task: {results['task']}\n")
            f.write(f"Date: {results['timestamp']}\n")
            f.write(f"Free APIs used: {results['free_apis_used']}\n")
            f.write(f"Local model used: {results['local_model_used']}\n\n")
            
            f.write(f"SUBTASKS:\n")
            for i, subtask in enumerate(results['subtasks'], 1):
                f.write(f"{i}. {subtask}\n")
            f.write("\n")
            
            f.write(f"RESULTS FROM APIS:\n")
            for i, result in enumerate(results['all_results'], 1):
                f.write(f"{i}. {result}\n")
            f.write("\n")
            
            f.write(f"FINAL ANSWER:\n")
            f.write(f"{results['final_answer']}\n\n")
            
            f.write(f"ARCHITECTURE:\n")
            f.write("-" * 40 + "\n")
            f.write("1. Free Cloud APIs (Google, Hugging Face, Together, Groq)\n")
            f.write("2. Local model fallback (TinyLlama/Llama-2/Mistral)\n")
            f.write("3. Parallel processing of subtasks\n")
            f.write("4. Local synthesis of final answer\n")
        
        print(f"\n📁 Results saved to: {filename}")
        return filename

async def main():
    print("🚀 FREE API AI ORCHESTRATOR")
    print("=" * 60)
    print("This system uses COMPLETELY FREE LLM APIs")
    print("No credit card required for basic usage")
    print("=" * 60)
    
    # Get task
    if len(sys.argv) > 1:
        task = " ".join(sys.argv[1:])
    else:
        print("\nEnter a complex topic to process:")
        print("(e.g., 'Explain quantum computing applications')")
        task = input("> ").strip()
        if not task:
            task = "artificial intelligence and machine learning"
    
    # Initialize orchestrator
    orchestrator = FreeAPIOrchestrator()
    
    if orchestrator.total_apis == 0 and not orchestrator.has_local:
        print("\n❌ No resources available!")
        print("\nSetup free APIs:")
        print("1. Google AI Studio: https://makersuite.google.com/app/apikey")
        print("2. Hugging Face: https://huggingface.co/settings/tokens")
        print("3. Together AI: https://together.ai")
        print("4. Groq: https://console.groq.com")
        print("\nOr ensure local models are in ~/models/")
        return
    
    # Run orchestration
    try:
        results = await orchestrator.orchestrate_complex_task(task)
        
        print(f"\n{'='*60}")
        print(f"✅ PROCESSING COMPLETE")
        print(f"{'='*60}")
        
        print(f"\n🎯 FINAL ANSWER:")
        print(f"{'='*60}")
        print(results['final_answer'])
        print(f"{'='*60}")
        
        # Save results
        orchestrator.save_results(results)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")

if __name__ == "__main__":
    # Install required package if not available
    try:
        import aiohttp
    except ImportError:
        print("Installing aiohttp...")
        import subprocess
        subprocess.run([sys.executable, "-m", "pip", "install", "aiohttp"])
        import aiohttp
    
    # Run the orchestrator
    asyncio.run(main())
