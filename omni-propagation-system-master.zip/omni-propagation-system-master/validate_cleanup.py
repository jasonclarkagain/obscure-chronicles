#!/usr/bin/env python3
import os
import re

def check_for_keys():
    suspicious = []
    
    patterns = [
        r'AIzaSy[A-Za-z0-9_\-]{35}',
        r'gsk_[A-Za-z0-9]{64}',
        r'sk-or-v1-[A-Za-z0-9]{64}',
        r'hf_[A-Za-z0-9]{34}',
        r'sk-[A-Za-z0-9-]{48,}',
        r'password["\']\s*:\s*["\'][^"\']*["\']',
    ]
    
    for root, dirs, files in os.walk('.'):
        # Skip .git directory
        if '.git' in root:
            continue
            
        for file in files:
            if file.endswith(('.py', '.sh', '.md', '.txt', '.json', '.yml', '.yaml')):
                filepath = os.path.join(root, file)
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        for pattern in patterns:
                            if re.search(pattern, content):
                                suspicious.append((filepath, pattern))
                                break
                except:
                    pass
    
    return suspicious

if __name__ == "__main__":
    print("🔍 Validating cleanup...")
    issues = check_for_keys()
    
    if issues:
        print("❌ Found potential issues:")
        for file, pattern in issues[:10]:  # Show first 10
            print(f"  {file}: Matches {pattern}")
        print(f"\nTotal issues: {len(issues)}")
    else:
        print("✅ No API keys found!")
