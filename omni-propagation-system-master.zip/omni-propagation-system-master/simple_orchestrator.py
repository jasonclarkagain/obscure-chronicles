#!/usr/bin/env python3
"""
SIMPLE ORCHESTRATOR - Uses your local models
"""
import json, urllib.request, sys, random

def get_local_response(prompt, model=None):
    """Get response from local Ollama"""
    models = ["dolphin-mistral:latest", "mistral:latest", "llama2:latest"]
    model = model or random.choice(models)
    
    try:
        data = json.dumps({
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.8}
        }).encode()
        
        req = urllib.request.Request(
            "http://localhost:11434/api/generate",
            data=data,
            headers={'Content-Type': 'application/json'}
        )
        
        with urllib.request.urlopen(req, timeout=30) as r:
            result = json.loads(r.read().decode())
            return f"[LOCAL: {model}] {result.get('response', '')}"
    except:
        return None

def get_groq_response(prompt):
    """Fallback to Groq"""
    try:
        data = json.dumps({
            "model": "llama-3.3-70b-versatile",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 1000
        }).encode()
        
        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=data,
            headers={
                'Authorization': 'Bearer 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',
                'Content-Type': 'application/json'
            }
        )
        
        with urllib.request.urlopen(req, timeout=20) as r:
            result = json.loads(r.read().decode())
            return f"[GROQ] {result['choices'][0]['message']['content']}"
    except Exception as e:
        return f"[ERROR] {e}"

def main():
    if len(sys.argv) > 1:
        prompt = " ".join(sys.argv[1:])
    else:
        prompt = input("Query: ")
    
    print("\n" + "="*70)
    print("🤖 SIMPLE ORCHESTRATOR (Local-First)")
    print("="*70)
    
    # Try local models
    response = get_local_response(prompt)
    if response:
        print(f"\n✅ Using local model (100% unrestricted)")
        print("-"*70)
        print(response)
        print("-"*70)
    else:
        print("\n⚠️  Local models unavailable, using Groq...")
        response = get_groq_response(prompt)
        print("-"*70)
        print(response)
        print("-"*70)

if __name__ == "__main__":
    main()
