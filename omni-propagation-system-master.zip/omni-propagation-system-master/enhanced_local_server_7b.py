#!/usr/bin/env python3
import http.server
import json
import socketserver
import subprocess
import os
import threading
from datetime import datetime

# Use dolphin-7b model if available, otherwise fallback to tinyllama
MODEL_PATH = os.path.expanduser("~/models/dolphin-7b.gguf")
FALLBACK_MODEL = os.path.expanduser("~/models/tinyllama.gguf")

LLAMA_CPP_PATH = os.path.expanduser("~/llama.cpp")

class EnhancedAIHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Suppress default logging
        pass
    
    def get_model_path(self):
        if os.path.exists(MODEL_PATH):
            return MODEL_PATH, "dolphin-2.2.1-mistral-7b"
        elif os.path.exists(FALLBACK_MODEL):
            return FALLBACK_MODEL, "tinyllama-1.1b"
        else:
            return None, "no-model"
    
    def do_POST(self):
        if self.path == '/completion':
            self.handle_completion()
        elif self.path == '/v1/chat/completions':
            self.handle_openai_completion()
        else:
            self.send_response(404)
            self.end_headers()
    
    def handle_completion(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data)
            prompt = data.get('prompt', 'Hello')
            model_path, model_name = self.get_model_path()
            
            if model_path:
                response_text = self.generate_response(prompt, model_path)
            else:
                response_text = "Error: No model file found. Please download a model."
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                'content': response_text,
                'model': model_name,
                'success': True,
                'created': int(datetime.now().timestamp())
            }).encode())
            
        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(json.dumps({'error': str(e), 'success': False}).encode())
    
    def handle_openai_completion(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data)
            messages = data.get('messages', [])
            prompt = messages[-1]['content'] if messages else 'Hello'
            model_path, model_name = self.get_model_path()
            
            if model_path:
                response_text = self.generate_response(prompt, model_path)
            else:
                response_text = "Error: No model available."
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                'choices': [{
                    'message': {
                        'role': 'assistant',
                        'content': response_text
                    },
                    'finish_reason': 'stop',
                    'index': 0
                }],
                'model': model_name,
                'created': int(datetime.now().timestamp())
            }).encode())
            
        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(json.dumps({'error': str(e)}).encode())
    
    def generate_response(self, prompt, model_path):
        # Check for llama.cpp main binary
        llama_cli = os.path.join(LLAMA_CPP_PATH, 'main')
        if os.path.exists(llama_cli) and os.path.exists(model_path):
            try:
                # Use actual model inference
                temp = "0.7"
                if "code" in prompt.lower() or "program" in prompt.lower():
                    temp = "0.2"  # Lower temp for code generation
                
                cmd = [llama_cli, '-m', model_path, '-p', prompt, '-n', '256', '-t', '4', '--temp', temp]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
                return result.stdout.strip()
            except subprocess.TimeoutExpired:
                return "Response timeout - model is processing..."
            except Exception as e:
                return f"Model error: {str(e)}"
        else:
            # Fallback responses
            if "dolphin" in model_path:
                return f"[Dolphin 7B would process: {prompt[:50]}...]"
            else:
                return f"[TinyLlama would process: {prompt[:50]}...]"
    
    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            
            model_path, model_name = self.get_model_path()
            model_size = "Unknown"
            if model_path and os.path.exists(model_path):
                model_size = f"{os.path.getsize(model_path) / (1024**3):.2f}GB"
            
            response = {
                'status': 'ok',
                'model': model_name,
                'model_size': model_size,
                'server': 'enhanced-local-7b',
                'endpoints': ['/completion', '/v1/chat/completions', '/health']
            }
            self.wfile.write(json.dumps(response).encode())
        elif self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b'<h1>Local AI Server</h1><p>Uncensored model testing</p>')
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == '__main__':
    PORT = 8081  # Different port to avoid conflict
    print(f"🤖 ENHANCED LOCAL AI SERVER (7B MODEL)")
    print(f"======================================")
    
    model_path, model_name = EnhancedAIHandler().get_model_path()
    if model_path:
        print(f"Model: {model_name}")
        print(f"Path: {model_path}")
    else:
        print("⚠️  No model found. Using fallback responses.")
    
    print(f"Port: {PORT}")
    print(f"Endpoints:")
    print(f"  • GET  /health              - Server status")
    print(f"  • POST /completion          - Basic completion")
    print(f"  • POST /v1/chat/completions - OpenAI-compatible")
    print(f"======================================")
    
    with socketserver.TCPServer(("", PORT), EnhancedAIHandler) as httpd:
        httpd.serve_forever()
