import requests
import json

def trigger_n8n_swarm(query):
    """
    Calls the n8n webhook to execute the ParallelAI research workflow.
    """
    # Use 127.0.0.1 if host.docker.internal isn't mapped
    URL = "http://127.0.0.1:5678/webhook/swarm-research"
    payload = {"query": query}
    
    try:
        # We send the request to your local n8n instance
        response = requests.post(URL, json=payload, timeout=30)
        if response.status_code == 200:
            return response.text
        else:
            return f"Error: n8n returned status {response.status_code}"
    except Exception as e:
        return f"Connection Failed: {str(e)}"
