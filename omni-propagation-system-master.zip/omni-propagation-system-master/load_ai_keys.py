#!/usr/bin/env python3
import os
import sys

# Set environment variables
os.environ['OPENROUTER_API_KEY'] = ANTHROPIC_API_KEY_PLACEHOLDER
os.environ['HUGGINGFACE_TOKEN'] = "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"
os.environ['GROQ_API_KEY'] = "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"

print("✅ AI API keys set in Python environment")
print(f"OPENROUTER: {os.environ['OPENROUTER_API_KEY'][:10]}...")
print(f"HUGGINGFACE: {os.environ['HUGGINGFACE_TOKEN'][:10]}...")
print(f"GROQ: {os.environ['GROQ_API_KEY'][:10]}...")
