#!/usr/bin/env python3
import subprocess
import sys
import os

def run_tinyllama(prompt, max_tokens=80):
    """Run TinyLlama and return response"""
    cmd = [
        os.path.expanduser("~/llama.cpp/build/bin/llama-cli"),
        "-m", os.path.expanduser("~/models/tinyllama.gguf"),
        "-p", prompt,
        "-n", str(max_tokens),
        "--temp", "0.7",
        "-no-cnv"
    ]
    
    try:
        # Run command
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=15
        )
        
        # Find the line with our prompt
        output = result.stdout
        
        # Split by lines and look for our prompt
        for line in output.split('\n'):
            if prompt in line:
                # Extract everything after the prompt
                idx = line.find(prompt)
                if idx != -1:
                    response = line[idx + len(prompt):].strip()
                    # Clean up
                    response = response.lstrip(':').strip()
                    if response:
                        return response
        
        # If we didn't find it, look for any meaningful output
        lines = []
        for line in output.split('\n'):
            line = line.strip()
            if (line and 
                not line.startswith('llama_') and
                not line.startswith('print_info') and
                not line.startswith('build:') and
                not line.startswith('main:') and
                not line.startswith('system_info') and
                not line.startswith('sampler') and
                not line.startswith('generate:') and
                not line.startswith('common_perf_print:') and
                not line.startswith('llama_memory_breakdown_print:') and
                not line.startswith('IMPORTANT:') and
                '-----' not in line and
                'Dumping' not in line):
                lines.append(line)
        
        # Return the last meaningful line
        if lines:
            return lines[-1]
        
        return "No response generated."
        
    except Exception as e:
        return f"Error: {str(e)}"

def main():
    print("=" * 60)
    print("WORKING TinyLlama Assistant")
    print("=" * 60)
    
    if len(sys.argv) > 1:
        # Command line mode
        prompt = " ".join(sys.argv[1:])
        print(f"Q: {prompt}")
        response = run_tinyllama(prompt)
        print(f"A: {response}")
    else:
        # Interactive mode
        while True:
            print("\nAsk me anything (or 'quit' to exit):")
            user_input = input("> ").strip()
            
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("Goodbye!")
                break
            
            if not user_input:
                continue
            
            print("\nThinking...")
            response = run_tinyllama(user_input)
            print(f"\n{response}")
            print("-" * 40)

if __name__ == "__main__":
    main()
