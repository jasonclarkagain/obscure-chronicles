Here is an example of how to perform AES-256 encryption and decryption in Python using the `cryptography` library:

```python
from cryptography.fernet import Fernet
from base64 import b64encode, b64decode
import os

class AesCipher:
    def __init__(self):
        self.key = Fernet.generate_key()
        self.cipher_suite = Fernet(self.key)

    def encrypt(self, data: bytes) -> str:
        """Encrypts the given data using AES-256."""
        encrypted = self.cipher_suite.encrypt(data)
        return b64encode(encrypted).decode()

