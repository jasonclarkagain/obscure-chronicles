#!/usr/bin/env python3
import sys, json
query = sys.argv[1] if len(sys.argv) > 1 else "test"
print(json.dumps({"query": query, "status": "processed"}, indent=2))
