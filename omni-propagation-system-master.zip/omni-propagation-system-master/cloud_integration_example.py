#!/usr/bin/env python3
"""
EXAMPLE: Cloud LLM Integration for Orchestrator
Requires: pip install openai anthropic google-generativeai
"""

import os
import asyncio
import aiohttp

# ========== CONFIGURATION ==========
# Set these environment variables with your API keys
# export OPENAI_API_KEY="your-key"
# export ANTHROPIC_API_KEY="your-key"  
# export GOOGLE_API_KEY="your-key"

class CloudLLMOrchestrator:
    async def delegate_to_openai(self, prompt: str, model: str = "gpt-3.5-turbo"):
        """Delegate to OpenAI"""
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return "[OpenAI API key not set]"
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 500,
                    "temperature": 0.7
                }
            ) as response:
                data = await response.json()
                return data.get("choices", [{}])[0].get("message", {}).get("content", "No response")
    
    async def delegate_to_anthropic(self, prompt: str, model: str = "claude-3-haiku-20240307"):
        """Delegate to Anthropic Claude"""
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            return "[Anthropic API key not set]"
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json"
                },
                json={
                    "model": model,
                    "max_tokens": 500,
                    "messages": [{"role": "user", "content": prompt}]
                }
            ) as response:
                data = await response.json()
                return data.get("content", [{}])[0].get("text", "No response")
    
    async def delegate_to_google(self, prompt: str, model: str = "gemini-pro"):
        """Delegate to Google Gemini"""
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            return "[Google API key not set]"
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}",
                json={
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {
                        "maxOutputTokens": 500,
                        "temperature": 0.7
                    }
                }
            ) as response:
                data = await response.json()
                return data.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "No response")
    
    async def process_in_parallel(self, subtasks: list):
        """Process multiple subtasks in parallel using different cloud LLMs"""
        tasks = []
        
        # Assign each subtask to a different cloud LLM
        for i, subtask in enumerate(subtasks):
            if i % 3 == 0:
                tasks.append(self.delegate_to_openai(f"Explain: {subtask}"))
            elif i % 3 == 1:
                tasks.append(self.delegate_to_anthropic(f"Explain: {subtask}"))
            else:
                tasks.append(self.delegate_to_google(f"Explain: {subtask}"))
        
        # Run all tasks in parallel
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle any exceptions
        clean_results = []
        for result in results:
            if isinstance(result, Exception):
                clean_results.append(f"Error: {str(result)}")
            else:
                clean_results.append(result)
        
        return clean_results

# Example usage
async def main():
    orchestrator = CloudLLMOrchestrator()
    
    # Example subtasks
    subtasks = [
        "Historical development of relativity theory",
        "Core principles of special relativity",
        "Core principles of general relativity",
        "Real-world applications of relativity"
    ]
    
    print("Starting parallel cloud processing...")
    results = await orchestrator.process_in_parallel(subtasks)
    
    print("\nResults from cloud LLMs:")
    for i, result in enumerate(results, 1):
        print(f"\n--- Result {i} (First 200 chars) ---")
        print(result[:200])

if __name__ == "__main__":
    asyncio.run(main())
