#!/usr/bin/env python3
"""
HYBRID AI ORCHESTRATOR - Cloud first, local fallback
"""

import os
import sys
import asyncio
import aiohttp
import json
import subprocess
import time
from datetime import datetime

class HybridOrchestrator:
    def __init__(self):
        # Set API keys from environment
        self.openrouter_key = os.getenv('OPENROUTER_API_KEY')
        self.groq_key = os.getenv('GROQ_API_KEY')
        
        self.cloud_apis = []
        if self.openrouter_key:
            self.cloud_apis.append('openrouter')
        if self.groq_key:
            self.cloud_apis.append('groq')
    
    async def call_openrouter(self, query: str) -> dict:
        """Call OpenRouter API"""
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.openrouter_key}",
            "Content-Type": "application/json"
        }
        data = {
            "model": "mistralai/mistral-7b-instruct:free",
            "messages": [{"role": "user", "content": query}],
            "max_tokens": 500
        }
        
        try:
            timeout = aiohttp.ClientTimeout(total=15)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        return {
                            "success": True,
                            "api": "openrouter",
                            "response": result['choices'][0]['message']['content'],
                            "tokens": result.get('usage', {}).get('total_tokens', 0)
                        }
                    else:
                        return {"success": False, "error": f"HTTP {response.status}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def call_groq(self, query: str) -> dict:
        """Call Groq API (with updated model)"""
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.groq_key}",
            "Content-Type": "application/json"
        }
        # Try updated models based on deprecation info
        models_to_try = ["llama-3.3-70b-versatile", "llama-3.2-11b-vision-preview", "gemma2-9b-it"]
        
        for model in models_to_try:
            data = {
                "model": model,
                "messages": [{"role": "user", "content": query}],
                "max_tokens": 500,
                "temperature": 0.7
            }
            
            try:
                timeout = aiohttp.ClientTimeout(total=15)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.post(url, headers=headers, json=data) as response:
                        if response.status == 200:
                            result = await response.json()
                            return {
                                "success": True,
                                "api": "groq",
                                "model": model,
                                "response": result['choices'][0]['message']['content'],
                                "tokens": result.get('usage', {}).get('total_tokens', 0)
                            }
                        elif response.status == 400:
                            # Try next model
                            continue
            except:
                continue
        
        return {"success": False, "error": "All models failed"}
    
    def call_local(self, query: str, model: str = "tinyllama") -> dict:
        """Call local model"""
        try:
            cmd = ["python3", "ultimate_orchestrator.py", model, query]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode == 0:
                # Extract answer
                lines = result.stdout.split('\n')
                answer = ""
                in_answer = False
                
                for line in lines:
                    if "FINAL ANSWER" in line or "🎯 FINAL ANSWER" in line:
                        in_answer = True
                        continue
                    if in_answer and line.strip() and "====" not in line:
                        answer += line.strip() + "\n"
                    if in_answer and "====" in line and answer:
                        break
                
                if not answer:
                    # Fallback: get last meaningful content
                    for line in reversed(lines):
                        if line.strip() and len(line.strip()) > 20 and "====" not in line:
                            answer = line.strip()
                            break
                
                return {
                    "success": True,
                    "api": "local",
                    "model": model,
                    "response": answer.strip(),
                    "tokens": 0
                }
            else:
                return {"success": False, "error": f"Exit code {result.returncode}"}
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Timeout"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def orchestrate(self, query: str, force_local: bool = False) -> dict:
        """Main orchestration method"""
        print(f"\n🤖 HYBRID ORCHESTRATOR")
        print("="*60)
        print(f"Query: {query[:80]}...")
        print("="*60)
        
        start_time = time.time()
        results = []
        
        if force_local:
            print("\n🔧 Forced local mode")
            # Try local models in order of quality
            for model in ["mistral", "llama2", "tinyllama"]:
                print(f"  Trying {model}...")
                result = self.call_local(query, model)
                if result["success"]:
                    results.append(result)
                    print(f"  ✅ {model} succeeded")
                    break
                else:
                    print(f"  ❌ {model} failed: {result['error'][:30]}")
        else:
            print("\n☁️  Trying cloud APIs...")
            # Try cloud APIs in parallel
            cloud_tasks = []
            if 'openrouter' in self.cloud_apis:
                cloud_tasks.append(self.call_openrouter(query))
            if 'groq' in self.cloud_apis:
                cloud_tasks.append(self.call_groq(query))
            
            if cloud_tasks:
                cloud_results = await asyncio.gather(*cloud_tasks)
                cloud_success = False
                
                for result in cloud_results:
                    if result["success"]:
                        results.append(result)
                        cloud_success = True
                        print(f"  ✅ {result['api']} succeeded")
                
                if not cloud_success:
                    print("  ⚠️  All cloud APIs failed, falling back to local...")
                    # Fallback to local
                    for model in ["tinyllama", "llama2", "mistral"]:
                        print(f"    Trying {model}...")
                        result = self.call_local(query, model)
                        if result["success"]:
                            results.append(result)
                            print(f"    ✅ {model} succeeded")
                            break
            else:
                print("  ⚠️  No cloud APIs configured, using local...")
                result = self.call_local(query, "tinyllama")
                if result["success"]:
                    results.append(result)
        
        # Process results
        elapsed = time.time() - start_time
        
        if results:
            best_result = results[0]  # First successful result
            return {
                "success": True,
                "query": query,
                "response": best_result["response"],
                "source": best_result["api"],
                "model": best_result.get("model", ""),
                "tokens": best_result.get("tokens", 0),
                "time": elapsed,
                "timestamp": datetime.now().isoformat()
            }
        else:
            return {
                "success": False,
                "query": query,
                "error": "All orchestration methods failed",
                "time": elapsed,
                "timestamp": datetime.now().isoformat()
            }

async def main():
    if len(sys.argv) < 2:
        print("Usage: python hybrid_orchestrator.py \"Your query\"")
        print("       python hybrid_orchestrator.py --local \"Query\"")
        sys.exit(1)
    
    force_local = False
    query_start = 1
    
    if sys.argv[1] == "--local":
        force_local = True
        query_start = 2
    
    query = " ".join(sys.argv[query_start:])
    
    orchestrator = HybridOrchestrator()
    result = await orchestrator.orchestrate(query, force_local)
    
    print("\n" + "="*60)
    if result["success"]:
        print("✅ ORCHESTRATION SUCCESSFUL")
        print("="*60)
        print(f"Source: {result['source']}")
        if result.get('model'):
            print(f"Model: {result['model']}")
        print(f"Time: {result['time']:.1f}s")
        if result.get('tokens', 0) > 0:
            print(f"Tokens: {result['tokens']}")
        
        print("\n🎯 ANSWER:")
        print("="*60)
        print(result['response'])
        print("="*60)
        
        # Save result
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"hybrid_result_{timestamp}.json"
        with open(filename, "w") as f:
            json.dump(result, f, indent=2)
        print(f"\n💾 Saved to: {filename}")
    else:
        print("❌ ORCHESTRATION FAILED")
        print("="*60)
        print(f"Error: {result['error']}")

if __name__ == "__main__":
    asyncio.run(main())
