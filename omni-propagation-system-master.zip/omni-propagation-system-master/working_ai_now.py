#!/usr/bin/env python3
"""
CURRENTLY WORKING AI APIS - DEC 2025
"""

import urllib.request
import json
import sys
import time

def query_deepseek(prompt):
    """DeepSeek API - Currently working and free"""
    url = "https://api.deepseek.com/chat/completions"
    
    data = json.dumps({
        "model": "deepseek-chat",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 300,
        "stream": False
    }).encode('utf-8')
    
    try:
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                'Content-Type': 'application/json',
                'Authorization': 'Bearer sk-xxxx'  # You can get free key at deepseek.com
            }
        )
        
        with urllib.request.urlopen(req, timeout=15) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result['choices'][0]['message']['content']
    except Exception as e:
        return f"DeepSeek Error: {str(e)[:100]}"

def query_openrouter_free(prompt):
    """OpenRouter with completely free models"""
    url = "https://openrouter.ai/api/v1/chat/completions"
    
    data = json.dumps({
        "model": "google/gemma-7b-it:free",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 300
    }).encode('utf-8')
    
    try:
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                'Content-Type': 'application/json',
                'Authorization': 'Bearer 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',
                'HTTP-Referer': 'http://localhost:3000',
                'X-Title': 'AI Tester'
            }
        )
        
        with urllib.request.urlopen(req, timeout=15) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result['choices'][0]['message']['content']
    except Exception as e:
        return f"OpenRouter Error: {str(e)[:100]}"

def query_local_huggingface(prompt):
    """Hugging Face with local inference"""
    try:
        # Use HF Inference API
        url = "https://api-inference.huggingface.co/models/gpt2"
        data = json.dumps({"inputs": prompt}).encode('utf-8')
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                'Content-Type': 'application/json',
                'Authorization': 'Bearer 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'
            }
        )
        
        with urllib.request.urlopen(req, timeout=15) as response:
            result = json.loads(response.read().decode('utf-8'))
            if isinstance(result, list):
                return result[0].get('generated_text', 'No text')[len(prompt):]
            return str(result)[:300]
    except Exception as e:
        return f"HF Error: {str(e)[:100]}"

def query_together_ai(prompt):
    """Together AI - $25 free credit"""
    url = "https://api.together.xyz/v1/chat/completions"
    
    data = json.dumps({
        "model": "mistralai/Mistral-7B-Instruct-v0.2",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 300,
        "temperature": 0.7
    }).encode('utf-8')
    
    try:
        # You need to sign up at together.ai for free $25
        key = "YOUR_TOGETHER_KEY"  # Get from together.ai
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {key}'
            }
        )
        
        with urllib.request.urlopen(req, timeout=15) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result['choices'][0]['message']['content']
    except Exception as e:
        return f"Together AI: Sign up at together.ai for free $25 credit"

def main():
    print("🤖 WORKING AI APIS - DECEMBER 2025")
    print("="*50)
    
    # Get question
    if len(sys.argv) > 1:
        question = " ".join(sys.argv[1:])
    else:
        print("\nWhat would you like to know?")
        question = sys.stdin.readline().strip() or "What is AI?"
    
    print(f"\n📝 Question: {question}")
    
    # Try different APIs
    print("\n1. Trying OpenRouter (free Gemma model)...")
    response1 = query_openrouter_free(question)
    print(f"   Response: {response1[:200]}...")
    
    print("\n2. Trying Hugging Face GPT-2...")
    response2 = query_local_huggingface(question)
    print(f"   Response: {response2[:200]}...")
    
    print("\n3. Together AI (needs free registration)...")
    print("   " + query_together_ai(question))
    
    print("\n" + "="*50)
    print("💡 To get free API keys:")
    print("1. OpenRouter: https://openrouter.ai (free models)")
    print("2. Together AI: https://together.ai ($25 free)")
    print("3. DeepSeek: https://platform.deepseek.com (free tier)")
    print("="*50)

if __name__ == "__main__":
    main()
