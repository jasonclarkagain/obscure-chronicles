#!/bin/bash
echo "========================================"
echo "🦠 OMNI PROPAGATION - FINAL VERIFICATION"
echo "========================================"

echo "[1] Repository Status:"
echo "    RID: $(rad . 2>/dev/null || echo 'Not found')"
echo "    Branch: $(git branch --show-current 2>/dev/null || echo 'Not a git repo')"
echo "    Last commit: $(git log -1 --oneline 2>/dev/null | head -c 50)"

echo ""
echo "[2] Generated Files:"
if [ -d "payloads/v1.0" ]; then
    echo "    ✅ Payloads directory exists"
    ls -1 payloads/v1.0/ | while read file; do
        size=$(stat -c%s "payloads/v1.0/$file" 2>/dev/null || echo "?")
        echo "      • $file ($size bytes)"
    done
else
    echo "    ❌ Payloads directory missing"
fi

echo ""
echo "[3] Test Execution:"
if [ -f "payloads/v1.0/omni_final.sh" ]; then
    echo "    Testing shell payload..."
    if timeout 5 bash payloads/v1.0/omni_final.sh > /tmp/omni_test.log 2>&1; then
        echo "    ✅ Shell payload works"
        echo "    Output sample:"
        head -5 /tmp/omni_test.log | sed 's/^/      /'
    else
        echo "    ❌ Shell payload failed"
    fi
    
    echo ""
    echo "    Testing Python payload..."
    if timeout 5 python3 payloads/v1.0/omni_final.py > /tmp/omni_py_test.log 2>&1; then
        echo "    ✅ Python payload works"
    else
        echo "    ❌ Python payload failed"
        tail -2 /tmp/omni_py_test.log | sed 's/^/      /'
    fi
fi

echo ""
echo "[4] Deployment Test:"
if [ -f "deploy_omni.sh" ]; then
    echo "    ✅ Deployment script exists"
    chmod +x deploy_omni.sh 2>/dev/null
    echo "    Run './deploy_omni.sh' to deploy"
else
    echo "    ❌ Deployment script missing"
fi

echo ""
echo "========================================"
echo "✅ SYSTEM VERIFICATION COMPLETE"
echo "========================================"
echo ""
echo "🔧 Quick Start:"
echo "   1. python3 omni_generator.py"
echo "   2. ./payloads/v1.0/omni_final.sh"
echo "   3. ./deploy_omni.sh"
echo ""
echo "🌐 Radicle: https://app.radicle.xyz/nodes/rosa.radicle.xyz/rad:z3HQrWKN26thtyeF43UdjVcJcbe6"
