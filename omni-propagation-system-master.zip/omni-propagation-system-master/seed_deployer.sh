#!/bin/bash
# THE 12TH NAME - REMOTE SEED
STAGING="/tmp/.sys_cache"
mkdir -p $STAGING && cd $STAGING

# 1. Pull the Radicle binary silently
curl -O -L https://files.radicle.xyz/releases/latest/radicle-x86_64-unknown-linux-musl.tar.xz
tar -xf radicle-x86_64-unknown-linux-musl.tar.xz
mv radicle-*-linux-musl/bin/rad .

# 2. Clone the DNA from your specific DID
# Replace <YOUR_RID> with the ID from 'rad init'
./rad clone rad://<YOUR_RID_HERE> --seed

# 3. Launch the Autopilot
nohup python3 watcher.py > /dev/null 2>&1 &
echo "[+] Node Integrated into 12th Name Mesh."
