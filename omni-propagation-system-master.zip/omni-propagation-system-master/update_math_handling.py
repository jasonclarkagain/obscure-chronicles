#!/usr/bin/env python3
"""
Update to handle math and simple queries better
"""

import re

def improve_math_prompt(query: str) -> str:
    """Improve prompts for math/simple queries"""
    # Check if it's a math question
    math_patterns = [
        r'\d+\s*[+\-*/]\s*\d+',
        r'what is \d+',
        r'calculate',
        r'equals',
        r'=\s*\?',
        r'\d+\s+plus\s+\d+',
        r'\d+\s+minus\s+\d+'
    ]
    
    for pattern in math_patterns:
        if re.search(pattern, query.lower()):
            return f"Calculate this exactly: {query}. Give only the numerical answer."
    
    # Check if it's a very simple factual question
    simple_patterns = [
        r'^what (is|are) .*\?$',
        r'^who (is|are) .*\?$',
        r'^where (is|are) .*\?$',
        r'^when (is|are) .*\?$'
    ]
    
    for pattern in simple_patterns:
        if re.search(pattern, query.lower()):
            return f"Answer this question directly and concisely: {query}"
    
    return query

# Test it
test_queries = [
    "What is the capital of France?",
    "2+2=?",
    "Calculate 15 * 3",
    "Explain machine learning",
    "Hello, how are you?"
]

print("Testing improved prompting:")
for query in test_queries:
    improved = improve_math_prompt(query)
    print(f"  Original: {query}")
    print(f"  Improved: {improved}")
    print()
