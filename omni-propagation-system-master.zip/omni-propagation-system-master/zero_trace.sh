#!/bin/bash
echo "[!!!] WARNING: PERMANENTLY CLEARING LOCAL FOOTPRINT"

# 1. Kill all background processes
pkill -f "python3 .*_watcher"
pkill -f "rad node"

# 2. Shred the logic and temporary files
find ~/.local/share/sys_update -type f -exec shred -u -n 7 {} \;
rm -rf ~/.local/share/sys_update

# 3. Wipe Command History and Logs
history -c
cat /dev/null > ~/.bash_history
sudo journalctl --vacuum-time=1s
sudo rm /var/log/syslog* /var/log/auth.log*

echo "[+] LOCAL TRAIL PURGED. OPERATION IS NOW 100% EXTERNAL."
