#!/usr/bin/env python3
"""
N8N + SWARM INTEGRATION
Visual workflow orchestration for your AI swarm
"""

import json
import subprocess
import os
import sys
import time
import threading
from typing import Dict, List, Any
import urllib.request
import socket

class N8nSwarmIntegration:
    """Integrates n8n workflow automation with AI swarm"""
    
    def __init__(self, n8n_port=5678, swarm_port=8888):
        self.n8n_port = n8n_port
        self.swarm_port = swarm_port
        self.n8n_process = None
        self.swarm_nodes = []
        
        print("🤖 N8N + Swarm Integration")
        print("==========================")
    
    def install_n8n(self):
        """Install n8n and required nodes"""
        print("📦 Installing n8n...")
        
        try:
            # Install n8n globally
            subprocess.run(['npm', 'install', '-g', 'n8n'], check=True, capture_output=True)
            
            # Install useful n8n nodes
            subprocess.run(['npm', 'install', '-g', 
                'n8n-nodes-base',
                'n8n-nodes-custom',
                'n8n-nodes-ai'
            ], capture_output=True)
            
            print("✅ n8n installed successfully")
            return True
        except Exception as e:
            print(f"⚠️ n8n installation failed: {e}")
            return False
    
    def start_n8n(self):
        """Start n8n server"""
        print(f"🚀 Starting n8n on port {self.n8n_port}...")
        
        # Set N8N environment variables
        env = os.environ.copy()
        env['N8N_PORT'] = str(self.n8n_port)
        env['N8N_PROTOCOL'] = 'http'
        env['N8N_HOST'] = 'localhost'
        
        # Start n8n in background
        self.n8n_process = subprocess.Popen(
            ['n8n', 'start'],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Wait for n8n to start
        time.sleep(5)
        print(f"✅ n8n started at http://localhost:{self.n8n_port}")
        print(f"   Default credentials: admin@n8n.io / password")
        return True
    
    def create_swarm_workflow(self, workflow_name="AI Swarm Orchestrator"):
        """Create n8n workflow for swarm management"""
        workflow = {
            "name": workflow_name,
            "nodes": [
                # Trigger node
                {
                    "name": "Manual Trigger",
                    "type": "n8n-nodes-base.manualTrigger",
                    "position": [250, 300],
                    "parameters": {}
                },
                # Swarm Discovery Node
                {
                    "name": "Discover Swarm Nodes",
                    "type": "n8n-nodes-base.httpRequest",
                    "position": [450, 300],
                    "parameters": {
                        "method": "GET",
                        "url": f"http://localhost:{self.swarm_port}/workers",
                        "authentication": "genericCredentialType",
                        "genericAuthType": "httpHeaderAuth",
                        "sendHeaders": True,
                        "headerParameters": {
                            "parameters": [
                                {
                                    "name": "Content-Type",
                                    "value": "application/json"
                                }
                            ]
                        }
                    }
                },
                # Task Decomposition Node
                {
                    "name": "Decompose AI Task",
                    "type": "n8n-nodes-base.code",
                    "position": [650, 300],
                    "parameters": {
                        "jsCode": f"""
// Decompose complex AI task
const task = $input.first().json.prompt || $input.first().json;

// Call local swarm for decomposition
const decomposed = await $http.post(
  `http://localhost:{self.swarm_port}/decompose`,
  {{
    prompt: task
  }}
);

// Return decomposed tasks
return decomposed.tasks.map((t, i) => ({{
  json: {{
    task_id: 'task_${i}_${Date.now()}',
    subtask: t,
    priority: i === 0 ? 'high' : 'medium',
    timestamp: new Date().toISOString()
  }}
}}));
"""
                    }
                },
                # Swarm Distribution Node
                {
                    "name": "Distribute to Swarm",
                    "type": "n8n-nodes-base.httpRequest",
                    "position": [850, 300],
                    "parameters": {
                        "method": "POST",
                        "url": f"http://localhost:{self.swarm_port}/distribute",
                        "authentication": "genericCredentialType",
                        "genericAuthType": "httpHeaderAuth",
                        "sendHeaders": True,
                        "headerParameters": {
                            "parameters": [
                                {
                                    "name": "Content-Type",
                                    "value": "application/json"
                                }
                            ]
                        },
                        "sendBody": True,
                        "bodyParameters": {
                            "parameters": [
                                {
                                    "name": "tasks",
                                    "value": "={{ $json.tasks }}"
                                }
                            ]
                        }
                    }
                },
                # AI Processing Nodes (parallel execution)
                {
                    "name": "Process with Groq AI",
                    "type": "n8n-nodes-base.httpRequest",
                    "position": [1050, 200],
                    "parameters": {
                        "method": "POST",
                        "url": "https://api.groq.com/openai/v1/chat/completions",
                        "authentication": "genericCredentialType",
                        "genericAuthType": "httpHeaderAuth",
                        "sendHeaders": True,
                        "headerParameters": {
                            "parameters": [
                                {
                                    "name": "Authorization",
                                    "value": "Bearer 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"
                                },
                                {
                                    "name": "Content-Type",
                                    "value": "application/json"
                                }
                            ]
                        },
                        "sendBody": True,
                        "bodyParameters": {
                            "parameters": [
                                {
                                    "name": "model",
                                    "value": "llama-3.3-70b-versatile"
                                },
                                {
                                    "name": "messages",
                                    "value": "=[{\"role\": \"user\", \"content\": \"{{ $json.subtask }}\"}]"
                                },
                                {
                                    "name": "max_tokens",
                                    "value": 1000
                                }
                            ]
                        }
                    }
                },
                {
                    "name": "Process with Local Model",
                    "type": "n8n-nodes-base.httpRequest",
                    "position": [1050, 400],
                    "parameters": {
                        "method": "POST",
                        "url": "http://localhost:11434/api/generate",
                        "sendHeaders": True,
                        "headerParameters": {
                            "parameters": [
                                {
                                    "name": "Content-Type",
                                    "value": "application/json"
                                }
                            ]
                        },
                        "sendBody": True,
                        "bodyParameters": {
                            "parameters": [
                                {
                                    "name": "model",
                                    "value": "mistral:7b"
                                },
                                {
                                    "name": "prompt",
                                    "value": "={{ $json.subtask }}"
                                },
                                {
                                    "name": "stream",
                                    "value": False
                                }
                            ]
                        }
                    }
                },
                # Result Aggregation Node
                {
                    "name": "Aggregate Results",
                    "type": "n8n-nodes-base.merge",
                    "position": [1250, 300],
                    "parameters": {
                        "mode": "combine",
                        "outputFormat": "singleItem"
                    }
                },
                # Final Synthesis Node
                {
                    "name": "Synthesize Final Answer",
                    "type": "n8n-nodes-base.code",
                    "position": [1450, 300],
                    "parameters": {
                        "jsCode": """
// Combine all AI responses
const responses = $input.all();

// Create final synthesis
const synthesis = {
  original_task: $input.first().json.original_task,
  decomposed_tasks: responses.map(r => r.json.subtask),
  ai_responses: responses.map(r => r.json.response || r.json),
  timestamp: new Date().toISOString(),
  total_tasks: responses.length,
  swarm_nodes_used: responses.length
};

// Call swarm for final synthesis if available
try {
  const final = await $http.post(
    'http://localhost:8888/synthesize',
    {
      task: $input.first().json.original_task,
      responses: responses.map(r => r.json)
    }
  );
  synthesis.final_result = final.result;
} catch (e) {
  synthesis.final_result = "Synthesis failed: " + e.message;
}

return [{ json: synthesis }];
"""
                    }
                }
            ],
            "connections": {
                "Manual Trigger": {
                    "main": [
                        {
                            "node": "Discover Swarm Nodes",
                            "type": "main",
                            "index": 0
                        }
                    ]
                },
                "Discover Swarm Nodes": {
                    "main": [
                        {
                            "node": "Decompose AI Task",
                            "type": "main",
                            "index": 0
                        }
                    ]
                },
                "Decompose AI Task": {
                    "main": [
                        [
                            {
                                "node": "Distribute to Swarm",
                                "type": "main",
                                "index": 0
                            }
                        ]
                    ]
                },
                "Distribute to Swarm": {
                    "main": [
                        [
                            {
                                "node": "Process with Groq AI",
                                "type": "main",
                                "index": 0
                            },
                            {
                                "node": "Process with Local Model",
                                "type": "main",
                                "index": 1
                            }
                        ]
                    ]
                },
                "Process with Groq AI": {
                    "main": [
                        {
                            "node": "Aggregate Results",
                            "type": "main",
                            "index": 0
                        }
                    ]
                },
                "Process with Local Model": {
                    "main": [
                        {
                            "node": "Aggregate Results",
                            "type": "main",
                            "index": 1
                        }
                    ]
                },
                "Aggregate Results": {
                    "main": [
                        {
                            "node": "Synthesize Final Answer",
                            "type": "main",
                            "index": 0
                        }
                    ]
                }
            },
            "settings": {},
            "staticData": None,
            "pinData": {}
        }
        
        return workflow
    
    def deploy_workflow(self, workflow_json, n8n_api_key=None):
        """Deploy workflow to n8n via API"""
        try:
            workflow_str = json.dumps(workflow_json)
            
            # Save to file
            workflow_path = os.path.expanduser("~/swarm_workflow.json")
            with open(workflow_path, 'w') as f:
                f.write(workflow_str)
            
            print(f"📁 Workflow saved to: {workflow_path}")
            print(f"🔗 Import manually at: http://localhost:{self.n8n_port}/workflow/new")
            
            # Try to auto-import via API
            if n8n_api_key:
                import_url = f"http://localhost:{self.n8n_port}/rest/workflows"
                headers = {
                    'X-N8N-API-KEY': n8n_api_key,
                    'Content-Type': 'application/json'
                }
                
                req = urllib.request.Request(
                    import_url,
                    data=workflow_str.encode(),
                    headers=headers,
                    method='POST'
                )
                
                with urllib.request.urlopen(req) as response:
                    result = json.loads(response.read().decode())
                    print(f"✅ Workflow imported with ID: {result.get('id')}")
            
            return True
        except Exception as e:
            print(f"⚠️ Workflow deployment failed: {e}")
            return False
    
    def create_swarm_api_for_n8n(self):
        """Create a simple API for n8n to interact with swarm"""
        from http.server import HTTPServer, BaseHTTPRequestHandler
        import threading
        
        class SwarmAPIHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == '/workers':
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    
                    # Simulate discovered workers
                    workers = [
                        {"id": "worker_1", "type": "groq", "status": "active"},
                        {"id": "worker_2", "type": "local", "status": "active"},
                        {"id": "worker_3", "type": "openrouter", "status": "ready"}
                    ]
                    
                    self.wfile.write(json.dumps({"workers": workers}).encode())
                    
                elif self.path == '/health':
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"OK")
                    
                else:
                    self.send_response(404)
                    self.end_headers()
            
            def do_POST(self):
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode())
                
                if self.path == '/decompose':
                    # Task decomposition endpoint
                    prompt = data.get('prompt', '')
                    
                    # Simple decomposition logic
                    words = prompt.split()
                    tasks = []
                    
                    if len(words) > 10:
                        # Break into chunks
                        chunk_size = len(words) // 3
                        for i in range(0, len(words), chunk_size):
                            task = ' '.join(words[i:i+chunk_size])
                            tasks.append(f"Process: {task}")
                    else:
                        tasks = [f"Analyze: {prompt}"]
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({"tasks": tasks}).encode())
                    
                elif self.path == '/distribute':
                    # Task distribution endpoint
                    tasks = data.get('tasks', [])
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    
                    response = {
                        "distributed": True,
                        "task_count": len(tasks),
                        "message": f"Distributed {len(tasks)} tasks to swarm"
                    }
                    
                    self.wfile.write(json.dumps(response).encode())
                    
                elif self.path == '/synthesize':
                    # Result synthesis endpoint
                    task = data.get('task', '')
                    responses = data.get('responses', [])
                    
                    # Simple synthesis
                    synthesis = f"Based on {len(responses)} AI responses:\n\n"
                    for i, resp in enumerate(responses):
                        synthesis += f"Response {i+1}: {str(resp)[:100]}...\n"
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({"result": synthesis}).encode())
                
                else:
                    self.send_response(404)
                    self.end_headers()
            
            def log_message(self, format, *args):
                pass
        
        # Start API server in background thread
        def run_api():
            server = HTTPServer(('localhost', self.swarm_port), SwarmAPIHandler)
            print(f"🌐 Swarm API listening on port {self.swarm_port}")
            server.serve_forever()
        
        api_thread = threading.Thread(target=run_api, daemon=True)
        api_thread.start()
        return True
    
    def create_ai_workflow_templates(self):
        """Create common AI workflow templates"""
        templates = {
            "security_audit": {
                "name": "Security Audit Workflow",
                "description": "Comprehensive security assessment using swarm AI",
                "steps": [
                    "1. Input target system/network",
                    "2. Decompose into security domains",
                    "3. Parallel vulnerability assessment",
                    "4. Threat modeling",
                    "5. Generate remediation report"
                ]
            },
            "code_review": {
                "name": "AI-Powered Code Review",
                "description": "Multi-AI code analysis and optimization",
                "steps": [
                    "1. Input codebase",
                    "2. Static analysis (Groq)",
                    "3. Security audit (Local model)",
                    "4. Performance optimization (OpenRouter)",
                    "5. Generate review report"
                ]
            },
            "research_assistant": {
                "name": "Research Assistant",
                "description": "Distributed research and synthesis",
                "steps": [
                    "1. Research topic input",
                    "2. Parallel information gathering",
                    "3. Cross-reference validation",
                    "4. Synthesis and citation",
                    "5. Generate research paper"
                ]
            }
        }
        
        return templates

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="n8n + Swarm Integration")
    parser.add_argument('--install', action='store_true', help='Install n8n')
    parser.add_argument('--start', action='store_true', help='Start n8n and swarm API')
    parser.add_argument('--create-workflow', action='store_true', help='Create swarm workflow')
    parser.add_argument('--n8n-port', type=int, default=5678, help='n8n port')
    parser.add_argument('--swarm-port', type=int, default=8888, help='Swarm API port')
    
    args = parser.parse_args()
    
    integrator = N8nSwarmIntegration(args.n8n_port, args.swarm_port)
    
    if args.install:
        integrator.install_n8n()
    
    if args.start:
        # Start n8n
        if integrator.start_n8n():
            # Start swarm API
            integrator.create_swarm_api_for_n8n()
            
            print("\n✅ System Ready!")
            print(f"📊 n8n Dashboard: http://localhost:{args.n8n_port}")
            print(f"🔧 Swarm API: http://localhost:{args.swarm_port}")
            print("\n💡 Workflow templates available:")
            templates = integrator.create_ai_workflow_templates()
            for key, template in templates.items():
                print(f"  • {template['name']}: {template['description']}")
    
    if args.create_workflow:
        workflow = integrator.create_swarm_workflow()
        integrator.deploy_workflow(workflow)
        
        print("\n📋 Workflow Nodes Created:")
        for node in workflow['nodes']:
            print(f"  • {node['name']} ({node['type'].split('.')[-1]})")

if __name__ == "__main__":
    main()
