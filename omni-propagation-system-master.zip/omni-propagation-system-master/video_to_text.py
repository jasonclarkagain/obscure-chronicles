import subprocess
import os

def extract_video_text(video_path):
    """Extract text from video using multiple methods"""
    
    if not os.path.exists(video_path):
        print(f"❌ Video not found: {video_path}")
        return None
    
    print(f"🎬 Processing: {os.path.basename(video_path)}")
    
    # Method 1: Extract embedded subtitles
    print("📝 Extracting subtitles...")
    subtitle_cmd = f"ffmpeg -i '{video_path}' -map 0:s:0 subtitles.srt 2>/dev/null"
    os.system(subtitle_cmd)
    
    if os.path.exists("subtitles.srt"):
        with open("subtitles.srt", "r") as f:
            subtitles = f.read()
        print(f"   ✅ Found {len(subtitles)} characters of subtitles")
    else:
        subtitles = ""
        print("   ⚠️ No embedded subtitles found")
    
    # Method 2: Extract metadata
    print("📊 Extracting metadata...")
    metadata_cmd = f"ffprobe -v quiet -print_format json -show_format -show_streams '{video_path}'"
    result = subprocess.run(metadata_cmd, shell=True, capture_output=True, text=True)
    
    # Ask AI to analyze what we found
    prompt = f"""Analyze this video file information:
    
    VIDEO: {os.path.basename(video_path)}
    
    METADATA:
    {result.stdout[:1000] if result.returncode == 0 else "No metadata"}
    
    SUBTITLES (if any):
    {subtitles[:1500]}
    
    Provide analysis:
    1. What type of video is this? (duration, format, resolution)
    2. Key information from subtitles/metadata
    3. Recommended next steps for video analysis"""
    
    ai_result = subprocess.run(
        ['ollama', 'run', 'tinyllama', prompt],
        capture_output=True,
        text=True,
        timeout=60
    )
    
    if ai_result.returncode == 0:
        return ai_result.stdout
    else:
        return "AI analysis failed"

# Test with a video from your drive
video_path = "/run/media/unknown/ADATA HD710 PRO/VIDEO/sample.mp4"  # CHANGE THIS
# Or find videos:
print("🔍 Looking for video files...")
find_cmd = "find '/run/media/unknown/ADATA HD710 PRO' -name '*.mp4' -o -name '*.mov' -o -name '*.avi' | head -5"
videos = subprocess.run(find_cmd, shell=True, capture_output=True, text=True).stdout.strip().split('\n')

if videos and videos[0]:
    analysis = extract_video_text(videos[0])
    print("\n" + "="*60)
    print("📹 VIDEO ANALYSIS RESULT:")
    print("="*60)
    print(analysis)
else:
    print("No video files found. Try a specific path.")
