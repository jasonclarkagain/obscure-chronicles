#!/usr/bin/env python3
import requests
import sys
api_key = "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"
question = sys.argv[1] if len(sys.argv) > 1 else "Hello"
r = requests.post("https://api.groq.com/openai/v1/chat/completions",
    headers={"Authorization": f"Bearer {api_key}"},
    json={"model": "mixtral-8x7b-32768",
          "messages": [{"role": "user", "content": question}],
          "max_tokens": 1000})
print(r.json()["choices"][0]["message"]["content"])
