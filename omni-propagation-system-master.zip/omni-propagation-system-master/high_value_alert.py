import os
import time

# Keywords for the First Strike Triage
CRITICAL_TARGETS = ["root", "admin", "id_rsa", "aws_secret", "prod_db"]

def monitor_shards():
    print("[*] [ALERT] High-Value Monitor Active. Watching for First Strike loot...")
    seen_shards = set(os.listdir('./shards'))
    
    while True:
        current_shards = set(os.listdir('./shards'))
        new_shards = current_shards - seen_shards
        
        for shard in new_shards:
            for keyword in CRITICAL_TARGETS:
                if keyword in shard.lower():
                    # This triggers the visual alert on your mobile .onion dashboard
                    with open("alert.signal", "a") as f:
                        f.write(f"CRITICAL LOOT DETECTED: {shard}\n")
                    print(f"[!!!] ALERT: {shard} matches {keyword}")
        
        seen_shards = current_shards
        time.sleep(10)

if __name__ == "__main__":
    monitor_shards()
