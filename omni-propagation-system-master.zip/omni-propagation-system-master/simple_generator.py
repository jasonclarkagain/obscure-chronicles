#!/usr/bin/env python3
import os
import uuid
import platform
from pathlib import Path

class SimpleEngine:
    def __init__(self):
        self.ident = str(uuid.uuid4())
        self.platform = platform.system().lower()
    
    def generate_payload(self):
        return f'''#!/bin/sh
echo "[*] Omni Propagation System"
echo "[*] ID: {self.ident}"
echo "[*] Platform: {self.platform}"

# Simple network scan
echo "[*] Scanning network..."
for i in $(seq 1 5); do
    ping -c 1 -W 1 192.168.1.$i >/dev/null 2>&1 && echo "[+] Host alive: 192.168.1.$i" &
done
wait

echo "[*] Propagation test complete"
'''
    
    def save_payload(self):
        payload = self.generate_payload()
        output_dir = Path('/tmp/simple_payloads')
        output_dir.mkdir(exist_ok=True)
        
        # Save as shell script
        filepath = output_dir / 'simple.sh'
        with open(filepath, 'w') as f:
            f.write(payload)
        
        os.chmod(filepath, 0o755)
        print(f"✅ Generated: {filepath}")
        
        # Also save as Python
        py_file = output_dir / 'simple.py'
        with open(py_file, 'w') as f:
            f.write(f'''print("[*] Omni Propagation - Python")
print("[*] ID: {self.ident}")
print("[*] Platform: {self.platform}")''')
        
        os.chmod(py_file, 0o755)
        print(f"✅ Generated: {py_file}")
        
        return [filepath, py_file]

def main():
    print("🚀 Simple Payload Generator")
    engine = SimpleEngine()
    print(f"[*] Platform: {engine.platform}")
    print(f"[*] ID: {engine.ident}")
    
    files = engine.save_payload()
    print(f"\n📦 Generated {len(files)} files")
    print(f"📁 Location: /tmp/simple_payloads/")
    print("\n🔧 Test with:")
    print("   /tmp/simple_payloads/simple.sh")
    print("   python3 /tmp/simple_payloads/simple.py")

if __name__ == "__main__":
    main()
