import os
import time
import subprocess

# 24-hour silence threshold
SILENCE_THRESHOLD = 86400 
SYNC_FILE = ".last_sync"

def secure_cleanup():
    print("[X] [GHOST] Initiating Secure Decommission...")
    # Targets for forensic wiping
    targets = ["config.json", "node_identity.key", "WAKE_CALL.sig", "shards/"]
    for target in targets:
        full_path = os.path.join(os.getcwd(), target)
        if os.path.exists(full_path):
            subprocess.run(["shred", "-n", "3", "-u", "-r", full_path])
    
    # Wipe shell history and exit
    os.system("history -c && history -w")
    os._exit(0)

def monitor():
    while True:
        if os.path.exists(SYNC_FILE):
            last_sync = os.path.getmtime(SYNC_FILE)
            if (time.time() - last_sync) > SILENCE_THRESHOLD:
                secure_cleanup()
        time.sleep(3600) # Check every hour

if __name__ == "__main__":
    monitor()
