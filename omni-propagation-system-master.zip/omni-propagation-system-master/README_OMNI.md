
## Features
- Network scanning
- System enumeration
- Multi-platform support (Linux, Windows, macOS)
- USB deployment ready
- Radicle decentralized storage

## Warning
For educational and research purposes only.

## Repository Information
- RID: `z3HQrWKN26thtyeF43UdjVcJcbe6`
- URL: https://app.radicle.xyz/nodes/rosa.radicle.xyz/rad:z3HQrWKN26thtyeF43UdjVcJcbe6
- Last Test: $(date)
