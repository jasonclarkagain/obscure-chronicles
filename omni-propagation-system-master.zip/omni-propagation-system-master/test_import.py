import sys
import os

# Try multiple paths
paths_to_try = [
    '/home/unknown/parallelai',
    '/home/unknown/parallelai-swarm',
    os.path.expanduser('~/parallelai'),
    os.path.expanduser('~/parallelai-swarm'),
    os.getcwd()
]

for path in paths_to_try:
    if os.path.exists(path):
        sys.path.insert(0, path)
        try:
            from llmswarm import LLMSwarm
            print(f"✓ Success from: {path}")
            print(f"  File location: {LLMSwarm.__module__}")
            break
        except ImportError as e:
            print(f"✗ Failed from: {path}")
            # Check what's there
            if os.path.exists(os.path.join(path, 'llmswarm')):
                print(f"  Has llmswarm directory")
            py_files = [f for f in os.listdir(path) if f.endswith('.py')]
            if py_files:
                print(f"  Python files: {py_files[:3]}")
