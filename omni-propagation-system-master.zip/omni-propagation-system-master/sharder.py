import os
import base64
from cryptography.fernet import Fernet

def generate_shards(input_file, shard_size=1024):
    print(f"[+] Starting Fragmentation on {input_file}...")
    
    # Generate a unique key for this 'Recirculation' loop
    key = Fernet.generate_key()
    f = Fernet(key)
    
    with open(input_file, 'rb') as source:
        data = source.read()
        
    # Encrypt the entire payload before shredding
    encrypted_data = f.encrypt(data)
    encoded_data = base64.b64encode(encrypted_data)
    
    # Create the 'Ghost' fragments
    os.makedirs('shards', exist_ok=True)
    
    total_shards = (len(encoded_data) // shard_size) + 1
    for i in range(total_shards):
        chunk = encoded_data[i*shard_size : (i+1)*shard_size]
        with open(f"shards/sys_log_part_{i}.shard", 'wb') as shard_file:
            # We wrap the shard in 'Noise' to look like a log entry
            shard_file.write(b"TIMESTAMP: 2025-12-25 | LOG_LEVEL: INFO | DATA: " + chunk)
            
    with open("shards/master.key", "wb") as key_file:
        key_file.write(key)
        
    print(f"[!] Created {total_shards} Fragments. Key secured in master.key.")

if __name__ == "__main__":
    # For testing, we'll create a dummy payload
    with open("payload.bin", "wb") as f:
        f.write(os.urandom(5120)) # 5KB dummy payload
        
    generate_shards("payload.bin")
