#!/usr/bin/env python3
"""
FINAL AI ORCHESTRATOR - Reliable, clean, handles edge cases
"""

import os
import sys
import asyncio
import aiohttp
import json
import subprocess
import time
import re
from datetime import datetime

class FinalAIOrchestrator:
    def __init__(self):
        self.openrouter_key = os.getenv('OPENROUTER_API_KEY')
        self.groq_key = os.getenv('GROQ_API_KEY')
        
    def improve_prompt(self, query: str) -> str:
        """Improve prompts for better responses"""
        query_lower = query.lower()
        
        # Math queries
        if any(pattern in query_lower for pattern in ['+', '-', '*', '/', '=', 'calculate', 'math']):
            if '?' in query:
                return query
            return f"{query}?"
        
        # Very short/simple queries
        if len(query.split()) <= 3 and '?' not in query:
            return f"{query}?"
        
        return query
    
    def create_system_prompt(self, query: str) -> str:
        """Create dynamic system prompt based on query type"""
        query_lower = query.lower()
        
        if any(word in query_lower for word in ['math', 'calculate', '+', '-', '*', '/', '=']):
            return """You are a precise calculator. Provide only the numerical answer or simple factual response."""
        elif len(query.split()) <= 5:
            return """You are a concise assistant. Answer questions directly with minimal words."""
        else:
            return """You are a helpful AI assistant. Provide clear, informative answers without unnecessary formatting."""
    
    async def call_openrouter(self, query: str) -> dict:
        """Call OpenRouter with optimized prompting"""
        if not self.openrouter_key:
            return {"success": False, "error": "No API key"}
        
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.openrouter_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/ai-orchestrator"
        }
        
        improved_query = self.improve_prompt(query)
        
        messages = [
            {"role": "system", "content": self.create_system_prompt(query)},
            {"role": "user", "content": improved_query}
        ]
        
        data = {
            "model": "mistralai/mistral-7b-instruct:free",
            "messages": messages,
            "max_tokens": 300,
            "temperature": 0.3,  # Lower for more consistent answers
            "top_p": 0.9
        }
        
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        answer = result['choices'][0]['message']['content']
                        
                        # Clean and validate
                        answer = self.clean_response(answer)
                        
                        if not answer or len(answer.strip()) < 1:
                            return {"success": False, "error": "Empty response"}
                        
                        return {
                            "success": True,
                            "api": "openrouter",
                            "response": answer,
                            "tokens": result.get('usage', {}).get('total_tokens', 0)
                        }
                    else:
                        return {"success": False, "error": f"HTTP {response.status}"}
        except Exception as e:
            return {"success": False, "error": str(e)[:100]}
    
    async def call_groq(self, query: str) -> dict:
        """Call Groq as backup"""
        if not self.groq_key:
            return {"success": False, "error": "No API key"}
        
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.groq_key}",
            "Content-Type": "application/json"
        }
        
        models = ["llama-3.3-70b-versatile", "gemma2-9b-it"]
        
        for model in models:
            messages = [
                {"role": "system", "content": "Answer questions directly and concisely."},
                {"role": "user", "content": self.improve_prompt(query)}
            ]
            
            data = {
                "model": model,
                "messages": messages,
                "max_tokens": 100,
                "temperature": 0.3
            }
            
            try:
                timeout = aiohttp.ClientTimeout(total=10)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.post(url, headers=headers, json=data) as response:
                        if response.status == 200:
                            result = await response.json()
                            answer = result['choices'][0]['message']['content']
                            answer = self.clean_response(answer)
                            
                            if answer and len(answer.strip()) > 0:
                                return {
                                    "success": True,
                                    "api": "groq",
                                    "model": model,
                                    "response": answer,
                                    "tokens": result.get('usage', {}).get('total_tokens', 0)
                                }
            except:
                continue
        
        return {"success": False, "error": "All Groq models failed"}
    
    def clean_response(self, text: str) -> str:
        """Clean AI responses"""
        if not text:
            return ""
        
        # Remove tags
        text = re.sub(r'<s>|</s>|\[OUT\]|\[/OUT\]|\[/s\]|<\|.*?\|>', '', text)
        
        # Remove "Answer:" prefixes
        text = re.sub(r'^(Answer|Response|A|The answer is)\s*[:.-]\s*', '', text, flags=re.IGNORECASE)
        
        # Clean whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        # Ensure it ends with proper punctuation for statements
        if text and text[-1] not in '.!?' and len(text.split()) > 3:
            text += '.'
        
        return text
    
    async def orchestrate(self, query: str, mode: str = "auto") -> dict:
        """Main orchestration with mode selection"""
        print(f"\n🤖 AI ORCHESTRATOR")
        print("="*60)
        print(f"Query: {query}")
        print(f"Mode: {mode}")
        print("="*60)
        
        start_time = time.time()
        result = None
        
        if mode == "cloud":
            print("\n☁️  Cloud-only mode")
            result = await self.call_openrouter(query)
            if not result["success"]:
                result = await self.call_groq(query)
        
        elif mode == "local":
            print("\n🤖 Local-only mode (placeholder)")
            # For now, just use cloud since local is unreliable
            result = await self.call_openrouter(query)
        
        else:  # auto
            print("\n⚡ Auto mode (OpenRouter → Groq)")
            result = await self.call_openrouter(query)
            if not result["success"]:
                print("  ⚠️  OpenRouter failed, trying Groq...")
                result = await self.call_groq(query)
        
        elapsed = time.time() - start_time
        
        if result and result["success"]:
            return {
                "success": True,
                "query": query,
                "mode": mode,
                "response": result["response"],
                "source": result["api"],
                "model": result.get("model", "mistral-7b-instruct"),
                "tokens": result.get("tokens", 0),
                "time": elapsed,
                "timestamp": datetime.now().isoformat()
            }
        else:
            error_msg = result["error"] if result else "Unknown error"
            return {
                "success": False,
                "query": query,
                "mode": mode,
                "error": error_msg,
                "time": elapsed,
                "timestamp": datetime.now().isoformat()
            }

async def main():
    if len(sys.argv) < 2:
        print("Usage: python ai_orchestrator_final.py \"Your query\"")
        print("       python ai_orchestrator_final.py --mode [auto|cloud|local] \"Query\"")
        sys.exit(1)
    
    # Parse arguments
    mode = "auto"
    query_start = 1
    
    if sys.argv[1] == "--mode" and len(sys.argv) > 3:
        mode = sys.argv[2]
        query_start = 3
    
    query = " ".join(sys.argv[query_start:])
    
    orchestrator = FinalAIOrchestrator()
    result = await orchestrator.orchestrate(query, mode)
    
    print("\n" + "="*60)
    if result["success"]:
        print("✅ SUCCESS")
        print("="*60)
        print(f"Source: {result['source']}")
        print(f"Time: {result['time']:.1f}s")
        
        print("\n🎯 ANSWER:")
        print("="*60)
        print(result['response'])
        print("="*60)
        
        # Save result
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"ai_result_{timestamp}.json"
        with open(filename, "w") as f:
            json.dump(result, f, indent=2)
        print(f"\n💾 Saved to: {filename}")
    else:
        print("❌ FAILED")
        print("="*60)
        print(f"Error: {result['error']}")
        print(f"Mode: {result['mode']}")
        print(f"Time: {result['time']:.1f}s")

if __name__ == "__main__":
    asyncio.run(main())
