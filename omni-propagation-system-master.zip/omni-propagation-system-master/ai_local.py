#!/usr/bin/env python3
"""
LOCAL-FIRST AI ASSISTANT
Uses your local models first, falls back to Groq
"""
import json, urllib.request, sys, subprocess, os

# Configuration
LOCAL_MODELS = [
    "mistral:latest",      # 4.4 GB - Balanced
    "dolphin-mistral:latest", # 4.1 GB - Uncensored
    "tinyllama:latest",    # 637 MB - Fast
    "phi3:mini",          # 2.2 GB - Capable
]

def ask_local(prompt, model="mistral:latest"):
    """Use your local Ollama models"""
    try:
        data = json.dumps({
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.7}
        }).encode()
        
        req = urllib.request.Request(
            "http://localhost:11434/api/generate",
            data=data,
            headers={'Content-Type': 'application/json'}
        )
        
        with urllib.request.urlopen(req, timeout=30) as r:
            result = json.loads(r.read().decode())
            return f"[LOCAL: {model}] {result.get('response', 'No response')}"
    except Exception as e:
        return f"[LOCAL ERROR: {str(e)[:50]}]"

def ask_groq(prompt):
    """Fallback to Groq API"""
    try:
        data = json.dumps({
            "model": "llama-3.3-70b-versatile",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 1000
        }).encode()
        
        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=data,
            headers={
                'Authorization': 'Bearer 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',
                'Content-Type': 'application/json'
            }
        )
        
        with urllib.request.urlopen(req, timeout=20) as r:
            result = json.loads(r.read().decode())
            return f"[GROQ] {result['choices'][0]['message']['content']}"
    except Exception as e:
        return f"[GROQ ERROR: {e}]"

def main():
    if len(sys.argv) > 1:
        prompt = " ".join(sys.argv[1:])
    else:
        prompt = input("Ask: ")
    
    print("\n" + "="*70)
    print("🤖 LOCAL-FIRST AI ASSISTANT")
    print("="*70)
    
    # Try local models first
    print("\n🔍 Trying local models (100% free/unrestricted)...")
    for model in LOCAL_MODELS[:2]:  # Try first 2
        print(f"  Testing {model}...")
        response = ask_local(prompt, model)
        if "ERROR" not in response:
            print(f"✅ Success with {model}")
            print("\n" + "-"*70)
            print(response)
            print("-"*70 + "\n")
            return
    
    # Fallback to Groq
    print("⚠️ Local models unavailable, using Groq API...")
    response = ask_groq(prompt)
    print("\n" + "-"*70)
    print(response)
    print("-"*70)
    print("\n💡 Tip: Ensure Ollama is running: 'ollama serve'")

if __name__ == "__main__":
    main()
