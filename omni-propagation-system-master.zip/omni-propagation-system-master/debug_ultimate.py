#!/usr/bin/env python3
import subprocess
import time

print("Debugging ultimate_orchestrator.py...")

# Test with a simple query
query = "Write a haiku about computers"
print(f"Query: {query}")

try:
    start = time.time()
    result = subprocess.run(
        ["python3", "ultimate_orchestrator.py", "tinyllama", query],
        capture_output=True,
        text=True,
        timeout=60
    )
    elapsed = time.time() - start
    
    print(f"\nTime: {elapsed:.1f}s")
    print(f"Exit code: {result.returncode}")
    
    print("\n=== STDOUT (last 20 lines) ===")
    for line in result.stdout.split('\n')[-20:]:
        print(line)
    
    print("\n=== STDERR ===")
    print(result.stderr[:500])
    
except subprocess.TimeoutExpired:
    print("Timeout after 60 seconds")
except Exception as e:
    print(f"Exception: {e}")
