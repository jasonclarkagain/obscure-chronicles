#!/bin/bash
echo "🔄 COMPLETE REPOSITORY RESET"
echo "============================="

# 1. Scrub keys
./scrub_keys.sh

# 2. Add safety files
cp config_template.py safe_config.py
cp .env.example .env.sample

# 3. Force push
git add -A
git commit -m "SECURITY RESET: Remove all credentials, add safe templates"
git push -f origin main

# 4. Final check
echo ""
echo "✅ Reset complete!"
echo "📊 Check your repository at:"
echo "   https://github.com/jasonclarkagain/omni-propagation-system"
echo ""
echo "🔐 Remember for future:"
echo "   export API_KEY='your_key'  # NOT in code"
echo "   echo '.env' >> .gitignore  # Always"
echo "   Keep repo PRIVATE          # Always"
