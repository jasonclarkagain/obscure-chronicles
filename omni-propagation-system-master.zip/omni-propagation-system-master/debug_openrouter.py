#!/usr/bin/env python3
import os
import requests
import json

print("🔍 DEBUGGING OPENROUTER RESPONSES")
print("="*60)

key = os.getenv('OPENROUTER_API_KEY')
url = "https://openrouter.ai/api/v1/chat/completions"

test_queries = [
    "What is the capital of France?",
    "Say 'Paris'",
    "Answer with just one word: What is the capital of France?"
]

headers = {
    "Authorization": f"Bearer {key}",
    "Content-Type": "application/json",
    "HTTP-Referer": "https://github.com/ai-orchestrator",
    "X-Title": "AI Debugger"
}

for i, query in enumerate(test_queries, 1):
    print(f"\nTest {i}: '{query}'")
    
    # Test different prompting strategies
    prompts = [
        # Strategy 1: Simple
        [{"role": "user", "content": query}],
        
        # Strategy 2: With system prompt
        [
            {"role": "system", "content": "You are a helpful assistant. Provide direct, concise answers."},
            {"role": "user", "content": query}
        ],
        
        # Strategy 3: Explicit instruction
        [
            {"role": "system", "content": "Answer questions directly without any additional formatting or explanation."},
            {"role": "user", "content": query}
        ]
    ]
    
    for j, messages in enumerate(prompts, 1):
        data = {
            "model": "mistralai/mistral-7b-instruct:free",
            "messages": messages,
            "max_tokens": 50,
            "temperature": 0.1  # Low temperature for deterministic responses
        }
        
        try:
            response = requests.post(url, headers=headers, json=data, timeout=10)
            if response.status_code == 200:
                result = response.json()
                answer = result['choices'][0]['message']['content']
                print(f"  Strategy {j}: '{answer}' (len={len(answer)})")
            else:
                print(f"  Strategy {j}: Error {response.status_code}")
        except Exception as e:
            print(f"  Strategy {j}: Exception - {str(e)[:50]}")
