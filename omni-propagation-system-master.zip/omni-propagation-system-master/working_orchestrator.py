#!/usr/bin/env python3
"""
WORKING AI ORCHESTRATOR - Fixed prompting and response handling
"""

import os
import sys
import asyncio
import aiohttp
import json
import subprocess
import time
import re
from datetime import datetime

class WorkingOrchestrator:
    def __init__(self):
        self.openrouter_key = os.getenv('OPENROUTER_API_KEY')
        self.groq_key = os.getenv('GROQ_API_KEY')
        
        # Tested working models
        self.groq_models = [
            "llama-3.3-70b-versatile",  # Primary
            "llama-3.2-90b-vision-preview",  # Backup
            "gemma2-9b-it"  # Fallback
        ]
    
    def create_system_prompt(self) -> str:
        """Create an effective system prompt"""
        return """You are a helpful AI assistant. Follow these rules:
1. Answer questions directly and concisely
2. Do NOT use markdown, XML tags, or special formatting
3. Do NOT add prefixes like "Answer:" or "Response:"
4. Just provide the answer itself
5. For simple questions, give short answers
6. For complex questions, give detailed answers"""
    
    async def call_openrouter(self, query: str) -> dict:
        """Call OpenRouter with optimized prompting"""
        if not self.openrouter_key:
            return {"success": False, "error": "No API key"}
        
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.openrouter_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/working-orchestrator"
        }
        
        messages = [
            {"role": "system", "content": self.create_system_prompt()},
            {"role": "user", "content": query}
        ]
        
        data = {
            "model": "mistralai/mistral-7b-instruct:free",
            "messages": messages,
            "max_tokens": 300,
            "temperature": 0.7,
            "top_p": 0.9
        }
        
        try:
            timeout = aiohttp.ClientTimeout(total=15)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        answer = result['choices'][0]['message']['content']
                        
                        # Clean the response
                        answer = self.clean_response(answer)
                        
                        # Validate it's not empty
                        if not answer or len(answer.strip()) < 2:
                            return {"success": False, "error": "Empty response"}
                        
                        return {
                            "success": True,
                            "api": "openrouter",
                            "response": answer,
                            "tokens": result.get('usage', {}).get('total_tokens', 0)
                        }
                    else:
                        error_text = await response.text()
                        return {"success": False, "error": f"HTTP {response.status}: {error_text[:100]}"}
        except Exception as e:
            return {"success": False, "error": str(e)[:100]}
    
    async def call_groq(self, query: str) -> dict:
        """Call Groq with updated models"""
        if not self.groq_key:
            return {"success": False, "error": "No API key"}
        
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.groq_key}",
            "Content-Type": "application/json"
        }
        
        messages = [
            {"role": "system", "content": self.create_system_prompt()},
            {"role": "user", "content": query}
        ]
        
        for model in self.groq_models:
            data = {
                "model": model,
                "messages": messages,
                "max_tokens": 300,
                "temperature": 0.7
            }
            
            try:
                timeout = aiohttp.ClientTimeout(total=15)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.post(url, headers=headers, json=data) as response:
                        if response.status == 200:
                            result = await response.json()
                            answer = result['choices'][0]['message']['content']
                            answer = self.clean_response(answer)
                            
                            if not answer or len(answer.strip()) < 2:
                                continue  # Try next model if empty
                            
                            return {
                                "success": True,
                                "api": "groq",
                                "model": model,
                                "response": answer,
                                "tokens": result.get('usage', {}).get('total_tokens', 0)
                            }
            except:
                continue  # Try next model on error
        
        return {"success": False, "error": "All Groq models failed"}
    
    def call_local_fast(self, query: str) -> dict:
        """Call local model with timeout and proper parsing"""
        # First, try a quick test to see if local models work
        try:
            # Use a simpler approach - call tinyllama directly
            model_path = os.path.expanduser("~/models/tinyllama.gguf")
            if not os.path.exists(model_path):
                return {"success": False, "error": "Model file not found"}
            
            # Create a simple prompt file
            prompt_file = "/tmp/ai_prompt.txt"
            with open(prompt_file, "w") as f:
                f.write(f"Q: {query}\nA: ")
            
            # Try to use llama.cpp directly if available
            llama_cli = os.path.expanduser("~/llama.cpp/build/bin/llama-cli")
            if os.path.exists(llama_cli):
                try:
                    result = subprocess.run(
                        [llama_cli, "-m", model_path, "-p", f"Q: {query}\nA:", "-n", "50", "-t", "4"],
                        capture_output=True,
                        text=True,
                        timeout=30
                    )
                    
                    if result.returncode == 0:
                        # Extract the answer after "A:"
                        output = result.stdout
                        if "A:" in output:
                            answer = output.split("A:", 1)[1].strip()
                            answer = self.clean_response(answer)
                            return {
                                "success": True,
                                "api": "local",
                                "model": "tinyllama",
                                "response": answer,
                                "tokens": 0
                            }
                except subprocess.TimeoutExpired:
                    return {"success": False, "error": "Local model timeout"}
            
            # Fallback to ultimate_orchestrator with shorter timeout
            try:
                result = subprocess.run(
                    ["python3", "ultimate_orchestrator.py", "tinyllama", query],
                    capture_output=True,
                    text=True,
                    timeout=45  # Much shorter timeout
                )
                
                if result.returncode == 0:
                    # Simple extraction
                    lines = result.stdout.split('\n')
                    for i, line in enumerate(lines):
                        if "FINAL ANSWER" in line or "🎯 FINAL ANSWER" in line:
                            # Get next non-empty line
                            for j in range(i+1, len(lines)):
                                if lines[j].strip() and not lines[j].startswith("==="):
                                    answer = self.clean_response(lines[j].strip())
                                    return {
                                        "success": True,
                                        "api": "local",
                                        "model": "tinyllama",
                                        "response": answer,
                                        "tokens": 0
                                    }
            except subprocess.TimeoutExpired:
                return {"success": False, "error": "Local model timeout (45s)"}
            
            return {"success": False, "error": "Could not extract answer"}
            
        except Exception as e:
            return {"success": False, "error": str(e)[:100]}
    
    def clean_response(self, text: str) -> str:
        """Clean and validate AI responses"""
        if not text:
            return ""
        
        # Remove common tags
        text = re.sub(r'<s>|</s>|\[OUT\]|\[/OUT\]|\[/s\]|<\|.*?\|>', '', text)
        
        # Remove "Answer:" or similar prefixes
        text = re.sub(r'^(Answer|Response|A)\s*[:.-]\s*', '', text, flags=re.IGNORECASE)
        
        # Clean whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    async def orchestrate(self, query: str) -> dict:
        """Simple, reliable orchestration"""
        print(f"\n🤖 WORKING ORCHESTRATOR")
        print("="*60)
        print(f"Query: {query}")
        print("="*60)
        
        start_time = time.time()
        
        # Strategy: Try OpenRouter first, then Groq, then local
        print("\n1. Trying OpenRouter...")
        result = await self.call_openrouter(query)
        
        if result["success"]:
            print(f"   ✅ OpenRouter: Success")
            source = "openrouter"
        else:
            print(f"   ❌ OpenRouter: {result['error']}")
            
            print("\n2. Trying Groq...")
            result = await self.call_groq(query)
            
            if result["success"]:
                print(f"   ✅ Groq: Success ({result.get('model', '')})")
                source = "groq"
            else:
                print(f"   ❌ Groq: {result['error']}")
                
                print("\n3. Trying local model...")
                result = self.call_local_fast(query)
                
                if result["success"]:
                    print(f"   ✅ Local: Success ({result.get('model', '')})")
                    source = "local"
                else:
                    print(f"   ❌ Local: {result['error']}")
        
        elapsed = time.time() - start_time
        
        if result["success"]:
            return {
                "success": True,
                "query": query,
                "response": result["response"],
                "source": source,
                "model": result.get("model", ""),
                "tokens": result.get("tokens", 0),
                "time": elapsed,
                "timestamp": datetime.now().isoformat()
            }
        else:
            return {
                "success": False,
                "query": query,
                "error": "All methods failed",
                "time": elapsed,
                "timestamp": datetime.now().isoformat()
            }

async def main():
    if len(sys.argv) < 2:
        print("Usage: python working_orchestrator.py \"Your query\"")
        sys.exit(1)
    
    query = " ".join(sys.argv[1:])
    
    orchestrator = WorkingOrchestrator()
    result = await orchestrator.orchestrate(query)
    
    print("\n" + "="*60)
    if result["success"]:
        print("✅ SUCCESS")
        print("="*60)
        print(f"Source: {result['source']}")
        if result.get('model'):
            print(f"Model: {result['model']}")
        print(f"Time: {result['time']:.1f}s")
        
        print("\n🎯 ANSWER:")
        print("="*60)
        print(result['response'])
        print("="*60)
        
        # Save result
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"working_result_{timestamp}.json"
        with open(filename, "w") as f:
            json.dump(result, f, indent=2)
        print(f"\n💾 Saved to: {filename}")
    else:
        print("❌ FAILED")
        print("="*60)
        print(f"Error: {result['error']}")

if __name__ == "__main__":
    asyncio.run(main())
