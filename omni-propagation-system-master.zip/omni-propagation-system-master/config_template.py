#!/usr/bin/env python3
"""
SAFE CONFIGURATION TEMPLATE
Use environment variables, never hardcode credentials!
"""

import os

# SAFE: Get from environment variables
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "YOUR_GOOGLE_API_KEY_HERE")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "YOUR_GROQ_API_KEY_HERE")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "YOUR_OPENROUTER_API_KEY_HERE")

# SAFE: Example function that uses environment variables
def safe_api_call():
    """Example of safe API usage"""
    api_key = os.getenv("MY_API_KEY")
    if not api_key:
        print("⚠️  Set MY_API_KEY environment variable")
        print("   Example: export MY_API_KEY='your_key_here'")
        return None
    
    # Use api_key safely
    print(f"API key length: {len(api_key)}")
    return True

if __name__ == "__main__":
    print("🔐 Safe configuration example")
    print("Never hardcode credentials in source code!")
    safe_api_call()
