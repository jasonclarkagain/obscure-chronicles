#!/usr/bin/env python3
"""WORKING Google Gemini API Example"""

import google.generativeai as genai
import sys

# Configure with your API key
GEMINI_API_KEY = "AIzaSyC9g4B4sY9xeaUntjNmN2MeWFyp5gL3_EM"

# Configure the API
genai.configure(api_key=GEMINI_API_KEY)

# Create the model
model = genai.GenerativeModel('gemini-pro')

def query_gemini(prompt):
    """Query Gemini with proper SDK"""
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Error: {str(e)}"

def main():
    prompt = sys.argv[1] if len(sys.argv) > 1 else "Explain AI in one sentence"
    
    print(f"🔍 Querying Gemini: {prompt}")
    print("="*50)
    
    result = query_gemini(prompt)
    
    print("📝 Response:")
    print(result)
    print("="*50)

if __name__ == "__main__":
    main()
