#!/usr/bin/env python3
"""
SIMPLE AI QUERY - WORKS ON KALI
"""

import urllib.request
import json
import sys

GEMINI_KEY = "AIzaSyC9g4B4sY9xeaUntjNmN2MeWFyp5gL3_EM"

def query_gemini_simple(prompt):
    """Query Gemini using urllib (no external packages needed)"""
    
    # Try different endpoints
    endpoints = [
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent",
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent",
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.0-pro:generateContent"
    ]
    
    for endpoint in endpoints:
        url = f"{endpoint}?key={GEMINI_KEY}"
        
        data = json.dumps({
            "contents": [{
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "maxOutputTokens": 200
            }
        }).encode('utf-8')
        
        try:
            req = urllib.request.Request(
                url,
                data=data,
                headers={'Content-Type': 'application/json'}
            )
            
            with urllib.request.urlopen(req, timeout=10) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                # Extract text
                if 'candidates' in result and result['candidates']:
                    text = result['candidates'][0]['content']['parts'][0]['text']
                    return f"🤖 Gemini: {text}"
        
        except Exception as e:
            continue
    
    return "❌ Could not connect to Gemini API"

def main():
    if len(sys.argv) > 1:
        question = " ".join(sys.argv[1:])
    else:
        question = input("Ask me anything: ").strip() or "What is AI?"
    
    print(f"\n📝 Your question: {question}")
    print("\n🔄 Getting response...\n")
    
    response = query_gemini_simple(question)
    print(response)
    
    # Also test Groq
    print("\n\n🔄 Trying Groq API...")
    try:
        groq_data = json.dumps({
            "model": "llama3-8b-8192",
            "messages": [{"role": "user", "content": question}],
            "max_tokens": 100
        }).encode('utf-8')
        
        groq_req = urllib.request.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=groq_data,
            headers={
                'Authorization': 'Bearer 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',
                'Content-Type': 'application/json'
            }
        )
        
        with urllib.request.urlopen(groq_req, timeout=10) as response:
            groq_result = json.loads(response.read().decode('utf-8'))
            groq_text = groq_result['choices'][0]['message']['content']
            print(f"⚡ Groq: {groq_text}")
    
    except Exception as e:
        print(f"❌ Groq error: {str(e)[:100]}")

if __name__ == "__main__":
    main()
