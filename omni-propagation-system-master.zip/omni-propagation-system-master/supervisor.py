import subprocess, os, time, sys

class SovereignAgent:
    def __init__(self):
        self.vault = "/dev/shm/.sov_vault"
        self.log_file = "/dev/shm/supervisor.log"
        os.makedirs(self.vault, exist_ok=True)

    def log(self, msg):
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(self.log_file, "a") as f:
            f.write(f"[{timestamp}] {msg}\n")
        print(f"[*] {msg}")

    def execute_and_learn(self, command, context):
        self.log(f"Task: {context}")
        # Use sudo -n (non-interactive) to ensure it fails fast instead of hanging
        cmd_with_flags = f"sudo -n {command}" if "sudo" in command else command
        
        process = subprocess.run(command, shell=True, capture_output=True, text=True)
        
        if process.returncode != 0:
            return self.debug_logic(process.stderr, command)
        
        return True

    def debug_logic(self, error, failed_cmd):
        self.log(f"Self-Correcting Error: {error[:50]}...")
        
        # Scenario A: Tor configuration conflict
        if "rendezvous" in error or "Permission denied" in error:
            fix = "sudo tor --defaults-torrc /dev/null --DataDirectory /dev/shm/.t --ControlPort 9051 --CookieAuthentication 0 --runasdaemon 1"
            return self.execute_and_learn(fix, "Force-starting isolated Tor instance")

        # Scenario B: Ghost processes blocking ports
        if "address already in use" in error.lower():
            self.log("Nuking zombie ports 9051/11438")
            subprocess.run("sudo fuser -k 9051/tcp 11438/tcp", shell=True)
            return self.execute_and_learn(failed_cmd, "Retrying after port clearance")

        return False

    def run_loop(self):
        # Establish infrastructure
        self.execute_and_learn("systemctl stop tor", "Stopping system-level Tor")
        self.execute_and_learn("tor --ControlPort 9051 --runasdaemon 1", "Initializing Tor Control")
        self.execute_and_learn("python3 sovereign_bot.py &", "Deploying Ghost Hunter")

if __name__ == "__main__":
    agent = SovereignAgent()
    while True:
        try:
            agent.run_loop()
        except Exception as e:
            agent.log(f"CRITICAL FAULT: {e}")
        time.sleep(60)
