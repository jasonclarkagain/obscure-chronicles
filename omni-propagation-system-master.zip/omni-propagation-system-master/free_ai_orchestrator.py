#!/usr/bin/env python3
"""
FREE AI ORCHESTRATOR - Local First, Cloud Fallback
"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime

# Check and install requests if needed
try:
    import requests
except ImportError:
    print("Installing requests...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

def check_local_models():
    """Check available local models"""
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=5)
        if response.status_code == 200:
            data = response.json()
            return [model["name"] for model in data.get("models", [])]
    except:
        return []
    return []

def query_local(prompt, model="dolphin-mistral:latest"):
    """Query local Ollama model"""
    try:
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "num_predict": 2000
            }
        }
        response = requests.post(
            "http://localhost:11434/api/generate",
            json=payload,
            timeout=60
        )
        if response.status_code == 200:
            return response.json().get("response", "")
    except Exception as e:
        print(f"Local error: {e}")
    return None

def query_groq(prompt):
    """Query Groq API"""
    try:
        api_key = "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"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "mixtral-8x7b-32768",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 2000,
            "temperature": 0.7
        }
        response = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=30
        )
        if response.status_code == 200:
            data = response.json()
            return data.get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as e:
        print(f"Groq error: {e}")
    return None

def save_response(prompt, response, source):
    """Save response to file"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"ai_response_{timestamp}.txt"
    
    with open(filename, 'w') as f:
        f.write("="*60 + "\n")
        f.write("AI ORCHESTRATOR - UNRESTRICTED RESPONSE\n")
        f.write("="*60 + "\n\n")
        f.write(f"PROMPT:\n{prompt}\n\n")
        f.write(f"SOURCE: {source.upper()}\n")
        f.write("="*60 + "\n")
        f.write("RESPONSE:\n")
        f.write("="*60 + "\n")
        f.write(response + "\n")
        f.write("="*60 + "\n")
    
    return filename

def main():
    """Main function"""
    print("\n" + "="*60)
    print("🤖 UNRESTRICTED AI ORCHESTRATOR")
    print("="*60)
    
    # Check available models
    local_models = check_local_models()
    print(f"\n🔍 Available local models: {len(local_models)}")
    for model in local_models[:5]:  # Show first 5
        print(f"   • {model}")
    
    # Get prompt from command line or input
    if len(sys.argv) > 1:
        prompt = " ".join(sys.argv[1:])
    else:
        print("\n🎯 Enter your question (press Enter for test):")
        prompt = input("> ").strip()
        if not prompt:
            prompt = "Explain why open source AI models are important for freedom of information"
    
    print(f"\n📝 Processing: {prompt[:100]}..." if len(prompt) > 100 else f"\n📝 Processing: {prompt}")
    print("-" * 60)
    
    # Try local first (unrestricted)
    start_time = time.time()
    response = query_local(prompt)
    
    if response:
        source = "local"
        print(f"\n✅ FROM LOCAL MODEL (100% UNRESTRICTED)")
        print("-" * 60)
        print(response)
        print("-" * 60)
    else:
        # Fallback to Groq
        print("\n⚠️  Local model unavailable, using Groq...")
        response = query_groq(prompt)
        if response:
            source = "groq"
            print(f"\n⚠️ FROM GROQ (RESTRICTED - local unavailable)")
            print("-" * 60)
            print(response)
            print("-" * 60)
        else:
            print("\n❌ No AI resources available!")
            return
    
    elapsed = time.time() - start_time
    
    # Save response
    filename = save_response(prompt, response, source)
    
    # Print summary
    print(f"\n📊 SUMMARY:")
    print(f"   Source: {source.upper()}")
    print(f"   Time: {elapsed:.2f} seconds")
    print(f"   Saved to: {filename}")
    print(f"\n💡 Tip: Use 'ollama serve' to ensure local models are always available")
    print("="*60)

if __name__ == "__main__":
    main()
