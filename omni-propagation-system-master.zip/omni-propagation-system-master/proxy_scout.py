import socket
import os

# Common internal proxy ports
PORTS = [3128, 8080, 1080, 8888]

def scan_subnet():
    # Detect local subnet
    cmd = "hostname -I | cut -d' ' -f1 | cut -d. -f1-3"
    subnet = os.popen(cmd).read().strip()
    
    print(f"[*] [SCOUT] Scanning subnet {subnet}.0/24 for new chain links...")
    
    for i in range(1, 255):
        target = f"{subnet}.{i}"
        for port in PORTS:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.01)
                if s.connect_ex((target, port)) == 0:
                    print(f"[+] [SCOUT] Proxy found: {target}:{port}")
                    append_to_chain(target, port)

def append_to_chain(ip, port):
    with open("proxychains.conf", "a") as f:
        f.write(f"socks5 {ip} {port}\n")

if __name__ == "__main__":
    scan_subnet()
