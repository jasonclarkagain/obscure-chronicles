import os, time, subprocess, shutil, socket

# 1. CONSTANTS & PATHS
VAULT = '/dev/shm/.sov_vault'
GHOST = '/dev/shm/.ghost'
TOR_DATA = '/dev/shm/.tor_sov'
BLOBS = f"{VAULT}/blobs"
MANIFEST = f"{VAULT}/manifests/registry.ollama.ai/library/test"

def setup_env():
    print("[*] Cleaning environment and setting up RAM vaults...")
    for d in [BLOBS, MANIFEST, GHOST, TOR_DATA]:
        os.makedirs(d, exist_ok=True)
    os.chmod(TOR_DATA, 0o700)

def force_start_tor():
    print("[*] Nuking system Tor and launching Sovereign Tor...")
    subprocess.run(["sudo", "systemctl", "stop", "tor"], capture_output=True)
    subprocess.run(["sudo", "pkill", "-9", "tor"], capture_output=True)
    # Launch Tor with zero-config and RAM-only data directory
    tor_cmd = [
        "sudo", "tor", "--defaults-torrc", "/dev/null",
        "--DataDirectory", TOR_DATA,
        "--ControlPort", "9051",
        "--CookieAuthentication", "0",
        "--runasdaemon", "1"
    ]
    subprocess.Popen(tor_cmd, stdout=subprocess.DEVNULL)
    
    # Wait for port 9051 to open
    for _ in range(10):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('127.0.0.1', 9051)) == 0:
                print("[+] Tor Controller is LIVE.")
                return True
        time.sleep(1)
    return False

def start_onion():
    try:
        from stem.control import Controller
        with Controller.from_port(port=9051) as ctrl:
            ctrl.authenticate()
            svc = ctrl.create_ephemeral_hidden_service({80: 11438}, await_publication=True)
            print(f"\n[!!!] SOVEREIGNTY ESTABLISHED: {svc.service_id}.onion\n")
            with open(f"{VAULT}/address.txt", "w") as f: f.write(f"{svc.service_id}.onion")
    except Exception as e:
        print(f"[!] Onion setup failed: {e}")

def hunt():
    print("[*] Hunter is active. Monitoring for shards...")
    target_digest = "sha256-" + "0"*64
    with open(f"{MANIFEST}/latest", "w") as f:
        f.write('{"schemaVersion":2,"layers":[{"mediaType":"application/vnd.ollama.image.model","digest":"'+target_digest+'"}]}')

    while True:
        try:
            for f in os.listdir(GHOST):
                f_path = os.path.join(GHOST, f)
                if f.startswith('model') and os.path.getsize(f_path) > 1024**2: # Any size > 1MB for testing
                    dest = f"{BLOBS}/{target_digest}"
                    if not os.path.exists(dest):
                        os.link(f_path, dest)
                        print(f"[!] CAPTURED SHARD: {f_path} -> {dest}")
                        # Launch the local service
                        env = os.environ.copy()
                        env["OLLAMA_HOST"] = "127.0.0.1:11438"
                        env["OLLAMA_MODELS"] = VAULT
                        subprocess.Popen(["/usr/local/bin/ollama", "serve"], env=env)
        except: pass
        time.sleep(0.5)

if __name__ == "__main__":
    setup_env()
    if force_start_tor():
        start_onion()
    hunt()
