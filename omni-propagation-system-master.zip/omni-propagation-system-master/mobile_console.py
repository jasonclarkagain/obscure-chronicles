from flask import Flask, render_template_string
import os

app = Flask(__name__)

HTML_TEMPLATE = """
<html>
<head><title>12TH NAME | MOBILE CMD</title></head>
<body style="background:#000; color:#0f0; font-family:monospace; padding:20px;">
    <h2>[ 12TH NAME OPERATIONAL DASHBOARD ]</h2>
    <hr>
    <h3>Swarm Status: <span style="color:white;">ACTIVE</span></h3>
    <h3>World View (Peers):</h3>
    <pre style="background:#111; padding:10px; color:#0a0;">{{ world_view }}</pre>
    <hr>
    <h3>Latest Loot Shards:</h3>
    <ul>
        {% for loot in loots %}
            <li>{{ loot }}</li>
        {% endfor %}
    </ul>
</body>
</html>
"""

@app.route('/')
def dashboard():
    loots = os.listdir('./shards')[:10]
    # Dynamically pull the routing table for the World View
    world_view = os.popen('./rad node routing').read()
    if not world_view:
        world_view = "No external peers synced yet..."
    return render_template_string(HTML_TEMPLATE, loots=loots, world_view=world_view)

if __name__ == "__main__":
    app.run(port=8080)
