#!/usr/bin/env python3
"""
PRODUCTION SWARM ORCHESTRATOR v3.0
Uses real Google Gemini and Hugging Face APIs
"""

import os
import sys
import json
import re
import asyncio
import aiohttp
from datetime import datetime

# ========== API CONFIGURATION ==========
API_KEYS = {
    "google": os.getenv("GOOGLE_API_KEY", "AIzaSyC9g4B4sY9xeaUntjNmN2MeWFyp5gL3_EM"),
    "huggingface": os.getenv("HUGGINGFACE_TOKEN", "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"),
    "openrouter": os.getenv("OPENROUTER_API_KEY", ANTHROPIC_API_KEY_PLACEHOLDER),
    "groq": os.getenv("GROQ_API_KEY", "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")
}

class PrivacyLayer:
    """Mask sensitive information before sending to cloud"""
    
    def mask_pii(self, text):
        """Replace sensitive data with tokens"""
        # Email masking
        text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', 
                     '[EMAIL_MASKED]', text)
        # IP masking
        text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', 
                     '[IP_MASKED]', text)
        # Phone masking
        text = re.sub(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', 
                     '[PHONE_MASKED]', text)
        # Custom tokens (like API keys)
        text = re.sub(r'AIzaSy[A-Za-z0-9_\-]{35}', '[API_KEY_MASKED]', text)
        text = re.sub(r'sk-or-v1-[A-Za-z0-9]{64}', '[API_KEY_MASKED]', text)
        text = re.sub(r'gsk_[A-Za-z0-9]{64}', '[API_KEY_MASKED]', text)
        text = re.sub(r'hf_[A-Za-z0-9]{34}', '[API_KEY_MASKED]', text)
        
        return text

class CloudAPIs:
    """Actual API implementations"""
    
    async def query_gemini(self, prompt):
        """Google Gemini API - 60 RPM, 1M tokens/month FREE"""
        api_key = API_KEYS["google"]
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={api_key}"
        
        payload = {
            "contents": [{
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "maxOutputTokens": 1000,
                "temperature": 0.7
            }
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "No response")
                    else:
                        return f"[Gemini Error: {response.status}]"
        except Exception as e:
            return f"[Gemini Error: {str(e)}]"
    
    async def query_huggingface(self, prompt):
        """Hugging Face Inference API - 30K tokens/month FREE"""
        api_key = API_KEYS["huggingface"]
        url = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2"
        headers = {"Authorization": f"Bearer {api_key}"}
        
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": 500,
                "temperature": 0.7,
                "return_full_text": False
            }
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()
                        if isinstance(data, list) and len(data) > 0:
                            return data[0].get("generated_text", "No response")
                        return str(data)
                    else:
                        return f"[HF Error: {response.status}]"
        except Exception as e:
            return f"[HF Error: {str(e)}]"
    
    async def query_openrouter(self, prompt):
        """OpenRouter API - Check free tier"""
        api_key = API_KEYS["openrouter"]
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "HTTP-Referer": "http://localhost:3000",
            "X-Title": "Swarm Orchestrator"
        }
        
        payload = {
            "model": "mistralai/mistral-7b-instruct:free",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 500
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("choices", [{}])[0].get("message", {}).get("content", "No response")
                    else:
                        return f"[OpenRouter Error: {response.status}]"
        except Exception as e:
            return f"[OpenRouter Error: {str(e)}]"
    
    async def query_groq(self, prompt):
        """Groq API - Free tier"""
        api_key = API_KEYS["groq"]
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": "mixtral-8x7b-32768",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 500,
            "temperature": 0.7
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("choices", [{}])[0].get("message", {}).get("content", "No response")
                    else:
                        return f"[Groq Error: {response.status}]"
        except Exception as e:
            return f"[Groq Error: {str(e)}]"

class SwarmOrchestrator:
    """Main orchestrator with real API calls"""
    
    def __init__(self):
        self.privacy = PrivacyLayer()
        self.apis = CloudAPIs()
        print("=" * 60)
        print("🤖 PRODUCTION SWARM ORCHESTRATOR v3.0")
        print("=" * 60)
        print("APIs Available:")
        print(f"  ✓ Google Gemini (60 RPM free)")
        print(f"  ✓ Hugging Face (30K tokens/month)")
        print(f"  ✓ OpenRouter (free models)")
        print(f"  ✓ Groq (free tier)")
        print("=" * 60)
    
    def decompose_task(self, task):
        """Break task into subtasks"""
        subtasks = [
            f"Provide background and context about: {task}",
            f"Explain technical implementation details for: {task}",
            f"List best practices and security considerations for: {task}",
            f"Provide code examples or templates for: {task}"
        ]
        return subtasks[:3]  # Return first 3 subtasks
    
    async def process_in_parallel(self, subtasks):
        """Process all subtasks in parallel"""
        print(f"\n⚡ Processing {len(subtasks)} subtasks in parallel...")
        
        # Create tasks for each API
        tasks = []
        for i, subtask in enumerate(subtasks):
            if i == 0:
                tasks.append(self.apis.query_gemini(subtask))
            elif i == 1:
                tasks.append(self.apis.query_huggingface(subtask))
            elif i == 2:
                tasks.append(self.apis.query_groq(subtask))
        
        # Run all in parallel
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        processed = []
        api_names = ["Google Gemini", "Hugging Face", "Groq"]
        
        for i, (api_name, result) in enumerate(zip(api_names, results)):
            if isinstance(result, Exception):
                processed.append(f"[{api_name}] Error: {str(result)[:100]}")
            else:
                processed.append(f"[{api_name}] {result[:200]}...")
        
        return processed
    
    def synthesize_results(self, task, results):
        """Combine API results"""
        synthesis = f"""
FINAL ANALYSIS FOR: {task}

📊 MULTI-API ANALYSIS RESULTS:
{'-'*50}

1. {results[0] if len(results) > 0 else 'No data'}

2. {results[1] if len(results) > 1 else 'No data'}

3. {results[2] if len(results) > 2 else 'No data'}

🎯 KEY INSIGHTS:
• Combined analysis from {len(results)} AI providers
• Privacy: All sensitive data was masked before processing
• Cost: 100% free using API free tiers
• Speed: Parallel processing completed in seconds

💡 RECOMMENDATIONS:
• Review all perspectives above
• Implement security best practices
• Test in controlled environment first
"""
        return synthesis
    
    async def run(self, user_task):
        """Main orchestration flow"""
        print(f"\n🎯 USER TASK: {user_task}")
        
        # Step 1: Privacy masking
        print("\n🔒 Step 1: Privacy Masking...")
        masked_task = self.privacy.mask_pii(user_task)
        print(f"   Masked: {masked_task}")
        
        # Step 2: Decompose
        print("\n🔍 Step 2: Task Decomposition...")
        subtasks = self.decompose_task(masked_task)
        for i, subtask in enumerate(subtasks, 1):
            print(f"   {i}. {subtask[:80]}...")
        
        # Step 3: Parallel processing
        results = await self.process_in_parallel(subtasks)
        
        # Step 4: Synthesis
        print("\n🧩 Step 4: Synthesizing Results...")
        final_output = self.synthesize_results(user_task, results)
        
        return final_output

async def main():
    # Get task from command line or input
    if len(sys.argv) > 1:
        task = " ".join(sys.argv[1:])
    else:
        print("\nEnter your task (can include sensitive data):")
        print("Example: 'Secure backup script for server 192.168.1.100'")
        task = input("\n> ").strip()
        
        if not task:
            task = "Create a secure data backup system"
    
    # Run orchestrator
    orchestrator = SwarmOrchestrator()
    
    try:
        print("\n" + "="*60)
        print("🔄 PROCESSING WITH REAL APIS...")
        print("="*60)
        
        result = await orchestrator.run(task)
        
        print("\n" + "="*60)
        print("✅ PROCESSING COMPLETE")
        print("="*60)
        print(result)
        
        # Save to file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"swarm_result_{timestamp}.txt"
        with open(filename, 'w') as f:
            f.write(result)
        
        print(f"\n💾 Results saved to: {filename}")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")

if __name__ == "__main__":
    # Install required package if missing
    try:
        import aiohttp
    except ImportError:
        print("Installing aiohttp...")
        import subprocess
        subprocess.run([sys.executable, "-m", "pip", "install", "aiohttp"])
    
    # Run
    asyncio.run(main())
