from swarm import Swarm, Agent
from bridge import trigger_n8n_swarm

client = Swarm()

# Specialized Agent for Research
research_agent = Agent(
    name="Research_Agent",
    instructions="You are a data gatherer. Use 'trigger_n8n_swarm' to find information.",
    functions=[trigger_n8n_swarm],
)

# Entry Agent
triage_agent = Agent(
    name="Triage_Agent",
    instructions="You talk to the user. If they need research, hand off to Research_Agent.",
)

def transfer_to_researcher():
    return research_agent

triage_agent.functions.append(transfer_to_researcher)

# Execution logic
if __name__ == "__main__":
    print("--- Swarm Activated ---")
    user_input = input("User: ")
    response = client.run(
        agent=triage_agent,
        messages=[{"role": "user", "content": user_input}],
    )
    print(f"\nSwarm Response:\n{response.messages[-1]['content']}")
