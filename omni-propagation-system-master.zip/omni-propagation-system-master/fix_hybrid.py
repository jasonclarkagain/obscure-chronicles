#!/usr/bin/env python3
"""
Quick fix for hybrid orchestrator response handling
"""

import json
import re

def clean_response(text: str) -> str:
    """Clean up API response formatting"""
    if not text:
        return "No response generated."
    
    # Remove common formatting tags
    text = re.sub(r'<s>|</s>|\[OUT\]|\[/OUT\]|\[/s\]', '', text)
    
    # Remove multiple spaces and newlines
    text = re.sub(r'\s+', ' ', text).strip()
    
    # If text is very short or just whitespace, return meaningful message
    if len(text) < 10 or text.isspace():
        return "Response was too short or empty. Please try again with a different query."
    
    return text

# Test with your saved files
print("=== CLEANING SAVED RESPONSES ===")

files = [
    "hybrid_result_20251211_082454.json",
    "hybrid_result_20251211_082500.json",
    "cloud_result_20251211_082458.json"
]

for filename in files:
    try:
        with open(filename, 'r') as f:
            data = json.load(f)
        
        print(f"\n📄 {filename}:")
        if 'response' in data:
            original = data['response']
            cleaned = clean_response(original)
            print(f"  Original: {original[:100]}...")
            print(f"  Cleaned:  {cleaned[:100]}...")
            
            # Update the file
            data['response'] = cleaned
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
            print("  ✅ Updated")
    except FileNotFoundError:
        print(f"  ⚠️  File not found: {filename}")
