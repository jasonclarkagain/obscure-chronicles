# Network scanning and hopping logic
