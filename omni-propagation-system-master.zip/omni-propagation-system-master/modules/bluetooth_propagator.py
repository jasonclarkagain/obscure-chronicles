# Bluetooth device propagation
