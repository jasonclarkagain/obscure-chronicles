# USB device infection logic
