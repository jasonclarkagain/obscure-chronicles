#!/usr/bin/env python3
"""Direct REST API for Gemini that WORKS"""

import requests
import json
import sys

API_KEY = "AIzaSyC9g4B4sY9xeaUntjNmN2MeWFyp5gL3_EM"
url = f"https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key={API_KEY}"

def query_gemini(prompt):
    headers = {'Content-Type': 'application/json'}
    
    data = {
        "contents": [{
            "parts": [{"text": prompt}]
        }]
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=10)
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            return result['candidates'][0]['content']['parts'][0]['text']
        else:
            return f"Error {response.status_code}: {response.text[:200]}"
    except Exception as e:
        return f"Exception: {str(e)}"

def main():
    prompt = sys.argv[1] if len(sys.argv) > 1 else "Explain AI in one sentence"
    
    print(f"🔍 Querying: {prompt}")
    print("="*50)
    
    result = query_gemini(prompt)
    
    print("📝 Response:")
    print(result)
    print("="*50)

if __name__ == "__main__":
    main()
