import os
import subprocess
import json
import time

os.chdir("/run/media/unknown/ADATA HD710 PRO/epstein_research")

print(f"📚 PDF ANALYSIS (No External Tools)")
print("="*60)

# Find PDFs
pdfs = []
for root, dirs, files in os.walk("."):
    for file in files:
        if file.lower().endswith('.pdf'):
            pdfs.append(os.path.join(root, file))

print(f"📊 Found {len(pdfs)} PDF files")

if len(pdfs) == 0:
    print("No PDFs found.")
    exit()

# Quick analysis strategy
print(f"\n🎯 Analysis Strategy for {len(pdfs)} PDFs:")
print("1. Sample files from each directory")
print("2. Use file command to identify type")
print("3. Analyze filenames and structure")
print("4. Use AI for investigative insights")

# Analyze directory structure
print(f"\n📁 Directory Structure Analysis:")
directories = {}
for pdf in pdfs[:50]:  # First 50
    dir_path = os.path.dirname(pdf)
    directories[dir_path] = directories.get(dir_path, 0) + 1

print(f"PDFs distributed across {len(directories)} directories")
print("\nTop directories:")
for dir_path, count in sorted(directories.items(), key=lambda x: x[1], reverse=True)[:5]:
    print(f"  {dir_path}: {count} PDFs")

# Sample analysis without pdftotext
print(f"\n🔍 Analyzing Sample PDFs (Filename & Metadata Only)...")

samples_to_analyze = 3
results = []

for i, pdf in enumerate(pdfs[:samples_to_analyze], 1):
    try:
        print(f"\n[{i}] {os.path.basename(pdf)}")
        print(f"   📍 Location: {pdf}")
        
        # Get file info
        size = os.path.getsize(pdf)
        size_kb = size / 1024
        
        # Use file command to get basic info
        file_cmd = f"file -b '{pdf}'"
        file_info = subprocess.run(file_cmd, shell=True, capture_output=True, text=True).stdout.strip()
        
        print(f"   📏 Size: {size_kb:.1f} KB ({size:,} bytes)")
        print(f"   📄 Type: {file_info[:100]}")
        
        # Analyze filename pattern
        filename = os.path.basename(pdf)
        dir_name = os.path.dirname(pdf)
        
        # Ask AI for analysis based on filename/structure
        prompt = f"""INVESTIGATIVE ANALYSIS OF PDF COLLECTION:

PDF FILENAME: {filename}
LOCATION: {pdf}
DIRECTORY STRUCTURE: {dir_name}
FILE SIZE: {size_kb:.1f} KB
FILE TYPE: {file_info}

ADDITIONAL CONTEXT:
- Total collection: {len(pdfs)} PDF files
- Directory pattern: Contains 'DataSet 1', 'VOL00001', 'IMAGES' folders
- Filename pattern: 'EFTA00000983.pdf' (sequential numbering)

ANALYSIS QUESTIONS:
1. What type of documents are these likely to be?
2. What does 'EFTA' prefix suggest? (European Free Trade Association?)
3. Investigative significance of this collection?
4. Best approach to analyze 4,000+ image-based PDFs?
5. Recommended forensic tools/methods?

Provide concise investigative analysis."""
        
        print(f"   🤖 AI Analysis...")
        start = time.time()
        
        ai_result = subprocess.run(
            ['ollama', 'run', 'tinyllama', prompt],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        elapsed = time.time() - start
        
        if ai_result.returncode == 0:
            analysis = ai_result.stdout.strip()
            print(f"   ✅ Analysis ({elapsed:.1f}s):")
            print(f"   {analysis[:200]}...")
            
            results.append({
                'file': pdf,
                'size_kb': size_kb,
                'file_info': file_info,
                'analysis': analysis[:500]
            })
        else:
            print(f"   ❌ AI failed after {elapsed:.1f}s")
            
    except Exception as e:
        print(f"   ⚠️  Error: {str(e)[:50]}")

# Collection-wide analysis
print(f"\n📈 COLLECTION-WIDE ANALYSIS")
print("="*60)

collection_prompt = f"""ANALYZE THIS PDF COLLECTION FOR INVESTIGATIVE PURPOSES:

COLLECTION SIZE: {len(pdfs)} PDF files
LOCATION: /run/media/unknown/ADATA HD710 PRO/epstein_research/

DIRECTORY STRUCTURE:
{chr(10).join([f"- {d}: {c} files" for d, c in sorted(directories.items(), key=lambda x: x[1], reverse=True)[:5]])}

SAMPLE FILES ANALYZED:
{chr(10).join([f"- {r['file']} ({r['size_kb']:.1f} KB): {r['file_info'][:50]}" for r in results[:3]])}

FILENAME PATTERN: EFTA00000983.pdf, EFTA00000984.pdf, etc.
(Sequential numbering, likely scanned documents)

INVESTIGATIVE QUESTIONS:
1. What is the likely origin/purpose of this collection?
2. Why would EFTA (European Free Trade Association) documents be in 'epstein_research'?
3. Best strategy to process 4,000+ potentially image-based PDFs?
4. What forensic tools are essential?
5. Recommended analysis workflow?

Provide strategic investigative analysis."""

print("🤖 Analyzing entire collection...")
ai_result = subprocess.run(
    ['ollama', 'run', 'tinyllama', collection_prompt],
    capture_output=True,
    text=True,
    timeout=45
)

if ai_result.returncode == 0:
    collection_analysis = ai_result.stdout.strip()
    print(f"\n📋 COLLECTION ANALYSIS:")
    print("-"*40)
    print(collection_analysis)
else:
    print("❌ Collection analysis failed")

# Save results
if results:
    report_file = "pdf_analysis_no_tools.json"
    with open(report_file, "w") as f:
        json.dump({
            'total_pdfs': len(pdfs),
            'directories_analyzed': len(directories),
            'samples_analyzed': len(results),
            'directory_distribution': dict(sorted(directories.items(), key=lambda x: x[1], reverse=True)[:10]),
            'sample_results': results,
            'collection_analysis': collection_analysis if 'collection_analysis' in locals() else ""
        }, f, indent=2)
    
    print(f"\n✅ Analysis saved to: {report_file}")
    print(f"📊 Summary: {len(pdfs)} PDFs across {len(directories)} directories")
    
print(f"\n🎯 NEXT STEPS:")
print("1. Install poppler-utils for text extraction: sudo apt --fix-broken install poppler-utils")
print("2. Use OCR if PDFs are image-based: sudo apt install tesseract-ocr")
print("3. Bulk search: pdfgrep -r 'pattern' .")
print("4. Consider sampling strategy for 4,000+ files")
