import httpx
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP for your "Parallel Swarm"
mcp = FastMCP("Parallel_AI_Swarm")

@mcp.tool()
async def search_3tb_archive(query_text: str):
    """Searches the 3.6TB Epstein Research archive for specific keywords."""
    async with httpx.AsyncClient() as client:
        # This hits your live terminal DB
        response = await client.post(
            "http://localhost:6333/collections/epstein_research/points/scroll",
            json={
                "filter": {"must": [{"key": "text", "match": {"value": query_text}}]},
                "limit": 3
            }
        )
        return response.json()

if __name__ == "__main__":
    mcp.run()
