#!/bin/bash
echo "🔒 FINAL SECURITY CHECK"
echo "========================"

echo "[1] Checking for remaining API keys..."
if grep -r -E "(AIzaSy|gsk_|sk-or-v1-|hf_|sk-[a-zA-Z0-9-]{48,})" --include="*.py" --include="*.sh" --include="*.md" . 2>/dev/null | grep -v "PLACEHOLDER" | grep -v "YOUR_"; then
    echo "❌ Found potential API keys!"
    grep -r -E "(AIzaSy|gsk_|sk-or-v1-|hf_|sk-[a-zA-Z0-9-]{48,})" --include="*.py" --include="*.sh" --include="*.md" . 2>/dev/null | grep -v "PLACEHOLDER" | grep -v "YOUR_"
else
    echo "✅ No API keys found"
fi

echo ""
echo "[2] Checking .gitignore..."
if [ -f .gitignore ]; then
    echo "✅ .gitignore exists"
    echo "Protected patterns:"
    grep -E "(\.env|key|token|secret|password|credential)" .gitignore || echo "⚠️  Missing some patterns"
else
    echo "❌ No .gitignore!"
fi

echo ""
echo "[3] Checking repository visibility..."
echo "   Go to: https://github.com/jasonclarkagain/omni-propagation-system/settings"
echo "   Ensure 'Repository visibility' is set to PRIVATE"

echo ""
echo "[4] Quick file scan..."
echo "Files with potential issues:"
find . -type f -name "*.py" -o -name "*.sh" | xargs grep -l "pass\|key\|token\|secret" 2>/dev/null | head -10

echo ""
echo "========================"
echo "📋 SECURITY SUMMARY"
echo "========================"
echo "If everything looks clean:"
echo "1. git push -f origin main"
echo "2. Verify on GitHub"
echo "3. Consider the repository secure"
echo ""
echo "⚠️  Future precautions:"
echo "   - Always use environment variables"
echo "   - Never commit .env files"
echo "   - Regular security audits"
echo "========================"
