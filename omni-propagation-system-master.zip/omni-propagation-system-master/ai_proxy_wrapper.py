from fastapi import FastAPI
import uvicorn
import subprocess
import json

app = FastAPI()

@app.get("/")
def root():
    return {"service": "AI Orchestrator Proxy", "port": 8345}

@app.get("/orchestrate/{prompt}")
def orchestrate(prompt: str):
    # Run your orchestrator with the prompt
    result = subprocess.run(
        ["python3", "ai_orchestrator.py", prompt],
        capture_output=True,
        text=True
    )
    return {"prompt": prompt, "output": result.stdout}

print("🚀 AI Orchestrator Proxy on port 8345")
uvicorn.run(app, host="0.0.0.0", port=8345)
