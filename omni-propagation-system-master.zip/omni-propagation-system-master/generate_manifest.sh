#!/bin/bash
# 12TH NAME - INTEGRITY GENERATOR
MANIFEST="manifest.sha256"

echo "[*] Generating Integrity Manifest for DNA fb5a8a8..."
# Hash all core python and shell scripts
sha256sum *.py *.sh > $MANIFEST

# Sign the manifest with your Radicle Key (Logic check)
# In a full deployment, you'd use: rad auth --id
echo "[+] Manifest created. DNA is now immutable."
