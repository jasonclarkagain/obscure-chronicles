import os
from rich.console import Console
from rich.table import Table
from datetime import datetime

console = Console()
ARCHIVE_DIR = os.path.expanduser("~/missions/archived")

def get_summary():
    table = Table(title="🛡️ AI Factory: Mission History")
    table.add_column("Date/Time", style="cyan", no_wrap=True)
    table.add_column("Mission File", style="magenta")
    table.add_column("Status", justify="center")

    if not os.path.exists(ARCHIVE_DIR):
        console.print("[yellow]No missions archived yet.[/yellow]")
        return

    # List files and sort by modification time (newest first)
    files = [f for f in os.listdir(ARCHIVE_DIR) if f.endswith(('.txt', '.md'))]
    files.sort(key=lambda x: os.path.getmtime(os.path.join(ARCHIVE_DIR, x)), reverse=True)

    for filename in files:
        file_path = os.path.join(ARCHIVE_DIR, filename)
        timestamp = datetime.fromtimestamp(os.path.getmtime(file_path)).strftime('%Y-%m-%d %H:%M')
        
        # We assume archived means "Completed" in this basic setup
        table.add_row(timestamp, filename, "[green]COMPLETED[/green]")

    console.print(table)

if __name__ == "__main__":
    get_summary()
