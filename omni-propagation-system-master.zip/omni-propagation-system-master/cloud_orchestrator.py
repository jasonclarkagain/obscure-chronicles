#!/usr/bin/env python3
"""
CLOUD AI ORCHESTRATOR USING FREE APIS
"""

import os
import sys
import asyncio
import aiohttp
import json
import time
from datetime import datetime

class CloudOrchestrator:
    def __init__(self):
        self.apis = {
            "openrouter": {
                "url": "https://openrouter.ai/api/v1/chat/completions",
                "headers": {"Authorization": f"Bearer {os.getenv('OPENROUTER_API_KEY')}"},
                "model": "mistralai/mistral-7b-instruct:free"
            },
            "groq": {
                "url": "https://api.groq.com/openai/v1/chat/completions",
                "headers": {"Authorization": f"Bearer {os.getenv('GROQ_API_KEY')}"},
                "model": "mixtral-8x7b-32768"
            }
        }
        
    async def call_api(self, api_name: str, prompt: str) -> str:
        """Call a specific API"""
        if api_name not in self.apis:
            return None
            
        config = self.apis[api_name]
        headers = config["headers"].copy()
        headers["Content-Type"] = "application/json"
        
        data = {
            "model": config["model"],
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 300
        }
        
        try:
            timeout = aiohttp.ClientTimeout(total=15)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(config["url"], headers=headers, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        return result["choices"][0]["message"]["content"]
                    else:
                        print(f"   ⚠️  {api_name} error: {response.status}")
                        return None
        except Exception as e:
            print(f"   ⚠️  {api_name} failed: {str(e)[:50]}")
            return None
    
    async def orchestrate(self, query: str) -> dict:
        """Orchestrate across available APIs"""
        print(f"\n🚀 Processing: {query[:60]}...")
        
        results = {}
        tasks = []
        
        # Try both APIs in parallel
        for api_name in self.apis.keys():
            task = self.call_api(api_name, query)
            tasks.append((api_name, task))
        
        for api_name, task in tasks:
            result = await task
            if result:
                results[api_name] = result
                print(f"✅ {api_name.upper()}: Got response")
        
        # Combine results if we got multiple
        if len(results) == 0:
            final = "No cloud APIs responded. Try local fallback."
        elif len(results) == 1:
            final = list(results.values())[0]
        else:
            # Combine the best parts of each
            responses = list(results.values())
            final = f"Combined from {len(responses)} sources:\n\n"
            for i, resp in enumerate(responses, 1):
                final += f"Source {i}: {resp[:200]}...\n\n"
        
        return {
            "query": query,
            "responses": results,
            "final_answer": final,
            "timestamp": datetime.now().isoformat(),
            "apis_used": list(results.keys())
        }

async def main():
    if len(sys.argv) < 2:
        print("Usage: python cloud_orchestrator.py \"Your query here\"")
        sys.exit(1)
    
    query = " ".join(sys.argv[1:])
    
    print("\n" + "="*60)
    print("🌐 CLOUD AI ORCHESTRATOR")
    print("="*60)
    print("Using: OpenRouter (free) + Groq (free)")
    print("="*60)
    
    orchestrator = CloudOrchestrator()
    start_time = time.time()
    result = await orchestrator.orchestrate(query)
    elapsed = time.time() - start_time
    
    print("\n" + "="*60)
    print("✅ COMPLETE")
    print("="*60)
    print(f"Query: {result['query'][:80]}...")
    print(f"Time: {elapsed:.1f}s")
    print(f"APIs used: {', '.join(result['apis_used']) if result['apis_used'] else 'None'}")
    print("\n🎯 ANSWER:")
    print("="*60)
    print(result['final_answer'])
    print("="*60)
    
    # Save result
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"cloud_result_{timestamp}.json"
    with open(filename, "w") as f:
        json.dump(result, f, indent=2)
    print(f"\n💾 Saved to: {filename}")

if __name__ == "__main__":
    asyncio.run(main())
