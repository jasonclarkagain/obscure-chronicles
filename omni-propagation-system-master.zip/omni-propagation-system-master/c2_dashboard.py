import time
import random

def display_c2_header():
    print("\033[92m" + "="*60)
    print("   SOVEREIGN SWARM: THE 12TH NAME - GLOBAL COMMAND CENTER")
    print("="*60 + "\033[0m")

def simulate_agent_traffic():
    agents = ["Shard-Alpha-01", "Shard-Beta-09", "Ghost-Weaver-04", "Lateral-Scout-02"]
    status = ["CLOAKED", "RECIRCULATING", "HEALING", "SCOUTING"]
    
    while True:
        agent = random.choice(agents)
        stat = random.choice(status)
        ip = f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}"
        
        print(f"[{time.strftime('%H:%M:%S')}] [SIGNAL] {agent} @ {ip} | STATUS: {stat}")
        
        if stat == "HEALING":
            print(f"  \033[93m[!] WARNING: Integrity Breach Detected. Self-Healing in Progress...\033[0m")
        
        time.sleep(2)

if __name__ == "__main__":
    display_c2_header()
    try:
        simulate_agent_traffic()
    except KeyboardInterrupt:
        print("\n[!] C2 Offline. Swarm continuing in Autonomous Mode.")
