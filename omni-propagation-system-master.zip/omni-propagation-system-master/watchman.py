import time
import subprocess
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

WATCH_DIR = os.path.expanduser("~/missions")
FACTORY_SCRIPT = os.path.expanduser("~/factory.py")

class MissionHandler(FileSystemEventHandler):
    def on_created(self, event):
        # Now watches for .txt AND .md files
        if not event.is_directory and event.src_path.endswith((".txt", ".md")):
            print(f"📂 Mission Manifest Detected: {event.src_path}")
            
            with open(event.src_path, 'r') as f:
                content = f.read()
                # Pass the content into our factory orchestrator
                process = subprocess.Popen(
                    ['python3', FACTORY_SCRIPT],
                    stdin=subprocess.PIPE,
                    text=True
                )
                process.communicate(input=content)
            
            # Archive the used mission
            archive_dir = os.path.join(WATCH_DIR, "archived")
            if not os.path.exists(archive_dir): os.makedirs(archive_dir)
            os.rename(event.src_path, os.path.join(archive_dir, os.path.basename(event.src_path)))

if __name__ == "__main__":
    if not os.path.exists(WATCH_DIR): os.makedirs(WATCH_DIR)
    event_handler = MissionHandler()
    observer = Observer()
    observer.schedule(event_handler, WATCH_DIR, recursive=False)
    print(f"🕵️ Watchman is active. Waiting for missions in {WATCH_DIR}")
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
