#!/usr/bin/env python3
"""
SIMPLE SWARM - Working Kali Linux Version
No external dependencies needed
"""

import json
import socket
import threading
import time
import hashlib
import sys
import os
import base64
from typing import Dict, List
import urllib.request

class SimpleSwarm:
    def __init__(self, node_id=None):
        self.node_id = node_id or self.generate_id()
        self.peers: Dict[str, Dict] = {}
        self.tasks = []
        self.running = True
        
        print(f"""
╔══════════════════════════════════╗
║   SIMPLE SWARM - Node: {self.node_id[:8]}   ║
╚══════════════════════════════════╝
""")
    
    def generate_id(self) -> str:
        """Generate unique node ID"""
        import uuid
        hostname = socket.gethostname()
        timestamp = str(time.time())
        unique = f"{hostname}_{timestamp}_{uuid.getnode()}"
        return f"node_{hashlib.md5(unique.encode()).hexdigest()[:12]}"
    
    def simple_encrypt(self, text: str, key: str = "swarm") -> str:
        """Simple XOR encryption for demo"""
        encrypted = []
        for i, char in enumerate(text):
            key_char = key[i % len(key)]
            encrypted.append(chr(ord(char) ^ ord(key_char)))
        return base64.b64encode(''.join(encrypted).encode()).decode()
    
    def simple_decrypt(self, encrypted: str, key: str = "swarm") -> str:
        """Simple XOR decryption"""
        try:
            decoded = base64.b64decode(encrypted).decode()
            decrypted = []
            for i, char in enumerate(decoded):
                key_char = key[i % len(key)]
                decrypted.append(chr(ord(char) ^ ord(key_char)))
            return ''.join(decrypted)
        except:
            return encrypted
    
    def discover_peers_local(self) -> List[Dict]:
        """Discover peers on local network"""
        peers = []
        
        # Get local IP range
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            
            # Simple broadcast
            broadcast_ip = '.'.join(local_ip.split('.')[:3]) + '.255'
            
            # Send discovery
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.settimeout(2)
            
            discovery_msg = json.dumps({
                'type': 'discovery',
                'node_id': self.node_id,
                'action': 'ping'
            }).encode()
            
            sock.sendto(discovery_msg, (broadcast_ip, 8888))
            
            # Listen
            start = time.time()
            while time.time() - start < 3:
                try:
                    data, addr = sock.recvfrom(1024)
                    response = json.loads(data.decode())
                    if response.get('type') == 'response':
                        peers.append({
                            'ip': addr[0],
                            'port': response.get('port', 8888),
                            'node_id': response.get('node_id'),
                            'timestamp': time.time()
                        })
                except:
                    continue
                    
            sock.close()
            
        except Exception as e:
            print(f"⚠️ Discovery error: {e}")
        
        return peers
    
    def start_server(self, port=8888):
        """Start UDP server for peer communication"""
        def server_loop():
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.bind(('0.0.0.0', port))
            sock.settimeout(1)
            
            print(f"📡 Listening on port {port}")
            
            while self.running:
                try:
                    data, addr = sock.recvfrom(1024)
                    message = json.loads(data.decode())
                    
                    if message.get('type') == 'discovery':
                        # Respond to discovery
                        response = json.dumps({
                            'type': 'response',
                            'node_id': self.node_id,
                            'port': port,
                            'status': 'active'
                        }).encode()
                        sock.sendto(response, addr)
                        print(f"📡 Discovery request from {addr[0]}")
                    
                    elif message.get('type') == 'message':
                        # Handle encrypted message
                        encrypted = message.get('data', '')
                        decrypted = self.simple_decrypt(encrypted)
                        print(f"📨 Message from {addr[0]}: {decrypted[:50]}...")
                        
                        # Echo back
                        response = json.dumps({
                            'type': 'ack',
                            'node_id': self.node_id
                        }).encode()
                        sock.sendto(response, addr)
                        
                except socket.timeout:
                    continue
                except Exception as e:
                    print(f"⚠️ Server error: {e}")
            
            sock.close()
        
        threading.Thread(target=server_loop, daemon=True).start()
    
    def send_message(self, peer_ip: str, message: str, port=8888):
        """Send message to peer"""
        try:
            encrypted = self.simple_encrypt(message)
            
            data = json.dumps({
                'type': 'message',
                'node_id': self.node_id,
                'data': encrypted,
                'timestamp': time.time()
            }).encode()
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(data, (peer_ip, port))
            sock.close()
            
            print(f"📤 Sent message to {peer_ip}")
            return True
            
        except Exception as e:
            print(f"❌ Send failed: {e}")
            return False
    
    def query_ai(self, prompt: str):
        """Use Groq API for AI tasks"""
        try:
            api_key = "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"
            url = "https://api.groq.com/openai/v1/chat/completions"
            
            data = json.dumps({
                "model": "llama-3.3-70b-versatile",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 500
            }).encode()
            
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                }
            )
            
            with urllib.request.urlopen(req, timeout=10) as response:
                result = json.loads(response.read().decode())
                return result['choices'][0]['message']['content']
                
        except Exception as e:
            return f"AI Error: {str(e)}"
    
    def distribute_task(self, task: str):
        """Distribute task to peers"""
        print(f"🔧 Distributing task: {task[:50]}...")
        
        # First, discover peers
        peers = self.discover_peers_local()
        
        if not peers:
            print("⚠️ No peers found, processing locally")
            result = self.query_ai(task)
            print(f"🤖 Local AI Result: {result[:100]}...")
            return result
        
        # Send to first peer
        peer = peers[0]
        self.send_message(peer['ip'], f"AI_TASK:{task}")
        
        # Also process locally
        local_result = self.query_ai(task)
        
        return f"Distributed to {len(peers)} peers. Local: {local_result[:100]}..."
    
    def start_interactive(self):
        """Start interactive mode"""
        self.start_server()
        
        print("\n💬 Interactive Swarm Mode")
        print("Commands:")
        print("  discover   - Find peers")
        print("  peers      - List known peers")
        print("  send IP    - Send message to IP")
        print("  task PROMPT - Distribute AI task")
        print("  quit       - Exit")
        print("=" * 50)
        
        while self.running:
            try:
                cmd = input("\nswarm> ").strip()
                
                if cmd == "quit":
                    self.running = False
                    print("👋 Goodbye!")
                    break
                    
                elif cmd == "discover":
                    print("🔍 Discovering peers...")
                    peers = self.discover_peers_local()
                    if peers:
                        print(f"📡 Found {len(peers)} peers:")
                        for p in peers:
                            print(f"  • {p['node_id'][:8]} @ {p['ip']}")
                    else:
                        print("❌ No peers found")
                
                elif cmd == "peers":
                    print(f"📊 Known peers: {len(self.peers)}")
                    for peer_id, info in self.peers.items():
                        print(f"  • {peer_id[:8]} @ {info.get('ip', 'unknown')}")
                
                elif cmd.startswith("send "):
                    parts = cmd.split()
                    if len(parts) >= 3:
                        ip = parts[1]
                        message = ' '.join(parts[2:])
                        self.send_message(ip, message)
                    else:
                        print("Usage: send IP MESSAGE")
                
                elif cmd.startswith("task "):
                    task = cmd[5:]
                    result = self.distribute_task(task)
                    print(f"📋 Task Result: {result}")
                
                elif cmd == "help":
                    print("Commands: discover, peers, send IP MSG, task PROMPT, quit")
                
                else:
                    print("❌ Unknown command. Type 'help' for commands.")
                    
            except KeyboardInterrupt:
                print("\n👋 Goodbye!")
                self.running = False
                break
            except Exception as e:
                print(f"❌ Error: {e}")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Simple Swarm for Kali")
    parser.add_argument('--node-id', help='Custom node ID')
    parser.add_argument('--discover', action='store_true', help='Discover peers and exit')
    parser.add_argument('--send', nargs=2, metavar=('IP', 'MESSAGE'), help='Send message to IP')
    parser.add_argument('--task', help='Process AI task')
    
    args = parser.parse_args()
    
    swarm = SimpleSwarm(args.node_id)
    
    if args.discover:
        peers = swarm.discover_peers_local()
        print(f"Found {len(peers)} peers:")
        for p in peers:
            print(f"  {p['ip']} - {p.get('node_id', 'unknown')}")
    
    elif args.send:
        ip, message = args.send
        swarm.send_message(ip, message)
        print(f"Message sent to {ip}")
    
    elif args.task:
        result = swarm.distribute_task(args.task)
        print(f"Task Result: {result}")
    
    else:
        swarm.start_interactive()

if __name__ == "__main__":
    main()
