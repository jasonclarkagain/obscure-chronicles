# Global Configuration for the Swarm's Command & Control
C2_BROKER = "broker.emqx.io"  # In production, use your private mesh IP
C2_PORT = 8883                # Secure TLS Port
C2_TOPIC = "sys/updates/v1/shards"
SWARM_ID = "GHOST_LEADER_001"

# The 'Invisible' Payload Wrapper
def wrap_signal(agent_id, status, data):
    import json
    import time
    return json.dumps({
        "ts": time.time(),
        "id": agent_id,
        "status": status,
        "payload": data
    })
