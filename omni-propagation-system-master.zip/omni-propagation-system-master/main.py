from fastapi import FastAPI, Depends
from src.tools.parallelai import parallelai_tool
from src.auth.server import validate_swarm_key

app = FastAPI(title="ParallelAI Swarm")

@app.post("/research")
async def conduct_swarm_research(
    query: str, 
    key_record = Depends(validate_swarm_key) # Our new API Key Server
):
    # This calls your local ParallelAI platform
    intelligence = await parallelai_tool(query, provider="groq")
    
    return {
        "status": "success",
        "agent_id": "swarm_01",
        "intelligence": intelligence
    }
