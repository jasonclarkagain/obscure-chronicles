#!/usr/bin/env python3
"""
CLEAN AI SYSTEM - No conflicts, no errors
"""
import os
import sys
import json
import subprocess
import time
from datetime import datetime

class CleanAISystem:
    def __init__(self):
        self.model = "dolphin-mistral:latest"  # Your working model
        self.history_file = os.path.expanduser("~/ai_history.json")
        self.responses_dir = os.path.expanduser("~/ai_responses")
        
        # Create directory if needed
        os.makedirs(self.responses_dir, exist_ok=True)
        
        # Load history
        self.history = self.load_history()
    
    def load_history(self):
        """Load previous queries"""
        try:
            with open(self.history_file, 'r') as f:
                return json.load(f)
        except:
            return []
    
    def save_history(self):
        """Save history to file"""
        with open(self.history_file, 'w') as f:
            json.dump(self.history[-50:], f, indent=2)  # Keep last 50
    
    def check_ollama(self):
        """Check if Ollama is working"""
        try:
            result = subprocess.run(["ollama", "list"], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0 and self.model in result.stdout:
                return True, f"✅ Model '{self.model}' available"
            elif result.returncode == 0:
                return True, f"⚠️ Model '{self.model}' not found, using first available"
            else:
                return False, "❌ Ollama not responding"
        except Exception as e:
            return False, f"❌ Error: {str(e)}"
    
    def get_available_models(self):
        """Get list of available models"""
        try:
            result = subprocess.run(["ollama", "list"], 
                                  capture_output=True, text=True, timeout=10)
            models = []
            for line in result.stdout.strip().split('\n')[1:]:
                if line.strip():
                    parts = line.split()
                    if parts:
                        models.append(parts[0])
            return models
        except:
            return []
    
    def query_ai(self, prompt, timeout=60):
        """Query the AI model"""
        try:
            # Prepare the prompt
            safe_prompt = prompt[:4000]  # Limit length
            
            # Build command
            cmd = ["ollama", "run", self.model, safe_prompt]
            
            # Run with timeout
            start_time = time.time()
            result = subprocess.run(cmd, 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=timeout)
            elapsed = time.time() - start_time
            
            if result.returncode == 0:
                return {
                    "success": True,
                    "response": result.stdout.strip(),
                    "error": None,
                    "time": f"{elapsed:.1f}s"
                }
            else:
                return {
                    "success": False,
                    "response": None,
                    "error": result.stderr[:200],
                    "time": f"{elapsed:.1f}s"
                }
                
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "response": None,
                "error": "Timeout - model is processing",
                "time": f">{timeout}s"
            }
        except Exception as e:
            return {
                "success": False,
                "response": None,
                "error": str(e),
                "time": "0s"
            }
    
    def save_response(self, query, response_data):
        """Save response to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Text file
        txt_file = os.path.join(self.responses_dir, f"response_{timestamp}.txt")
        with open(txt_file, 'w') as f:
            f.write(f"QUERY: {query}\n")
            f.write(f"TIME: {datetime.now()}\n")
            f.write(f"MODEL: {self.model}\n")
            f.write(f"STATUS: {'SUCCESS' if response_data['success'] else 'FAILED'}\n")
            f.write(f"RESPONSE TIME: {response_data.get('time', 'N/A')}\n")
            f.write("\n" + "="*60 + "\n\n")
            
            if response_data['success']:
                f.write(response_data['response'])
            else:
                f.write(f"ERROR: {response_data['error']}")
        
        # JSON file
        json_file = os.path.join(self.responses_dir, f"response_{timestamp}.json")
        with open(json_file, 'w') as f:
            json.dump({
                "query": query,
                "model": self.model,
                "timestamp": datetime.now().isoformat(),
                "response_time": response_data.get('time', 'N/A'),
                "success": response_data['success'],
                "response": response_data['response'] if response_data['success'] else None,
                "error": response_data['error'] if not response_data['success'] else None
            }, f, indent=2)
        
        # Update history
        self.history.append({
            "timestamp": datetime.now().isoformat(),
            "query": query,
            "model": self.model,
            "success": response_data['success'],
            "file": txt_file
        })
        self.save_history()
        
        return txt_file, json_file
    
    def run_interactive(self):
        """Run interactive session"""
        print("🚀 CLEAN AI SYSTEM")
        print("=" * 70)
        
        # Check Ollama
        ollama_ok, message = self.check_ollama()
        print(f"Ollama Status: {message}")
        
        if not ollama_ok:
            print("\n⚠️  Starting Ollama service...")
            subprocess.Popen(["ollama", "serve"], 
                           stdout=subprocess.DEVNULL, 
                           stderr=subprocess.DEVNULL)
            time.sleep(5)
            ollama_ok, message = self.check_ollama()
            print(f"New Status: {message}")
        
        # Show available models
        models = self.get_available_models()
        if models:
            print(f"\n📚 Available models: {', '.join(models)}")
            if self.model not in models and models:
                self.model = models[0]
                print(f"⚠️  Switching to: {self.model}")
        else:
            print("\n❌ No models found. Please run: ollama pull dolphin-mistral")
            return
        
        print(f"\n🎯 Using model: {self.model}")
        print("=" * 70)
        
        while True:
            print("\n" + "=" * 70)
            print("Options:")
            print("1. New query")
            print("2. View history")
            print("3. Change model")
            print("4. Exit")
            
            choice = input("\nSelect option (1-4): ").strip()
            
            if choice == "1":
                self.process_query()
            elif choice == "2":
                self.show_history()
            elif choice == "3":
                self.change_model(models)
            elif choice == "4":
                print("\n👋 Goodbye!")
                break
            else:
                print("❌ Invalid choice")
    
    def process_query(self):
        """Process a single query"""
        print("\n" + "=" * 70)
        query = input("Enter your query (or press Enter to cancel): ").strip()
        
        if not query:
            return
        
        print(f"\n🔍 Processing: {query[:80]}...")
        print("-" * 70)
        
        # Get response
        response_data = self.query_ai(query)
        
        # Display results
        if response_data['success']:
            print("\n✅ RESPONSE:")
            print("-" * 70)
            print(response_data['response'])
            print("-" * 70)
            print(f"⏱️  Time: {response_data['time']}")
        else:
            print(f"\n❌ ERROR: {response_data['error']}")
        
        # Save to file
        if response_data['success'] or response_data['error']:
            txt_file, json_file = self.save_response(query, response_data)
            print(f"\n💾 Saved to: {txt_file}")
            print(f"📁 JSON: {json_file}")
    
    def show_history(self):
        """Show query history"""
        if not self.history:
            print("\n📭 No history yet")
            return
        
        print("\n📜 QUERY HISTORY:")
        print("-" * 70)
        
        for i, entry in enumerate(self.history[-10:], 1):  # Show last 10
            date = entry['timestamp'][:19].replace('T', ' ')
            status = "✅" if entry['success'] else "❌"
            query_preview = entry['query'][:50] + ("..." if len(entry['query']) > 50 else "")
            
            print(f"{i}. {date} {status} {query_preview}")
        
        print("\nEnter number to view details, or press Enter to continue:")
        choice = input("> ").strip()
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(self.history):
                entry = self.history[-(idx+1)]  # Reverse index
                print(f"\n📄 Details for entry #{len(self.history)-idx}:")
                print(f"Time: {entry['timestamp']}")
                print(f"Model: {entry.get('model', 'N/A')}")
                print(f"Success: {entry['success']}")
                print(f"Query: {entry['query']}")
                if 'file' in entry and os.path.exists(entry['file']):
                    print(f"File: {entry['file']}")
    
    def change_model(self, available_models):
        """Change the AI model"""
        print("\n🤖 AVAILABLE MODELS:")
        for i, model in enumerate(available_models, 1):
            print(f"{i}. {model}")
        
        choice = input(f"\nSelect model (1-{len(available_models)}) or press Enter to cancel: ").strip()
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(available_models):
                self.model = available_models[idx]
                print(f"✅ Model changed to: {self.model}")
            else:
                print("❌ Invalid selection")
        else:
            print("⚠️  Model not changed")

def main():
    system = CleanAISystem()
    system.run_interactive()

if __name__ == "__main__":
    main()
