#!/usr/bin/env python3
import json, urllib.request, sys

API_KEY = "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"

def ask(prompt):
    url = "https://api.groq.com/openai/v1/chat/completions"
    data = json.dumps({
        "model": "llama-3.3-70b-versatile",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 1000
    }).encode()
    
    req = urllib.request.Request(url, data=data, headers={
        'Authorization': f'Bearer {API_KEY}',
        'Content-Type': 'application/json'
    })
    
    try:
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read().decode())['choices'][0]['message']['content']
    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    question = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else input("Ask: ")
    print("\n" + "="*60)
    print(ask(question))
    print("="*60)
