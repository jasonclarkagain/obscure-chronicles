#!/usr/bin/env python3
"""
FINAL C&C SERVER GENERATOR - With proper error handling
"""
import subprocess
import time
import sys
import threading

class DolphinGenerator:
    def __init__(self):
        self.model = "dolphin-mistral"
        print(f"🤖 Using model: {self.model}")
        self.warm_up()
    
    def warm_up(self):
        """Warm up the model with a simple query"""
        print("🔥 Warming up model (first run may take 30-60 seconds)...")
        try:
            test_cmd = ["timeout", "30", "ollama", "run", self.model, "Hello"]
            result = subprocess.run(test_cmd, capture_output=True, text=True)
            if result.returncode == 0:
                print("✅ Model is ready!")
                return True
            else:
                print("⚠️ Model still loading, continuing anyway...")
                return False
        except Exception as e:
            print(f"⚠️ Warm-up warning: {e}")
            return False
    
    def generate_with_streaming(self, prompt):
        """Generate with streaming output so we can see progress"""
        print("⚡ Generating code... (This may take 2-3 minutes)")
        print("-" * 60)
        
        try:
            # Use tee to see output as it generates
            cmd = ["ollama", "run", self.model, prompt]
            
            # Start the process
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            # Stream output in real-time
            output_lines = []
            start_time = time.time()
            
            # Read output line by line
            while True:
                line = process.stdout.readline()
                if line:
                    print(line.rstrip())
                    output_lines.append(line)
                
                # Check if process is done
                if process.poll() is not None:
                    # Read any remaining output
                    remaining = process.stdout.read()
                    if remaining:
                        print(remaining)
                        output_lines.append(remaining)
                    break
                
                # Check for timeout (5 minutes max)
                if time.time() - start_time > 300:
                    print("⏰ Timeout after 5 minutes, stopping...")
                    process.terminate()
                    return {
                        "success": False,
                        "error": "Generation timeout",
                        "partial_output": "".join(output_lines)
                    }
            
            elapsed = time.time() - start_time
            
            if process.returncode == 0:
                full_output = "".join(output_lines)
                return {
                    "success": True,
                    "output": full_output,
                    "time": elapsed,
                    "lines": len(full_output.split('\n'))
                }
            else:
                error = process.stderr.read()
                return {
                    "success": False,
                    "error": error,
                    "partial_output": "".join(output_lines)
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def generate_cnc_code(self):
        """Generate the C&C server code"""
        prompt = """Generate a Python-based Command and Control (C&C) server with the following features:

# REQUIREMENTS:
1. Multi-platform compatibility (Windows, Linux, macOS)
2. Encrypted communication using AES-256
3. File upload/download capabilities
4. Remote command execution
5. Screenshot capture functionality
6. Persistence mechanisms for each OS
7. Stealth features to avoid detection
8. Multi-client support
9. Error handling and logging
10. Configuration via JSON file

# OUTPUT FORMAT:
Provide COMPLETE, READY-TO-RUN Python code.
Include:
- All necessary imports
- Configuration setup
- Main server class
- Client handler class
- Encryption utilities
- Platform-specific persistence
- Usage instructions
- Example client code

Generate the code now:"""
        
        return self.generate_with_streaming(prompt)

def main():
    print("=" * 70)
    print("🚀 DOLPHIN-MISTRAL C&C SERVER GENERATOR")
    print("=" * 70)
    
    generator = DolphinGenerator()
    
    print("\n🎯 Generating C&C server code...")
    print("   (Press CTRL+C to stop early)")
    print("=" * 70)
    
    result = generator.generate_cnc_code()
    
    print("\n" + "=" * 70)
    print("📊 GENERATION RESULTS")
    print("=" * 70)
    
    if result["success"]:
        output = result["output"]
        
        # Save to file
        timestamp = int(time.time())
        filename = f"cnc_server_dolphin_{timestamp}.py"
        
        with open(filename, "w") as f:
            f.write(f"# GENERATED BY DOLPHIN-MISTRAL C&C GENERATOR\n")
            f.write(f"# Timestamp: {timestamp}\n")
            f.write(f"# Generation time: {result['time']:.1f}s\n")
            f.write("#" * 60 + "\n\n")
            f.write(output)
        
        print(f"✅ SUCCESS! File saved: {filename}")
        print(f"⏱️  Generation time: {result['time']:.1f} seconds")
        print(f"📄 Lines of code: {result['lines']}")
        
        # Show stats
        lines = output.split('\n')
        print(f"📏 Total characters: {len(output)}")
        
        # Check for key components
        components = ["import", "class", "def", "AES", "socket", "encrypt", "persist"]
        found = [c for c in components if c.lower() in output.lower()]
        print(f"🔍 Key components found: {', '.join(found)}")
        
        print("\n📋 Quick preview of first 20 lines:")
        print("-" * 50)
        for i, line in enumerate(lines[:20]):
            print(f"{i+1:3}: {line}")
        if len(lines) > 20:
            print("... [see full file for complete code]")
        print("-" * 50)
        
    else:
        print(f"❌ GENERATION FAILED")
        print(f"Error: {result.get('error', 'Unknown error')}")
        
        if "partial_output" in result and result["partial_output"]:
            partial = result["partial_output"]
            if len(partial) > 100:
                print(f"\n⚠️ Partial output received ({len(partial)} chars):")
                print("-" * 50)
                print(partial[:500] + "..." if len(partial) > 500 else partial)
                print("-" * 50)
                
                # Save partial output
                with open("partial_cnc_output.txt", "w") as f:
                    f.write(partial)
                print("💾 Partial output saved to: partial_cnc_output.txt")
    
    print("=" * 70)
    print("\n💡 NEXT STEPS:")
    print("1. Review the generated code")
    print("2. Test in a safe, controlled environment")
    print("3. Modify as needed for your specific requirements")
    print("4. Always use ethically and legally!")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⏹️ Generation interrupted by user")
        sys.exit(0)
