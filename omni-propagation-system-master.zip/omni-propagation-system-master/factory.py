import os, asyncio, sys
from anthropic import Anthropic
from rich.console import Console

console = Console()

def get_client():
    # Attempt to read from .env file first
    for line in open(".env"):
        if line.startswith("ANTHROPIC_API_KEY="):
            return Anthropic(api_key=line.split("=")[1].strip())
    # Fallback to environment
    return Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", "").strip())

async def execute_mission(mission_text):
    try:
        client = get_client()
        mission_brief = mission_text.split('\n')[0]
        console.print(f"\n[bold cyan]🚀 Mission Brief:[/bold cyan] {mission_brief[:60]}...")

        message = client.messages.create(
            model="claude-3-7-sonnet-20250219",
            max_tokens=4096,
            messages=[{"role": "user", "content": mission_text}]
        )
        
        console.print(f"\n[bold green]✅ Mission Accomplished![/bold green]")
        print(message.content[0].text)
        
    except Exception as e:
        console.print(f"\n[bold red]❌ Connection Error:[/bold red] {e}")

async def main():
    if not sys.stdin.isatty():
        await execute_mission(sys.stdin.read())

if __name__ == "__main__":
    asyncio.run(main())
