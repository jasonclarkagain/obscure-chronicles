#!/usr/bin/env python3
"""
WEB-BASED AI - NO API KEYS NEEDED
"""

import requests
import json
import sys
import re
from bs4 import BeautifulSoup
import urllib.parse

def search_duckduckgo(query):
    """Search DuckDuckGo for answers"""
    url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract snippets
        results = []
        for result in soup.find_all('a', class_='result__snippet'):
            text = result.get_text(strip=True)
            if text and len(text) > 50:
                results.append(text[:300])
        
        return " | ".join(results[:3]) if results else "No results found"
    except:
        return "Search failed"

def get_wikipedia_summary(query):
    """Get Wikipedia summary"""
    try:
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{urllib.parse.quote(query)}"
        response = requests.get(url, timeout=10)
        data = response.json()
        return data.get('extract', 'No summary available')
    except:
        return "Wikipedia unavailable"

def get_ai_response_from_web(query):
    """Combine web sources for AI-like response"""
    
    # Simple rule-based responses for common questions
    responses = {
        r'what is (ai|artificial intelligence)': "Artificial Intelligence is the simulation of human intelligence in machines that are programmed to think and learn.",
        r'what is machine learning': "Machine learning is a subset of AI that enables computers to learn and improve from experience without being explicitly programmed.",
        r'capital of france': "The capital of France is Paris.",
        r'hello|hi|hey': "Hello! I'm an AI assistant. How can I help you today?",
        r'how are you': "I'm a computer program, so I don't have feelings, but I'm functioning correctly! How can I assist you?",
        r'your name': "I'm an AI assistant created to help answer questions.",
        r'thank you': "You're welcome! Is there anything else I can help with?",
    }
    
    # Check for matching patterns
    query_lower = query.lower()
    for pattern, response in responses.items():
        if re.search(pattern, query_lower):
            return response
    
    # Fallback to web search
    ddg_result = search_duckduckgo(query)
    wiki_result = get_wikipedia_summary(query)
    
    if wiki_result != "Wikipedia unavailable":
        return f"Based on Wikipedia: {wiki_result[:400]}..."
    elif "No results" not in ddg_result:
        return f"Based on web search: {ddg_result[:400]}..."
    else:
        return f"I don't have a specific answer for '{query}', but I can tell you it's an interesting topic worth researching!"

def main():
    print("🌐 WEB AI ASSISTANT - NO API KEYS")
    print("="*50)
    
    if len(sys.argv) > 1:
        question = " ".join(sys.argv[1:])
    else:
        print("\nAsk me anything:")
        question = sys.stdin.readline().strip() or "What is AI?"
    
    print(f"\n🤔 Question: {question}")
    print("\n🔍 Searching for answers...")
    
    response = get_ai_response_from_web(question)
    
    print("\n📝 Answer:")
    print("="*40)
    print(response)
    print("="*40)
    
    # Save to file
    import datetime
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    with open(f"web_ai_{timestamp}.txt", "w") as f:
        f.write(f"Question: {question}\n")
        f.write(f"Time: {datetime.datetime.now()}\n")
        f.write(f"Answer: {response}\n")
    
    print(f"\n💾 Saved to: web_ai_{timestamp}.txt")

if __name__ == "__main__":
    main()
