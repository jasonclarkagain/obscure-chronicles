#!/usr/bin/env python3
"""
SIMPLE GROQ AI - 100% WORKING
"""

import json
import urllib.request
import sys

API_KEY = "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"

def query_groq(prompt, model="llama-3.3-70b-versatile"):
    """Simple Groq query that always works"""
    url = "https://api.groq.com/openai/v1/chat/completions"
    
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 500,
        "temperature": 0.7
    }
    
    try:
        data = json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                'Authorization': f'Bearer {API_KEY}',
                'Content-Type': 'application/json'
            }
        )
        
        with urllib.request.urlopen(req, timeout=15) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result['choices'][0]['message']['content']
            
    except Exception as e:
        return f"Error: {str(e)}"

def main():
    print("🤖 GROQ AI ASSISTANT")
    print("="*50)
    
    if len(sys.argv) > 1:
        prompt = " ".join(sys.argv[1:])
    else:
        prompt = input("Your question: ").strip() or "Hello, how are you?"
    
    print(f"\n📝 Question: {prompt}")
    print("\n🔄 Getting response...\n")
    
    response = query_groq(prompt)
    
    print("📝 Response:")
    print("="*50)
    print(response)
    print("="*50)
    
    # Save to file
    import datetime
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    with open(f"ai_{timestamp}.txt", "w") as f:
        f.write(f"Q: {prompt}\n\nA: {response}")

if __name__ == "__main__":
    main()
