#!/usr/bin/env python3
"""
GROQ-ONLY ORCHESTRATOR - 100% WORKING
Uses Groq API with multiple models for intelligent orchestration
"""

import json
import urllib.request
import urllib.error
import asyncio
import sys
import re
from datetime import datetime

# Groq API Configuration
GROQ_API_KEY = "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"

class GroqOrchestrator:
    """Intelligent orchestrator using only Groq API"""
    
    def __init__(self):
        self.models = [
            "llama-3.3-70b-versatile",  # Main model
            "mixtral-8x7b-32768",       # Fast alternative
            "gemma-7b-it",              # Google's model
        ]
        print("=" * 60)
        print("🤖 GROQ AI ORCHESTRATOR")
        print("=" * 60)
        print("Available Models:")
        for model in self.models:
            print(f"  • {model}")
        print("=" * 60)
    
    async def query_groq(self, prompt, model_index=0, max_tokens=400):
        """Query Groq API with specific model"""
        model = self.models[model_index % len(self.models)]
        url = "https://api.groq.com/openai/v1/chat/completions"
        
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.7,
            "top_p": 0.8
        }
        
        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    'Authorization': f'Bearer {GROQ_API_KEY}',
                    'Content-Type': 'application/json'
                }
            )
            
            with urllib.request.urlopen(req, timeout=20) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if 'choices' in result and result['choices']:
                    text = result['choices'][0]['message']['content']
                    return {
                        "success": True,
                        "model": model,
                        "response": text,
                        "tokens": len(text.split())
                    }
                else:
                    return {
                        "success": False,
                        "model": model,
                        "error": result.get('error', {}).get('message', 'Unknown error')
                    }
                    
        except urllib.error.HTTPError as e:
            return {
                "success": False,
                "model": model,
                "error": f"HTTP {e.code}: {e.reason}"
            }
        except Exception as e:
            return {
                "success": False,
                "model": model,
                "error": str(e)[:100]
            }
    
    def create_smart_subtasks(self, task):
        """Create intelligent subtasks based on task type"""
        
        task_lower = task.lower()
        
        # Determine task type
        if any(word in task_lower for word in ['explain', 'what is', 'describe', 'define']):
            return [
                f"Provide a clear, comprehensive explanation of: {task}",
                f"Give practical examples and real-world applications of: {task}",
                f"Explain the key concepts and principles behind: {task}",
                f"Discuss the importance and implications of: {task}"
            ]
        elif any(word in task_lower for word in ['how to', 'create', 'build', 'write', 'make']):
            return [
                f"Provide step-by-step instructions for: {task}",
                f"List best practices, tips, and common pitfalls for: {task}",
                f"Give code examples or templates for: {task}",
                f"Explain tools and resources needed for: {task}"
            ]
        elif any(word in task_lower for word in ['compare', 'difference', 'vs', 'versus']):
            return [
                f"Analyze and compare the key aspects of: {task}",
                f"List advantages and disadvantages of each part in: {task}",
                f"Provide use cases and when to use each option in: {task}",
                f"Give a summary comparison table for: {task}"
            ]
        elif any(word in task_lower for word in ['list', 'top', 'best', 'examples']):
            return [
                f"Provide a comprehensive list for: {task}",
                f"Explain each item in the list for: {task}",
                f"Give context and applications for each item in: {task}",
                f"Provide additional resources for: {task}"
            ]
        else:
            # General analysis
            return [
                f"Analyze and provide insights about: {task}",
                f"Explain the key aspects of: {task}",
                f"Discuss implications and future developments of: {task}",
                f"Provide actionable recommendations for: {task}"
            ]
    
    async def orchestrate(self, user_task):
        """Main orchestration workflow"""
        
        print(f"\n🎯 TASK: {user_task}")
        
        # Step 1: Create intelligent subtasks
        print("\n🔍 Step 1: Intelligent Task Analysis...")
        subtasks = self.create_smart_subtasks(user_task)
        print(f"   Created {len(subtasks)} specialized subtasks:")
        for i, subtask in enumerate(subtasks[:3], 1):  # Show first 3
            print(f"     {i}. {subtask[:70]}...")
        
        # Step 2: Parallel processing with different models
        print(f"\n⚡ Step 2: Parallel Processing ({len(subtasks)} subtasks)...")
        
        # Create tasks for each subtask (using different models)
        tasks = []
        for i, subtask in enumerate(subtasks):
            print(f"   Processing subtask {i+1} with model {self.models[i % len(self.models)]}...")
            tasks.append(self.query_groq(subtask, i))
        
        # Run all tasks in parallel
        results = await asyncio.gather(*tasks)
        
        # Step 3: Process results
        print("\n🧩 Step 3: Synthesizing Results...")
        
        successful = [r for r in results if r["success"]]
        failed = [r for r in results if not r["success"]]
        
        if successful:
            synthesis = self._synthesize_responses(user_task, successful)
        else:
            synthesis = "❌ All API calls failed. Please check your API key and connection."
        
        return {
            "task": user_task,
            "subtasks": subtasks,
            "results": results,
            "synthesis": synthesis,
            "successful": len(successful),
            "failed": len(failed),
            "timestamp": datetime.now().isoformat()
        }
    
    def _synthesize_responses(self, task, results):
        """Synthesize multiple responses into comprehensive answer"""
        
        synthesis = f"# 🎯 ANALYSIS: {task}\n\n"
        
        # Add executive summary
        synthesis += "## 📊 EXECUTIVE SUMMARY\n\n"
        synthesis += f"**Task analyzed by {len(results)} different AI models**\n\n"
        
        models_used = ", ".join(set(r["model"] for r in results))
        synthesis += f"**Models used**: {models_used}\n\n"
        
        total_tokens = sum(r.get("tokens", 0) for r in results)
        synthesis += f"**Total analysis**: ~{total_tokens} tokens\n\n"
        
        # Add detailed responses
        synthesis += "## 📝 DETAILED ANALYSIS\n\n"
        
        for i, result in enumerate(results, 1):
            synthesis += f"### {i}. Analysis from {result['model']}:\n\n"
            synthesis += f"{result['response']}\n\n"
            synthesis += "---\n\n"
        
        # Add key insights
        synthesis += "## 🔍 KEY INSIGHTS\n\n"
        synthesis += "1. **Multi-model analysis provides comprehensive coverage**\n"
        synthesis += "2. **Different models offer unique perspectives**\n"
        synthesis += "3. **Consensus across models indicates reliability**\n"
        synthesis += "4. **Divergent views highlight areas for further research**\n\n"
        
        # Add recommendations
        synthesis += "## 🎯 RECOMMENDATIONS\n\n"
        synthesis += "1. **Review all analyses above for comprehensive understanding**\n"
        synthesis += "2. **Implement consistent advice across multiple models**\n"
        synthesis += "3. **Test any code or procedures in safe environment first**\n"
        synthesis += "4. **Consider model-specific strengths for different aspects**\n\n"
        
        # Add next steps
        synthesis += "## 🚀 NEXT STEPS\n\n"
        synthesis += "- Implement actionable items from above\n"
        synthesis += "- Monitor results and adjust as needed\n"
        synthesis += "- Conduct further research on specific areas of interest\n"
        synthesis += "- Share findings with relevant stakeholders\n"
        
        return synthesis

async def main():
    """Main execution function"""
    
    print("\n🚀 GROQ AI ORCHESTRATOR - WORKING")
    print("="*60)
    
    # Get task from user
    if len(sys.argv) > 1:
        user_task = " ".join(sys.argv[1:])
    else:
        print("\n📝 Enter your question or task:")
        print("Examples:")
        print("  • 'Explain quantum computing'")
        print("  • 'How to secure a Linux server'")
        print("  • 'Write Python code for file encryption'")
        print("  • 'Compare different AI algorithms'")
        print("\nYour task:")
        
        user_task = sys.stdin.readline().strip()
        if not user_task:
            user_task = "Explain artificial intelligence and machine learning"
    
    # Create orchestrator
    orchestrator = GroqOrchestrator()
    
    try:
        print("\n" + "="*60)
        print("🔄 PROCESSING...")
        print("="*60)
        
        # Run orchestration
        result = await orchestrator.orchestrate(user_task)
        
        # Display results
        print("\n" + "="*60)
        print("✅ ORCHESTRATION COMPLETE")
        print("="*60)
        
        print(f"\n📊 Results: {result['successful']} successful, {result['failed']} failed")
        print(result['synthesis'])
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save JSON
        json_file = f"groq_result_{timestamp}.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        
        # Save text
        txt_file = f"groq_result_{timestamp}.txt"
        with open(txt_file, 'w', encoding='utf-8') as f:
            f.write(result['synthesis'])
        
        print(f"\n💾 Results saved to:")
        print(f"   • {json_file} (structured data)")
        print(f"   • {txt_file} (readable report)")
        print("\n" + "="*60)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")

if __name__ == "__main__":
    asyncio.run(main())
