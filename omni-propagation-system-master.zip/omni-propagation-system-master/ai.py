#!/usr/bin/env python3
import json
import urllib.request
import sys

# Your working Groq API key
API_KEY = "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"

def ask_ai(question):
    """Ask the AI a question"""
    url = "https://api.groq.com/openai/v1/chat/completions"
    
    data = json.dumps({
        "model": "llama-3.3-70b-versatile",
        "messages": [{"role": "user", "content": question}],
        "max_tokens": 1000,
        "temperature": 0.7
    }).encode('utf-8')
    
    try:
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                'Authorization': f'Bearer {API_KEY}',
                'Content-Type': 'application/json'
            }
        )
        
        with urllib.request.urlopen(req, timeout=20) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result['choices'][0]['message']['content']
    except Exception as e:
        return f"Error: {str(e)}"

# Main execution
if __name__ == "__main__":
    if len(sys.argv) > 1:
        question = " ".join(sys.argv[1:])
    else:
        # Read from stdin if no arguments
        question = sys.stdin.read().strip()
        if not question:
            question = input("Ask me anything: ")
    
    print("\n🤖 AI Assistant:")
    print("=" * 60)
    response = ask_ai(question)
    print(response)
    print("=" * 60)
