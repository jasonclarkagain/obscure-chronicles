#!/usr/bin/env python3
"""
LOCAL AI WITH PRE-BUILT RESPONSES
Works offline with no APIs
"""

import random
import sys
import datetime

# Knowledge base
KNOWLEDGE = {
    "ai": "Artificial Intelligence is the simulation of human intelligence in machines.",
    "ml": "Machine Learning is a subset of AI where computers learn from data.",
    "python": "Python is a high-level programming language known for its readability.",
    "linux": "Linux is an open-source operating system kernel.",
    "kali": "Kali Linux is a Debian-based distribution for penetration testing.",
    "hacking": "Ethical hacking involves authorized testing of systems for vulnerabilities.",
    "programming": "Programming is the process of writing instructions for computers.",
    "security": "Cybersecurity protects systems, networks, and programs from digital attacks.",
}

def get_local_response(question):
    """Generate a response from local knowledge"""
    question_lower = question.lower()
    
    # Check for keywords
    for keyword, answer in KNOWLEDGE.items():
        if keyword in question_lower:
            return answer
    
    # If no keyword found, generate a generic response
    responses = [
        f"That's an interesting question about '{question}'. Based on general knowledge, this is a topic in computer science.",
        f"I understand you're asking about '{question}'. This is commonly discussed in technology circles.",
        f"The topic '{question}' is complex. It involves various aspects of computing and technology.",
        f"Regarding '{question}', there are multiple perspectives in the field of information technology.",
    ]
    
    return random.choice(responses)

def main():
    print("🤖 LOCAL AI ASSISTANT")
    print("="*50)
    
    if len(sys.argv) > 1:
        question = " ".join(sys.argv[1:])
    else:
        print("\nAsk me anything (I work offline!):")
        question = sys.stdin.readline().strip() or "What is AI?"
    
    print(f"\n📝 Question: {question}")
    print("\n💭 Thinking...")
    
    response = get_local_response(question)
    
    print("\n📝 Answer:")
    print("="*40)
    print(response)
    print("="*40)
    
    # Save conversation
    with open("local_ai_conversation.txt", "a") as f:
        f.write(f"\n[{datetime.datetime.now()}] Q: {question}\n")
        f.write(f"[{datetime.datetime.now()}] A: {response}\n")
        f.write("-"*50 + "\n")
    
    print(f"\n💾 Conversation saved to: local_ai_conversation.txt")
    print("\n💡 Tip: Add more knowledge by editing the KNOWLEDGE dictionary!")

if __name__ == "__main__":
    main()
