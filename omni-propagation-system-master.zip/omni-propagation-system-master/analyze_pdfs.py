import os
import subprocess
import json

# Navigate to research directory
os.chdir("/run/media/unknown/ADATA HD710 PRO/epstein_research")

print(f"📚 PDF DOCUMENT ANALYSIS")
print("="*60)

# Find all PDFs
pdfs = []
for root, dirs, files in os.walk("."):
    for file in files:
        if file.lower().endswith('.pdf'):
            full_path = os.path.join(root, file)
            pdfs.append(full_path)

print(f"Found {len(pdfs)} PDF files")

if len(pdfs) == 0:
    print("No PDFs found. Checking file types...")
    os.system("find . -type f | head -20 | xargs file -b | head -10")
    exit()

# Analyze first 5 PDFs
print(f"\n🔍 Analyzing first 5 PDFs...")

results = []
for i, pdf in enumerate(pdfs[:5], 1):
    try:
        print(f"\n[{i}] {pdf}")
        
        # Get file info
        size = os.path.getsize(pdf)
        print(f"   Size: {size:,} bytes")
        
        # Try to extract text using pdftotext (if installed)
        # First check if we have pdftotext
        has_pdftotext = subprocess.run(["which", "pdftotext"], 
                                     capture_output=True).returncode == 0
        
        extracted_text = ""
        if has_pdftotext:
            print("   Extracting text with pdftotext...")
            temp_txt = f"temp_extract_{i}.txt"
            cmd = f"pdftotext '{pdf}' {temp_txt} 2>/dev/null"
            os.system(cmd)
            
            if os.path.exists(temp_txt):
                with open(temp_txt, 'r', encoding='utf-8', errors='ignore') as f:
                    extracted_text = f.read(2000)
                os.remove(temp_txt)
                print(f"   Extracted {len(extracted_text)} characters")
            else:
                print("   Could not extract text")
        else:
            print("   pdftotext not available. Using file command for info.")
            file_info = subprocess.run(["file", "-b", pdf], 
                                     capture_output=True, text=True).stdout
            print(f"   File type: {file_info[:100]}")
        
        # Ask AI to analyze based on what we have
        if extracted_text:
            prompt = f"""Analyze this PDF document extract:
            
            PDF: {os.path.basename(pdf)}
            SIZE: {size:,} bytes
            DIRECTORY: {os.path.dirname(pdf)}
            
            EXTRACTED TEXT (first 2000 chars):
            {extracted_text}
            
            Provide analysis:
            1. What type of document is this? (legal, financial, report, etc.)
            2. Key topics or subjects mentioned
            3. Any names, dates, locations, or patterns
            4. Recommended next analysis steps"""
        else:
            prompt = f"""Analyze this PDF file:
            
            PDF: {os.path.basename(pdf)}
            SIZE: {size:,} bytes ({size/1024/1024:.1f} MB)
            DIRECTORY: {os.path.dirname(pdf)}
            
            We couldn't extract text content. Based on the filename and location,
            provide investigative analysis:
            1. What might this document contain based on filename/directory?
            2. How should an investigator approach analyzing this PDF?
            3. What tools would be needed for proper analysis?
            4. Recommended forensic approach"""
        
        print("   🤖 Asking AI for analysis...")
        result = subprocess.run(
            ['ollama', 'run', 'tinyllama', prompt],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0:
            analysis = result.stdout.strip()
            print(f"   Analysis: {analysis[:200]}...")
            
            results.append({
                'pdf': pdf,
                'size': size,
                'analysis': analysis[:1000]
            })
        else:
            print(f"   ❌ AI analysis failed")
            
    except Exception as e:
        print(f"   ⚠️  Error: {str(e)[:50]}")

# Save results
if results:
    with open("pdf_analysis_report.json", "w") as f:
        json.dump({
            'total_pdfs': len(pdfs),
            'analyzed': len(results),
            'results': results
        }, f, indent=2)
    
    print(f"\n✅ Analysis complete!")
    print(f"📊 Total PDFs in research directory: {len(pdfs)}")
    print(f"📄 Analyzed: {len(results)} PDFs")
    print(f"💾 Report saved: pdf_analysis_report.json")
    
    # Show summary
    print("\n📈 QUICK SUMMARY:")
    for r in results:
        print(f"  • {r['pdf']} ({r['size']:,} bytes)")
else:
    print("\n❌ Could not analyze any PDFs")

print(f"\n🎯 Next: Install pdftotext for better analysis: sudo apt install poppler-utils")
