#!/usr/bin/env python3
"""
AI ORCHESTRATOR WITH BUILT-IN KEYS
No need to set environment variables externally
"""

import os
import sys

# SET KEYS DIRECTLY IN THE SCRIPT
os.environ['OPENROUTER_API_KEY'] = ANTHROPIC_API_KEY_PLACEHOLDER
os.environ['HUGGINGFACE_TOKEN'] = "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"
os.environ['GROQ_API_KEY'] = "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"

# Now import and run the cloud orchestrator
import subprocess

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python orchestrator_with_keys.py \"Your query here\"")
        sys.exit(1)
    
    query = " ".join(sys.argv[1:])
    
    print("="*60)
    print("🔑 KEYS PRE-LOADED - STARTING ORCHESTRATION")
    print("="*60)
    
    # Run the cloud orchestrator
    result = subprocess.run(
        [sys.executable, "cloud_orchestrator.py", query],
        capture_output=True,
        text=True
    )
    
    print(result.stdout)
    if result.stderr:
        print("Errors:", result.stderr[:200])
