#!/usr/bin/env npx tsx

import fs from "fs";
import path from "path";
import ffmpeg from "fluent-ffmpeg";
import OpenAI from "openai";
import { createCanvas } from "canvas";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

async function generateTestVideo() {
  console.log("🎬 Generating a test video...");
  
  const outputDir = "./test_videos";
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  try {
    // 1. Generate a simple script
    console.log("📝 Generating script with AI...");
    const scriptResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{
        role: "system",
        content: "Create a very short 30-second educational script about the ocean. Include narration only, no characters."
      }],
      max_tokens: 200
    });
    
    const script = scriptResponse.choices[0].message.content || "Welcome to our ocean adventure. The ocean covers 70% of Earth's surface.";
    console.log("✅ Script generated:", script.substring(0, 100) + "...");

    // 2. Generate audio
    console.log("🎙️ Generating audio with TTS...");
    const audioPath = path.join(outputDir, "narration.mp3");
    const mp3Response = await openai.audio.speech.create({
      model: "tts-1",
      voice: "nova",
      input: script
    });
    
    const buffer = Buffer.from(await mp3Response.arrayBuffer());
    fs.writeFileSync(audioPath, buffer);
    console.log("✅ Audio saved to", audioPath);

    // 3. Create a simple image
    console.log("🖼️ Creating test image...");
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext("2d");
    
    // Ocean blue background
    const gradient = ctx.createLinearGradient(0, 0, 0, 1080);
    gradient.addColorStop(0, "#87CEEB");
    gradient.addColorStop(1, "#006994");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1920, 1080);
    
    // Add text
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "bold 72px Arial";
    ctx.textAlign = "center";
    ctx.fillText("Ocean Adventure", 960, 540);
    
    const imagePath = path.join(outputDir, "background.png");
    fs.writeFileSync(imagePath, canvas.toBuffer("image/png"));
    console.log("✅ Image saved to", imagePath);

    // 4. Create video with FFmpeg
    console.log("🎥 Creating video with FFmpeg...");
    const videoPath = path.join(outputDir, `test_video_${Date.now()}.mp4`);
    
    await new Promise((resolve, reject) => {
      ffmpeg()
        .input(imagePath)
        .loop(30) // Loop for 30 seconds
        .input(audioPath)
        .outputOptions([
          "-c:v libx264",
          "-preset fast",
          "-pix_fmt yuv420p",
          "-c:a aac",
          "-shortest"
        ])
        .output(videoPath)
        .on("end", () => {
          console.log("✅ Video created successfully!");
          resolve(true);
        })
        .on("error", (err) => {
          console.error("❌ FFmpeg error:", err);
          reject(err);
        })
        .run();
    });

    console.log(`\n🎉 SUCCESS! Video generated at: ${videoPath}`);
    console.log(`📁 File size: ${(fs.statSync(videoPath).size / 1024 / 1024).toFixed(2)} MB`);
    
    return videoPath;

  } catch (error) {
    console.error("❌ Error generating video:", error);
    throw error;
  }
}

// Run the test
generateTestVideo()
  .then(path => {
    console.log("\n✨ Video generation complete!");
    console.log("📍 Location:", path);
  })
  .catch(error => {
    console.error("\n💥 Failed to generate video:", error.message);
    if (error.message.includes("401")) {
      console.error("⚠️ OpenAI API key may be invalid or expired");
    }
    process.exit(1);
  });