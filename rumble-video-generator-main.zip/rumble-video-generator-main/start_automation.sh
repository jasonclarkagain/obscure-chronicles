#!/bin/bash

echo "🚀 Starting YouTube Automation System"
echo "======================================"

# Set environment variables
export YOUTUBE_REFRESH_TOKEN="1//04qVzyFdnseqYCgYIARAAGAQSNwF-L9IrFUZayIl9FXjpy4fIAjTu2dE0vmhl9hdpw1Ww3Pv7onNtOMElj0rWHAuADrREBoIsL78"
export YOUTUBE_CLIENT_ID="205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com"
export YOUTUBE_CLIENT_SECRET="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"

echo "✅ Environment configured"
echo "📺 YouTube Account: jasonclarkagain@gmail.com"
echo "🎬 30-day educational series ready"
echo ""

echo "Starting Node.js automation server..."
cd /home/runner/workspace
node server/complete-youtube-automation.ts