#!/bin/bash

# Multi-Channel Video Generation System CLI
# Usage: ./multichannel.sh <command> [args...]

npx tsx server/cli.ts "$@"
