import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { google } from 'googleapis';
import OpenAI from 'openai';

const execAsync = promisify(exec);

// Simple video generator that creates a video and uploads to YouTube
async function generateVideo(title: string, duration: number = 15): Promise<string> {
  const outputPath = path.join(process.cwd(), 'output.mp4');
  
  // Create a simple video with text using FFmpeg
  // This creates a video with colored background and text
  const ffmpegCommand = `ffmpeg -f lavfi -i color=c=blue:s=1280x720:d=${duration} -vf "drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${title.replace(/'/g, "\\'")}':fontcolor=white:fontsize=48:x=(w-text_w)/2:y=(h-text_h)/2" -c:v libx264 -t ${duration} -pix_fmt yuv420p -y ${outputPath}`;
  
  console.log('🎬 Generating video...');
  await execAsync(ffmpegCommand);
  console.log('✅ Video generated:', outputPath);
  
  return outputPath;
}

async function uploadToYouTube(videoPath: string, title: string, description: string) {
  // YouTube upload requires OAuth2 credentials
  // User will need to set up YouTube API credentials
  
  const CLIENT_ID = process.env.YOUTUBE_CLIENT_ID;
  const CLIENT_SECRET = process.env.YOUTUBE_CLIENT_SECRET;
  const REFRESH_TOKEN = process.env.YOUTUBE_REFRESH_TOKEN;
  
  if (!CLIENT_ID || !CLIENT_SECRET || !REFRESH_TOKEN) {
    console.error('❌ Missing YouTube credentials. You need to set:');
    console.error('   YOUTUBE_CLIENT_ID');
    console.error('   YOUTUBE_CLIENT_SECRET');
    console.error('   YOUTUBE_REFRESH_TOKEN');
    console.error('\n📚 See: https://developers.google.com/youtube/v3/quickstart/nodejs');
    return null;
  }
  
  const oauth2Client = new google.auth.OAuth2(
    CLIENT_ID,
    CLIENT_SECRET,
    'http://localhost:3000/oauth2callback'
  );
  
  oauth2Client.setCredentials({
    refresh_token: REFRESH_TOKEN
  });
  
  const youtube = google.youtube({
    version: 'v3',
    auth: oauth2Client
  });
  
  console.log('📤 Uploading to YouTube...');
  
  const response = await youtube.videos.insert({
    part: ['snippet', 'status'],
    requestBody: {
      snippet: {
        title,
        description,
        tags: ['AI', 'automated', 'content'],
        categoryId: '22', // People & Blogs
      },
      status: {
        privacyStatus: 'public', // or 'unlisted' for testing
      },
    },
    media: {
      body: fs.createReadStream(videoPath),
    },
  });
  
  const videoId = response.data.id;
  console.log('✅ Video uploaded!');
  console.log(`🔗 https://youtube.com/watch?v=${videoId}`);
  
  return videoId;
}

async function main() {
  console.log('🚀 Starting video generation and upload...\n');
  
  // Generate a simple video
  const title = `AI Generated Video ${new Date().toISOString().split('T')[0]}`;
  const videoPath = await generateVideo(title, 15);
  
  // Upload to YouTube
  const description = 'This is an AI-generated video created automatically.';
  const videoId = await uploadToYouTube(videoPath, title, description);
  
  if (videoId) {
    console.log('\n🎉 SUCCESS! Video is live on YouTube');
  } else {
    console.log('\n⚠️  Video generated but not uploaded (credentials needed)');
    console.log('   Video saved at:', videoPath);
  }
  
  // Clean up
  if (videoId && fs.existsSync(videoPath)) {
    fs.unlinkSync(videoPath);
    console.log('🧹 Cleaned up temporary files');
  }
}

main().catch(console.error);
