#!/bin/bash
cd client && npx vite --host 0.0.0.0 --port 5173