import { google } from 'googleapis';
import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';
import { createCanvas } from 'canvas';
import ffmpeg from 'fluent-ffmpeg';
import cron from 'node-cron';

// Configuration
const REFRESH_TOKEN = "1//04qVzyFdnseqYCgYIARAAGAQSNwF-L9IrFUZayIl9FXjpy4fIAjTu2dE0vmhl9hdpw1Ww3Pv7onNtOMElj0rWHAuADrREBoIsL78";
const CLIENT_ID = "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com";
const CLIENT_SECRET = "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";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface Episode {
  number: number;
  title: string;
  topic: string;
  script: any;
  status: 'pending' | 'generating' | 'uploading' | 'uploaded' | 'failed';
  videoId?: string;
  url?: string;
  uploadTime?: string;
}

export class RealYouTubeAutomation {
  private episodes: Episode[] = [];
  private currentEpisode = 1;
  private outputDir: string;
  private youtube: any;
  private oauth2Client: any;
  private scheduledTask: cron.ScheduledTask | null = null;

  constructor() {
    this.outputDir = path.join(process.cwd(), 'server', 'automation_output');
    this.initializeEpisodes();
    this.ensureDirectories();
    this.setupOAuth();
  }

  private initializeEpisodes() {
    const topics = [
      "The Water Cycle Adventure",
      "Journey Through the Solar System", 
      "Plants and How They Grow",
      "Amazing Animals of the Ocean",
      "Weather Patterns Around the World",
      "Exploring Ocean Depths",
      "Dinosaurs: Giants of the Past",
      "Learning to Count with Fun",
      "Shapes in Our World",
      "Patterns Everywhere",
      "Addition Made Easy",
      "Measuring Everything",
      "Understanding Time",
      "Money and Shopping",
      "The Alphabet Adventure",
      "Storytelling Basics",
      "Reading is Fun",
      "Creative Writing",
      "Languages Around the World",
      "Poetry and Rhymes",
      "Colors and Art",
      "Music and Rhythm",
      "World Cultures",
      "Building and Construction",
      "Dance and Movement",
      "Cooking Together",
      "Nature Art Projects",
      "Being Kind to Others",
      "Problem Solving Skills",
      "Friendship and Community"
    ];

    this.episodes = topics.map((topic, index) => ({
      number: index + 1,
      title: `${topic} - Episode ${index + 1}/30`,
      topic,
      script: null,
      status: 'pending'
    }));
  }

  private async ensureDirectories() {
    const dirs = [this.outputDir, path.join(this.outputDir, 'videos'), path.join(this.outputDir, 'thumbnails')];
    for (const dir of dirs) {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }
  }

  private setupOAuth() {
    this.oauth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, 'urn:ietf:wg:oauth:2.0:oob');
    this.oauth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });
    this.youtube = google.youtube({ version: 'v3', auth: this.oauth2Client });
  }

  async testYouTubeConnection(): Promise<boolean> {
    try {
      const response = await this.youtube.channels.list({
        part: ['snippet'],
        mine: true
      });

      if (response.data.items && response.data.items.length > 0) {
        const channelName = response.data.items[0].snippet.title;
        console.log(`✅ Connected to YouTube channel: ${channelName}`);
        return true;
      } else {
        console.log('❌ No YouTube channel found');
        return false;
      }
    } catch (error) {
      console.error('❌ YouTube connection failed:', error.message);
      return false;
    }
  }

  async generateEpisodeScript(episode: Episode): Promise<any> {
    console.log(`📝 Generating script for Episode ${episode.number}: ${episode.topic}`);

    const prompt = `Create an engaging 5-minute educational video script for children about "${episode.topic}".

    Include:
    - Educational objectives appropriate for ages 5-12
    - 3 main characters: Captain Marina (adventurous leader), Curious Casey (asks great questions), Luna (wise explorer)
    - Interactive elements and questions for young viewers
    - 5-6 scenes with specific visual descriptions
    - Family-friendly G-rated content only
    - Clear educational outcomes

    Format as JSON with: title, description, educational_objectives (array), scenes (array with character, dialog, visual_description, duration)`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content);
  }

  async createVideoFile(episode: Episode): Promise<string> {
    console.log(`🎬 Creating video for Episode ${episode.number}`);

    const videoPath = path.join(this.outputDir, 'videos', `episode_${episode.number}.mp4`);
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');

    // Create scenes from script
    const scenes = episode.script.scenes || [];
    const frameRate = 30;
    const totalFrames = 5 * 60 * frameRate; // 5 minutes at 30fps
    const framesPerScene = Math.floor(totalFrames / scenes.length);

    console.log(`Creating ${scenes.length} scenes with ${framesPerScene} frames each`);

    // Generate frames
    for (let sceneIndex = 0; sceneIndex < scenes.length; sceneIndex++) {
      const scene = scenes[sceneIndex];
      
      for (let frame = 0; frame < framesPerScene; frame++) {
        // Clear canvas
        ctx.fillStyle = '#87CEEB'; // Sky blue background
        ctx.fillRect(0, 0, 1920, 1080);

        // Add scene title
        ctx.fillStyle = '#000000';
        ctx.font = 'bold 48px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(scene.visual_description || `Scene ${sceneIndex + 1}`, 960, 100);

        // Add character dialog
        if (scene.character && scene.dialog) {
          ctx.font = 'bold 36px Arial';
          ctx.fillText(`${scene.character}:`, 960, 200);
          
          ctx.font = '32px Arial';
          ctx.fillStyle = '#333333';
          this.wrapText(ctx, scene.dialog, 960, 300, 1600, 40);
        }

        // Add episode info
        ctx.font = '24px Arial';
        ctx.fillStyle = '#666666';
        ctx.textAlign = 'left';
        ctx.fillText(`Episode ${episode.number}: ${episode.topic}`, 50, 1050);

        // Add progress indicator
        const progress = ((sceneIndex * framesPerScene + frame) / totalFrames) * 100;
        ctx.fillStyle = '#4CAF50';
        ctx.fillRect(50, 1000, (progress / 100) * 300, 20);

        // Save frame
        const frameBuffer = canvas.toBuffer('image/png');
        const frameDir = path.join(this.outputDir, 'frames');
        if (!fs.existsSync(frameDir)) {
          fs.mkdirSync(frameDir, { recursive: true });
        }
        
        const frameNumber = sceneIndex * framesPerScene + frame;
        fs.writeFileSync(path.join(frameDir, `frame_${frameNumber.toString().padStart(6, '0')}.png`), frameBuffer);
      }
    }

    // Create video from frames using FFmpeg
    return new Promise((resolve, reject) => {
      ffmpeg()
        .input(path.join(this.outputDir, 'frames', 'frame_%06d.png'))
        .inputFPS(frameRate)
        .outputOptions([
          '-c:v libx264',
          '-pix_fmt yuv420p',
          '-crf 18',
          '-preset slow'
        ])
        .output(videoPath)
        .on('end', () => {
          console.log(`✅ Video created: ${videoPath}`);
          // Clean up frames
          const frameDir = path.join(this.outputDir, 'frames');
          if (fs.existsSync(frameDir)) {
            fs.rmSync(frameDir, { recursive: true });
          }
          resolve(videoPath);
        })
        .on('error', (err) => {
          console.error('❌ Video creation failed:', err);
          reject(err);
        })
        .run();
    });
  }

  private wrapText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number): void {
    const words = text.split(' ');
    let line = '';
    let currentY = y;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;

      if (testWidth > maxWidth && n > 0) {
        ctx.fillText(line, x, currentY);
        line = words[n] + ' ';
        currentY += lineHeight;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, x, currentY);
  }

  async createThumbnail(episode: Episode): Promise<string> {
    console.log(`🖼️ Creating thumbnail for Episode ${episode.number}`);

    const thumbnailPath = path.join(this.outputDir, 'thumbnails', `episode_${episode.number}_thumbnail.png`);
    const canvas = createCanvas(1280, 720);
    const ctx = canvas.getContext('2d');

    // Gradient background
    const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
    gradient.addColorStop(0, '#FF6B6B');
    gradient.addColorStop(1, '#4ECDC4');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1280, 720);

    // Title
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 64px Arial';
    ctx.textAlign = 'center';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 4;
    ctx.strokeText(episode.topic, 640, 200);
    ctx.fillText(episode.topic, 640, 200);

    // Episode number
    ctx.font = 'bold 48px Arial';
    ctx.fillText(`Episode ${episode.number}`, 640, 300);

    // Series info
    ctx.font = '36px Arial';
    ctx.fillText('Amazing Learning Adventures', 640, 500);

    // Characters
    ctx.font = '32px Arial';
    ctx.fillText('with Captain Marina, Curious Casey & Luna', 640, 600);

    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(thumbnailPath, buffer);

    return thumbnailPath;
  }

  async uploadToYouTube(episode: Episode, videoPath: string, thumbnailPath: string): Promise<any> {
    console.log(`📤 Uploading Episode ${episode.number} to YouTube`);

    const title = `${episode.title} | Amazing Learning Adventures`;
    const description = this.createDescription(episode);
    const tags = [
      'educational', 'children', 'learning', 'kids', 'family friendly',
      'educational videos', 'kids learning', 'science for kids',
      'amazing learning adventures', 'captain marina', 'curious casey', 'luna'
    ];

    try {
      // Upload video
      const videoResponse = await this.youtube.videos.insert({
        part: ['snippet', 'status'],
        requestBody: {
          snippet: {
            title,
            description,
            tags,
            categoryId: '27', // Education category
            defaultLanguage: 'en',
            defaultAudioLanguage: 'en'
          },
          status: {
            privacyStatus: 'public',
            madeForKids: true
          }
        },
        media: {
          body: fs.createReadStream(videoPath)
        }
      });

      const videoId = videoResponse.data.id;
      console.log(`✅ Video uploaded! ID: ${videoId}`);

      // Upload thumbnail
      try {
        await this.youtube.thumbnails.set({
          videoId,
          media: {
            body: fs.createReadStream(thumbnailPath)
          }
        });
        console.log('✅ Thumbnail uploaded!');
      } catch (thumbError) {
        console.warn('⚠️ Thumbnail upload failed:', thumbError.message);
      }

      return {
        videoId,
        url: `https://www.youtube.com/watch?v=${videoId}`,
        title,
        uploadTime: new Date().toISOString()
      };

    } catch (error) {
      console.error('❌ YouTube upload failed:', error.message);
      throw error;
    }
  }

  private createDescription(episode: Episode): string {
    const objectives = episode.script.educational_objectives || [];
    
    return `🎓 Welcome to Amazing Learning Adventures!

Join Captain Marina, Curious Casey, and Luna the Explorer as they discover "${episode.topic}"!

📚 What You'll Learn:
${objectives.map(obj => `• ${obj}`).join('\n')}

👨‍👩‍👧‍👦 Perfect for:
• Ages 5-12
• Family learning time
• Homeschool education
• Curious young minds

🌟 Educational Series (Episode ${episode.number}/30)
This is part of our comprehensive 30-day educational journey covering science, math, language arts, and life skills.

📺 Subscribe for daily educational adventures!
🔔 Ring the bell for notifications!

#Education #KidsLearning #FamilyFriendly #Educational #LearningAdventures #Science #KidsEducation

Created by AI Video Generation System - jasonclarkagain@gmail.com`;
  }

  async processEpisode(episodeNumber: number): Promise<void> {
    const episode = this.episodes[episodeNumber - 1];
    if (!episode) {
      throw new Error(`Episode ${episodeNumber} not found`);
    }

    console.log(`\n🎬 Processing Episode ${episodeNumber}: ${episode.topic}`);
    console.log('=' * 60);

    try {
      episode.status = 'generating';
      
      // Generate script
      episode.script = await this.generateEpisodeScript(episode);
      
      // Create video
      const videoPath = await this.createVideoFile(episode);
      
      // Create thumbnail
      const thumbnailPath = await this.createThumbnail(episode);
      
      episode.status = 'uploading';
      
      // Upload to YouTube
      const uploadResult = await this.uploadToYouTube(episode, videoPath, thumbnailPath);
      
      episode.videoId = uploadResult.videoId;
      episode.url = uploadResult.url;
      episode.uploadTime = uploadResult.uploadTime;
      episode.status = 'uploaded';
      
      console.log(`\n✅ Episode ${episodeNumber} completed successfully!`);
      console.log(`📺 YouTube URL: ${episode.url}`);
      
      // Save progress
      await this.saveProgress();
      
    } catch (error) {
      console.error(`❌ Episode ${episodeNumber} failed:`, error.message);
      episode.status = 'failed';
      await this.saveProgress();
      throw error;
    }
  }

  async saveProgress(): Promise<void> {
    const progressPath = path.join(this.outputDir, 'progress.json');
    const progress = {
      currentEpisode: this.currentEpisode,
      episodes: this.episodes,
      lastUpdate: new Date().toISOString()
    };
    
    fs.writeFileSync(progressPath, JSON.stringify(progress, null, 2));
  }

  async startDailyAutomation(): Promise<void> {
    console.log('🤖 Starting daily automation (9:00 AM UTC)');
    
    // Schedule daily video generation at 9:00 AM UTC
    this.scheduledTask = cron.schedule('0 9 * * *', async () => {
      if (this.currentEpisode <= 30) {
        console.log(`\n⏰ Daily automation triggered - Episode ${this.currentEpisode}`);
        try {
          await this.processEpisode(this.currentEpisode);
          this.currentEpisode++;
        } catch (error) {
          console.error('Daily automation failed:', error.message);
        }
      } else {
        console.log('🎉 All 30 episodes completed! Stopping automation.');
        this.stopAutomation();
      }
    });

    console.log('✅ Daily automation scheduled');
  }

  stopAutomation(): void {
    if (this.scheduledTask) {
      this.scheduledTask.stop();
      this.scheduledTask = null;
      console.log('🛑 Automation stopped');
    }
  }

  getStatus(): any {
    const completed = this.episodes.filter(ep => ep.status === 'uploaded').length;
    const failed = this.episodes.filter(ep => ep.status === 'failed').length;
    const pending = this.episodes.filter(ep => ep.status === 'pending').length;

    return {
      totalEpisodes: 30,
      currentEpisode: this.currentEpisode,
      completed,
      failed,
      pending,
      successRate: completed > 0 ? ((completed / (completed + failed)) * 100).toFixed(1) + '%' : '0%',
      nextEpisode: this.currentEpisode <= 30 ? this.episodes[this.currentEpisode - 1]?.topic : 'Complete',
      isAutomationActive: this.scheduledTask !== null,
      episodes: this.episodes.map(ep => ({
        number: ep.number,
        title: ep.title,
        topic: ep.topic,
        status: ep.status,
        url: ep.url,
        uploadTime: ep.uploadTime
      }))
    };
  }
}

async function main() {
  console.log('🚀 YouTube Automation System Starting');
  console.log('====================================');
  
  const automation = new RealYouTubeAutomation();
  
  // Test YouTube connection
  const connected = await automation.testYouTubeConnection();
  if (!connected) {
    console.error('❌ YouTube connection failed. Please check credentials.');
    process.exit(1);
  }
  
  // Process first episode immediately
  console.log('\n🎬 Generating first episode...');
  try {
    await automation.processEpisode(1);
    console.log('\n🎉 First episode uploaded successfully!');
    
    // Start daily automation for remaining episodes
    await automation.startDailyAutomation();
    
    console.log('\n📊 System Status:');
    console.log(JSON.stringify(automation.getStatus(), null, 2));
    
    console.log('\n✅ YouTube automation is now active!');
    console.log('📺 Videos will be uploaded daily at 9:00 AM UTC');
    console.log('🎓 30-day educational series in progress');
    
    // Keep the process running
    process.on('SIGINT', () => {
      console.log('\n🛑 Shutting down automation...');
      automation.stopAutomation();
      process.exit(0);
    });
    
  } catch (error) {
    console.error('❌ Failed to process first episode:', error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  main().catch(console.error);
}

export { RealYouTubeAutomation };