import OpenAI from "openai";
import { nanoid } from "nanoid";
import { createCanvas, loadImage } from "canvas";
import fs from "fs/promises";
import path from "path";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface ChannelGenerationRequest {
  category: "education" | "entertainment" | "gaming" | "lifestyle" | "technology" | "science" | "arts" | "music";
  targetAudience: "kids" | "teens" | "adults" | "families" | "professionals";
  monetizationFocus: "ads" | "sponsorships" | "merchandise" | "memberships" | "mixed";
  niche?: string;
  tone?: "casual" | "professional" | "educational" | "entertaining";
}

interface GeneratedChannel {
  name: string;
  handle: string;
  description: string;
  contentStrategy: {
    uploadSchedule: "daily" | "weekly" | "bi-weekly";
    contentTypes: string[];
    themes: string[];
    tone: "casual" | "professional" | "educational" | "entertaining";
    averageDuration: number;
    monetizationFocus: "ads" | "sponsorships" | "merchandise" | "memberships" | "mixed";
  };
  branding: {
    colorScheme: {
      primary: string;
      secondary: string;
      accent: string;
    };
    thumbnailStyle: string;
    fontFamily: string;
  };
  monetization: {
    subscriberTarget: number;
    watchTimeTarget: number;
    strategies: string[];
  };
  bannerUrl?: string;
}

export class YouTubeChannelGenerator {
  private outputDir: string;

  constructor() {
    this.outputDir = path.join(process.cwd(), "server", "assets", "banners");
    this.ensureOutputDirectory();
  }

  private async ensureOutputDirectory() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
    } catch (error) {
      console.log("Banner output directory already exists");
    }
  }

  async generateChannel(request: ChannelGenerationRequest): Promise<GeneratedChannel> {
    console.log("🎬 Generating AI-powered YouTube channel...");

    // Generate channel concept using AI
    const channelConcept = await this.generateChannelConcept(request);
    
    // Generate professional banner
    const bannerUrl = await this.generateProfessionalBanner(channelConcept, request);

    return {
      ...channelConcept,
      bannerUrl
    };
  }

  private async generateChannelConcept(request: ChannelGenerationRequest): Promise<Omit<GeneratedChannel, 'bannerUrl'>> {
    const prompt = `Create a highly successful YouTube channel concept optimized for maximum growth and monetization.

Category: ${request.category}
Target Audience: ${request.targetAudience}
Monetization Focus: ${request.monetizationFocus}
${request.niche ? `Niche: ${request.niche}` : ''}
${request.tone ? `Preferred Tone: ${request.tone}` : ''}

Generate a channel that will:
1. Have viral potential and high engagement
2. Be optimized for maximum revenue generation
3. Have clear growth strategies
4. Appeal strongly to the target audience
5. Stand out in the competitive YouTube landscape

Provide the response in JSON format with the following structure:
{
  "name": "channel name (catchy, memorable, SEO-optimized)",
  "handle": "@channelhandle (no spaces, lowercase)",
  "description": "compelling channel description (2-3 sentences)",
  "contentStrategy": {
    "uploadSchedule": "daily|weekly|bi-weekly",
    "contentTypes": ["array of content types"],
    "themes": ["array of recurring themes"],
    "tone": "casual|professional|educational|entertaining",
    "averageDuration": 300,
    "monetizationFocus": "${request.monetizationFocus}"
  },
  "branding": {
    "colorScheme": {
      "primary": "#hex color",
      "secondary": "#hex color", 
      "accent": "#hex color"
    },
    "thumbnailStyle": "description of thumbnail style",
    "fontFamily": "font family name"
  },
  "monetization": {
    "subscriberTarget": 100000,
    "watchTimeTarget": 4000,
    "strategies": ["array of monetization strategies"]
  }
}`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        temperature: 0.8
      });

      const channelData = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        name: channelData.name,
        handle: channelData.handle,
        description: channelData.description,
        contentStrategy: {
          uploadSchedule: channelData.contentStrategy.uploadSchedule,
          contentTypes: channelData.contentStrategy.contentTypes,
          themes: channelData.contentStrategy.themes,
          tone: channelData.contentStrategy.tone,
          averageDuration: channelData.contentStrategy.averageDuration,
          monetizationFocus: request.monetizationFocus
        },
        branding: {
          colorScheme: channelData.branding.colorScheme,
          thumbnailStyle: channelData.branding.thumbnailStyle,
          fontFamily: channelData.branding.fontFamily
        },
        monetization: {
          subscriberTarget: channelData.monetization.subscriberTarget,
          watchTimeTarget: channelData.monetization.watchTimeTarget,
          strategies: channelData.monetization.strategies
        }
      };
    } catch (error) {
      console.error("Error generating channel concept:", error);
      throw new Error("Failed to generate channel concept");
    }
  }

  async generateProfessionalBanner(channelData: Omit<GeneratedChannel, 'bannerUrl'>, request: ChannelGenerationRequest): Promise<string> {
    console.log("🎨 Creating professional YouTube banner...");

    try {
      // Create banner using Canvas (2560x1440 - YouTube banner size)
      const canvas = createCanvas(2560, 1440);
      const ctx = canvas.getContext('2d');

      // Background gradient
      const gradient = ctx.createLinearGradient(0, 0, 2560, 1440);
      gradient.addColorStop(0, channelData.branding.colorScheme.primary);
      gradient.addColorStop(0.5, channelData.branding.colorScheme.secondary);
      gradient.addColorStop(1, channelData.branding.colorScheme.accent);
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 2560, 1440);

      // Add subtle pattern overlay
      ctx.globalAlpha = 0.1;
      for (let i = 0; i < 2560; i += 100) {
        for (let j = 0; j < 1440; j += 100) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(i, j, 50, 50);
        }
      }
      ctx.globalAlpha = 1;

      // Channel name (main text)
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 120px Arial';
      ctx.textAlign = 'center';
      ctx.shadowColor = 'rgba(0,0,0,0.5)';
      ctx.shadowBlur = 10;
      ctx.fillText(channelData.name, 1280, 600);

      // Tagline/description
      ctx.font = '48px Arial';
      ctx.fillText(channelData.description.split('.')[0], 1280, 720);

      // Category badge
      ctx.fillStyle = channelData.branding.colorScheme.accent;
      ctx.fillRect(1080, 800, 400, 80);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 36px Arial';
      ctx.fillText(request.category.toUpperCase(), 1280, 850);

      // Upload schedule indicator
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.font = '32px Arial';
      ctx.fillText(`New videos ${channelData.contentStrategy.uploadSchedule}`, 1280, 1000);

      // Professional elements
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 4;
      ctx.strokeRect(100, 100, 2360, 1240);

      // Save banner
      const bannerId = nanoid();
      const bannerPath = path.join(this.outputDir, `banner-${bannerId}.png`);
      const buffer = canvas.toBuffer('image/png');
      await fs.writeFile(bannerPath, buffer);

      console.log(`✅ Professional banner created: ${bannerPath}`);
      return `/assets/banners/banner-${bannerId}.png`;

    } catch (error) {
      console.error("Error generating banner:", error);
      
      // Fallback: Generate banner using DALL-E
      return await this.generateAIBanner(channelData, request);
    }
  }

  private async generateAIBanner(channelData: Omit<GeneratedChannel, 'bannerUrl'>, request: ChannelGenerationRequest): Promise<string> {
    console.log("🤖 Generating AI banner with DALL-E...");

    const bannerPrompt = `Create a professional YouTube channel banner for "${channelData.name}". 
    Style: Modern, clean, professional
    Category: ${request.category}
    Colors: ${channelData.branding.colorScheme.primary}, ${channelData.branding.colorScheme.secondary}
    Target Audience: ${request.targetAudience}
    Include: Channel name prominently displayed, ${channelData.contentStrategy.themes.join(', ')} themed elements
    Dimensions: 2560x1440 pixels (YouTube banner format)
    Quality: High-resolution, professional design suitable for monetization`;

    try {
      const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: bannerPrompt,
        n: 1,
        size: "1792x1024", // Closest available size
        quality: "hd"
      });

      const imageUrl = response.data[0].url;
      if (!imageUrl) {
        throw new Error("No image URL received from DALL-E");
      }

      // Download and save the image
      const imageResponse = await fetch(imageUrl);
      const imageBuffer = await imageResponse.arrayBuffer();
      
      const bannerId = nanoid();
      const bannerPath = path.join(this.outputDir, `ai-banner-${bannerId}.png`);
      await fs.writeFile(bannerPath, Buffer.from(imageBuffer));

      console.log(`✅ AI banner generated: ${bannerPath}`);
      return `/assets/banners/ai-banner-${bannerId}.png`;

    } catch (error) {
      console.error("Error generating AI banner:", error);
      return `/assets/banners/default-banner.png`;
    }
  }

  async saveChannelToDatabase(channelData: GeneratedChannel): Promise<any> {
    console.log("💾 Saving channel to database...");

    const channelId = nanoid();
    
    const newChannel = {
      id: channelId,
      name: channelData.name,
      handle: channelData.handle,
      description: channelData.description,
      category: "education" as const, // Will be dynamic based on request
      targetAudience: "families" as const, // Will be dynamic based on request
      contentStrategy: channelData.contentStrategy,
      branding: {
        ...channelData.branding,
        bannerUrl: channelData.bannerUrl
      },
      monetization: {
        isEligible: false,
        estimatedRevenue: 0,
        cpm: 0,
        ...channelData.monetization
      },
      analytics: {
        subscriberCount: 0,
        totalViews: 0,
        averageViewDuration: 0,
        engagement: 0,
        revenuePerMille: 0,
        growthRate: 0,
        lastUpdated: new Date().toISOString()
      },
      isActive: true
    };

    try {
      // For now, we'll simulate database save
      // In production, this would use the actual database storage
      console.log(`✅ Channel "${channelData.name}" saved with ID: ${channelId}`);
      return newChannel;
    } catch (error) {
      console.error("Error saving channel:", error);
      throw new Error("Failed to save channel to database");
    }
  }

  async generateContentCalendar(channelId: string, days: number = 30): Promise<any[]> {
    console.log(`📅 Generating ${days}-day content calendar...`);

    // This would generate a strategic content calendar
    // focused on growth and monetization
    const calendar = [];
    
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      
      calendar.push({
        id: nanoid(),
        channelId,
        scheduledDate: date,
        title: `Content Idea ${i + 1}`,
        contentType: i % 7 === 0 ? "viral_trend" : "educational",
        status: "planned"
      });
    }

    return calendar;
  }
}

export const youtubeChannelGenerator = new YouTubeChannelGenerator();