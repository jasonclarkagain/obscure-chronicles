import { advancedQualityEngine } from './advanced-quality-engine.js';
import { storage } from './storage.js';
import { nanoid } from 'nanoid';

interface ProductionQualityConfig {
  dailyQualityPreset: 'professional' | 'premium' | 'cinematic';
  platformTargets: string[];
  enableAdvancedEffects: boolean;
  qualityThreshold: number;
  autoOptimization: boolean;
}

export class ProductionQualityIntegration {
  private config: ProductionQualityConfig;

  constructor() {
    this.config = {
      dailyQualityPreset: 'professional',
      platformTargets: ['youtube', 'mobile'],
      enableAdvancedEffects: true,
      qualityThreshold: 90,
      autoOptimization: true
    };
  }

  async generateDailyProfessionalVideo(): Promise<{
    success: boolean;
    videoId: string;
    qualityScore: number;
    analytics: any;
  }> {
    console.log('Starting daily professional video generation with advanced quality engine');

    try {
      // Get daily theme and characters
      const themes = await storage.getVideoThemes();
      const characters = await storage.getCharacters();
      
      if (themes.length === 0 || characters.length === 0) {
        throw new Error('No themes or characters available for video generation');
      }

      // Select theme for today (rotate based on day of year)
      const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
      const selectedTheme = themes[dayOfYear % themes.length];
      const selectedCharacters = this.selectCharactersForTheme(characters, selectedTheme);

      // Generate enhanced script for professional quality
      const videoId = `daily_pro_${nanoid()}`;
      const script = await this.generateProfessionalScript(selectedTheme, selectedCharacters);

      // Configure quality settings for daily generation
      const qualityConfig = {
        qualityPreset: this.config.dailyQualityPreset,
        platformTarget: 'youtube', // Primary target for daily videos
        enableAdvancedEffects: this.config.enableAdvancedEffects,
        enhancementLevel: 'ultra' as const
      };

      // Generate video with advanced quality engine
      const result = await advancedQualityEngine.generateProfessionalVideo(
        videoId,
        script,
        qualityConfig
      );

      // Check quality threshold
      if (result.analytics.qualityScore < this.config.qualityThreshold) {
        console.log(`Quality score ${result.analytics.qualityScore} below threshold ${this.config.qualityThreshold}, regenerating...`);
        
        // Try again with higher quality preset
        const enhancedConfig = {
          ...qualityConfig,
          qualityPreset: 'premium' as const
        };
        
        const retryResult = await advancedQualityEngine.generateProfessionalVideo(
          `${videoId}_enhanced`,
          script,
          enhancedConfig
        );
        
        return {
          success: true,
          videoId: `${videoId}_enhanced`,
          qualityScore: retryResult.analytics.qualityScore,
          analytics: retryResult.analytics
        };
      }

      // Generate optimized versions for different platforms
      if (this.config.autoOptimization) {
        await this.generatePlatformOptimizedVersions(result.videoPath, videoId);
      }

      console.log(`Daily professional video generated successfully: ${videoId}`);
      console.log(`Quality score: ${result.analytics.qualityScore}/100`);

      return {
        success: true,
        videoId,
        qualityScore: result.analytics.qualityScore,
        analytics: result.analytics
      };

    } catch (error) {
      console.error('Error in daily professional video generation:', error);
      return {
        success: false,
        videoId: '',
        qualityScore: 0,
        analytics: null
      };
    }
  }

  private selectCharactersForTheme(characters: any[], theme: any): any[] {
    // Select 2-3 characters for diverse interaction
    const shuffled = [...characters].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, Math.min(3, characters.length));
  }

  private async generateProfessionalScript(theme: any, characters: any[]): Promise<any> {
    const educationalObjectives = [
      'Develop critical thinking skills',
      'Enhance creative problem-solving abilities',
      'Build scientific understanding',
      'Foster curiosity and exploration',
      'Strengthen communication skills'
    ];

    const script = {
      title: `${theme.name}: Professional Educational Adventure`,
      description: `Join ${characters.map(c => c.name).join(', ')} in an exciting educational journey exploring ${theme.description}. This high-quality video combines entertainment with learning to create an engaging experience for viewers of all ages.`,
      
      intro: {
        character: characters[0]?.name || 'Captain Marina',
        text: `Welcome, fellow explorers! I'm ${characters[0]?.name || 'Captain Marina'}, and today we're embarking on an incredible journey to discover the fascinating world of ${theme.name}. Are you ready for an adventure that will expand your mind and spark your imagination?`,
        duration: 15,
        effects: ['professional_entrance', 'knowledge_sparkle', 'adventure_theme']
      },

      main_content: {
        sections: [
          {
            character: characters[1]?.name || 'Curious Casey',
            text: `Let me tell you something amazing about ${theme.name}! Did you know that understanding this topic can help us ${educationalObjectives[Math.floor(Math.random() * educationalObjectives.length)]}? It's like having a superpower that makes us smarter and more creative every day!`,
            objective: `Introduce core concepts of ${theme.name}`,
            duration: 30,
            effects: ['concept_highlight', 'learning_burst', 'curiosity_spark']
          },
          {
            character: characters[2]?.name || characters[0]?.name || 'Luna',
            text: `That's incredible, ${characters[1]?.name || 'friend'}! And here's the really exciting part - when we explore ${theme.name}, we're not just learning facts, we're developing skills that will help us in so many areas of life. It's like building a foundation for lifelong learning and discovery!`,
            objective: `Connect learning to practical applications`,
            duration: 35,
            effects: ['connection_visualization', 'skill_development', 'future_thinking']
          },
          {
            character: characters[0]?.name || 'Captain Marina',
            text: `Absolutely! And the best part is that every question we ask, every problem we solve, and every discovery we make in ${theme.name} brings us closer to understanding the amazing world around us. Learning is the greatest adventure of all!`,
            objective: `Inspire continued exploration and learning`,
            duration: 30,
            effects: ['inspiration_wave', 'discovery_celebration', 'adventure_continuation']
          }
        ]
      },

      conclusion: {
        character: characters[0]?.name || 'Captain Marina',
        text: `What an incredible journey we've had exploring ${theme.name} together! Remember, every expert was once a beginner, and every question you ask is a step toward new discoveries. Keep exploring, keep wondering, and keep learning - the world is full of amazing adventures waiting for curious minds like yours!`,
        duration: 20,
        effects: ['achievement_celebration', 'future_inspiration', 'call_to_adventure']
      },

      educational_goals: educationalObjectives.slice(0, 3),
      age_appropriateness: 'G-rated, suitable for all ages',
      learning_outcomes: [
        `Understanding key concepts of ${theme.name}`,
        'Developing curiosity and questioning skills',
        'Building confidence in learning and exploration',
        'Connecting knowledge to real-world applications'
      ]
    };

    return script;
  }

  private async generatePlatformOptimizedVersions(
    originalVideoPath: string,
    videoId: string
  ): Promise<void> {
    console.log('Generating platform-optimized versions...');

    const optimizationPromises = this.config.platformTargets.map(async (platform) => {
      if (platform === 'youtube') return; // Original is already YouTube optimized
      
      try {
        const optimizedConfig = {
          qualityPreset: this.getOptimalPresetForPlatform(platform),
          platformTarget: platform,
          enableAdvancedEffects: platform !== 'mobile', // Reduce effects for mobile
          enhancementLevel: platform === 'broadcast' ? 'ultra' : 'advanced' as const
        };

        // Generate platform-specific version
        await advancedQualityEngine.generateProfessionalVideo(
          `${videoId}_${platform}`,
          await this.adaptScriptForPlatform(platform),
          optimizedConfig
        );

        console.log(`Generated ${platform}-optimized version`);
      } catch (error) {
        console.error(`Error generating ${platform} version:`, error);
      }
    });

    await Promise.allSettled(optimizationPromises);
  }

  private getOptimalPresetForPlatform(platform: string): 'standard' | 'professional' | 'premium' | 'cinematic' {
    const presetMap: Record<string, any> = {
      'mobile': 'standard',
      'youtube': 'professional',
      'broadcast': 'cinematic',
      'universal': 'professional'
    };

    return presetMap[platform] || 'professional';
  }

  private async adaptScriptForPlatform(platform: string): Promise<any> {
    // Platform-specific adaptations would be implemented here
    // For now, return a basic adapted script
    return {
      platform_optimized: true,
      target_platform: platform,
      adaptations_applied: true
    };
  }

  async getProductionQualityMetrics(): Promise<{
    dailyAverageQuality: number;
    weeklyTrends: number[];
    platformPerformance: any;
    recommendations: string[];
  }> {
    const analytics = await advancedQualityEngine.getQualityAnalytics();
    
    return {
      dailyAverageQuality: analytics.summary?.averageQualityScore || 0,
      weeklyTrends: analytics.trends?.qualityTrend || [],
      platformPerformance: analytics.summary?.platformDistribution || {},
      recommendations: await this.generateProductionRecommendations(analytics)
    };
  }

  private async generateProductionRecommendations(analytics: any): Promise<string[]> {
    const recommendations: string[] = [];
    
    if (analytics.summary?.averageQualityScore < 95) {
      recommendations.push('Consider upgrading daily quality preset to Premium for better results');
    }
    
    if (analytics.summary?.averageRenderTime > 180000) { // 3 minutes
      recommendations.push('Optimize rendering settings to improve daily generation speed');
    }
    
    const platformDist = analytics.summary?.platformDistribution || {};
    if (platformDist.mobile < platformDist.youtube * 0.5) {
      recommendations.push('Increase mobile optimization for better accessibility');
    }
    
    return recommendations;
  }

  updateProductionConfig(newConfig: Partial<ProductionQualityConfig>): void {
    this.config = { ...this.config, ...newConfig };
    console.log('Production quality configuration updated:', this.config);
  }

  getProductionConfig(): ProductionQualityConfig {
    return { ...this.config };
  }
}

export const productionQualityIntegration = new ProductionQualityIntegration();