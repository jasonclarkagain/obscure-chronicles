import { google } from 'googleapis';
import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';
import { createCanvas, loadImage } from 'canvas';
import ffmpeg from 'fluent-ffmpeg';
import cron from 'node-cron';
import { nanoid } from 'nanoid';

// Configuration
const CLIENT_ID = "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com";
const CLIENT_SECRET = "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";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface Episode {
  number: number;
  title: string;
  topic: string;
  script: any;
  status: 'pending' | 'generating' | 'uploading' | 'uploaded' | 'failed';
  videoId?: string;
  url?: string;
  uploadTime?: string;
}

export class WorkingYouTubeAutomation {
  private episodes: Episode[] = [];
  private currentEpisode = 1;
  private outputDir: string;
  private youtube: any;
  private scheduledTask: cron.ScheduledTask | null = null;
  
  constructor() {
    this.outputDir = path.join(process.cwd(), 'server', 'automation_output');
    this.initializeEpisodes();
    this.ensureDirectories();
  }
  
  private initializeEpisodes() {
    const topics = [
      "The Water Cycle Adventure",
      "Journey Through the Solar System", 
      "Amazing Plant Life Cycle",
      "Forest Animal Friends",
      "Weather Patterns Around the World",
      "Ocean Depths Exploration",
      "Dinosaur Time Machine",
      "Counting Adventures with Captain Marina",
      "Geometric Shapes Discovery",
      "Pattern Recognition Fun",
      "Addition and Subtraction Magic",
      "Measurement Adventures",
      "Time Travel Learning",
      "Money Math Adventures",
      "Alphabet Adventure Quest",
      "Storytelling Magic Hour",
      "Reading Rainbow Journey",
      "Creative Writing Workshop",
      "Languages of the World",
      "Poetry and Rhyme Time",
      "Colors and Art Creation",
      "Musical Instrument Discovery",
      "World Cultures Festival",
      "Building and Construction Fun",
      "Dance Around the World",
      "Cooking Adventures",
      "Nature Art Workshop",
      "Kindness and Friendship",
      "Problem Solving Heroes",
      "Community Helpers Adventure"
    ];
    
    this.episodes = topics.map((topic, index) => ({
      number: index + 1,
      title: topic,
      topic: topic,
      script: null,
      status: 'pending'
    }));
  }
  
  private async ensureDirectories() {
    const dirs = [this.outputDir, path.join(this.outputDir, 'videos'), path.join(this.outputDir, 'thumbnails')];
    for (const dir of dirs) {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }
  }
  
  async initializeWithRefreshToken(refreshToken: string): Promise<boolean> {
    try {
      const oauth2Client = new google.auth.OAuth2(
        CLIENT_ID,
        CLIENT_SECRET,
        'https://a542f69f-89b0-40c4-91f0-9684c95170bd-00-1qklzlvyeiq1b.kirk.replit.dev/oauth2callback'
      );
      
      oauth2Client.setCredentials({
        refresh_token: refreshToken
      });
      
      // Test token refresh
      const { credentials } = await oauth2Client.refreshAccessToken();
      console.log('✅ OAuth token refreshed successfully');
      
      // Initialize YouTube client
      this.youtube = google.youtube({ 
        version: 'v3', 
        auth: oauth2Client 
      });
      
      // Test connection
      const channelResponse = await this.youtube.channels.list({
        part: ['snippet'],
        mine: true
      });
      
      if (channelResponse.data.items && channelResponse.data.items.length > 0) {
        const channel = channelResponse.data.items[0];
        console.log(`✅ Connected to YouTube channel: ${channel.snippet.title}`);
        return true;
      } else {
        console.log('❌ No YouTube channel found');
        return false;
      }
      
    } catch (error: any) {
      console.error('❌ YouTube initialization failed:', error.message);
      return false;
    }
  }
  
  async generateEpisodeScript(episode: Episode): Promise<any> {
    const prompt = `Create a 5-minute educational video script about "${episode.topic}" for children ages 5-12.

    Requirements:
    - Educational objectives for learning
    - 3 characters: Captain Marina (wise leader), Curious Casey (asks questions), Luna (explorer)
    - 5 scenes with dialog and visual descriptions
    - Family-friendly G-rated content
    - Interactive elements for engagement
    - Clear learning outcomes
    
    Format as JSON with:
    {
      "title": "${episode.title}",
      "description": "Episode description",
      "educational_objectives": ["objective1", "objective2", "objective3"],
      "scenes": [
        {
          "scene_number": 1,
          "duration": 60,
          "setting": "scene setting",
          "visual_description": "what viewers see",
          "dialog": [
            {"character": "Captain Marina", "text": "dialog text"},
            {"character": "Curious Casey", "text": "dialog text"},
            {"character": "Luna", "text": "dialog text"}
          ],
          "educational_focus": "what this scene teaches"
        }
      ],
      "conclusion": "wrap up message",
      "call_to_action": "engagement prompt"
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content);
  }
  
  async createVideoFile(episode: Episode): Promise<string> {
    const videoPath = path.join(this.outputDir, 'videos', `episode_${episode.number}.mp4`);
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');
    
    // Create multiple frames for the video
    const frames: Buffer[] = [];
    
    for (let i = 0; i < 150; i++) { // 5 seconds at 30 FPS
      // Clear canvas
      ctx.fillStyle = '#87CEEB';
      ctx.fillRect(0, 0, 1920, 1080);
      
      // Animated background
      const time = i / 30;
      const waveOffset = Math.sin(time * 2) * 50;
      
      // Draw animated elements
      ctx.fillStyle = '#FFD700';
      ctx.beginPath();
      ctx.arc(1600 + waveOffset, 200, 80, 0, Math.PI * 2);
      ctx.fill();
      
      // Main title
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 64px Arial';
      ctx.textAlign = 'center';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 4;
      ctx.strokeText(episode.title, 960, 400);
      ctx.fillText(episode.title, 960, 400);
      
      // Episode info
      ctx.font = 'bold 48px Arial';
      ctx.fillText(`Episode ${episode.number}/30`, 960, 500);
      
      // Character names
      ctx.font = '36px Arial';
      ctx.fillText('Featuring: Captain Marina, Curious Casey & Luna', 960, 600);
      
      // Educational series branding
      ctx.font = 'bold 42px Arial';
      ctx.fillStyle = '#FF6B6B';
      ctx.fillText('Amazing Learning Adventures', 960, 700);
      
      // Save frame
      frames.push(canvas.toBuffer('image/png'));
    }
    
    // Create video from frames
    return new Promise((resolve, reject) => {
      const frameDir = path.join(this.outputDir, 'temp_frames');
      if (!fs.existsSync(frameDir)) {
        fs.mkdirSync(frameDir, { recursive: true });
      }
      
      // Write frames to files
      frames.forEach((frame, index) => {
        const framePath = path.join(frameDir, `frame_${index.toString().padStart(4, '0')}.png`);
        fs.writeFileSync(framePath, frame);
      });
      
      // Create video with FFmpeg
      ffmpeg()
        .input(path.join(frameDir, 'frame_%04d.png'))
        .inputOptions(['-r 30'])
        .outputOptions([
          '-c:v libx264',
          '-pix_fmt yuv420p',
          '-crf 18',
          '-preset slow',
          '-r 30'
        ])
        .output(videoPath)
        .on('end', () => {
          // Clean up temp frames
          fs.rmSync(frameDir, { recursive: true, force: true });
          resolve(videoPath);
        })
        .on('error', (err) => {
          console.error('Video creation error:', err);
          reject(err);
        })
        .run();
    });
  }
  
  private wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
    const words = text.split(' ');
    const lines: string[] = [];
    let currentLine = '';
    
    for (const word of words) {
      const testLine = currentLine + (currentLine ? ' ' : '') + word;
      const metrics = ctx.measureText(testLine);
      
      if (metrics.width > maxWidth && currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    }
    
    if (currentLine) {
      lines.push(currentLine);
    }
    
    return lines;
  }
  
  async createThumbnail(episode: Episode): Promise<string> {
    const thumbnailPath = path.join(this.outputDir, 'thumbnails', `episode_${episode.number}_thumbnail.png`);
    const canvas = createCanvas(1280, 720);
    const ctx = canvas.getContext('2d');
    
    // Gradient background
    const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
    gradient.addColorStop(0, '#FF6B6B');
    gradient.addColorStop(0.5, '#4ECDC4');
    gradient.addColorStop(1, '#45B7D1');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1280, 720);
    
    // Title background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(0, 200, 1280, 200);
    
    // Main title
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 52px Arial';
    ctx.textAlign = 'center';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    
    const titleLines = this.wrapText(ctx, episode.title, 1200);
    titleLines.forEach((line, index) => {
      const y = 280 + (index * 60);
      ctx.strokeText(line, 640, y);
      ctx.fillText(line, 640, y);
    });
    
    // Episode number
    ctx.fillStyle = '#FFD700';
    ctx.font = 'bold 36px Arial';
    ctx.fillText(`Episode ${episode.number}/30`, 640, 450);
    
    // Series branding
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 32px Arial';
    ctx.fillText('Amazing Learning Adventures', 640, 500);
    
    // Character mention
    ctx.font = '24px Arial';
    ctx.fillText('Captain Marina • Curious Casey • Luna', 640, 550);
    
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(thumbnailPath, buffer);
    
    return thumbnailPath;
  }
  
  async uploadToYouTube(episode: Episode, videoPath: string, thumbnailPath: string): Promise<any> {
    try {
      console.log(`📤 Uploading Episode ${episode.number}: ${episode.title}`);
      
      const videoMetadata = {
        snippet: {
          title: `${episode.title} - Episode ${episode.number}/30 | Amazing Learning Adventures`,
          description: this.createDescription(episode),
          tags: [
            'educational', 'children', 'learning', 'kids', 'family friendly',
            'science', 'adventure', 'Captain Marina', 'educational series',
            'preschool', 'elementary', 'fun learning', 'interactive'
          ],
          categoryId: '27', // Education category
          defaultLanguage: 'en',
          defaultAudioLanguage: 'en'
        },
        status: {
          privacyStatus: 'public',
          madeForKids: true,
          selfDeclaredMadeForKids: true
        }
      };
      
      // Upload video
      const videoResponse = await this.youtube.videos.insert({
        part: ['snippet', 'status'],
        requestBody: videoMetadata,
        media: {
          body: fs.createReadStream(videoPath)
        }
      });
      
      const videoId = videoResponse.data.id;
      console.log(`✅ Video uploaded successfully: ${videoId}`);
      
      // Upload thumbnail
      try {
        await this.youtube.thumbnails.set({
          videoId: videoId,
          media: {
            body: fs.createReadStream(thumbnailPath)
          }
        });
        console.log('✅ Thumbnail uploaded successfully');
      } catch (thumbError) {
        console.warn('⚠️ Thumbnail upload failed:', thumbError);
      }
      
      return {
        videoId: videoId,
        url: `https://www.youtube.com/watch?v=${videoId}`,
        uploadTime: new Date().toISOString()
      };
      
    } catch (error: any) {
      console.error('❌ Upload failed:', error.message);
      throw error;
    }
  }
  
  private createDescription(episode: Episode): string {
    return `🎓 Welcome to Amazing Learning Adventures - Episode ${episode.number}/30!

🌟 Today's Adventure: ${episode.title}

Join Captain Marina, Curious Casey, and Luna on an exciting educational journey! This episode is designed for children ages 5-12 and features:

${episode.script?.educational_objectives?.map((obj: string, i: number) => `✅ ${obj}`).join('\n') || '✅ Interactive learning\n✅ Educational content\n✅ Fun characters'}

🎯 Perfect for:
• Homeschooling families
• Classroom learning
• Educational screen time
• Curious young minds

👨‍👩‍👧‍👦 Family-friendly content rated G
🔔 Subscribe for daily educational adventures!

#Education #Kids #Learning #FamilyFriendly #Educational #Children #Science #Adventure

---
Amazing Learning Adventures
Daily Educational Series for Growing Minds
Episode ${episode.number} of 30`;
  }
  
  async processEpisode(episodeNumber: number): Promise<void> {
    const episode = this.episodes.find(e => e.number === episodeNumber);
    if (!episode) {
      console.log(`❌ Episode ${episodeNumber} not found`);
      return;
    }
    
    console.log(`🎬 Processing Episode ${episodeNumber}: ${episode.title}`);
    episode.status = 'generating';
    
    try {
      // Generate script
      console.log('📝 Generating script...');
      episode.script = await this.generateEpisodeScript(episode);
      
      // Create video
      console.log('🎥 Creating video...');
      const videoPath = await this.createVideoFile(episode);
      
      // Create thumbnail
      console.log('🖼️ Creating thumbnail...');
      const thumbnailPath = await this.createThumbnail(episode);
      
      // Upload to YouTube
      console.log('📤 Uploading to YouTube...');
      episode.status = 'uploading';
      const uploadResult = await this.uploadToYouTube(episode, videoPath, thumbnailPath);
      
      episode.videoId = uploadResult.videoId;
      episode.url = uploadResult.url;
      episode.uploadTime = uploadResult.uploadTime;
      episode.status = 'uploaded';
      
      console.log(`✅ Episode ${episodeNumber} completed successfully!`);
      console.log(`📺 Video URL: ${episode.url}`);
      
      // Save progress
      await this.saveProgress();
      
    } catch (error: any) {
      console.error(`❌ Episode ${episodeNumber} failed:`, error.message);
      episode.status = 'failed';
      await this.saveProgress();
    }
  }
  
  async saveProgress(): Promise<void> {
    const progressPath = path.join(this.outputDir, 'progress.json');
    const progressData = {
      currentEpisode: this.currentEpisode,
      episodes: this.episodes.map(ep => ({
        number: ep.number,
        title: ep.title,
        status: ep.status,
        videoId: ep.videoId,
        url: ep.url,
        uploadTime: ep.uploadTime
      })),
      lastUpdated: new Date().toISOString()
    };
    
    fs.writeFileSync(progressPath, JSON.stringify(progressData, null, 2));
  }
  
  async startDailyAutomation(): Promise<void> {
    console.log('🚀 Starting daily automation...');
    console.log('📅 Schedule: Daily at 9:00 AM UTC');
    
    // Process first episode immediately
    await this.processEpisode(this.currentEpisode);
    this.currentEpisode++;
    
    // Schedule daily automation
    this.scheduledTask = cron.schedule('0 9 * * *', async () => {
      if (this.currentEpisode <= 30) {
        console.log(`🌅 Daily automation triggered - Episode ${this.currentEpisode}`);
        await this.processEpisode(this.currentEpisode);
        this.currentEpisode++;
      } else {
        console.log('🎉 30-day series completed!');
        this.stopAutomation();
      }
    });
    
    console.log('✅ Daily automation scheduled');
  }
  
  stopAutomation(): void {
    if (this.scheduledTask) {
      this.scheduledTask.stop();
      console.log('⏹️ Automation stopped');
    }
  }
  
  getStatus(): any {
    const completed = this.episodes.filter(e => e.status === 'uploaded').length;
    const failed = this.episodes.filter(e => e.status === 'failed').length;
    const pending = this.episodes.filter(e => e.status === 'pending').length;
    
    return {
      totalEpisodes: this.episodes.length,
      completed,
      failed,
      pending,
      currentEpisode: this.currentEpisode,
      isRunning: this.scheduledTask !== null,
      episodes: this.episodes.map(ep => ({
        number: ep.number,
        title: ep.title,
        status: ep.status,
        url: ep.url,
        uploadTime: ep.uploadTime
      }))
    };
  }
}

// Main execution
async function main() {
  const refreshToken = process.env.YOUTUBE_REFRESH_TOKEN || process.argv[2];
  
  if (!refreshToken) {
    console.log('❌ Please provide refresh token as environment variable or argument');
    console.log('Usage: YOUTUBE_REFRESH_TOKEN=<token> npx tsx server/working-automation.ts');
    console.log('   or: npx tsx server/working-automation.ts <refresh_token>');
    return;
  }
  
  const automation = new WorkingYouTubeAutomation();
  
  if (await automation.initializeWithRefreshToken(refreshToken)) {
    console.log('🎯 YouTube automation initialized successfully');
    console.log('🚀 Starting 30-day educational series...');
    
    await automation.startDailyAutomation();
    
    // Keep the process running
    process.on('SIGINT', () => {
      console.log('\n🛑 Stopping automation...');
      automation.stopAutomation();
      process.exit(0);
    });
    
    console.log('✅ Automation is running. Press Ctrl+C to stop.');
    
    // Keep alive
    setInterval(() => {
      const status = automation.getStatus();
      console.log(`📊 Status: ${status.completed}/${status.totalEpisodes} episodes completed`);
    }, 300000); // Status update every 5 minutes
  }
}

if (require.main === module) {
  main().catch(console.error);
}