#!/usr/bin/env npx tsx

import OpenAI from "openai";
import { nanoid } from "nanoid";
import fs from "fs/promises";
import path from "path";
import cron from "node-cron";
import { youtubeUploader } from "./youtube-uploader";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface YouTubeCredentials {
  client_id: string;
  client_secret: string;
  refresh_token: string;
  access_token?: string;
}

interface RealVideoEpisode {
  episodeNumber: number;
  title: string;
  description: string;
  script: any;
  status: 'generated' | 'uploading' | 'uploaded' | 'failed';
  youtubeVideoId?: string;
  youtubeUrl?: string;
  uploadTime?: string;
  error?: string;
}

export class RealYouTubeAutomation {
  private series = {
    title: "Amazing Learning Adventures - Educational Series",
    youtubeAccount: "jasonclarkagain@gmail.com",
    characters: ["Captain Marina", "Curious Casey", "Luna the Explorer"],
    currentEpisode: 1,
    totalEpisodes: 30
  };

  private outputDir = path.join(process.cwd(), "real_youtube_output");
  private scheduledTask: cron.ScheduledTask | null = null;
  private credentials: YouTubeCredentials | null = null;

  constructor() {
    this.ensureDirectories();
  }

  private async ensureDirectories() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
      console.log(`📁 Real YouTube output directory ready: ${this.outputDir}`);
    } catch (error) {
      console.log("Output directory already exists");
    }
  }

  async setYouTubeCredentials(credentials: YouTubeCredentials): Promise<void> {
    this.credentials = credentials;
    console.log("✅ YouTube credentials configured for real uploads");
  }

  async generateTodaysRealVideo(): Promise<RealVideoEpisode> {
    console.log(`\n🎬 GENERATING REAL YOUTUBE VIDEO - Episode ${this.series.currentEpisode}/30`);
    console.log(`📧 YouTube Account: ${this.series.youtubeAccount}`);
    console.log(`🎭 Characters: ${this.series.characters.join(", ")}`);
    
    if (!this.credentials) {
      throw new Error("YouTube credentials not configured. Please provide OAuth credentials.");
    }

    const topics = [
      "The Water Cycle Adventure", "Solar System Exploration", "How Plants Grow", 
      "Animal Habitats", "Weather Patterns", "Ocean Life", "Dinosaur Discovery",
      "Counting Adventures", "Shape Recognition", "Pattern Discovery", 
      "Simple Addition", "Measurement Fun", "Time Concepts", "Money Basics",
      "Alphabet Adventures", "Storytelling Basics", "Reading Together", 
      "Writing Skills", "Communication", "Different Languages", "Poetry Fun",
      "Colors and Art", "Music Exploration", "World Cultures", 
      "Creative Building", "Dance and Movement", "Cooking Together", "Nature Art",
      "Kindness Matters", "Problem Solving", "Friendship"
    ];

    const todaysTopic = topics[this.series.currentEpisode - 1] || `Learning Adventure ${this.series.currentEpisode}`;
    
    console.log(`📚 Today's Topic: "${todaysTopic}"`);
    
    // Generate professional educational script
    const script = await this.generateProfessionalScript(todaysTopic, this.series.currentEpisode);
    
    // Create video episode
    const episode: RealVideoEpisode = {
      episodeNumber: this.series.currentEpisode,
      title: script.title,
      description: script.description,
      script: script,
      status: 'generated'
    };

    try {
      // Generate and upload real video to YouTube
      episode.status = 'uploading';
      const uploadResult = await youtubeUploader.generateAndUploadEpisode(
        script, 
        this.series.currentEpisode, 
        this.credentials
      );
      
      episode.status = 'uploaded';
      episode.youtubeVideoId = uploadResult.videoId;
      episode.youtubeUrl = uploadResult.url;
      episode.uploadTime = uploadResult.uploadTime;
      
      console.log(`✅ REAL VIDEO UPLOADED TO YOUTUBE!`);
      console.log(`📺 Title: "${episode.title}"`);
      console.log(`🆔 Video ID: ${episode.youtubeVideoId}`);
      console.log(`🔗 YouTube URL: ${episode.youtubeUrl}`);
      
    } catch (error) {
      episode.status = 'failed';
      episode.error = error.message;
      console.error(`❌ Upload failed:`, error);
      throw error;
    }

    // Save episode data
    await this.saveRealEpisode(episode);
    
    return episode;
  }

  private async generateProfessionalScript(topic: string, episodeNumber: number): Promise<any> {
    console.log(`🤖 Generating professional AI script for "${topic}"...`);
    
    const prompt = `Create a professional, engaging educational video script for "${topic}" - Episode ${episodeNumber}/30.

Series: Amazing Learning Adventures - Educational Series
Characters: Captain Marina (wise educator), Curious Casey (enthusiastic student), Luna the Explorer (creative problem-solver)
Target: Educational content for families, G-rated, 5-6 minutes optimal length
YouTube Channel: jasonclarkagain@gmail.com

Requirements:
1. Professional educational content that teaches real concepts
2. Age-appropriate for children 4-12 with family viewing
3. Interactive elements to engage viewers
4. Clear learning objectives and outcomes
5. YouTube SEO optimized title and description
6. Encourages subscription and engagement
7. Follows YouTube community guidelines
8. Educational standards aligned

Create a comprehensive script with detailed structure:

{
  "title": "SEO-optimized YouTube title (60 chars max)",
  "description": "Engaging description that explains the learning value",
  "educationalObjectives": [
    "Specific learning goal 1",
    "Specific learning goal 2", 
    "Specific learning goal 3"
  ],
  "targetAge": "4-12 years",
  "estimatedDuration": "5-6 minutes",
  "scenes": [
    {
      "sceneNumber": 1,
      "duration": 60,
      "setting": "Colorful educational environment",
      "dialog": [
        {
          "character": "Captain Marina",
          "text": "Welcome to our amazing adventure!",
          "timing": {"start": 0, "end": 5},
          "tone": "warm and welcoming"
        }
      ],
      "visualElements": [
        "Bright, colorful educational graphics",
        "Character animations",
        "Learning materials and props"
      ],
      "educationalContent": "Introduction to the topic with clear learning objectives",
      "interactiveElements": [
        "Question for viewers to think about",
        "Call to action for engagement"
      ]
    }
  ],
  "closingSegment": {
    "summary": "What we learned today",
    "callToAction": "Subscribe for more learning adventures",
    "nextEpisodeTeaser": "Preview of tomorrow's topic"
  },
  "youtubeMetadata": {
    "tags": ["education", "learning", "family-friendly", "kids"],
    "category": "Education",
    "thumbnail_elements": ["Episode number", "Topic highlight", "Characters"]
  }
}

Make this content educational, professional, and engaging for real YouTube upload.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 4000
      });

      const script = JSON.parse(response.choices[0].message.content || '{}');
      
      console.log(`✅ Professional script generated: "${script.title}"`);
      return script;
      
    } catch (error) {
      console.error("Error generating script:", error);
      
      // Fallback professional script
      return {
        title: `${topic} - Educational Adventure ${episodeNumber}`,
        description: `Join Captain Marina, Curious Casey, and Luna for an educational adventure about ${topic}. Perfect for families who love learning together!`,
        educationalObjectives: [
          `Understand the basics of ${topic}`,
          "Engage with interactive educational content", 
          "Develop curiosity and critical thinking skills"
        ],
        targetAge: "4-12 years",
        estimatedDuration: "5-6 minutes",
        scenes: [
          {
            sceneNumber: 1,
            duration: 360,
            setting: "Colorful educational environment with our three characters",
            dialog: [
              {
                character: "Captain Marina",
                text: `Welcome to our amazing learning adventure about ${topic}!`,
                timing: { start: 0, end: 5 },
                tone: "warm and welcoming"
              },
              {
                character: "Curious Casey", 
                text: `I can't wait to learn about ${topic}! What will we discover?`,
                timing: { start: 5, end: 10 },
                tone: "excited and curious"
              },
              {
                character: "Luna the Explorer",
                text: `Let's explore together and make some amazing discoveries!`,
                timing: { start: 10, end: 15 },
                tone: "adventurous and encouraging"
              }
            ],
            visualElements: [
              "Bright, colorful educational graphics",
              "Three main characters in educational setting",
              "Topic-specific learning materials and visual aids"
            ],
            educationalContent: `Comprehensive introduction to ${topic} with age-appropriate explanations`,
            interactiveElements: [
              "Can you guess what we'll learn about today?",
              "Follow along and ask questions with Curious Casey!"
            ]
          }
        ],
        closingSegment: {
          summary: `Today we learned amazing things about ${topic}`,
          callToAction: "Subscribe for daily educational adventures with Captain Marina, Curious Casey, and Luna!",
          nextEpisodeTeaser: "Tomorrow we'll have another exciting learning adventure!"
        },
        youtubeMetadata: {
          tags: ["education", "learning", "family-friendly", "kids", "educational", topic.toLowerCase()],
          category: "Education",
          thumbnail_elements: [`Episode ${episodeNumber}`, topic, "Captain Marina, Curious Casey, Luna"]
        }
      };
    }
  }

  private async saveRealEpisode(episode: RealVideoEpisode): Promise<void> {
    const filename = `real_episode_${episode.episodeNumber}_${episode.title.replace(/[^a-zA-Z0-9]/g, '_')}.json`;
    const filepath = path.join(this.outputDir, filename);
    
    await fs.writeFile(filepath, JSON.stringify(episode, null, 2));
    console.log(`💾 Real episode data saved: ${filepath}`);
  }

  async startRealDailyAutomation(): Promise<void> {
    console.log(`\n🚀 STARTING REAL 30-DAY YOUTUBE AUTOMATION`);
    console.log(`📧 Account: ${this.series.youtubeAccount}`);
    console.log(`📅 Schedule: Daily real YouTube uploads at 9:00 AM UTC`);
    console.log(`🎭 Characters: ${this.series.characters.join(", ")}`);
    
    if (!this.credentials) {
      throw new Error("YouTube credentials required for real automation. Please configure OAuth credentials first.");
    }

    // Generate today's real video
    await this.generateTodaysRealVideo();
    
    // Schedule daily generation and upload
    this.scheduledTask = cron.schedule('0 9 * * *', async () => {
      if (this.series.currentEpisode <= this.series.totalEpisodes) {
        try {
          await this.generateTodaysRealVideo();
          this.series.currentEpisode++;
        } catch (error) {
          console.error("Daily real video generation failed:", error);
        }
      } else {
        console.log("🎉 30-day real YouTube series completed!");
        this.stopAutomation();
      }
    }, {
      scheduled: true,
      timezone: "UTC"
    });

    console.log(`\n✅ REAL YOUTUBE AUTOMATION ACTIVE!`);
    console.log(`📊 Status: Uploading real videos daily to YouTube`);
    console.log(`🎬 Videos are being uploaded to your actual YouTube channel`);
    console.log(`📺 YouTube account: ${this.series.youtubeAccount}`);
  }

  public getRealAutomationStatus(): any {
    return {
      isActive: this.scheduledTask !== null,
      hasCredentials: this.credentials !== null,
      seriesTitle: this.series.title,
      currentEpisode: this.series.currentEpisode,
      totalEpisodes: this.series.totalEpisodes,
      remainingEpisodes: this.series.totalEpisodes - this.series.currentEpisode + 1,
      youtubeAccount: this.series.youtubeAccount,
      nextScheduledRun: this.scheduledTask ? "Daily at 9:00 AM UTC" : "Not scheduled",
      progress: `${this.series.currentEpisode - 1}/${this.series.totalEpisodes} real videos uploaded`,
      uploadType: "Real YouTube uploads with actual videos"
    };
  }

  public stopAutomation(): void {
    if (this.scheduledTask) {
      this.scheduledTask.stop();
      this.scheduledTask = null;
      console.log("🛑 Real YouTube automation stopped");
    }
  }
}

// Test function for immediate upload
async function testRealUpload() {
  console.log("🧪 TESTING REAL YOUTUBE UPLOAD");
  console.log("Note: This requires valid YouTube OAuth credentials");
  
  const automation = new RealYouTubeAutomation();
  
  // You would need to provide real credentials here
  // const credentials = {
  //   client_id: "your_client_id",
  //   client_secret: "your_client_secret", 
  //   refresh_token: "your_refresh_token"
  // };
  
  // automation.setYouTubeCredentials(credentials);
  // await automation.generateTodaysRealVideo();
  
  console.log("❗ Credentials required for real YouTube upload");
  console.log("📝 Please provide YouTube OAuth credentials to enable real uploads");
}

if (require.main === module) {
  testRealUpload().catch(console.error);
}