import OpenAI from "openai";
import { storage } from "./storage";
import type { YouTubeChannel } from "@shared/schema";
import { createCanvas } from "canvas";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface GeneratedScript {
  title: string;
  description: string;
  scenes: Array<{
    text: string;
    duration: number;
    visualCue: string;
  }>;
  tags: string[];
}

export class ContentGenerator {
  private outputDir = "server/content_output";

  async initialize() {
    await mkdir(this.outputDir, { recursive: true });
    await mkdir(join(this.outputDir, "thumbnails"), { recursive: true });
  }

  async generateScriptsForChannel(
    channel: YouTubeChannel,
    count: number = 5
  ): Promise<string[]> {
    console.log(`\n🎬 Generating ${count} scripts for channel: ${channel.name}`);
    
    const cacheIds: string[] = [];
    
    for (let i = 0; i < count; i++) {
      try {
        const script = await this.generateScript(channel);
        
        const cached = await storage.createCachedContent({
          type: "script",
          channelId: channel.id,
          data: { script },
          isUsed: false,
        });
        
        cacheIds.push(cached.id);
        console.log(`✅ Script ${i + 1}/${count}: "${script.title}"`);
      } catch (error) {
        console.error(`❌ Failed to generate script ${i + 1}:`, error);
      }
    }
    
    return cacheIds;
  }

  async generateThumbnailsForChannel(
    channel: YouTubeChannel,
    count: number = 5
  ): Promise<string[]> {
    console.log(`\n🎨 Generating ${count} thumbnails for channel: ${channel.name}`);
    
    const cacheIds: string[] = [];
    
    for (let i = 0; i < count; i++) {
      try {
        const title = `${channel.name} Episode ${i + 1}`;
        const thumbnailPath = await this.generateThumbnail(channel, title, i);
        
        const cached = await storage.createCachedContent({
          type: "thumbnail",
          channelId: channel.id,
          data: { 
            thumbnailPath,
            metadata: { index: i }
          },
          isUsed: false,
        });
        
        cacheIds.push(cached.id);
        console.log(`✅ Thumbnail ${i + 1}/${count}: ${thumbnailPath}`);
      } catch (error) {
        console.error(`❌ Failed to generate thumbnail ${i + 1}:`, error);
      }
    }
    
    return cacheIds;
  }

  private async generateScript(channel: YouTubeChannel): Promise<GeneratedScript> {
    const topics = channel.contentStrategy.themes || ['educational adventure'];
    const randomTopic = topics[Math.floor(Math.random() * topics.length)];
    
    const prompt = `Create a ${channel.contentStrategy.averageDuration}-second educational video script about "${randomTopic}" for ${channel.targetAudience}.

Requirements:
- Title: Catchy and family-friendly
- Description: SEO-optimized, 2-3 sentences
- 3-4 scenes with dialogue
- Each scene: 20-30 seconds
- Visual cues for each scene
- 5-10 YouTube tags
- Tone: ${channel.contentStrategy.tone}
- G-rated content only

Format as JSON:
{
  "title": "...",
  "description": "...",
  "scenes": [
    {
      "text": "Character speaks...",
      "duration": 25,
      "visualCue": "Visual description..."
    }
  ],
  "tags": ["tag1", "tag2"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a professional educational content creator for YouTube. Generate engaging, family-friendly scripts." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" },
      temperature: 0.8,
    });

    const content = response.choices[0].message.content;
    if (!content) throw new Error("No content generated");
    
    return JSON.parse(content);
  }

  private async generateThumbnail(
    channel: YouTubeChannel,
    title: string,
    index: number
  ): Promise<string> {
    const canvas = createCanvas(1280, 720);
    const ctx = canvas.getContext('2d');

    const colors = channel.branding.colorScheme;
    const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
    gradient.addColorStop(0, colors.primary);
    gradient.addColorStop(1, colors.secondary);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1280, 720);

    ctx.fillStyle = colors.accent;
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 8;
    const padding = 40;
    ctx.fillRect(padding, padding, 1280 - padding * 2, 720 - padding * 2);
    ctx.strokeRect(padding, padding, 1280 - padding * 2, 720 - padding * 2);

    ctx.fillStyle = 'white';
    ctx.font = 'bold 64px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    const words = title.split(' ');
    let line = '';
    let y = 320;
    
    for (const word of words) {
      const testLine = line + word + ' ';
      const metrics = ctx.measureText(testLine);
      if (metrics.width > 1100 && line !== '') {
        ctx.fillText(line, 640, y);
        line = word + ' ';
        y += 80;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, 640, y);

    ctx.font = 'bold 40px Arial';
    ctx.fillStyle = colors.primary;
    ctx.fillText(channel.name, 640, 620);

    const filename = `thumbnail_${channel.id}_${index}_${Date.now()}.png`;
    const filepath = join(this.outputDir, "thumbnails", filename);
    
    const buffer = canvas.toBuffer('image/png');
    await writeFile(filepath, buffer);
    
    return filepath;
  }
}
