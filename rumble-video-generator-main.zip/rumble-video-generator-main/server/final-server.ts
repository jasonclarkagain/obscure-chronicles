import express from 'express';
import { google } from 'googleapis';

const app = express();

// Basic middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

const YOUTUBE_CREDENTIALS = {
  client_id: process.env.GOOGLE_CLIENT_ID || "",
  client_secret: process.env.GOOGLE_CLIENT_SECRET || ""
};

// Validate credentials are present
if (!YOUTUBE_CREDENTIALS.client_id || !YOUTUBE_CREDENTIALS.client_secret) {
  console.error('ERROR: Missing Google OAuth credentials. Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in Replit Secrets.');
  process.exit(1);
}

const PORT = 3000;
const DOMAIN = process.env.REPLIT_DEV_DOMAIN;
const BASE_URL = DOMAIN ? `https://${DOMAIN}` : `http://localhost:${PORT}`;
const REDIRECT_URI = `${BASE_URL}/oauth2callback`;

console.log('Starting YouTube Automation Server...');
console.log('Base URL:', BASE_URL);
console.log('Redirect URI:', REDIRECT_URI);

app.get('/', (req, res) => {
  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Automation - Ready</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            max-width: 500px;
            margin: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            background: linear-gradient(45deg, #fff, #f093fb);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        h2 {
            color: #f093fb;
            margin-bottom: 30px;
            font-weight: 400;
        }
        .status-card {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        .auth-button {
            display: inline-block;
            background: linear-gradient(45deg, #f093fb, #f5576c);
            color: white;
            text-decoration: none;
            padding: 15px 30px;
            border-radius: 50px;
            font-weight: bold;
            font-size: 18px;
            margin: 20px 0;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(240, 147, 251, 0.4);
        }
        .auth-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(240, 147, 251, 0.6);
        }
        .feature {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 10px 0;
            font-size: 1.1rem;
        }
        .check {
            color: #4CAF50;
            margin-right: 10px;
            font-weight: bold;
        }
        .account {
            color: #f093fb;
            font-weight: bold;
            font-size: 1.2rem;
        }
        .info {
            font-size: 0.9rem;
            opacity: 0.8;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>YouTube Automation</h1>
        <h2>Amazing Learning Adventures</h2>
        
        <div class="status-card">
            <h3>System Status</h3>
            <div class="feature"><span class="check">✓</span> Video generation pipeline ready</div>
            <div class="feature"><span class="check">✓</span> 30-day educational series prepared</div>
            <div class="feature"><span class="check">✓</span> YouTube API integration active</div>
            <div class="feature"><span class="check">✓</span> OAuth configuration verified</div>
        </div>
        
        <p>YouTube Account: <span class="account">jasonclarkagain@gmail.com</span></p>
        
        <a href="/authorize" class="auth-button">
            🔐 Authorize YouTube Access
        </a>
        
        <div class="status-card">
            <h4>After Authorization</h4>
            <div class="feature">📤 Episode 1 uploads immediately</div>
            <div class="feature">⏰ Daily videos at 9:00 AM UTC</div>
            <div class="feature">🎬 30 educational episodes</div>
            <div class="feature">📊 Automated progress tracking</div>
        </div>
        
        <div class="info">
            <p>Server: ${BASE_URL}</p>
            <p>OAuth Redirect: ${REDIRECT_URI}</p>
        </div>
    </div>
</body>
</html>`;
  
  res.send(html);
});

app.get('/authorize', (req, res) => {
  try {
    const oauth2Client = new google.auth.OAuth2(
      YOUTUBE_CREDENTIALS.client_id,
      YOUTUBE_CREDENTIALS.client_secret,
      REDIRECT_URI
    );

    const scopes = [
      'https://www.googleapis.com/auth/youtube.upload',
      'https://www.googleapis.com/auth/youtube'
    ];

    const authUrl = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent'
    });

    console.log('Redirecting to auth URL:', authUrl);
    res.redirect(authUrl);
  } catch (error) {
    console.error('Authorization error:', error);
    res.status(500).send('Authorization setup failed');
  }
});

app.get('/oauth2callback', async (req, res) => {
  const code = req.query.code as string;
  const error = req.query.error;

  if (error) {
    res.send(`
      <html>
        <body style="font-family: Arial; padding: 50px; text-align: center; background: #f44336; color: white;">
          <h1>Authorization Cancelled</h1>
          <p>Error: ${error}</p>
          <a href="/" style="color: white;">Try Again</a>
        </body>
      </html>
    `);
    return;
  }

  if (!code) {
    res.send(`
      <html>
        <body style="font-family: Arial; padding: 50px; text-align: center; background: #f44336; color: white;">
          <h1>No Authorization Code</h1>
          <a href="/" style="color: white;">Try Again</a>
        </body>
      </html>
    `);
    return;
  }

  try {
    const oauth2Client = new google.auth.OAuth2(
      YOUTUBE_CREDENTIALS.client_id,
      YOUTUBE_CREDENTIALS.client_secret,
      REDIRECT_URI
    );

    const { tokens } = await oauth2Client.getToken(code);
    
    console.log('Tokens received successfully');
    console.log('Access token:', tokens.access_token ? 'RECEIVED' : 'MISSING');
    console.log('Refresh token:', tokens.refresh_token ? 'RECEIVED' : 'MISSING');

    // Test YouTube access
    oauth2Client.setCredentials(tokens);
    const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
    
    const channelResponse = await youtube.channels.list({
      part: ['snippet'],
      mine: true
    });

    const channelName = channelResponse.data.items?.[0]?.snippet?.title || 'Channel';
    
    const successHtml = `
<!DOCTYPE html>
<html>
<head>
    <title>Authorization Successful</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #4CAF50, #45a049);
            color: white;
            margin: 0;
            padding: 50px;
            text-align: center;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 40px;
            max-width: 600px;
        }
        .success {
            background: rgba(76, 175, 80, 0.3);
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
            border: 2px solid rgba(76, 175, 80, 0.5);
        }
        .token-box {
            background: rgba(0, 0, 0, 0.3);
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
            font-family: monospace;
            word-break: break-all;
            font-size: 14px;
            text-align: left;
        }
        .info {
            background: rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>✅ Authorization Successful!</h1>
        
        <div class="success">
            <h2>YouTube Channel Connected</h2>
            <p><strong>Channel:</strong> ${channelName}</p>
            <p><strong>Account:</strong> jasonclarkagain@gmail.com</p>
        </div>
        
        <div class="info">
            <h3>Tokens Received</h3>
            <p><strong>Access Token:</strong> ${tokens.access_token ? '✅ RECEIVED' : '❌ NOT RECEIVED'}</p>
            <p><strong>Refresh Token:</strong> ${tokens.refresh_token ? '✅ RECEIVED' : '❌ NOT RECEIVED'}</p>
        </div>
        
        <div class="token-box">
            <strong>Refresh Token:</strong><br>
            ${tokens.refresh_token || 'NOT RECEIVED'}
        </div>
        
        <div class="info">
            <h4>Ready for Video Automation</h4>
            <p>✅ YouTube API access confirmed</p>
            <p>✅ Upload permissions granted</p>
            <p>✅ Ready to start 30-day series</p>
        </div>
        
        <p>Save the refresh token above. You can now close this window.</p>
    </div>
</body>
</html>`;

    res.send(successHtml);
    
    console.log('🎉 AUTHORIZATION COMPLETE!');
    console.log('Channel:', channelName);
    console.log('Refresh token available for automation setup');
    
  } catch (error) {
    console.error('Token exchange failed:', error);
    res.status(500).send(`
      <html>
        <body style="font-family: Arial; padding: 50px; text-align: center; background: #f44336; color: white;">
          <h1>Authorization Failed</h1>
          <p>Error: ${error.message}</p>
          <a href="/" style="color: white;">Try Again</a>
        </body>
      </html>
    `);
  }
});

app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    server: 'YouTube Automation System',
    timestamp: new Date().toISOString(),
    baseUrl: BASE_URL,
    redirectUri: REDIRECT_URI
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('🚀 YouTube Automation Server Running');
  console.log('=====================================');
  console.log(`Port: ${PORT}`);
  console.log(`Base URL: ${BASE_URL}`);
  console.log(`OAuth Redirect: ${REDIRECT_URI}`);
  console.log('Ready for YouTube authorization');
});