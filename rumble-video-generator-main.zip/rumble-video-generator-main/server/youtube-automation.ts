import postgres from 'postgres';
import { nanoid } from 'nanoid';
import { youtubeUploader, YouTubeUploadConfig } from './youtube-uploader';
import dotenv from 'dotenv';
import cron from 'node-cron';

dotenv.config();

const client = postgres(process.env.DATABASE_URL!);

interface VideoGenerationTemplate {
  day: number;
  topic: string;
  title: string;
  description: string;
  tags: string[];
  scenes: any[];
}

class YouTubeAutomationScheduler {
  private uploadScheduler: cron.ScheduledTask | null = null;
  private dayCounter = 1;

  constructor() {
    this.initializeAutomation();
  }

  private initializeAutomation() {
    console.log('🎬 YouTube Automation initialized for jasonclarkagain@gmail.com');
    console.log('📺 Starting 30-day automated video generation and upload...');

    // Daily video generation and upload at 9:00 AM UTC
    this.uploadScheduler = cron.schedule('0 9 * * *', async () => {
      await this.generateAndUploadDaily();
    }, {
      scheduled: true,
      timezone: 'UTC'
    });

    // Generate first video immediately
    this.generateAndUploadDaily();
  }

  private async generateAndUploadDaily(): Promise<void> {
    try {
      console.log(`📅 Day ${this.dayCounter}: Generating and uploading educational video...`);

      // Get active themes and characters
      const [themes, characters] = await Promise.all([
        client`SELECT * FROM video_themes WHERE is_active = true ORDER BY RANDOM() LIMIT 1`,
        client`SELECT * FROM characters WHERE is_active = true ORDER BY RANDOM() LIMIT 3`
      ]);

      if (themes.length === 0 || characters.length === 0) {
        throw new Error('No active themes or characters available');
      }

      const theme = themes[0];
      const selectedCharacters = characters;

      // Generate video content
      const videoTemplate = this.createDailyVideo(this.dayCounter, theme, selectedCharacters);
      
      // Create video in database
      const videoId = await this.saveVideoToDatabase(videoTemplate, theme.id);
      
      // Prepare for YouTube upload
      const uploadConfig: YouTubeUploadConfig = {
        title: videoTemplate.title,
        description: this.createYouTubeDescription(videoTemplate),
        tags: videoTemplate.tags,
        categoryId: '27', // Education
        privacyStatus: 'public'
      };

      // Simulate video file path (in production, this would be the actual rendered video)
      const videoFilePath = `/tmp/video_${videoId}.mp4`;
      
      // Upload to YouTube
      const uploadResult = await youtubeUploader.uploadVideo(videoFilePath, uploadConfig);
      
      if (uploadResult.success) {
        // Update video record with YouTube details
        const updatedMetadata = {
          ...JSON.parse(await client`SELECT metadata FROM videos WHERE id = ${videoId}`.then(r => r[0].metadata)),
          youtube_video_id: uploadResult.videoId,
          youtube_url: uploadResult.url,
          uploaded_at: new Date().toISOString()
        };

        await client`
          UPDATE videos 
          SET metadata = ${JSON.stringify(updatedMetadata)},
              status = 'uploaded'
          WHERE id = ${videoId}
        `;

        console.log(`✅ Day ${this.dayCounter} video uploaded to YouTube: ${uploadResult.url}`);
      } else {
        console.error(`❌ Day ${this.dayCounter} upload failed: ${uploadResult.error}`);
      }

      this.dayCounter++;

      // Stop after 30 days
      if (this.dayCounter > 30) {
        console.log('🎯 30-day YouTube automation completed!');
        this.stopAutomation();
      }

    } catch (error) {
      console.error(`❌ Day ${this.dayCounter} automation failed:`, error);
    }
  }

  private createDailyVideo(day: number, theme: any, characters: any[]): VideoGenerationTemplate {
    const topics = [
      'Ocean Conservation', 'Space Exploration', 'Renewable Energy', 'Animal Habitats',
      'Weather Patterns', 'Plant Growth', 'Recycling Adventures', 'Healthy Eating',
      'Solar System', 'Water Cycle', 'Friendship Values', 'Cultural Diversity',
      'Math in Nature', 'Science Experiments', 'History Heroes', 'Art & Creativity',
      'Music & Rhythm', 'Community Helpers', 'Transportation', 'Geography Fun',
      'Language Learning', 'Safety First', 'Time & Seasons', 'Inventions',
      'Dinosaur Discovery', 'Underwater World', 'Forest Ecosystem', 'Desert Life',
      'Arctic Animals', 'Volcano Science'
    ];

    const topic = topics[(day - 1) % topics.length];
    const mainCharacter = characters[0]?.name || 'Captain Marina';
    const supportCharacter1 = characters[1]?.name || 'Curious Casey';
    const supportCharacter2 = characters[2]?.name || 'Luna the Storyteller';

    return {
      day,
      topic,
      title: `${topic} Adventure - Educational Series Day ${day}`,
      description: `Join ${mainCharacter} and friends in today's educational adventure exploring ${topic.toLowerCase()}! Perfect for kids and families.`,
      tags: [
        'educational videos for kids',
        'children learning',
        topic.toLowerCase(),
        'family friendly',
        'animation',
        'educational content',
        'kids entertainment',
        'learning adventure',
        'G rated'
      ],
      scenes: [
        {
          id: 'intro',
          duration: 25,
          dialog: [
            {
              character: mainCharacter,
              text: `Welcome back, young explorers! I'm ${mainCharacter}, and today we're discovering the amazing world of ${topic.toLowerCase()}!`,
              timing: { start: 0, end: 7 }
            },
            {
              character: supportCharacter1,
              text: `I can't wait to learn! What exciting things will we find out about ${topic.toLowerCase()} today?`,
              timing: { start: 8, end: 14 }
            }
          ],
          visualDescription: `Bright, colorful animated introduction featuring ${topic.toLowerCase()} elements with engaging educational graphics`,
          ambientSounds: ['upbeat learning music', 'positive atmosphere'],
          soundEffects: ['welcome chimes', 'adventure sounds']
        },
        {
          id: 'learning',
          duration: 40,
          dialog: [
            {
              character: supportCharacter2,
              text: `Great question! ${topic} is fascinating because it teaches us how our world works and how we can make it better!`,
              timing: { start: 0, end: 8 }
            },
            {
              character: mainCharacter,
              text: `That's exactly right! Let me show you some incredible facts that will amaze you and help you understand ${topic.toLowerCase()} better.`,
              timing: { start: 9, end: 17 }
            },
            {
              character: supportCharacter1,
              text: `Wow! This is so cool! I love learning new things every day!`,
              timing: { start: 18, end: 23 }
            }
          ],
          visualDescription: `Educational sequence with animated demonstrations of ${topic.toLowerCase()} concepts, featuring clear visuals and interactive elements`,
          ambientSounds: ['inspiring background music', 'educational atmosphere'],
          soundEffects: ['discovery sounds', 'positive learning chimes']
        },
        {
          id: 'conclusion',
          duration: 25,
          dialog: [
            {
              character: supportCharacter2,
              text: `Remember, learning about ${topic.toLowerCase()} helps us become better friends to our planet and each other!`,
              timing: { start: 0, end: 7 }
            },
            {
              character: supportCharacter1,
              text: `I'm going to share what I learned with my family! Thank you for this amazing adventure!`,
              timing: { start: 8, end: 14 }
            },
            {
              character: mainCharacter,
              text: `You're welcome! Keep exploring, keep learning, and join us tomorrow for another exciting educational journey!`,
              timing: { start: 15, end: 22 }
            }
          ],
          visualDescription: `Uplifting conclusion with characters celebrating learning achievements and encouraging continued education`,
          ambientSounds: ['celebratory music', 'positive conclusion'],
          soundEffects: ['success sounds', 'farewell chimes']
        }
      ]
    };
  }

  private async saveVideoToDatabase(template: VideoGenerationTemplate, themeId: string): Promise<string> {
    const videoId = nanoid();
    
    const video = {
      id: videoId,
      title: template.title,
      description: template.description,
      theme_id: themeId,
      status: 'completed',
      script: {
        scenes: template.scenes
      },
      metadata: {
        duration: template.scenes.reduce((total, scene) => total + scene.duration, 0),
        resolution: { width: 1920, height: 1080 },
        fps: 30,
        educational_objectives: [
          `Understanding ${template.topic.toLowerCase()} concepts`,
          'Critical thinking development',
          'Environmental awareness',
          'Social learning skills'
        ],
        content_rating: 'G - Family Friendly',
        generation_day: template.day,
        topic: template.topic,
        youtube_tags: template.tags,
        automated_generation: true,
        youtube_account: 'jasonclarkagain@gmail.com'
      },
      created_at: new Date(),
      completed_at: new Date()
    };

    await client`
      INSERT INTO videos (id, title, description, theme_id, status, script, metadata, created_at, completed_at)
      VALUES (
        ${video.id},
        ${video.title},
        ${video.description},
        ${video.theme_id},
        ${video.status},
        ${JSON.stringify(video.script)},
        ${JSON.stringify(video.metadata)},
        ${video.created_at},
        ${video.completed_at}
      )
    `;

    return videoId;
  }

  private createYouTubeDescription(template: VideoGenerationTemplate): string {
    return `🎓 ${template.title}

📚 Educational Adventure Series - Day ${template.day}

Join our educational adventure as we explore ${template.topic.toLowerCase()} in this fun, family-friendly animated story! Perfect for children, students, and anyone who loves learning.

🌟 What You'll Learn:
• ${template.topic} fundamentals and concepts
• Critical thinking and problem-solving skills
• Environmental awareness and responsibility
• The importance of curiosity and exploration

👨‍👩‍👧‍👦 Perfect for:
• Kids ages 4-12
• Homeschool families
• Classroom learning
• Family entertainment time

🔔 Subscribe for daily educational adventures!
💚 Like if you enjoyed learning with us today!
💬 Comment with what you'd like to learn about next!

#EducationalVideos #KidsLearning #FamilyFriendly #Educational #Animation #Learning #${template.topic.replace(' ', '')}

Created with AI-powered educational content generation.
Content is G-rated and appropriate for all ages.

© ${new Date().getFullYear()} AI Educational Adventures`;
  }

  public getAutomationStatus(): any {
    return {
      active: this.uploadScheduler !== null,
      current_day: this.dayCounter,
      remaining_days: Math.max(0, 30 - this.dayCounter + 1),
      youtube_account: 'jasonclarkagain@gmail.com',
      next_upload: this.uploadScheduler ? 'Daily at 9:00 AM UTC' : 'Inactive',
      total_planned: 30
    };
  }

  public stopAutomation(): void {
    if (this.uploadScheduler) {
      this.uploadScheduler.stop();
      this.uploadScheduler = null;
      console.log('🛑 YouTube automation stopped');
    }
  }
}

// Initialize YouTube automation
const youtubeAutomation = new YouTubeAutomationScheduler();

export { YouTubeAutomationScheduler, youtubeAutomation };