import express from 'express';
import { google } from 'googleapis';
import cors from 'cors';

const app = express();
app.use(cors());

const CREDENTIALS = {
  client_id: "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com",
  client_secret: "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"
};

// Get the correct base URL
const port = process.env.PORT || 3000;
const baseUrl = process.env.REPLIT_DEV_DOMAIN 
  ? `https://${process.env.REPLIT_DEV_DOMAIN}` 
  : `http://localhost:${port}`;

const redirectUri = `${baseUrl}/oauth2callback`;

app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>YouTube Automation</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          body { 
            font-family: Arial, sans-serif; 
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white; 
            text-align: center; 
            padding: 50px; 
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .container {
            background: rgba(255,255,255,0.1);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            max-width: 500px;
          }
          .button {
            background: #f093fb;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            margin: 20px 0;
            transition: transform 0.2s;
          }
          .button:hover { transform: scale(1.05); }
          .info { 
            background: rgba(255,255,255,0.2); 
            padding: 20px; 
            border-radius: 10px; 
            margin: 20px 0; 
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>YouTube Automation System</h1>
          <h2>Amazing Learning Adventures</h2>
          
          <div class="info">
            <h3>System Status: READY</h3>
            <p>Professional video generation prepared</p>
            <p>30-day educational series scripted</p>
            <p>YouTube API integration active</p>
          </div>
          
          <p><strong>YouTube Account:</strong><br>jasonclarkagain@gmail.com</p>
          
          <a href="/authorize" class="button">
            🔐 Authorize YouTube Access
          </a>
          
          <div class="info">
            <p><strong>After authorization:</strong></p>
            <p>• Episode 1 uploads immediately</p>
            <p>• Daily automation activates</p>
            <p>• 30 educational videos over 30 days</p>
            <p>• Upload time: 9:00 AM UTC daily</p>
          </div>
          
          <p><small>Redirect URI: ${redirectUri}</small></p>
        </div>
      </body>
    </html>
  `);
});

app.get('/authorize', (req, res) => {
  const oauth2Client = new google.auth.OAuth2(
    CREDENTIALS.client_id,
    CREDENTIALS.client_secret,
    redirectUri
  );

  const authUrl = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: [
      'https://www.googleapis.com/auth/youtube.upload',
      'https://www.googleapis.com/auth/youtube'
    ],
    prompt: 'consent'
  });

  console.log('Generated auth URL:', authUrl);
  res.redirect(authUrl);
});

app.get('/oauth2callback', async (req, res) => {
  const code = req.query.code as string;
  
  if (!code) {
    res.status(400).send(`
      <html>
        <body style="font-family: Arial; padding: 50px; text-align: center;">
          <h1 style="color: red;">No Authorization Code</h1>
          <p>The authorization was cancelled or failed.</p>
          <a href="/authorize">Try Again</a>
        </body>
      </html>
    `);
    return;
  }

  try {
    const oauth2Client = new google.auth.OAuth2(
      CREDENTIALS.client_id,
      CREDENTIALS.client_secret,
      redirectUri
    );

    const { tokens } = await oauth2Client.getToken(code);
    
    console.log('OAuth successful! Tokens received:', {
      access_token: tokens.access_token ? 'RECEIVED' : 'MISSING',
      refresh_token: tokens.refresh_token ? 'RECEIVED' : 'MISSING'
    });

    // Test YouTube access
    oauth2Client.setCredentials(tokens);
    const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
    
    const channelResponse = await youtube.channels.list({
      part: ['snippet'],
      mine: true
    });

    const channelName = channelResponse.data.items?.[0]?.snippet?.title || 'Unknown';
    
    res.send(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Authorization Successful</title>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: Arial, sans-serif; 
              background: linear-gradient(135deg, #667eea, #764ba2);
              color: white; 
              text-align: center; 
              padding: 50px; 
              margin: 0;
              min-height: 100vh;
              display: flex;
              align-items: center;
              justify-content: center;
            }
            .container {
              background: rgba(255,255,255,0.1);
              padding: 40px;
              border-radius: 20px;
              backdrop-filter: blur(10px);
              max-width: 500px;
            }
            .success {
              background: rgba(76, 175, 80, 0.3);
              padding: 20px;
              border-radius: 10px;
              margin: 20px 0;
            }
            .info {
              background: rgba(255,255,255,0.2);
              padding: 20px;
              border-radius: 10px;
              margin: 20px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>✅ Authorization Successful!</h1>
            
            <div class="success">
              <h2>YouTube Channel Connected</h2>
              <p><strong>Channel:</strong> ${channelName}</p>
              <p><strong>Account:</strong> jasonclarkagain@gmail.com</p>
            </div>
            
            <div class="info">
              <h3>Ready for Video Upload</h3>
              <p><strong>Refresh Token:</strong> ${tokens.refresh_token ? 'RECEIVED' : 'NOT RECEIVED'}</p>
              <p><strong>Access Token:</strong> ${tokens.access_token ? 'RECEIVED' : 'NOT RECEIVED'}</p>
            </div>
            
            <div class="info">
              <h4>Next Steps:</h4>
              <p>1. Copy your refresh token (shown above)</p>
              <p>2. Use it to initialize the automation system</p>
              <p>3. Videos will upload automatically</p>
            </div>
            
            <p>You can close this window.</p>
            
            <div style="background: rgba(0,0,0,0.3); padding: 15px; border-radius: 10px; margin: 20px 0; font-family: monospace; word-break: break-all;">
              <strong>Refresh Token:</strong><br>
              ${tokens.refresh_token || 'NOT RECEIVED - Try authorization again'}
            </div>
          </div>
        </body>
      </html>
    `);

    // TODO: Here you would normally start the automation with the refresh token
    console.log('🎉 AUTHORIZATION COMPLETE!');
    console.log('Channel:', channelName);
    console.log('Ready to start video automation');
    
  } catch (error) {
    console.error('Authorization failed:', error);
    res.status(500).send(`
      <html>
        <body style="font-family: Arial; padding: 50px; text-align: center;">
          <h1 style="color: red;">Authorization Failed</h1>
          <p>Error: ${error.message}</p>
          <a href="/authorize">Try Again</a>
        </body>
      </html>
    `);
  }
});

app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    server: 'YouTube Automation', 
    timestamp: new Date().toISOString(),
    redirectUri: redirectUri 
  });
});

app.listen(port, '0.0.0.0', () => {
  console.log('🚀 YouTube Automation Server Started');
  console.log('=====================================');
  console.log(`Port: ${port}`);
  console.log(`Base URL: ${baseUrl}`);
  console.log(`OAuth Redirect: ${redirectUri}`);
  console.log('✅ Ready for YouTube authorization');
});