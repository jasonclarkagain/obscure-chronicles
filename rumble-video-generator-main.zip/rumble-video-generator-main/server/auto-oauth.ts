#!/usr/bin/env npx tsx

import { google } from 'googleapis';
import http from 'http';
import url from 'url';
import open from 'open';
import { CompleteYouTubeAutomation } from './complete-youtube-automation';

const CREDENTIALS = {
  client_id: "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com",
  client_secret: "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",
  redirect_uri: "http://localhost:3000/oauth2callback"
};

async function automaticOAuthFlow(): Promise<string> {
  return new Promise((resolve, reject) => {
    const oauth2Client = new google.auth.OAuth2(
      CREDENTIALS.client_id,
      CREDENTIALS.client_secret,
      CREDENTIALS.redirect_uri
    );

    const scopes = [
      'https://www.googleapis.com/auth/youtube.upload',
      'https://www.googleapis.com/auth/youtube'
    ];

    const authUrl = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent'
    });

    const server = http.createServer(async (req, res) => {
      if (req.url?.startsWith('/oauth2callback')) {
        const parsedUrl = url.parse(req.url, true);
        const code = parsedUrl.query.code as string;

        if (code) {
          try {
            const { tokens } = await oauth2Client.getToken(code);
            
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(`
              <html>
                <body style="font-family: Arial, sans-serif; padding: 50px; text-align: center;">
                  <h1 style="color: green;">✅ Authorization Successful!</h1>
                  <p>YouTube automation is starting...</p>
                  <p>You can close this window.</p>
                  <div style="background: #f0f0f0; padding: 20px; margin: 20px; border-radius: 10px;">
                    <h3>Automation Status</h3>
                    <p>🎬 First video will be generated and uploaded now</p>
                    <p>📅 Daily uploads scheduled for 9:00 AM UTC</p>
                    <p>📺 Channel: jasonclarkagain@gmail.com</p>
                  </div>
                </body>
              </html>
            `);

            server.close();
            resolve(tokens.refresh_token!);
          } catch (error) {
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end('Error: ' + error.message);
            server.close();
            reject(error);
          }
        } else {
          res.writeHead(400, { 'Content-Type': 'text/plain' });
          res.end('No authorization code received');
          server.close();
          reject(new Error('No authorization code'));
        }
      }
    });

    server.listen(3000, async () => {
      console.log('🔐 Starting automatic OAuth flow...');
      console.log('📱 Opening browser for authorization...');
      console.log('🔗 If browser doesn\'t open, go to:');
      console.log(authUrl);
      console.log('');
      console.log('👤 Sign in with: jasonclarkagain@gmail.com');
      
      try {
        await open(authUrl);
      } catch (error) {
        console.log('❗ Please manually open the URL above');
      }
    });
  });
}

async function main() {
  try {
    console.log('🚀 YouTube Automation Setup');
    console.log('============================\n');
    
    console.log('🔑 Getting authorization...');
    const refreshToken = await automaticOAuthFlow();
    
    console.log('✅ Authorization complete!');
    console.log('🎬 Starting YouTube automation...\n');
    
    const automation = new CompleteYouTubeAutomation();
    const initialized = await automation.initializeWithRefreshToken(refreshToken);
    
    if (initialized) {
      await automation.startDailyAutomation();
      
      console.log('\n🎉 SUCCESS! YouTube automation is running!');
      console.log('📺 Videos uploading to: jasonclarkagain@gmail.com');
      console.log('🕘 Schedule: Daily at 9:00 AM UTC for 30 days');
      
      const status = automation.getStatus();
      console.log('📊 Status:', status.progress);
      
    } else {
      console.log('❌ Failed to initialize YouTube automation');
    }
    
  } catch (error) {
    console.error('❌ Setup failed:', error);
  }
}

if (require.main === module) {
  main().catch(console.error);
}