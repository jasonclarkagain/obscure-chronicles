import { createCanvas, loadImage } from "canvas";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

interface Scene {
  text: string;
  duration: number;
  visualCue: string;
}

interface RenderOptions {
  outputPath: string;
  title: string;
  scenes: Scene[];
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
}

export class VideoRenderer {
  private tempDir = "server/temp_frames";
  private fps = 10;

  async initialize() {
    await mkdir(this.tempDir, { recursive: true });
  }

  async renderVideo(options: RenderOptions): Promise<void> {
    console.log(`\n🎬 Starting video render: ${options.title}`);
    console.log(`📊 Scenes: ${options.scenes.length}, Total duration: ${options.scenes.reduce((sum, s) => sum + s.duration, 0)}s`);

    const frames: string[] = [];
    let frameIndex = 0;

    for (let sceneIndex = 0; sceneIndex < options.scenes.length; sceneIndex++) {
      const scene = options.scenes[sceneIndex];
      const sceneFrames = Math.floor(scene.duration * this.fps);
      
      console.log(`🎨 Rendering scene ${sceneIndex + 1}/${options.scenes.length}: ${sceneFrames} frames`);

      for (let i = 0; i < sceneFrames; i++) {
        const progress = i / sceneFrames;
        const framePath = await this.renderFrame({
          sceneIndex,
          frameInScene: i,
          totalFramesInScene: sceneFrames,
          progress,
          text: scene.text,
          visualCue: scene.visualCue,
          primaryColor: options.primaryColor,
          secondaryColor: options.secondaryColor,
          accentColor: options.accentColor,
          frameNumber: frameIndex,
        });
        
        frames.push(framePath);
        frameIndex++;

        if (i % 30 === 0) {
          process.stdout.write(`\r   Frame ${i}/${sceneFrames}`);
        }
      }
      console.log(`\r   ✅ Scene ${sceneIndex + 1} complete: ${sceneFrames} frames`);
    }

    console.log(`\n🎞️  Encoding ${frames.length} frames to video...`);
    await this.encodeFramesToVideo(frames, options.outputPath);
    
    console.log(`✅ Video saved: ${options.outputPath}`);
  }

  private async renderFrame(options: {
    sceneIndex: number;
    frameInScene: number;
    totalFramesInScene: number;
    progress: number;
    text: string;
    visualCue: string;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    frameNumber: number;
  }): Promise<string> {
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');

    const gradient = ctx.createLinearGradient(0, 0, 1920, 1080);
    gradient.addColorStop(0, options.primaryColor);
    gradient.addColorStop(0.5, options.secondaryColor);
    gradient.addColorStop(1, options.accentColor);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1920, 1080);

    const animationOffset = Math.sin(options.progress * Math.PI) * 50;
    
    ctx.save();
    ctx.translate(960 + animationOffset, 540);
    ctx.rotate((options.progress - 0.5) * 0.1);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.arc(0, 0, 200 + i * 100, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    const textBoxHeight = 300;
    const textBoxY = 1080 - textBoxHeight - 50;
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(50, textBoxY, 1920 - 100, textBoxHeight);
    
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 4;
    ctx.strokeRect(50, textBoxY, 1920 - 100, textBoxHeight);

    ctx.fillStyle = 'white';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    
    const words = options.text.split(' ');
    let line = '';
    let y = textBoxY + 40;
    const maxWidth = 1920 - 140;
    
    for (const word of words) {
      const testLine = line + word + ' ';
      const metrics = ctx.measureText(testLine);
      
      if (metrics.width > maxWidth && line !== '') {
        ctx.fillText(line, 960, y);
        line = word + ' ';
        y += 60;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, 960, y);

    ctx.font = '32px Arial';
    ctx.fillStyle = options.accentColor;
    ctx.fillText(`Scene ${options.sceneIndex + 1}`, 960, textBoxY + textBoxHeight - 50);

    const filename = `frame_${String(options.frameNumber).padStart(6, '0')}.png`;
    const filepath = join(this.tempDir, filename);
    
    const buffer = canvas.toBuffer('image/png');
    await writeFile(filepath, buffer);
    
    return filepath;
  }

  private async encodeFramesToVideo(frames: string[], outputPath: string): Promise<void> {
    const framePattern = join(this.tempDir, 'frame_%06d.png');
    
    const ffmpegCommand = `ffmpeg -y -framerate ${this.fps} -i ${framePattern} -c:v libx264 -preset fast -pix_fmt yuv420p -crf 23 ${outputPath}`;
    
    try {
      const { stdout, stderr } = await execAsync(ffmpegCommand);
      console.log('📹 FFmpeg encoding complete');
    } catch (error: any) {
      console.error('FFmpeg error:', error.stderr || error.message);
      throw error;
    }
  }

  async cleanup(): Promise<void> {
    try {
      await execAsync(`rm -rf ${this.tempDir}/*`);
    } catch (error) {
      console.error('Cleanup warning:', error);
    }
  }
}
