import { Router } from "express";
import { IStorage } from "./storage";
import { VideoOrchestratorService } from "./services/videoOrchestrator";
import { YouTubeUploaderService } from "./services/youtubeUploader";
import { SchedulerService } from "./services/scheduler";
import { insertVideoThemeSchema, insertCharacterSchema, createRumbleCampaignSchema, updateRumbleCampaignSchema } from "@shared/schema";
import { z } from "zod";

export function createRoutes(storage: IStorage): Router {
  const router = Router();
  
  // Lazy initialize services only when needed to avoid startup errors
  let orchestrator: VideoOrchestratorService | null = null;
  let youtubeUploader: YouTubeUploaderService | null = null;
  let scheduler: SchedulerService | null = null;
  
  const getOrchestrator = () => {
    if (!orchestrator) orchestrator = new VideoOrchestratorService(storage);
    return orchestrator;
  };
  
  const getYoutubeUploader = () => {
    if (!youtubeUploader) youtubeUploader = new YouTubeUploaderService();
    return youtubeUploader;
  };
  
  const getScheduler = () => {
    if (!scheduler) scheduler = new SchedulerService(storage);
    return scheduler;
  };

  // Video Themes
  router.get("/api/themes", async (req, res) => {
    try {
      const themes = await storage.getVideoThemes();
      res.json(themes);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/themes", async (req, res) => {
    try {
      const themeData = insertVideoThemeSchema.parse(req.body);
      const theme = await storage.createVideoTheme(themeData);
      res.status(201).json(theme);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Validation error", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  router.put("/api/themes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const themeData = insertVideoThemeSchema.partial().parse(req.body);
      const theme = await storage.updateVideoTheme(id, themeData);
      
      if (!theme) {
        return res.status(404).json({ error: "Theme not found" });
      }
      
      res.json(theme);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Validation error", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  router.delete("/api/themes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteVideoTheme(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Theme not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Characters
  router.get("/api/characters", async (req, res) => {
    try {
      const characters = await storage.getCharacters();
      res.json(characters);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/characters", async (req, res) => {
    try {
      const characterData = insertCharacterSchema.parse(req.body);
      const character = await storage.createCharacter(characterData);
      res.status(201).json(character);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Validation error", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  router.put("/api/characters/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const characterData = insertCharacterSchema.partial().parse(req.body);
      const character = await storage.updateCharacter(id, characterData);
      
      if (!character) {
        return res.status(404).json({ error: "Character not found" });
      }
      
      res.json(character);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Validation error", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  router.delete("/api/characters/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteCharacter(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Character not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Videos
  router.get("/api/videos", async (req, res) => {
    try {
      const videos = await storage.getVideos();
      res.json(videos);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/videos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const video = await storage.getVideo(id);
      
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }
      
      res.json(video);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.delete("/api/videos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteVideo(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Video not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Video Generation
  router.post("/api/videos/generate", async (req, res) => {
    try {
      const { themeId } = req.body;
      
      if (!themeId) {
        return res.status(400).json({ error: "Theme ID is required" });
      }

      // Start video generation (async)
      getOrchestrator().generateAndUploadVideo(themeId, (progress) => {
        // In production, you'd use WebSockets or Server-Sent Events for real-time updates
        console.log("Generation progress:", progress);
      }).catch(error => {
        console.error("Video generation failed:", error);
      });

      res.status(202).json({ 
        message: "Video generation started",
        status: "generating"
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/videos/generate-daily", async (req, res) => {
    try {
      // Start daily video generation
      const video = await getOrchestrator().generateDailyVideo();
      res.status(201).json(video);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/videos/:id/progress", async (req, res) => {
    try {
      const { id } = req.params;
      const progress = await getOrchestrator().getVideoGenerationProgress(id);
      
      if (!progress) {
        return res.status(404).json({ error: "Video not found" });
      }
      
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // YouTube Integration
  router.get("/api/youtube/auth-url", async (req, res) => {
    try {
      const authUrl = await getYoutubeUploader().generateAuthUrl();
      res.json({ authUrl });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/youtube/exchange-token", async (req, res) => {
    try {
      const { code } = req.body;
      
      if (!code) {
        return res.status(400).json({ error: "Authorization code is required" });
      }

      const tokens = await getYoutubeUploader().exchangeCodeForTokens(code);
      res.json({ tokens });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/youtube/status", async (req, res) => {
    try {
      const status = await getYoutubeUploader().testConnection();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Scheduler
  router.post("/api/scheduler/start", async (req, res) => {
    try {
      getScheduler().startDailyVideoGeneration();
      res.json({ message: "Scheduler started successfully" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/scheduler/stop", async (req, res) => {
    try {
      getScheduler().stopAllTasks();
      res.json({ message: "Scheduler stopped successfully" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/scheduler/status", async (req, res) => {
    try {
      const status = getScheduler().getSchedulerStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/scheduler/queue", async (req, res) => {
    try {
      const queueStatus = await getScheduler().getGenerationQueueStatus();
      res.json(queueStatus);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/scheduler/schedule", async (req, res) => {
    try {
      const { themeId, scheduledTime } = req.body;
      
      if (!scheduledTime) {
        return res.status(400).json({ error: "Scheduled time is required" });
      }

      await getScheduler().scheduleVideoGeneration(themeId, new Date(scheduledTime));
      res.json({ message: "Video generation scheduled successfully" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // System Status
  router.get("/api/system/status", async (req, res) => {
    try {
      const validation = await getOrchestrator().validateVideoGenerationRequirements();
      const youtubeStatus = await getYoutubeUploader().testConnection();
      const schedulerStatus = getScheduler().getSchedulerStatus();
      
      res.json({
        system: validation,
        youtube: youtubeStatus,
        scheduler: schedulerStatus,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Multi-Channel System Routes
  
  // YouTube Channels
  router.get("/api/youtube-channels", async (req, res) => {
    try {
      const channels = await storage.getYouTubeChannels();
      res.json(channels);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/youtube-channels/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const channel = await storage.getYouTubeChannel(id);
      
      if (!channel) {
        return res.status(404).json({ error: "Channel not found" });
      }
      
      res.json(channel);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/youtube-channels", async (req, res) => {
    try {
      const channel = await storage.createYouTubeChannel(req.body);
      res.status(201).json(channel);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.put("/api/youtube-channels/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const channel = await storage.updateYouTubeChannel(id, req.body);
      
      if (!channel) {
        return res.status(404).json({ error: "Channel not found" });
      }
      
      res.json(channel);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.delete("/api/youtube-channels/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteYouTubeChannel(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Channel not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Episodes
  router.get("/api/episodes", async (req, res) => {
    try {
      const { channelId } = req.query;
      
      if (channelId) {
        const episodes = await storage.getEpisodesByChannel(channelId as string);
        return res.json(episodes);
      }
      
      const episodes = await storage.getEpisodes();
      res.json(episodes);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/episodes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const episode = await storage.getEpisode(id);
      
      if (!episode) {
        return res.status(404).json({ error: "Episode not found" });
      }
      
      res.json(episode);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/episodes", async (req, res) => {
    try {
      const episode = await storage.createEpisode(req.body);
      res.status(201).json(episode);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.put("/api/episodes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const episode = await storage.updateEpisode(id, req.body);
      
      if (!episode) {
        return res.status(404).json({ error: "Episode not found" });
      }
      
      res.json(episode);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.delete("/api/episodes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteEpisode(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Episode not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Content Cache
  router.get("/api/content-cache", async (req, res) => {
    try {
      const cache = await storage.getContentCache();
      res.json(cache);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Multi-Channel Job Operations
  router.post("/api/jobs/cache-content", async (req, res) => {
    try {
      const { channelId, count = 5 } = req.body;
      
      if (!channelId) {
        return res.status(400).json({ error: "Channel ID is required" });
      }

      // Import and initialize ContentGenerator
      const { ContentGenerator } = await import("./content-generator");
      const generator = new ContentGenerator();
      await generator.initialize();

      const channel = await storage.getYouTubeChannel(channelId);
      if (!channel) {
        return res.status(404).json({ error: "Channel not found" });
      }

      // Generate content in background
      Promise.all([
        generator.generateScriptsForChannel(channel, count),
        generator.generateThumbnailsForChannel(channel, count)
      ]).catch(error => {
        console.error("Content generation failed:", error);
      });

      res.status(202).json({ 
        message: `Content caching started for ${count} items`,
        channelId,
        count
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/jobs/create-episodes", async (req, res) => {
    try {
      const { channelId, count = 5 } = req.body;
      
      if (!channelId) {
        return res.status(400).json({ error: "Channel ID is required" });
      }

      const channel = await storage.getYouTubeChannel(channelId);
      if (!channel) {
        return res.status(404).json({ error: "Channel not found" });
      }

      const existingEpisodes = await storage.getEpisodesByChannel(channelId);
      const startNumber = existingEpisodes.length + 1;
      const topics = channel.contentStrategy.themes;

      const createdEpisodes = [];

      for (let i = 0; i < count; i++) {
        const episodeNumber = startNumber + i;
        const topic = topics[i % topics.length];

        const episode = await storage.createEpisode({
          channelId,
          episodeNumber,
          title: `Episode ${episodeNumber}: ${topic}`,
          topic,
          status: "pending",
          phase: "init",
          scriptCacheId: null,
          thumbnailCacheId: null,
          videoPath: null,
          errorMessage: null,
          retryCount: 0,
        });

        createdEpisodes.push(episode);
      }

      res.status(201).json({
        message: `Created ${count} episodes`,
        episodes: createdEpisodes
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/jobs/batch-render", async (req, res) => {
    try {
      const { channelId, count = 5 } = req.body;
      
      if (!channelId) {
        return res.status(400).json({ error: "Channel ID is required" });
      }

      // Import and initialize JobManager
      const { JobManager } = await import("./job-manager");
      const manager = new JobManager();
      await manager.initialize();

      // Start batch processing in background
      manager.batchProcessChannel(channelId, count).catch(error => {
        console.error("Batch processing failed:", error);
      });

      res.status(202).json({ 
        message: `Batch rendering started for ${count} episodes`,
        channelId,
        count
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/jobs/status", async (req, res) => {
    try {
      const { JobManager } = await import("./job-manager");
      const manager = new JobManager();
      const status = await manager.getStatus();

      const channels = await storage.getYouTubeChannels();
      const cache = await storage.getContentCache();
      const unusedCache = cache.filter(c => !c.isUsed);

      res.json({
        episodes: status,
        channels: {
          total: channels.length,
          active: channels.filter(c => c.isActive).length
        },
        cache: {
          scripts: {
            total: cache.filter(c => c.type === "script").length,
            unused: unusedCache.filter(c => c.type === "script").length
          },
          thumbnails: {
            total: cache.filter(c => c.type === "thumbnail").length,
            unused: unusedCache.filter(c => c.type === "thumbnail").length
          }
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Rumble Campaigns
  router.get("/api/rumble/campaigns", async (req, res) => {
    try {
      const campaigns = await storage.getRumbleCampaigns();
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/rumble/campaigns/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const campaign = await storage.getRumbleCampaign(id);
      
      if (!campaign) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      
      res.json(campaign);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/rumble/campaigns", async (req, res) => {
    try {
      const activeCampaign = await storage.getActiveCampaign();
      if (activeCampaign) {
        return res.status(400).json({ 
          error: "An active campaign already exists. Please complete or pause it first." 
        });
      }
      
      const campaignData = createRumbleCampaignSchema.parse({
        ...req.body,
        status: "active",
        startDate: new Date()
      });
      
      const campaign = await storage.createRumbleCampaign(campaignData);
      
      res.status(201).json(campaign);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Validation error", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  router.patch("/api/rumble/campaigns/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = updateRumbleCampaignSchema.parse(req.body);
      
      const campaign = await storage.updateRumbleCampaign(id, updates);
      
      if (!campaign) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      
      res.json(campaign);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Validation error", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  // Rumble Videos
  router.get("/api/rumble/videos", async (req, res) => {
    try {
      const { campaignId } = req.query;
      
      let videos;
      if (campaignId) {
        videos = await storage.getRumbleVideosByCampaign(campaignId as string);
      } else {
        videos = await storage.getRumbleVideos();
      }
      
      res.json(videos);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/rumble/videos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const video = await storage.getRumbleVideo(id);
      
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }
      
      res.json(video);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/rumble/generate", async (req, res) => {
    try {
      const { campaignId, topic } = req.body;
      
      if (!campaignId) {
        return res.status(400).json({ error: "Campaign ID is required" });
      }
      
      const campaign = await storage.getRumbleCampaign(campaignId);
      if (!campaign) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      
      if (campaign.status !== "active") {
        return res.status(400).json({ error: "Campaign is not active" });
      }
      
      const { RumbleGenerationOrchestrator } = await import("./services/rumbleOrchestrator");
      const orchestrator = new RumbleGenerationOrchestrator(storage);
      
      orchestrator.generateVideo(campaignId, topic).catch(error => {
        console.error("Video generation failed:", error);
      });
      
      res.status(202).json({ 
        message: "Video generation started",
        campaignId,
        topic
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/rumble/status", async (req, res) => {
    try {
      const campaigns = await storage.getRumbleCampaigns();
      const videos = await storage.getRumbleVideos();
      const activeCampaign = await storage.getActiveCampaign();
      
      res.json({
        activeCampaign,
        totalCampaigns: campaigns.length,
        totalVideos: videos.length,
        videosByStatus: {
          queued: videos.filter(v => v.status === "queued").length,
          generating: videos.filter(v => v.status === "generating").length,
          completed: videos.filter(v => v.status === "completed").length,
          failed: videos.filter(v => v.status === "failed").length,
          uploaded_gdrive: videos.filter(v => v.status === "uploaded_gdrive").length
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  return router;
}