import fs from 'fs';
import path from 'path';
import { createCanvas } from 'canvas';
import ffmpeg from 'fluent-ffmpeg';

interface Channel {
  id: string;
  name: string;
  theme: string;
  characters: string[];
  targetAudience: string;
  contentStyle: string;
  description: string;
}

interface Episode {
  channelId: string;
  episodeNumber: number;
  title: string;
  topic: string;
  script: any;
  status: 'pending' | 'generating' | 'completed' | 'failed';
  videoPath?: string;
  thumbnailPath?: string;
  createdAt?: string;
}

class DemoMultiChannelManager {
  private channels: Map<string, Channel> = new Map();
  private episodes: Episode[] = [];
  private outputDir: string;

  constructor() {
    this.outputDir = path.join(process.cwd(), 'server', 'demo_multi_channel_output');
    this.initializeChannels();
    this.ensureDirectories();
  }

  private initializeChannels() {
    const channelConfigs = [
      {
        id: 'educational_adventures',
        name: 'Amazing Learning Adventures',
        theme: 'Educational content for children',
        characters: ['Captain Marina', 'Curious Casey', 'Luna'],
        targetAudience: 'Children ages 5-12',
        contentStyle: 'Interactive educational adventures',
        description: 'Educational adventures with Captain Marina and friends'
      },
      {
        id: 'science_explorers',
        name: 'Science Explorers',
        theme: 'Science and discovery',
        characters: ['Dr. Spark', 'Wonder Kid', 'Experiment Bot'],
        targetAudience: 'Students ages 8-14',
        contentStyle: 'Science experiments and explanations',
        description: 'Exciting science experiments and discoveries'
      },
      {
        id: 'story_time_magic',
        name: 'Story Time Magic',
        theme: 'Storytelling and creativity',
        characters: ['Narrator Nova', 'Story Sprite', 'Book Buddy'],
        targetAudience: 'Children ages 3-10',
        contentStyle: 'Interactive storytelling and moral lessons',
        description: 'Magical stories that inspire and teach'
      },
      {
        id: 'math_adventures',
        name: 'Math Adventures',
        theme: 'Mathematics made fun',
        characters: ['Count Captain', 'Number Ninja', 'Equation Explorer'],
        targetAudience: 'Students ages 6-12',
        contentStyle: 'Math concepts through games and adventures',
        description: 'Making math fun and accessible for everyone'
      },
      {
        id: 'creative_crafts',
        name: 'Creative Crafts Corner',
        theme: 'Arts, crafts, and creativity',
        characters: ['Artsy Amy', 'Crafty Carl', 'Creative Chloe'],
        targetAudience: 'Children ages 4-12',
        contentStyle: 'DIY crafts and artistic projects',
        description: 'Inspiring creativity through fun craft projects'
      }
    ];

    channelConfigs.forEach(config => {
      this.channels.set(config.id, config);
    });
  }

  private ensureDirectories() {
    const baseDir = this.outputDir;
    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true });
    }

    this.channels.forEach(channel => {
      const channelDir = path.join(baseDir, channel.id);
      const dirs = [
        channelDir,
        path.join(channelDir, 'videos'),
        path.join(channelDir, 'thumbnails'),
        path.join(channelDir, 'scripts')
      ];

      dirs.forEach(dir => {
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
      });
    });
  }

  private generateTopicsForChannel(channelId: string): string[] {
    const topicSets = {
      educational_adventures: [
        "The Water Cycle Adventure", "Journey Through Solar System", "Amazing Plant Life",
        "Forest Animal Friends", "Weather Around the World", "Ocean Depths Exploration"
      ],
      science_explorers: [
        "Chemical Reactions Lab", "Physics Fun with Magnets", "Electricity Experiments",
        "Light and Colors", "Sound Wave Discovery", "Matter States"
      ],
      story_time_magic: [
        "The Brave Little Mouse", "Magic Garden Adventure", "Friendship Forest",
        "The Kindness Castle", "Rainbow Bridge Mystery", "Helping Hands Village"
      ],
      math_adventures: [
        "Counting Carnival", "Shape Safari", "Pattern Palace",
        "Addition Castle", "Subtraction Station", "Multiplication Mountain"
      ],
      creative_crafts: [
        "Paper Airplane Factory", "Origami Adventure", "Painting Paradise",
        "Clay Creations", "Recycled Art", "Nature Crafts"
      ]
    };

    return topicSets[channelId] || [];
  }

  private generateDemoScript(channelId: string, topic: string, episodeNumber: number): any {
    const channel = this.channels.get(channelId);
    if (!channel) throw new Error(`Channel ${channelId} not found`);

    return {
      channel_id: channelId,
      channel_name: channel.name,
      title: topic,
      episode_number: episodeNumber,
      description: `Educational episode about ${topic} for ${channel.targetAudience}`,
      educational_objectives: [
        "Understand the main concept",
        "Learn through interactive examples",
        "Apply knowledge in real situations"
      ],
      target_audience: channel.targetAudience,
      characters: channel.characters.reduce((acc, char) => {
        acc[char.toLowerCase().replace(/\s+/g, '_')] = `${char} - ${channel.contentStyle}`;
        return acc;
      }, {}),
      scenes: [
        {
          scene_number: 1,
          duration: 60,
          setting: "Educational environment",
          visual_description: "Colorful animated background with characters",
          dialog: [
            {
              character: channel.characters[0],
              text: `Welcome to ${channel.name}! Today we're exploring ${topic}!`,
              emotion: "excited"
            },
            {
              character: channel.characters[1],
              text: `That sounds amazing! What will we learn about ${topic}?`,
              emotion: "curious"
            },
            {
              character: channel.characters[2],
              text: `Let's discover together! This is going to be fun!`,
              emotion: "amazed"
            }
          ],
          educational_focus: "Introduction to the topic",
          interactive_element: "Ask viewers what they already know"
        },
        {
          scene_number: 2,
          duration: 60,
          setting: "Learning demonstration area",
          visual_description: "Visual examples and demonstrations",
          dialog: [
            {
              character: channel.characters[0],
              text: "Let me show you how this works!",
              emotion: "teaching"
            },
            {
              character: channel.characters[1],
              text: "Wow, I never knew that!",
              emotion: "surprised"
            },
            {
              character: channel.characters[2],
              text: "This is so cool! Can we try it?",
              emotion: "excited"
            }
          ],
          educational_focus: "Core concept explanation",
          interactive_element: "Pause and predict what happens next"
        }
      ],
      conclusion: "Great job learning about " + topic + "! You're becoming an expert!",
      call_to_action: "Try this at home and share your discoveries!",
      fun_facts: [
        "Amazing fact about " + topic,
        "Interesting discovery related to " + topic
      ],
      vocabulary: ["concept", "discovery", "learning"]
    };
  }

  async createDemoVideo(channelId: string, episode: Episode): Promise<string> {
    const channel = this.channels.get(channelId);
    if (!channel) throw new Error(`Channel ${channelId} not found`);

    const videoPath = path.join(
      this.outputDir,
      channelId,
      'videos',
      `episode_${episode.episodeNumber.toString().padStart(2, '0')}_${episode.title.replace(/[^a-zA-Z0-9]/g, '_')}.mp4`
    );

    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');

    // Create shorter demo video (30 seconds at 30 FPS = 900 frames)
    const totalFrames = 900;
    const frameDir = path.join(this.outputDir, channelId, 'temp_frames');
    if (!fs.existsSync(frameDir)) {
      fs.mkdirSync(frameDir, { recursive: true });
    }

    console.log(`Creating demo video for ${channel.name}: ${episode.title}`);

    // Generate theme-based color scheme
    const themeColors = this.getThemeColors(channelId);

    for (let frameIndex = 0; frameIndex < totalFrames; frameIndex++) {
      const progress = frameIndex / totalFrames;

      // Dynamic background
      const bgGradient = ctx.createLinearGradient(0, 0, 1920, 1080);
      bgGradient.addColorStop(0, themeColors.primary);
      bgGradient.addColorStop(1, themeColors.secondary);
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, 1920, 1080);

      // Add decorative elements
      this.addThemeDecorations(ctx, channelId, frameIndex);

      // Channel branding
      ctx.fillStyle = themeColors.accent;
      ctx.font = 'bold 42px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(channel.name, 960, 100);

      // Episode title
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 72px Arial';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 6;
      ctx.strokeText(episode.title, 960, 300);
      ctx.fillText(episode.title, 960, 300);

      // Episode info
      ctx.font = 'bold 48px Arial';
      ctx.fillStyle = themeColors.text;
      ctx.fillText(`Episode ${episode.episodeNumber} - DEMO`, 960, 380);

      // Characters
      ctx.font = '36px Arial';
      ctx.fillStyle = themeColors.secondary;
      ctx.fillText(channel.characters.join(' • '), 960, 550);

      // Demo badge
      ctx.fillStyle = 'rgba(255, 215, 0, 0.9)';
      ctx.fillRect(760, 630, 400, 80);
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 32px Arial';
      ctx.fillText('DEMO VERSION', 960, 680);

      // Progress bar
      const progressWidth = 800;
      const progressX = (1920 - progressWidth) / 2;
      const progressY = 750;
      
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.fillRect(progressX, progressY, progressWidth, 20);
      
      ctx.fillStyle = themeColors.accent;
      ctx.fillRect(progressX, progressY, progressWidth * progress, 20);

      // Time indicator
      const seconds = Math.floor(frameIndex / 30);
      ctx.font = '28px Arial';
      ctx.fillStyle = themeColors.secondary;
      ctx.fillText(`0:${seconds.toString().padStart(2, '0')} / 0:30`, 960, 850);

      // Instructions
      ctx.font = '24px Arial';
      ctx.fillStyle = themeColors.text;
      ctx.fillText('Full 5-minute videos will be generated with OpenAI API', 960, 950);

      // Save frame
      const frameBuffer = canvas.toBuffer('image/png');
      const framePath = path.join(frameDir, `frame_${frameIndex.toString().padStart(5, '0')}.png`);
      fs.writeFileSync(framePath, frameBuffer);

      if (frameIndex % 100 === 0) {
        const progressPercent = ((frameIndex / totalFrames) * 100).toFixed(1);
        console.log(`${channel.name}: Frame ${frameIndex}/${totalFrames} (${progressPercent}%)`);
      }
    }

    // Create video with FFmpeg
    return new Promise((resolve, reject) => {
      ffmpeg()
        .input(path.join(frameDir, 'frame_%05d.png'))
        .inputOptions(['-r 30'])
        .outputOptions([
          '-c:v libx264',
          '-pix_fmt yuv420p',
          '-crf 18',
          '-preset fast',
          '-r 30',
          '-t 30'
        ])
        .output(videoPath)
        .on('progress', (progress) => {
          console.log(`${channel.name} video processing: ${progress.percent?.toFixed(1)}%`);
        })
        .on('end', () => {
          fs.rmSync(frameDir, { recursive: true, force: true });
          resolve(videoPath);
        })
        .on('error', reject)
        .run();
    });
  }

  private getThemeColors(channelId: string): { primary: string; secondary: string; accent: string; text: string } {
    const colorSchemes = {
      educational_adventures: {
        primary: '#87CEEB',
        secondary: '#4ECDC4',
        accent: '#FF6B6B',
        text: '#2C3E50'
      },
      science_explorers: {
        primary: '#9B59B6',
        secondary: '#3498DB',
        accent: '#F39C12',
        text: '#FFFFFF'
      },
      story_time_magic: {
        primary: '#E8B4E3',
        secondary: '#FFB6C1',
        accent: '#FFD700',
        text: '#4A0E4E'
      },
      math_adventures: {
        primary: '#28B463',
        secondary: '#5DADE2',
        accent: '#F1C40F',
        text: '#FFFFFF'
      },
      creative_crafts: {
        primary: '#F7DC6F',
        secondary: '#BB8FCE',
        accent: '#58D68D',
        text: '#2C3E50'
      }
    };

    return colorSchemes[channelId] || colorSchemes.educational_adventures;
  }

  private addThemeDecorations(ctx: CanvasRenderingContext2D, channelId: string, frameIndex: number) {
    const decorations = {
      educational_adventures: () => {
        for (let i = 0; i < 8; i++) {
          const x = 100 + (i * 200) + Math.sin(frameIndex * 0.02 + i) * 30;
          const y = 150 + Math.cos(frameIndex * 0.015 + i) * 50;
          const size = 15 + Math.sin(frameIndex * 0.03 + i) * 5;
          
          ctx.fillStyle = 'rgba(135, 206, 235, 0.6)';
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      science_explorers: () => {
        for (let i = 0; i < 6; i++) {
          const centerX = 200 + (i * 250);
          const centerY = 200 + Math.sin(frameIndex * 0.01 + i) * 30;
          
          ctx.fillStyle = 'rgba(244, 156, 18, 0.7)';
          ctx.beginPath();
          ctx.arc(centerX, centerY, 20, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      story_time_magic: () => {
        for (let i = 0; i < 20; i++) {
          const x = (i * 96) % 1920;
          const y = 100 + Math.sin(frameIndex * 0.05 + i) * 50;
          const size = 3 + Math.sin(frameIndex * 0.1 + i) * 2;
          
          ctx.fillStyle = `rgba(255, 215, 0, ${0.3 + Math.sin(frameIndex * 0.05 + i) * 0.3})`;
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      math_adventures: () => {
        for (let i = 0; i < 6; i++) {
          const x = 150 + (i * 280) + Math.sin(frameIndex * 0.02 + i) * 40;
          const y = 180 + Math.cos(frameIndex * 0.015 + i) * 30;
          
          ctx.fillStyle = 'rgba(241, 196, 15, 0.6)';
          ctx.beginPath();
          ctx.arc(x, y, 25, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      creative_crafts: () => {
        for (let i = 0; i < 10; i++) {
          const x = (i * 192) % 1920;
          const y = 150 + Math.sin(frameIndex * 0.03 + i) * 60;
          const size = 20 + Math.sin(frameIndex * 0.04 + i) * 10;
          
          const colors = ['rgba(231, 76, 60, 0.6)', 'rgba(46, 204, 113, 0.6)', 'rgba(52, 152, 219, 0.6)', 'rgba(155, 89, 182, 0.6)'];
          ctx.fillStyle = colors[i % colors.length];
          
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    };

    const decoration = decorations[channelId];
    if (decoration) decoration();
  }

  async createDemoThumbnail(channelId: string, episode: Episode): Promise<string> {
    const channel = this.channels.get(channelId);
    if (!channel) throw new Error(`Channel ${channelId} not found`);

    const thumbnailPath = path.join(
      this.outputDir,
      channelId,
      'thumbnails',
      `episode_${episode.episodeNumber.toString().padStart(2, '0')}_thumbnail.png`
    );

    const canvas = createCanvas(1280, 720);
    const ctx = canvas.getContext('2d');
    const colors = this.getThemeColors(channelId);

    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
    gradient.addColorStop(0, colors.primary);
    gradient.addColorStop(1, colors.secondary);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1280, 720);

    // Channel name
    ctx.fillStyle = colors.accent;
    ctx.font = 'bold 36px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(channel.name, 640, 80);

    // Episode number badge
    ctx.fillStyle = colors.accent;
    ctx.beginPath();
    ctx.arc(150, 150, 80, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = colors.text === '#FFFFFF' ? '#000000' : '#FFFFFF';
    ctx.font = 'bold 48px Arial';
    ctx.fillText(`${episode.episodeNumber}`, 150, 165);

    // Title background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
    ctx.fillRect(0, 250, 1280, 200);

    // Title text
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    ctx.strokeText(episode.title, 640, 320);
    ctx.fillText(episode.title, 640, 320);

    // Demo badge
    ctx.fillStyle = '#FFD700';
    ctx.fillRect(1050, 30, 200, 80);
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('DEMO', 1150, 80);

    // Characters
    ctx.fillStyle = colors.accent;
    ctx.font = '28px Arial';
    ctx.fillText(channel.characters.join(' • '), 640, 520);

    // Target audience
    ctx.fillStyle = colors.text;
    ctx.font = '22px Arial';
    ctx.fillText(channel.targetAudience, 640, 580);

    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(thumbnailPath, buffer);

    return thumbnailPath;
  }

  async processDemoEpisode(channelId: string, episodeNumber: number): Promise<void> {
    const channel = this.channels.get(channelId);
    if (!channel) throw new Error(`Channel ${channelId} not found`);

    const topics = this.generateTopicsForChannel(channelId);
    if (episodeNumber > topics.length) {
      console.log(`No topic for ${channel.name} episode ${episodeNumber}`);
      return;
    }

    const topic = topics[episodeNumber - 1];
    const episode: Episode = {
      channelId,
      episodeNumber,
      title: topic,
      topic,
      script: null,
      status: 'generating',
      createdAt: new Date().toISOString()
    };

    console.log(`\n🎬 Processing Demo ${channel.name} - Episode ${episodeNumber}: ${topic}`);

    try {
      // Generate demo script
      console.log('📝 Generating demo script...');
      episode.script = this.generateDemoScript(channelId, topic, episodeNumber);

      // Save script
      const scriptPath = path.join(
        this.outputDir,
        channelId,
        'scripts',
        `episode_${episodeNumber.toString().padStart(2, '0')}_script.json`
      );
      fs.writeFileSync(scriptPath, JSON.stringify(episode.script, null, 2));

      // Create thumbnail
      console.log('🖼️ Creating thumbnail...');
      episode.thumbnailPath = await this.createDemoThumbnail(channelId, episode);

      // Create video
      console.log('🎥 Creating demo video...');
      episode.videoPath = await this.createDemoVideo(channelId, episode);

      episode.status = 'completed';
      this.episodes.push(episode);

      console.log(`✅ Demo ${channel.name} Episode ${episodeNumber} completed!`);
      console.log(`📹 Video: ${episode.videoPath}`);
      console.log(`🖼️ Thumbnail: ${episode.thumbnailPath}`);
      console.log(`📄 Script: ${scriptPath}`);

    } catch (error: any) {
      console.error(`❌ Demo ${channel.name} Episode ${episodeNumber} failed:`, error.message);
      episode.status = 'failed';
      this.episodes.push(episode);
    }
  }

  async generateDemoForAllChannels(): Promise<void> {
    console.log('🚀 Generating demo videos for all channels...');
    
    for (const [channelId] of this.channels) {
      await this.processDemoEpisode(channelId, 1);
    }
    
    console.log('\n✅ All demo videos completed!');
    console.log(`📁 Output directory: ${this.outputDir}`);
    console.log('📋 Summary:');
    
    this.channels.forEach((channel, channelId) => {
      const channelEpisodes = this.episodes.filter(e => e.channelId === channelId);
      const completed = channelEpisodes.filter(e => e.status === 'completed').length;
      console.log(`  ${channel.name}: ${completed} demo video(s) created`);
    });
  }
}

// Main execution
async function main() {
  const manager = new DemoMultiChannelManager();
  
  console.log('🎯 Demo Multi-Channel Video Generator');
  console.log('====================================');
  console.log('This creates demo videos without using OpenAI API');
  console.log('');
  
  await manager.generateDemoForAllChannels();
  
  console.log('\n📝 Next Steps:');
  console.log('1. Review the generated demo videos and thumbnails');
  console.log('2. Add OpenAI API credits to generate full 5-minute videos');
  console.log('3. Use the full multi-channel system for production');
  console.log('4. Upload videos manually to your different YouTube accounts');
}

if (require.main === module) {
  main().catch(console.error);
}

export { DemoMultiChannelManager };