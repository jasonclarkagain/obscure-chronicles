#!/usr/bin/env npx tsx

// Simple OAuth flow to get refresh token
console.log('🔑 YouTube OAuth Setup for Real Uploads');
console.log('=======================================\n');

const credentials = {
  client_id: "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com",
  client_secret: "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"
};

console.log('✅ Your YouTube API credentials are ready!');
console.log('📋 Client ID: ' + credentials.client_id);
console.log('📋 Client Secret: ' + credentials.client_secret);

console.log('\n🎯 Now get your refresh token:');
console.log('1. Go to: https://developers.google.com/oauthplayground/');
console.log('2. Click settings gear (⚙️) in top-right corner');
console.log('3. Check "Use your own OAuth credentials"');
console.log('4. Paste your Client ID: ' + credentials.client_id);
console.log('5. Paste your Client Secret: ' + credentials.client_secret);
console.log('6. In left panel, find "YouTube Data API v3"');
console.log('7. Select these scopes:');
console.log('   ✅ https://www.googleapis.com/auth/youtube.upload');
console.log('   ✅ https://www.googleapis.com/auth/youtube');
console.log('8. Click "Authorize APIs"');
console.log('9. Sign in with: jasonclarkagain@gmail.com');
console.log('10. Grant all permissions');
console.log('11. Click "Exchange authorization code for tokens"');
console.log('12. Copy the "refresh_token" value');

console.log('\n🚀 Once you have the refresh token, run:');
console.log('npx tsx start-real-automation.ts "YOUR_REFRESH_TOKEN"');

console.log('\n💡 The refresh token looks like:');
console.log('1//04xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');