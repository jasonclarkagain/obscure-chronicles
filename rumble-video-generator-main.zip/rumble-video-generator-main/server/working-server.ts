import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import dotenv from "dotenv";
import { storage } from "./minimal-storage";
import { insertVideoThemeSchema, insertCharacterSchema } from "@shared/schema";
import { z } from "zod";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;
// Storage imported above

// Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"]
    }
  }
}));

app.use(cors());
app.use(morgan("combined"));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    version: "1.0.0"
  });
});

// API Routes
app.get("/api/themes", async (req, res) => {
  try {
    const themes = await storage.getVideoThemes();
    res.json(themes);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/themes", async (req, res) => {
  try {
    const themeData = insertVideoThemeSchema.parse(req.body);
    const theme = await storage.createVideoTheme(themeData);
    res.status(201).json(theme);
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: "Validation error", details: error.errors });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

app.get("/api/characters", async (req, res) => {
  try {
    const characters = await storage.getCharacters();
    res.json(characters);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/characters", async (req, res) => {
  try {
    const characterData = insertCharacterSchema.parse(req.body);
    const character = await storage.createCharacter(characterData);
    res.status(201).json(character);
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: "Validation error", details: error.errors });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

app.get("/api/videos", async (req, res) => {
  try {
    const videos = await storage.getVideos();
    res.json(videos);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Error handling middleware
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error("Unhandled error:", err);
  res.status(500).json({
    error: "Internal server error",
    message: process.env.NODE_ENV === "development" ? err.message : "Something went wrong"
  });
});

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({
    error: "Not found",
    path: req.originalUrl
  });
});

// Start server
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 AI Video Generation Server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log("✅ Database-powered API ready!");
});

// Graceful shutdown
process.on("SIGTERM", () => {
  console.log("SIGTERM received, shutting down gracefully...");
  process.exit(0);
});

process.on("SIGINT", () => {
  console.log("SIGINT received, shutting down gracefully...");
  process.exit(0);
});