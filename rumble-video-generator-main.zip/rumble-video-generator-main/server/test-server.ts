import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { nanoid } from "nanoid";
import { eq } from "drizzle-orm";

dotenv.config();

// Direct database setup
const client = postgres(process.env.DATABASE_URL!);
const db = drizzle(client);

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

app.get("/health", (req, res) => {
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    version: "1.0.0"
  });
});

// Raw SQL API endpoints to test database
app.get("/api/themes", async (req, res) => {
  try {
    const themes = await client`SELECT * FROM video_themes ORDER BY created_at DESC`;
    res.json(themes);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/characters", async (req, res) => {
  try {
    const characters = await client`SELECT * FROM characters ORDER BY created_at DESC`;
    res.json(characters);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/videos", async (req, res) => {
  try {
    const videos = await client`SELECT * FROM videos ORDER BY created_at DESC LIMIT 10`;
    res.json(videos);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// AI-powered video generation test endpoint
app.post("/api/test-generation", async (req, res) => {
  try {
    const { videoGenerator } = await import("./video-generator-simple.js");
    
    console.log("🚀 Starting AI video generation test...");
    const result = await videoGenerator.testGeneration();
    
    if (result.success) {
      res.json({
        success: true,
        message: result.message,
        details: result.details,
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({
        success: false,
        error: result.message,
        timestamp: new Date().toISOString()
      });
    }
  } catch (error: any) {
    console.error("Test generation error:", error);
    res.status(500).json({ 
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Full video generation endpoint
app.post("/api/generate-video", async (req, res) => {
  try {
    const { themeId, characterIds } = req.body;
    
    // Get theme from database
    const themes = await client`SELECT * FROM video_themes WHERE id = ${themeId}`;
    const theme = themes[0];
    
    if (!theme) {
      return res.status(404).json({ error: "Theme not found" });
    }
    
    // Get characters from database
    const characters = await client`SELECT * FROM characters WHERE id = ANY(${characterIds})`;
    
    if (characters.length === 0) {
      return res.status(404).json({ error: "No characters found" });
    }

    const { videoGenerator } = await import("./video-generator-simple.js");
    const script = await videoGenerator.generateScript(theme, characters);
    const videoPath = await videoGenerator.createSimpleVideo(script, characters);

    // Save to database
    const videoId = nanoid();
    await client`
      INSERT INTO videos (id, title, description, theme_id, status, script, metadata, file_path, created_at)
      VALUES (${videoId}, ${script.title}, ${script.description}, ${themeId}, 'completed', ${JSON.stringify(script)}, ${JSON.stringify({ duration: script.totalDuration, resolution: { width: 1920, height: 1080 }, fps: 30 })}, ${videoPath}, ${new Date()})
    `;

    res.json({
      success: true,
      message: "Video generated successfully",
      videoId: videoId,
      script: script,
      videoPath: videoPath
    });

  } catch (error: any) {
    console.error("Video generation error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Test Server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log("✅ Database-powered test APIs ready!");
});

// Graceful shutdown
process.on("SIGTERM", () => {
  client.end();
  process.exit(0);
});

process.on("SIGINT", () => {
  client.end();
  process.exit(0);
});