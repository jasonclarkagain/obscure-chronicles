import OpenAI from "openai";
import { nanoid } from "nanoid";
import fs from "fs/promises";
import path from "path";

// Initialize OpenAI
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface SimpleVideoScript {
  title: string;
  description: string;
  scenes: Array<{
    id: string;
    duration: number;
    dialog: Array<{
      character: string;
      text: string;
      timing: { start: number; end: number };
    }>;
    visualDescription: string;
    backgroundImage?: string;
    ambientSounds: string[];
    soundEffects: string[];
  }>;
  totalDuration: number;
}

export class SimpleVideoGenerator {
  private outputDir: string;

  constructor() {
    this.outputDir = path.join(process.cwd(), "server/output");
    this.ensureDirectories();
  }

  private async ensureDirectories() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
      await fs.mkdir(path.join(this.outputDir, "thumbnails"), { recursive: true });
      await fs.mkdir(path.join(this.outputDir, "assets"), { recursive: true });
    } catch (error) {
      console.error("Error creating directories:", error);
    }
  }

  async generateScript(theme: any, characters: any[]): Promise<SimpleVideoScript> {
    try {
      console.log("🎬 Generating video script with OpenAI...");
      
      const prompt = `Create a G-rated educational video script based on this theme: "${theme.name}"
      Description: ${theme.description}
      
      Characters available: ${characters.map(c => `${c.name} (${c.description})`).join(", ")}
      
      Requirements:
      - Create exactly 3 scenes
      - Each scene should be 20-30 seconds long
      - Include dialog for 2-3 characters per scene
      - Make it educational and family-friendly
      - Include visual descriptions for each scene
      - Add ambient sounds and sound effects suggestions
      
      Respond with JSON in this exact format:
      {
        "title": "Video Title",
        "description": "Brief video description",
        "totalDuration": 75,
        "scenes": [
          {
            "id": "scene1",
            "duration": 25,
            "dialog": [
              {
                "character": "Character Name",
                "text": "Dialog text here",
                "timing": {"start": 0, "end": 5}
              }
            ],
            "visualDescription": "Detailed scene description",
            "ambientSounds": ["nature", "birds"],
            "soundEffects": ["whoosh", "ding"]
          }
        ]
      }`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a professional video script writer specializing in educational content for children. Always respond with valid JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 2000
      });

      const scriptData = JSON.parse(response.choices[0].message.content || "{}");
      
      // Enhance the script with proper IDs and timing
      const enhancedScript: SimpleVideoScript = {
        ...scriptData,
        scenes: scriptData.scenes.map((scene: any, index: number) => ({
          ...scene,
          id: scene.id || `scene-${index + 1}`,
        }))
      };

      console.log("✅ Script generated successfully:", enhancedScript.title);
      return enhancedScript;

    } catch (error: any) {
      console.error("❌ Error generating script:", error.message);
      throw new Error(`Script generation failed: ${error.message}`);
    }
  }

  async generateSceneImage(description: string, style: string = "cartoon"): Promise<string> {
    try {
      console.log("🎨 Generating scene image...");
      
      const imagePrompt = `Create a ${style} style image for a children's educational video. Scene: ${description}. Make it colorful, engaging, and appropriate for all ages. High quality, 1920x1080 aspect ratio.`;

      const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: imagePrompt,
        n: 1,
        size: "1792x1024", // Closest to 1920x1080
        quality: "standard"
      });

      const imageUrl = response.data[0].url;
      if (!imageUrl) {
        throw new Error("No image URL returned from OpenAI");
      }

      console.log("✅ Scene image generated successfully");
      return imageUrl;

    } catch (error: any) {
      console.error("❌ Error generating image:", error.message);
      throw new Error(`Image generation failed: ${error.message}`);
    }
  }

  async generateSpeech(text: string, character: any): Promise<Buffer> {
    try {
      console.log(`🎤 Generating speech for ${character.name}...`);
      
      // Map character voice profile to OpenAI TTS voice
      let voice: "alloy" | "echo" | "fable" | "onyx" | "nova" | "shimmer" = "alloy";
      
      if (character.voiceProfile?.gender === "female") {
        voice = character.voiceProfile?.age === "child" ? "nova" : "shimmer";
      } else {
        voice = character.voiceProfile?.age === "child" ? "echo" : "onyx";
      }

      const response = await openai.audio.speech.create({
        model: "tts-1",
        voice: voice,
        input: text,
        speed: 1.0
      });

      const buffer = Buffer.from(await response.arrayBuffer());
      console.log("✅ Speech generated successfully");
      return buffer;

    } catch (error: any) {
      console.error("❌ Error generating speech:", error.message);
      throw new Error(`Speech generation failed: ${error.message}`);
    }
  }

  async createSimpleVideo(script: SimpleVideoScript, characters: any[]): Promise<string> {
    try {
      console.log("🎥 Creating simple video...");
      
      // For now, create a simple text-based representation
      // In production, this would generate actual video files using FFmpeg
      
      const videoData = {
        id: nanoid(),
        script: script,
        characters: characters,
        createdAt: new Date().toISOString(),
        status: "completed",
        format: "text-representation"
      };

      const outputPath = path.join(this.outputDir, `video-${videoData.id}.json`);
      await fs.writeFile(outputPath, JSON.stringify(videoData, null, 2));

      console.log("✅ Simple video created:", outputPath);
      return outputPath;

    } catch (error: any) {
      console.error("❌ Error creating video:", error.message);
      throw new Error(`Video creation failed: ${error.message}`);
    }
  }

  async testGeneration(): Promise<{ success: boolean; message: string; details?: any }> {
    try {
      console.log("🧪 Testing video generation pipeline...");

      // Test theme
      const testTheme = {
        name: "Ocean Adventures",
        description: "Educational content about marine life and ocean conservation"
      };

      // Test characters
      const testCharacters = [
        {
          name: "Captain Marina",
          description: "A friendly sea captain who loves teaching about ocean life",
          voiceProfile: { gender: "female", age: "adult", personality: "enthusiastic" }
        },
        {
          name: "Finn the Fish",
          description: "A curious young fish who asks lots of questions",
          voiceProfile: { gender: "male", age: "child", personality: "curious" }
        }
      ];

      // Generate script
      const script = await this.generateScript(testTheme, testCharacters);
      
      // Generate one image as test
      const imageUrl = await this.generateSceneImage(script.scenes[0].visualDescription);
      
      // Generate one speech sample as test
      const speechBuffer = await this.generateSpeech(script.scenes[0].dialog[0].text, testCharacters[0]);
      
      // Create simple video representation
      const videoPath = await this.createSimpleVideo(script, testCharacters);

      return {
        success: true,
        message: "Video generation test completed successfully!",
        details: {
          scriptTitle: script.title,
          totalDuration: script.totalDuration,
          scenesCount: script.scenes.length,
          imageGenerated: !!imageUrl,
          speechGenerated: speechBuffer.length > 0,
          videoCreated: !!videoPath
        }
      };

    } catch (error: any) {
      return {
        success: false,
        message: `Test failed: ${error.message}`
      };
    }
  }
}

export const videoGenerator = new SimpleVideoGenerator();