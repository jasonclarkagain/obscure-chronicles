import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';
import { createCanvas } from 'canvas';
import ffmpeg from 'fluent-ffmpeg';
import cron from 'node-cron';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface Episode {
  number: number;
  title: string;
  topic: string;
  script: any;
  status: 'pending' | 'generating' | 'completed' | 'failed';
  videoPath?: string;
  thumbnailPath?: string;
  createdAt?: string;
}

class StandaloneVideoGenerator {
  private episodes: Episode[] = [];
  private outputDir: string;
  private scheduledTask: cron.ScheduledTask | null = null;
  
  constructor() {
    this.outputDir = path.join(process.cwd(), 'server', 'output');
    this.initializeEpisodes();
    this.ensureDirectories();
  }
  
  private initializeEpisodes() {
    const topics = [
      "The Water Cycle Adventure",
      "Journey Through the Solar System", 
      "Amazing Plant Life Cycle",
      "Forest Animal Friends",
      "Weather Patterns Around the World",
      "Ocean Depths Exploration",
      "Dinosaur Time Machine",
      "Counting Adventures with Captain Marina",
      "Geometric Shapes Discovery",
      "Pattern Recognition Fun",
      "Addition and Subtraction Magic",
      "Measurement Adventures",
      "Time Travel Learning",
      "Money Math Adventures",
      "Alphabet Adventure Quest",
      "Storytelling Magic Hour",
      "Reading Rainbow Journey",
      "Creative Writing Workshop",
      "Languages of the World",
      "Poetry and Rhyme Time",
      "Colors and Art Creation",
      "Musical Instrument Discovery",
      "World Cultures Festival",
      "Building and Construction Fun",
      "Dance Around the World",
      "Cooking Adventures",
      "Nature Art Workshop",
      "Kindness and Friendship",
      "Problem Solving Heroes",
      "Community Helpers Adventure"
    ];
    
    this.episodes = topics.map((topic, index) => ({
      number: index + 1,
      title: topic,
      topic: topic,
      script: null,
      status: 'pending'
    }));
  }
  
  private ensureDirectories() {
    const dirs = [
      this.outputDir,
      path.join(this.outputDir, 'videos'),
      path.join(this.outputDir, 'thumbnails'),
      path.join(this.outputDir, 'scripts')
    ];
    
    for (const dir of dirs) {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }
  }
  
  async generateEpisodeScript(episode: Episode): Promise<any> {
    const prompt = `Create a 5-minute educational video script about "${episode.topic}" for children ages 5-12.

    Requirements:
    - Educational objectives for learning
    - 3 characters: Captain Marina (wise ocean explorer), Curious Casey (enthusiastic questioner), Luna (adventurous discoverer)
    - 5 scenes with detailed dialog and visual descriptions
    - Family-friendly G-rated content
    - Interactive elements for engagement
    - Clear learning outcomes
    - Consistent character personalities across episodes
    
    Format as JSON with:
    {
      "title": "${episode.title}",
      "episode_number": ${episode.number},
      "description": "Engaging episode description",
      "educational_objectives": ["objective1", "objective2", "objective3"],
      "characters": {
        "captain_marina": "Wise ocean explorer who guides the adventures",
        "curious_casey": "Enthusiastic child who asks great questions",
        "luna": "Adventurous discoverer who finds amazing things"
      },
      "scenes": [
        {
          "scene_number": 1,
          "duration": 60,
          "setting": "detailed scene setting",
          "visual_description": "what viewers see in detail",
          "dialog": [
            {"character": "Captain Marina", "text": "Welcome, young explorers! Today we're going to discover...", "emotion": "excited"},
            {"character": "Curious Casey", "text": "Oh wow! But Captain Marina, how does...", "emotion": "curious"},
            {"character": "Luna", "text": "Look what I found! This is amazing because...", "emotion": "amazed"}
          ],
          "educational_focus": "what this scene teaches",
          "interactive_element": "question or activity for viewers"
        }
      ],
      "conclusion": "memorable wrap-up message",
      "call_to_action": "engagement prompt for next episode",
      "fun_facts": ["interesting fact 1", "interesting fact 2"],
      "vocabulary": ["new word 1", "new word 2", "new word 3"]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content);
  }
  
  async createVideoFile(episode: Episode): Promise<string> {
    const videoPath = path.join(this.outputDir, 'videos', `episode_${episode.number.toString().padStart(2, '0')}_${episode.title.replace(/[^a-zA-Z0-9]/g, '_')}.mp4`);
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');
    
    // Create 5-minute video (300 seconds at 30 FPS = 9000 frames)
    const totalFrames = 9000;
    const framesPerScene = Math.floor(totalFrames / 5); // 5 scenes
    
    console.log(`Creating ${totalFrames} frames for ${episode.title}...`);
    
    const frameDir = path.join(this.outputDir, 'temp_frames');
    if (!fs.existsSync(frameDir)) {
      fs.mkdirSync(frameDir, { recursive: true });
    }
    
    for (let frameIndex = 0; frameIndex < totalFrames; frameIndex++) {
      const sceneIndex = Math.floor(frameIndex / framesPerScene);
      const sceneFrame = frameIndex % framesPerScene;
      const sceneProgress = sceneFrame / framesPerScene;
      
      // Clear canvas with animated background
      const bgHue = (frameIndex * 0.1) % 360;
      ctx.fillStyle = `hsl(${bgHue}, 70%, 85%)`;
      ctx.fillRect(0, 0, 1920, 1080);
      
      // Add floating elements
      for (let i = 0; i < 5; i++) {
        const x = 200 + (i * 300) + Math.sin(frameIndex * 0.02 + i) * 50;
        const y = 100 + Math.cos(frameIndex * 0.015 + i) * 30;
        
        ctx.fillStyle = `hsl(${(bgHue + i * 60) % 360}, 80%, 60%)`;
        ctx.beginPath();
        ctx.arc(x, y, 20 + Math.sin(frameIndex * 0.03 + i) * 5, 0, Math.PI * 2);
        ctx.fill();
      }
      
      // Episode title
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 72px Arial';
      ctx.textAlign = 'center';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 6;
      ctx.strokeText(episode.title, 960, 300);
      ctx.fillText(episode.title, 960, 300);
      
      // Episode number
      ctx.font = 'bold 48px Arial';
      ctx.fillStyle = '#FF6B6B';
      ctx.fillText(`Episode ${episode.number}/30`, 960, 380);
      
      // Scene indicator
      ctx.font = '36px Arial';
      ctx.fillStyle = '#4ECDC4';
      ctx.fillText(`Scene ${sceneIndex + 1}/5`, 960, 450);
      
      // Character names with animation
      const characterY = 550 + Math.sin(frameIndex * 0.05) * 10;
      ctx.font = 'bold 42px Arial';
      ctx.fillStyle = '#2C3E50';
      ctx.fillText('Captain Marina • Curious Casey • Luna', 960, characterY);
      
      // Series branding
      ctx.font = 'bold 54px Arial';
      ctx.fillStyle = '#E74C3C';
      ctx.fillText('Amazing Learning Adventures', 960, 650);
      
      // Progress bar
      const progressWidth = 800;
      const progressX = (1920 - progressWidth) / 2;
      const progressY = 750;
      
      ctx.fillStyle = '#BDC3C7';
      ctx.fillRect(progressX, progressY, progressWidth, 20);
      
      ctx.fillStyle = '#27AE60';
      ctx.fillRect(progressX, progressY, progressWidth * (frameIndex / totalFrames), 20);
      
      // Educational focus text
      if (episode.script && episode.script.scenes && episode.script.scenes[sceneIndex]) {
        const scene = episode.script.scenes[sceneIndex];
        ctx.font = '32px Arial';
        ctx.fillStyle = '#34495E';
        ctx.fillText(`Learning: ${scene.educational_focus}`, 960, 850);
      }
      
      // Time indicator
      const minutes = Math.floor(frameIndex / 30 / 60);
      const seconds = Math.floor((frameIndex / 30) % 60);
      ctx.font = '28px Arial';
      ctx.fillStyle = '#7F8C8D';
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, '0')}`, 960, 950);
      
      // Save frame
      const frameBuffer = canvas.toBuffer('image/png');
      const framePath = path.join(frameDir, `frame_${frameIndex.toString().padStart(5, '0')}.png`);
      fs.writeFileSync(framePath, frameBuffer);
      
      // Progress logging
      if (frameIndex % 1000 === 0) {
        const progress = ((frameIndex / totalFrames) * 100).toFixed(1);
        console.log(`Frame ${frameIndex}/${totalFrames} (${progress}%)`);
      }
    }
    
    // Create video with FFmpeg
    return new Promise((resolve, reject) => {
      console.log('Creating video with FFmpeg...');
      
      ffmpeg()
        .input(path.join(frameDir, 'frame_%05d.png'))
        .inputOptions(['-r 30'])
        .outputOptions([
          '-c:v libx264',
          '-pix_fmt yuv420p',
          '-crf 18',
          '-preset medium',
          '-r 30',
          '-t 300' // 5 minutes
        ])
        .output(videoPath)
        .on('progress', (progress) => {
          console.log(`Video processing: ${progress.percent?.toFixed(1)}%`);
        })
        .on('end', () => {
          console.log('Video creation completed!');
          // Clean up temp frames
          fs.rmSync(frameDir, { recursive: true, force: true });
          resolve(videoPath);
        })
        .on('error', (err) => {
          console.error('Video creation error:', err);
          reject(err);
        })
        .run();
    });
  }
  
  async createThumbnail(episode: Episode): Promise<string> {
    const thumbnailPath = path.join(this.outputDir, 'thumbnails', `episode_${episode.number.toString().padStart(2, '0')}_thumbnail.png`);
    const canvas = createCanvas(1280, 720);
    const ctx = canvas.getContext('2d');
    
    // Gradient background
    const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
    gradient.addColorStop(0, '#FF6B6B');
    gradient.addColorStop(0.5, '#4ECDC4');
    gradient.addColorStop(1, '#45B7D1');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1280, 720);
    
    // Title background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
    ctx.fillRect(0, 150, 1280, 250);
    
    // Episode number badge
    ctx.fillStyle = '#FFD700';
    ctx.beginPath();
    ctx.arc(150, 100, 60, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 36px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`${episode.number}`, 150, 110);
    
    // Main title
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    
    // Word wrap for title
    const words = episode.title.split(' ');
    const lines = [];
    let currentLine = '';
    
    for (const word of words) {
      const testLine = currentLine + (currentLine ? ' ' : '') + word;
      const metrics = ctx.measureText(testLine);
      
      if (metrics.width > 1100 && currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) lines.push(currentLine);
    
    lines.forEach((line, index) => {
      const y = 240 + (index * 60);
      ctx.strokeText(line, 640, y);
      ctx.fillText(line, 640, y);
    });
    
    // Series branding
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 32px Arial';
    ctx.fillText('Amazing Learning Adventures', 640, 450);
    
    // Character names
    ctx.font = '24px Arial';
    ctx.fillText('Captain Marina • Curious Casey • Luna', 640, 500);
    
    // Educational badge
    ctx.fillStyle = '#27AE60';
    ctx.fillRect(1050, 550, 200, 80);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 18px Arial';
    ctx.fillText('EDUCATIONAL', 1150, 580);
    ctx.fillText('AGES 5-12', 1150, 605);
    
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(thumbnailPath, buffer);
    
    return thumbnailPath;
  }
  
  async processEpisode(episodeNumber: number): Promise<void> {
    const episode = this.episodes.find(e => e.number === episodeNumber);
    if (!episode) {
      console.log(`Episode ${episodeNumber} not found`);
      return;
    }
    
    console.log(`\n🎬 Processing Episode ${episodeNumber}: ${episode.title}`);
    episode.status = 'generating';
    episode.createdAt = new Date().toISOString();
    
    try {
      // Generate script
      console.log('📝 Generating AI script...');
      episode.script = await this.generateEpisodeScript(episode);
      
      // Save script to file
      const scriptPath = path.join(this.outputDir, 'scripts', `episode_${episode.number.toString().padStart(2, '0')}_script.json`);
      fs.writeFileSync(scriptPath, JSON.stringify(episode.script, null, 2));
      console.log(`✅ Script saved to: ${scriptPath}`);
      
      // Create thumbnail
      console.log('🖼️ Creating thumbnail...');
      episode.thumbnailPath = await this.createThumbnail(episode);
      console.log(`✅ Thumbnail created: ${episode.thumbnailPath}`);
      
      // Create video
      console.log('🎥 Creating video (this may take several minutes)...');
      episode.videoPath = await this.createVideoFile(episode);
      console.log(`✅ Video created: ${episode.videoPath}`);
      
      episode.status = 'completed';
      
      // Save progress
      await this.saveProgress();
      
      console.log(`\n🎉 Episode ${episodeNumber} completed successfully!`);
      console.log(`📹 Video: ${episode.videoPath}`);
      console.log(`🖼️ Thumbnail: ${episode.thumbnailPath}`);
      console.log(`📄 Script: ${scriptPath}`);
      
    } catch (error: any) {
      console.error(`❌ Episode ${episodeNumber} failed:`, error.message);
      episode.status = 'failed';
      await this.saveProgress();
    }
  }
  
  async saveProgress(): Promise<void> {
    const progressPath = path.join(this.outputDir, 'progress.json');
    const progressData = {
      episodes: this.episodes.map(ep => ({
        number: ep.number,
        title: ep.title,
        status: ep.status,
        videoPath: ep.videoPath,
        thumbnailPath: ep.thumbnailPath,
        createdAt: ep.createdAt
      })),
      lastUpdated: new Date().toISOString()
    };
    
    fs.writeFileSync(progressPath, JSON.stringify(progressData, null, 2));
  }
  
  async startDailyGeneration(): Promise<void> {
    console.log('🚀 Starting daily video generation...');
    
    // Process Episode 1 immediately
    await this.processEpisode(1);
    
    // Schedule daily generation for remaining episodes
    let currentEpisode = 2;
    
    this.scheduledTask = cron.schedule('0 9 * * *', async () => {
      if (currentEpisode <= 30) {
        console.log(`🌅 Daily generation: Episode ${currentEpisode}`);
        await this.processEpisode(currentEpisode);
        currentEpisode++;
      } else {
        console.log('🎉 30-day series completed!');
        this.stopGeneration();
      }
    });
    
    console.log('✅ Daily generation scheduled for 9:00 AM UTC');
    console.log(`📅 Next episode: Episode ${currentEpisode} tomorrow`);
  }
  
  stopGeneration(): void {
    if (this.scheduledTask) {
      this.scheduledTask.stop();
      console.log('⏹️ Daily generation stopped');
    }
  }
  
  getStatus(): any {
    const completed = this.episodes.filter(e => e.status === 'completed').length;
    const failed = this.episodes.filter(e => e.status === 'failed').length;
    const pending = this.episodes.filter(e => e.status === 'pending').length;
    
    return {
      totalEpisodes: this.episodes.length,
      completed,
      failed,
      pending,
      isScheduled: this.scheduledTask !== null,
      outputDirectory: this.outputDir,
      episodes: this.episodes.map(ep => ({
        number: ep.number,
        title: ep.title,
        status: ep.status,
        videoPath: ep.videoPath,
        thumbnailPath: ep.thumbnailPath,
        createdAt: ep.createdAt
      }))
    };
  }
}

// Main execution
async function main() {
  const generator = new StandaloneVideoGenerator();
  
  console.log('🎯 Standalone Video Generator');
  console.log('============================');
  console.log('Creating Episode 1 now, then scheduling daily generation...');
  
  await generator.startDailyGeneration();
  
  // Keep the process running
  process.on('SIGINT', () => {
    console.log('\n🛑 Stopping video generation...');
    generator.stopGeneration();
    process.exit(0);
  });
  
  console.log('\n✅ System is running. Press Ctrl+C to stop.');
  
  // Status updates every 5 minutes
  setInterval(() => {
    const status = generator.getStatus();
    console.log(`📊 Status: ${status.completed}/${status.totalEpisodes} episodes completed`);
  }, 300000);
}

if (require.main === module) {
  main().catch(console.error);
}

export { StandaloneVideoGenerator };