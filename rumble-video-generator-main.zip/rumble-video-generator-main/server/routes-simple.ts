import { Router } from "express";
import { IStorage } from "./storage";
import { insertVideoThemeSchema, insertCharacterSchema } from "@shared/schema";
import { z } from "zod";

export function createRoutes(storage: IStorage): Router {
  const router = Router();

  // Health check for API
  router.get("/api/health", (req, res) => {
    res.json({ status: "API is running", timestamp: new Date().toISOString() });
  });

  // Video Themes
  router.get("/api/themes", async (req, res) => {
    try {
      const themes = await storage.getVideoThemes();
      res.json(themes);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/themes", async (req, res) => {
    try {
      const themeData = insertVideoThemeSchema.parse(req.body);
      const theme = await storage.createVideoTheme(themeData);
      res.status(201).json(theme);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Validation error", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  // Characters
  router.get("/api/characters", async (req, res) => {
    try {
      const characters = await storage.getCharacters();
      res.json(characters);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/characters", async (req, res) => {
    try {
      const characterData = insertCharacterSchema.parse(req.body);
      const character = await storage.createCharacter(characterData);
      res.status(201).json(character);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Validation error", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  // Videos
  router.get("/api/videos", async (req, res) => {
    try {
      const videos = await storage.getVideos();
      res.json(videos);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  return router;
}