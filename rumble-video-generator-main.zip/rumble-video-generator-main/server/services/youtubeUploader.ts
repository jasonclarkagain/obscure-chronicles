import { google, youtube_v3 } from "googleapis";
import fs from "fs";
import path from "path";

export interface YouTubeUploadConfig {
  title: string;
  description: string;
  tags: string[];
  categoryId: string;
  privacyStatus: "private" | "public" | "unlisted";
  thumbnailPath?: string;
}

export interface YouTubeUploadResult {
  videoId: string;
  videoUrl: string;
  thumbnailUrl?: string;
}

export class YouTubeUploaderService {
  private youtube: youtube_v3.Youtube;
  private oauth2Client: any;

  constructor() {
    // Initialize YouTube API client
    this.oauth2Client = new google.auth.OAuth2(
      process.env.YOUTUBE_CLIENT_ID,
      process.env.YOUTUBE_CLIENT_SECRET,
      process.env.YOUTUBE_REDIRECT_URI
    );

    // Set refresh token if available
    if (process.env.YOUTUBE_REFRESH_TOKEN) {
      this.oauth2Client.setCredentials({
        refresh_token: process.env.YOUTUBE_REFRESH_TOKEN
      });
    }

    this.youtube = google.youtube({
      version: "v3",
      auth: this.oauth2Client
    });
  }

  async uploadVideo(
    videoPath: string,
    config: YouTubeUploadConfig
  ): Promise<YouTubeUploadResult> {
    try {
      console.log("Starting YouTube upload...");

      // Ensure video file exists
      if (!fs.existsSync(videoPath)) {
        throw new Error(`Video file not found: ${videoPath}`);
      }

      // Prepare video metadata
      const videoMetadata = {
        snippet: {
          title: this.sanitizeTitle(config.title),
          description: this.enhanceDescription(config.description),
          tags: config.tags,
          categoryId: config.categoryId || "22", // People & Blogs
          defaultLanguage: "en",
          defaultAudioLanguage: "en"
        },
        status: {
          privacyStatus: config.privacyStatus,
          selfDeclaredMadeForKids: true, // G-rated content
          embeddable: true,
          license: "youtube"
        }
      };

      // Upload video
      const uploadResponse = await this.youtube.videos.insert({
        part: ["snippet", "status"],
        requestBody: videoMetadata,
        media: {
          body: fs.createReadStream(videoPath)
        }
      });

      const videoId = uploadResponse.data.id;
      if (!videoId) {
        throw new Error("Failed to get video ID from upload response");
      }

      console.log(`Video uploaded successfully: ${videoId}`);

      // Upload thumbnail if provided
      let thumbnailUrl;
      if (config.thumbnailPath && fs.existsSync(config.thumbnailPath)) {
        try {
          await this.uploadThumbnail(videoId, config.thumbnailPath);
          thumbnailUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
          console.log("Thumbnail uploaded successfully");
        } catch (error) {
          console.error("Error uploading thumbnail:", error);
        }
      }

      // Wait a moment for processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      return {
        videoId,
        videoUrl: `https://www.youtube.com/watch?v=${videoId}`,
        thumbnailUrl
      };

    } catch (error) {
      console.error("Error uploading to YouTube:", error);
      throw new Error(`YouTube upload failed: ${error.message}`);
    }
  }

  private async uploadThumbnail(videoId: string, thumbnailPath: string): Promise<void> {
    await this.youtube.thumbnails.set({
      videoId: videoId,
      media: {
        body: fs.createReadStream(thumbnailPath)
      }
    });
  }

  private sanitizeTitle(title: string): string {
    // YouTube title restrictions
    return title
      .slice(0, 100) // Max 100 characters
      .replace(/[<>]/g, "") // Remove invalid characters
      .trim();
  }

  private enhanceDescription(description: string): string {
    const enhancedDescription = `${description}

🎬 Welcome to our family-friendly channel!
This video is created with AI technology to provide educational and entertaining content for all ages.

📚 Educational Content: All our videos are designed to be both fun and informative
👨‍👩‍👧‍👦 Family Friendly: G-rated content suitable for children and adults
🤖 AI Generated: Created using advanced AI technology for consistent, high-quality content

#EducationalContent #FamilyFriendly #AIGenerated #Learning #Educational #KidsContent #SafeContent

Subscribe for daily educational adventures!`;

    return enhancedDescription.slice(0, 5000); // YouTube description limit
  }

  async getChannelInfo(): Promise<any> {
    try {
      const response = await this.youtube.channels.list({
        part: ["snippet", "statistics"],
        mine: true
      });

      return response.data.items?.[0] || null;
    } catch (error) {
      console.error("Error getting channel info:", error);
      throw error;
    }
  }

  async generateAuthUrl(): Promise<string> {
    const scopes = [
      "https://www.googleapis.com/auth/youtube.upload",
      "https://www.googleapis.com/auth/youtube",
      "https://www.googleapis.com/auth/youtube.readonly"
    ];

    return this.oauth2Client.generateAuthUrl({
      access_type: "offline",
      scope: scopes,
      prompt: "consent"
    });
  }

  async exchangeCodeForTokens(code: string): Promise<any> {
    const { tokens } = await this.oauth2Client.getToken(code);
    this.oauth2Client.setCredentials(tokens);
    return tokens;
  }

  isAuthenticated(): boolean {
    const credentials = this.oauth2Client.credentials;
    return !!(credentials && (credentials.access_token || credentials.refresh_token));
  }

  async refreshTokenIfNeeded(): Promise<void> {
    try {
      const { credentials } = await this.oauth2Client.refreshAccessToken();
      this.oauth2Client.setCredentials(credentials);
    } catch (error) {
      console.error("Error refreshing YouTube token:", error);
      throw new Error("Failed to refresh YouTube authentication");
    }
  }

  async testConnection(): Promise<{ success: boolean; channelName?: string; error?: string }> {
    try {
      if (!this.isAuthenticated()) {
        return { success: false, error: "Not authenticated with YouTube" };
      }

      const channelInfo = await this.getChannelInfo();
      
      if (channelInfo) {
        return {
          success: true,
          channelName: channelInfo.snippet?.title || "Unknown Channel"
        };
      } else {
        return { success: false, error: "Could not retrieve channel information" };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}