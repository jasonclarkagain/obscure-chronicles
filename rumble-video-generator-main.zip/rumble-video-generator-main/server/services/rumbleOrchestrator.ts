import { IStorage } from "../storage";
import { rumbleVideoGenerator } from "./rumbleVideoGenerator";
import { nanoid } from "nanoid";

export class RumbleGenerationOrchestrator {
  constructor(private storage: IStorage) {}

  async generateVideo(campaignId: string, customTopic?: string): Promise<void> {
    const campaign = await this.storage.getRumbleCampaign(campaignId);
    if (!campaign) {
      throw new Error(`Campaign ${campaignId} not found`);
    }

    if (campaign.status !== "active") {
      throw new Error(`Campaign ${campaign.name} is not active`);
    }

    const nextDay = (campaign.currentDay || 0) + 1;

    if (nextDay > campaign.targetDays) {
      await this.storage.updateRumbleCampaign(campaignId, {
        status: "completed",
        completedAt: new Date()
      });
      throw new Error(`Campaign ${campaign.name} has reached its target of ${campaign.targetDays} days`);
    }

    let topic = customTopic;
    if (!topic) {
      const topics = campaign.config.topics;
      if (topics && topics.length > 0) {
        topic = topics[(nextDay - 1) % topics.length];
      } else {
        topic = `Day ${nextDay} - ${campaign.name}`;
      }
    }

    const title = `${campaign.name} - Day ${nextDay}: ${topic}`;
    const description = `${campaign.description}\n\nThis is video ${nextDay} of ${campaign.targetDays} in our series.`;

    const video = await this.storage.createRumbleVideo({
      campaignId,
      dayNumber: nextDay,
      title,
      description,
      topic,
      status: "queued"
    });

    console.log(`🎬 Starting video generation for Day ${nextDay}: ${topic}`);

    try {
      await this.storage.updateRumbleVideo(video.id, {
        status: "generating"
      });

      const result = await rumbleVideoGenerator.generateVideo(
        topic,
        campaign.targetDuration,
        {
          videoStyle: campaign.config.videoStyle,
          voicePreference: campaign.config.voicePreference
        },
        (progress) => {
          console.log(`[Day ${nextDay}] ${progress.phase}: ${progress.message}`);
        }
      );

      await this.storage.updateRumbleVideo(video.id, {
        status: "completed",
        filePath: result.filePath,
        duration: result.duration,
        fileSize: result.fileSize,
        script: result.script,
        transcriptChecksum: result.checksum,
        metadata: {
          resolution: { width: 1920, height: 1080 },
          fps: 30,
          audioFormat: "aac",
          videoCodec: "h264",
          chapters: result.chapters
        },
        completedAt: new Date()
      });

      const updatedCampaign = await this.storage.getRumbleCampaign(campaignId);
      const newCurrentDay = nextDay;
      const newVideosGenerated = (updatedCampaign?.videosGenerated || 0) + 1;
      
      await this.storage.updateRumbleCampaign(campaignId, {
        currentDay: newCurrentDay,
        videosGenerated: newVideosGenerated,
        lastGeneratedAt: new Date(),
        lastRunStatus: "success",
        nextScheduledAt: this.calculateNextScheduledTime()
      });

      console.log(`✅ Day ${nextDay} video completed: ${result.filePath}`);
      console.log(`📊 Duration: ${Math.floor(result.duration / 60)}m ${result.duration % 60}s`);
      console.log(`📁 Size: ${Math.floor(result.fileSize / 1024 / 1024)}MB`);

      if (campaign.config.uploadToGoogleDrive) {
        try {
          const { GoogleDriveUploader } = await import("./googleDriveUploader");
          const uploader = new GoogleDriveUploader();
          
          const driveResult = await uploader.uploadVideo({
            filePath: result.filePath,
            title,
            description,
            folderId: campaign.config.googleDriveFolderId
          });

          await this.storage.updateRumbleVideo(video.id, {
            googleDriveFileId: driveResult.fileId,
            googleDriveUrl: driveResult.url,
            status: "uploaded_gdrive"
          });

          console.log(`☁️  Uploaded to Google Drive: ${driveResult.url}`);
        } catch (error: any) {
          console.error(`Failed to upload to Google Drive: ${error.message}`);
        }
      }

    } catch (error: any) {
      console.error(`❌ Video generation failed for Day ${nextDay}:`, error);
      
      await this.storage.updateRumbleVideo(video.id, {
        status: "failed",
        errorMessage: error.message
      });

      await this.storage.updateRumbleCampaign(campaignId, {
        lastRunStatus: "failed"
      });

      throw error;
    } finally {
      await rumbleVideoGenerator.cleanupTempFiles();
    }
  }

  private calculateNextScheduledTime(): Date {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(2, 0, 0, 0);
    return tomorrow;
  }
}
