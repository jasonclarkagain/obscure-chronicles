import OpenAI from "openai";
import { VideoTheme, Character } from "@shared/schema";
import fs from "fs";
import path from "path";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface ScriptScene {
  id: string;
  duration: number;
  dialog: Array<{
    character: string;
    text: string;
    timing: { start: number; end: number };
  }>;
  visualDescription: string;
  ambientSounds: string[];
  soundEffects: string[];
}

export interface VideoScript {
  title: string;
  description: string;
  scenes: ScriptScene[];
  totalDuration: number;
}

export class OpenAIService {
  async generateVideoScript(
    theme: VideoTheme,
    characters: Character[],
    targetDuration: number = 180 // 3 minutes default
  ): Promise<VideoScript> {
    const characterDescriptions = characters.map(c => 
      `${c.name}: ${c.description} (${c.voiceProfile.gender}, ${c.voiceProfile.age}, ${c.voiceProfile.personality})`
    ).join('\n');

    const prompt = `Create a G-rated, family-friendly video script based on this theme: "${theme.name} - ${theme.description}"

REQUIREMENTS:
- Target duration: ${targetDuration} seconds (3 minutes)
- Use these characters: ${characterDescriptions}
- Scene style: ${theme.prompts.visualStyle}
- Include ambient sounds from: ${theme.prompts.ambientSounds.join(', ')}
- Content must be educational, positive, and completely family-friendly
- Create engaging dialog between characters
- Include sound effects like "bounce", "boink", "whoosh", etc.
- Each scene should be 30-45 seconds long
- Include detailed visual descriptions for image generation

SCRIPT FORMAT (respond with valid JSON):
{
  "title": "Video title",
  "description": "Brief video description for YouTube",
  "scenes": [
    {
      "id": "scene_1",
      "duration": 35,
      "dialog": [
        {
          "character": "Teacher Alex",
          "text": "Welcome to our amazing adventure!",
          "timing": { "start": 0, "end": 3 }
        }
      ],
      "visualDescription": "Detailed description for DALL-E image generation",
      "ambientSounds": ["gentle wind", "birds chirping"],
      "soundEffects": ["whoosh", "sparkle"]
    }
  ],
  "totalDuration": ${targetDuration}
}

Generate a complete, engaging script now:`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a professional children's content creator who creates engaging, educational, and family-friendly video scripts. Always respond with valid JSON only."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.8,
      });

      const script = JSON.parse(response.choices[0].message.content || "{}");
      
      // Validate and enhance the script
      return this.enhanceScript(script, theme, characters);
    } catch (error) {
      console.error("Error generating video script:", error);
      throw new Error("Failed to generate video script");
    }
  }

  private enhanceScript(script: any, theme: VideoTheme, characters: Character[]): VideoScript {
    // Ensure proper timing distribution
    let currentTime = 0;
    const enhancedScenes: ScriptScene[] = script.scenes.map((scene: any, index: number) => {
      const sceneStart = currentTime;
      const sceneDuration = scene.duration || 35;
      
      // Distribute dialog timing within scene
      const dialogDuration = sceneDuration * 0.8; // 80% of scene for dialog
      const timePerDialog = dialogDuration / scene.dialog.length;
      
      const enhancedDialog = scene.dialog.map((d: any, i: number) => ({
        ...d,
        timing: {
          start: sceneStart + (i * timePerDialog),
          end: sceneStart + ((i + 1) * timePerDialog)
        }
      }));

      currentTime += sceneDuration;

      return {
        id: scene.id || `scene_${index + 1}`,
        duration: sceneDuration,
        dialog: enhancedDialog,
        visualDescription: scene.visualDescription,
        ambientSounds: scene.ambientSounds || theme.prompts.ambientSounds.slice(0, 2),
        soundEffects: scene.soundEffects || ["transition", "accent"]
      };
    });

    return {
      title: script.title,
      description: script.description,
      scenes: enhancedScenes,
      totalDuration: currentTime
    };
  }

  async generateSceneImage(description: string, style: string): Promise<string> {
    const prompt = `${description}

Style: ${style}
Requirements: G-rated, family-friendly, high-quality, 1920x1080 resolution, bright and engaging colors, professional animation style`;

    try {
      const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: prompt,
        n: 1,
        size: "1792x1024", // Closest to 1920x1080
        quality: "hd",
      });

      return response.data[0].url || "";
    } catch (error) {
      console.error("Error generating scene image:", error);
      throw new Error("Failed to generate scene image");
    }
  }

  async generateCharacterImage(character: Character, sceneContext: string): Promise<string> {
    const prompt = `${character.visualStyle} in ${sceneContext}

Character details: ${character.description}
Style: High-quality, family-friendly, G-rated, cartoon/animated style, professional quality
Requirements: Clear, bright colors, engaging expression, suitable for children's content`;

    try {
      const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: prompt,
        n: 1,
        size: "1024x1024",
        quality: "hd",
      });

      return response.data[0].url || "";
    } catch (error) {
      console.error("Error generating character image:", error);
      throw new Error("Failed to generate character image");
    }
  }

  async generateSpeech(text: string, character: Character): Promise<Buffer> {
    // Map character voice profiles to OpenAI TTS voices
    const voiceMap: Record<string, "alloy" | "echo" | "fable" | "onyx" | "nova" | "shimmer"> = {
      "male_adult": "onyx",
      "male_child": "echo",
      "female_adult": "nova",
      "female_child": "shimmer",
      "male_elderly": "fable",
      "female_elderly": "alloy"
    };

    const voiceKey = `${character.voiceProfile.gender}_${character.voiceProfile.age}`;
    const voice = voiceMap[voiceKey] || "alloy";

    try {
      const mp3 = await openai.audio.speech.create({
        model: "tts-1-hd",
        voice: voice,
        input: text,
        speed: 1.0,
      });

      const buffer = Buffer.from(await mp3.arrayBuffer());
      return buffer;
    } catch (error) {
      console.error("Error generating speech:", error);
      throw new Error("Failed to generate speech");
    }
  }

  async filterContentForFamilyFriendly(content: string): Promise<{ isAppropriate: boolean; filteredContent?: string }> {
    const prompt = `Review this content for family-friendly, G-rated appropriateness:

"${content}"

Ensure it:
- Contains no inappropriate language
- Is educational or entertaining for all ages
- Has positive messages
- Contains no violence, scary content, or inappropriate themes
- Is suitable for children

Respond with JSON only:
{
  "isAppropriate": true/false,
  "filteredContent": "corrected version if needed",
  "issues": ["any issues found"]
}`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a content moderator ensuring all content is G-rated and family-friendly."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result;
    } catch (error) {
      console.error("Error filtering content:", error);
      return { isAppropriate: false };
    }
  }
}