import cron from "node-cron";
import { VideoOrchestratorService } from "./videoOrchestrator";
import { IStorage } from "../storage";

export class SchedulerService {
  private orchestrator: VideoOrchestratorService;
  private storage: IStorage;
  private scheduledTasks: Map<string, cron.ScheduledTask> = new Map();

  constructor(storage: IStorage) {
    this.storage = storage;
    this.orchestrator = new VideoOrchestratorService(storage);
  }

  startDailyVideoGeneration(): void {
    console.log("Starting daily video generation scheduler...");
    
    // Schedule daily video generation at 9:00 AM UTC
    const dailyTask = cron.schedule("0 9 * * *", async () => {
      console.log("Starting scheduled daily video generation...");
      
      try {
        // Add to generation queue
        await this.storage.createQueueItem({
          themeId: null, // Will be auto-selected
          scheduledFor: new Date(),
          status: "pending",
          retryCount: 0,
          errorMessage: null
        });

        console.log("Daily video generation queued successfully");
      } catch (error) {
        console.error("Error scheduling daily video generation:", error);
      }
    }, {
      scheduled: false,
      timezone: "UTC"
    });

    this.scheduledTasks.set("daily", dailyTask);
    dailyTask.start();

    // Start queue processor
    this.startQueueProcessor();
    
    console.log("Daily video generation scheduler started at 9:00 AM UTC");
  }

  private startQueueProcessor(): void {
    // Process queue every minute
    const queueProcessor = cron.schedule("* * * * *", async () => {
      await this.processGenerationQueue();
    }, {
      scheduled: true,
      timezone: "UTC"
    });

    this.scheduledTasks.set("queue", queueProcessor);
  }

  private async processGenerationQueue(): Promise<void> {
    try {
      const pendingItems = await this.storage.getPendingQueueItems();
      
      for (const item of pendingItems) {
        if (item.status === "pending") {
          console.log(`Processing queue item: ${item.id}`);
          
          // Update status to processing
          await this.storage.updateQueueItem(item.id, {
            status: "processing"
          });

          try {
            // Generate video
            const video = await this.orchestrator.generateDailyVideo();
            
            // Mark as completed
            await this.storage.updateQueueItem(item.id, {
              status: "completed"
            });

            console.log(`Queue item ${item.id} completed successfully. Video: ${video.id}`);

          } catch (error) {
            console.error(`Error processing queue item ${item.id}:`, error);
            
            const retryCount = (item.retryCount || 0) + 1;
            const maxRetries = 3;

            if (retryCount < maxRetries) {
              // Retry later
              await this.storage.updateQueueItem(item.id, {
                status: "pending",
                retryCount,
                errorMessage: error.message
              });
              
              console.log(`Queue item ${item.id} will be retried (attempt ${retryCount}/${maxRetries})`);
            } else {
              // Mark as failed
              await this.storage.updateQueueItem(item.id, {
                status: "failed",
                retryCount,
                errorMessage: error.message
              });
              
              console.log(`Queue item ${item.id} failed after ${maxRetries} attempts`);
            }
          }
        }
      }
    } catch (error) {
      console.error("Error processing generation queue:", error);
    }
  }

  scheduleVideoGeneration(themeId: string, scheduledTime: Date): Promise<void> {
    return this.storage.createQueueItem({
      themeId,
      scheduledFor: scheduledTime,
      status: "pending",
      retryCount: 0,
      errorMessage: null
    }).then(() => {
      console.log(`Video generation scheduled for ${scheduledTime.toISOString()}`);
    });
  }

  stopAllTasks(): void {
    console.log("Stopping all scheduled tasks...");
    
    this.scheduledTasks.forEach((task, name) => {
      task.stop();
      console.log(`Stopped task: ${name}`);
    });
    
    this.scheduledTasks.clear();
  }

  getSchedulerStatus(): {
    isRunning: boolean;
    activeTasks: string[];
    nextExecution?: string;
  } {
    const activeTasks = Array.from(this.scheduledTasks.keys()).filter(name => {
      const task = this.scheduledTasks.get(name);
      return task?.getStatus() === "scheduled";
    });

    return {
      isRunning: activeTasks.length > 0,
      activeTasks,
      nextExecution: "9:00 AM UTC daily"
    };
  }

  async getGenerationQueueStatus(): Promise<{
    pending: number;
    processing: number;
    completed: number;
    failed: number;
    totalToday: number;
  }> {
    const allItems = await this.storage.getGenerationQueue();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayItems = allItems.filter(item => {
      const itemDate = new Date(item.createdAt!);
      itemDate.setHours(0, 0, 0, 0);
      return itemDate.getTime() === today.getTime();
    });

    return {
      pending: allItems.filter(item => item.status === "pending").length,
      processing: allItems.filter(item => item.status === "processing").length,
      completed: allItems.filter(item => item.status === "completed").length,
      failed: allItems.filter(item => item.status === "failed").length,
      totalToday: todayItems.length
    };
  }
}