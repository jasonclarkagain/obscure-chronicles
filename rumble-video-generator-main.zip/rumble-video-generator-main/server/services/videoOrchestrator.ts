import { OpenAIService } from "./openai";
import { VideoGeneratorService } from "./videoGenerator";
import { YouTubeUploaderService } from "./youtubeUploader";
import { IStorage } from "../storage";
import { Video, VideoTheme, Character } from "@shared/schema";
import { nanoid } from "nanoid";

export interface VideoGenerationProgress {
  stage: "script" | "assets" | "generation" | "upload" | "completed" | "failed";
  progress: number;
  message: string;
  error?: string;
}

export class VideoOrchestratorService {
  private openaiService: OpenAIService;
  private videoGenerator: VideoGeneratorService;
  private youtubeUploader: YouTubeUploaderService;
  private storage: IStorage;
  private progressCallbacks: Map<string, (progress: VideoGenerationProgress) => void> = new Map();

  constructor(storage: IStorage) {
    this.storage = storage;
    this.openaiService = new OpenAIService();
    this.videoGenerator = new VideoGeneratorService();
    this.youtubeUploader = new YouTubeUploaderService();
  }

  async generateAndUploadVideo(
    themeId: string,
    onProgress?: (progress: VideoGenerationProgress) => void
  ): Promise<Video> {
    const progressId = nanoid();
    if (onProgress) {
      this.progressCallbacks.set(progressId, onProgress);
    }

    const updateProgress = (stage: VideoGenerationProgress["stage"], progress: number, message: string) => {
      const progressData: VideoGenerationProgress = { stage, progress, message };
      onProgress?.(progressData);
      console.log(`[${stage.toUpperCase()}] ${progress}% - ${message}`);
    };

    try {
      updateProgress("script", 5, "Loading theme and characters...");

      // Get theme and characters
      const theme = await this.storage.getVideoTheme(themeId);
      if (!theme) {
        throw new Error(`Theme not found: ${themeId}`);
      }

      const allCharacters = await this.storage.getCharacters();
      const activeCharacters = allCharacters.filter(c => c.isActive);

      if (activeCharacters.length < 2) {
        throw new Error("Need at least 2 active characters for video generation");
      }

      updateProgress("script", 15, "Generating video script...");

      // Generate video script
      const script = await this.openaiService.generateVideoScript(theme, activeCharacters);

      // Filter content for family-friendly
      updateProgress("script", 25, "Filtering content for family-friendly compliance...");
      const contentCheck = await this.openaiService.filterContentForFamilyFriendly(
        JSON.stringify(script)
      );

      if (!contentCheck.isAppropriate) {
        throw new Error("Generated content failed family-friendly filter");
      }

      updateProgress("script", 35, "Creating video record...");

      // Create video record
      const video = await this.storage.createVideo({
        title: script.title,
        description: script.description,
        themeId: theme.id,
        status: "generating",
        script: { scenes: script.scenes },
        metadata: {
          duration: script.totalDuration,
          resolution: { width: 1920, height: 1080 },
          fps: 30
        },
        filePath: null,
        thumbnailPath: null
      });

      updateProgress("assets", 45, "Generating visual and audio assets...");

      // Generate video
      const videoResult = await this.videoGenerator.generateVideo(
        script,
        activeCharacters,
        theme.prompts.visualStyle
      );

      updateProgress("generation", 75, "Video generation completed, preparing for upload...");

      // Update video record with file paths
      await this.storage.updateVideo(video.id, {
        filePath: videoResult.videoPath,
        thumbnailPath: videoResult.thumbnailPath,
        metadata: {
          ...video.metadata,
          duration: videoResult.duration,
          fileSize: this.getFileSize(videoResult.videoPath)
        }
      });

      updateProgress("upload", 85, "Uploading to YouTube...");

      // Upload to YouTube
      const uploadResult = await this.youtubeUploader.uploadVideo(
        videoResult.videoPath,
        {
          title: script.title,
          description: script.description,
          tags: this.generateTags(theme, script),
          categoryId: "22", // People & Blogs
          privacyStatus: "public",
          thumbnailPath: videoResult.thumbnailPath
        }
      );

      updateProgress("upload", 95, "Upload completed, finalizing...");

      // Update video record with YouTube info
      const finalVideo = await this.storage.updateVideo(video.id, {
        status: "uploaded",
        completedAt: new Date(),
        metadata: {
          ...video.metadata,
          youtubeVideoId: uploadResult.videoId,
          uploadedAt: new Date().toISOString()
        }
      });

      updateProgress("completed", 100, "Video generation and upload completed successfully!");

      this.progressCallbacks.delete(progressId);
      return finalVideo!;

    } catch (error) {
      console.error("Error in video generation:", error);
      
      const errorProgress: VideoGenerationProgress = {
        stage: "failed",
        progress: 0,
        message: "Video generation failed",
        error: error.message
      };
      
      onProgress?.(errorProgress);
      this.progressCallbacks.delete(progressId);
      
      throw error;
    }
  }

  async generateDailyVideo(): Promise<Video> {
    console.log("Starting daily video generation...");

    try {
      // Get active themes
      const themes = await this.storage.getVideoThemes();
      const activeThemes = themes.filter(t => t.isActive);

      if (activeThemes.length === 0) {
        throw new Error("No active themes available for video generation");
      }

      // Select theme (rotate through available themes)
      const videos = await this.storage.getVideos();
      const recentVideos = videos.slice(0, activeThemes.length);
      const usedThemes = new Set(recentVideos.map(v => v.themeId));
      
      const availableThemes = activeThemes.filter(t => !usedThemes.has(t.id));
      const selectedTheme = availableThemes.length > 0 
        ? availableThemes[0] 
        : activeThemes[Math.floor(Math.random() * activeThemes.length)];

      console.log(`Selected theme: ${selectedTheme.name}`);

      // Generate video
      const video = await this.generateAndUploadVideo(selectedTheme.id, (progress) => {
        console.log(`Daily generation progress: ${progress.stage} - ${progress.progress}% - ${progress.message}`);
      });

      console.log(`Daily video generation completed: ${video.id}`);
      return video;

    } catch (error) {
      console.error("Error in daily video generation:", error);
      throw error;
    }
  }

  private generateTags(theme: VideoTheme, script: any): string[] {
    const baseTags = [
      "educational",
      "family-friendly",
      "kids-content",
      "learning",
      "ai-generated",
      "daily-content"
    ];

    const themeSpecificTags = theme.name.toLowerCase().split(" ");
    
    // Extract keywords from script title and description
    const scriptWords = (script.title + " " + script.description)
      .toLowerCase()
      .replace(/[^\w\s]/g, "")
      .split(/\s+/)
      .filter(word => word.length > 3);

    const uniqueScriptTags = [...new Set(scriptWords)].slice(0, 5);

    return [...baseTags, ...themeSpecificTags, ...uniqueScriptTags].slice(0, 15);
  }

  private getFileSize(filePath: string): number {
    try {
      const fs = require("fs");
      const stats = fs.statSync(filePath);
      return stats.size;
    } catch (error) {
      console.error("Error getting file size:", error);
      return 0;
    }
  }

  async getVideoGenerationProgress(videoId: string): Promise<VideoGenerationProgress | null> {
    // This would be enhanced with real-time progress tracking in production
    const video = await this.storage.getVideo(videoId);
    if (!video) return null;

    switch (video.status) {
      case "generating":
        return { stage: "generation", progress: 50, message: "Video generation in progress..." };
      case "uploading":
        return { stage: "upload", progress: 85, message: "Uploading to YouTube..." };
      case "uploaded":
        return { stage: "completed", progress: 100, message: "Video completed successfully!" };
      case "failed":
        return { stage: "failed", progress: 0, message: "Video generation failed", error: "Unknown error" };
      default:
        return { stage: "script", progress: 10, message: "Preparing video generation..." };
    }
  }

  async validateVideoGenerationRequirements(): Promise<{
    isValid: boolean;
    errors: string[];
    warnings: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Check OpenAI API key
    if (!process.env.OPENAI_API_KEY) {
      errors.push("OpenAI API key is required");
    }

    // Check YouTube authentication
    const youtubeTest = await this.youtubeUploader.testConnection();
    if (!youtubeTest.success) {
      errors.push(`YouTube authentication failed: ${youtubeTest.error}`);
    }

    // Check themes
    const themes = await this.storage.getVideoThemes();
    const activeThemes = themes.filter(t => t.isActive);
    if (activeThemes.length === 0) {
      errors.push("No active video themes available");
    }

    // Check characters
    const characters = await this.storage.getCharacters();
    const activeCharacters = characters.filter(c => c.isActive);
    if (activeCharacters.length < 2) {
      errors.push("Need at least 2 active characters for video generation");
    }

    // Check system dependencies
    try {
      const ffmpeg = require("fluent-ffmpeg");
      // Basic FFmpeg test would go here
    } catch (error) {
      errors.push("FFmpeg is not properly installed");
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }
}