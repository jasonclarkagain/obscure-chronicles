import cron from "node-cron";
import { IStorage } from "../storage";
import { RumbleGenerationOrchestrator } from "./rumbleOrchestrator";

export class RumbleCronService {
  private scheduledTask: cron.ScheduledTask | null = null;
  private isRunning = false;

  constructor(private storage: IStorage) {}

  start(): void {
    if (this.scheduledTask) {
      console.log("⚠️  Rumble cron service is already running");
      return;
    }

    this.scheduledTask = cron.schedule(
      "0 2 * * *",
      async () => {
        await this.runDailyGeneration();
      },
      {
        scheduled: true,
        timezone: "UTC"
      }
    );

    console.log("✅ Rumble cron service started - daily generation at 02:00 UTC");
  }

  stop(): void {
    if (this.scheduledTask) {
      this.scheduledTask.stop();
      this.scheduledTask = null;
      console.log("🛑 Rumble cron service stopped");
    }
  }

  async runDailyGeneration(): Promise<void> {
    if (this.isRunning) {
      console.log("⏭️  Skipping daily generation - previous run still in progress");
      return;
    }

    this.isRunning = true;
    console.log(`\n🕐 Daily Rumble video generation started at ${new Date().toISOString()}`);

    try {
      const activeCampaign = await this.storage.getActiveCampaign();

      if (!activeCampaign) {
        console.log("ℹ️  No active campaign found - skipping generation");
        return;
      }

      const currentDay = activeCampaign.currentDay || 0;
      if (currentDay >= activeCampaign.targetDays) {
        console.log(`✅ Campaign "${activeCampaign.name}" has completed all ${activeCampaign.targetDays} days`);
        
        await this.storage.updateRumbleCampaign(activeCampaign.id, {
          status: "completed",
          completedAt: new Date(),
          lastRunStatus: "skipped"
        });
        
        return;
      }

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (activeCampaign.lastGeneratedAt) {
        const lastGen = new Date(activeCampaign.lastGeneratedAt);
        lastGen.setHours(0, 0, 0, 0);
        
        if (lastGen.getTime() === today.getTime()) {
          console.log("ℹ️  Video already generated today - skipping");
          await this.storage.updateRumbleCampaign(activeCampaign.id, {
            lastRunStatus: "skipped"
          });
          return;
        }
      }

      console.log(`📹 Generating Day ${currentDay + 1}/${activeCampaign.targetDays} for campaign: ${activeCampaign.name}`);

      const orchestrator = new RumbleGenerationOrchestrator(this.storage);
      await orchestrator.generateVideo(activeCampaign.id);

      console.log(`✅ Daily generation completed successfully`);

    } catch (error: any) {
      console.error(`❌ Daily generation failed:`, error);
      
      const activeCampaign = await this.storage.getActiveCampaign();
      if (activeCampaign) {
        await this.storage.updateRumbleCampaign(activeCampaign.id, {
          lastRunStatus: "failed"
        });
      }
    } finally {
      this.isRunning = false;
      console.log(`🕐 Daily generation ended at ${new Date().toISOString()}\n`);
    }
  }

  async runNow(): Promise<void> {
    console.log("🚀 Manually triggering daily generation...");
    await this.runDailyGeneration();
  }

  getStatus(): { isRunning: boolean; isScheduled: boolean } {
    return {
      isRunning: this.isRunning,
      isScheduled: this.scheduledTask !== null
    };
  }
}

let cronServiceInstance: RumbleCronService | null = null;

export function getRumbleCronService(storage: IStorage): RumbleCronService {
  if (!cronServiceInstance) {
    cronServiceInstance = new RumbleCronService(storage);
  }
  return cronServiceInstance;
}
