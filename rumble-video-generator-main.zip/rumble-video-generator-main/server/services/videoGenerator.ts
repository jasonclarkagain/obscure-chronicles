import ffmpeg from "fluent-ffmpeg";
import { createCanvas, loadImage, CanvasRenderingContext2D } from "canvas";
import fs from "fs";
import path from "path";
import { OpenAIService, VideoScript } from "./openai";
import { Character } from "@shared/schema";

export interface VideoAssets {
  backgroundImages: string[];
  characterImages: string[];
  audioFiles: string[];
  soundEffects: string[];
}

export class VideoGeneratorService {
  private openaiService: OpenAIService;
  private outputDir: string;
  private assetsDir: string;

  constructor() {
    this.openaiService = new OpenAIService();
    this.outputDir = path.join(process.cwd(), "output");
    this.assetsDir = path.join(process.cwd(), "assets");
    
    // Ensure directories exist
    this.ensureDirectories();
  }

  private ensureDirectories() {
    [this.outputDir, this.assetsDir, 
     path.join(this.assetsDir, "audio"),
     path.join(this.assetsDir, "images"),
     path.join(this.assetsDir, "sounds")].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    });
  }

  async generateVideo(
    script: VideoScript,
    characters: Character[],
    themeStyle: string
  ): Promise<{ videoPath: string; thumbnailPath: string; duration: number }> {
    console.log("Starting video generation...");
    
    try {
      // 1. Generate all visual assets
      const assets = await this.generateAssets(script, characters, themeStyle);
      
      // 2. Generate all audio assets
      await this.generateAudioAssets(script, characters);
      
      // 3. Create animated scenes
      const sceneVideos = await this.createAnimatedScenes(script, assets);
      
      // 4. Combine scenes into final video
      const finalVideo = await this.combineScenes(sceneVideos, script);
      
      // 5. Generate thumbnail
      const thumbnail = await this.generateThumbnail(finalVideo, script.title);
      
      console.log("Video generation completed successfully");
      return {
        videoPath: finalVideo,
        thumbnailPath: thumbnail,
        duration: script.totalDuration
      };
    } catch (error) {
      console.error("Error in video generation:", error);
      throw new Error(`Video generation failed: ${error.message}`);
    }
  }

  private async generateAssets(
    script: VideoScript,
    characters: Character[],
    themeStyle: string
  ): Promise<VideoAssets> {
    console.log("Generating visual assets...");
    
    const backgroundImages: string[] = [];
    const characterImages: string[] = [];

    // Generate background images for each scene
    for (let i = 0; i < script.scenes.length; i++) {
      const scene = script.scenes[i];
      try {
        const imageUrl = await this.openaiService.generateSceneImage(
          scene.visualDescription,
          themeStyle
        );
        const imagePath = await this.downloadImage(imageUrl, `background_${i}.jpg`);
        backgroundImages.push(imagePath);
      } catch (error) {
        console.error(`Error generating background for scene ${i}:`, error);
        // Create a fallback background
        const fallbackPath = await this.createFallbackBackground(i);
        backgroundImages.push(fallbackPath);
      }
    }

    // Generate character images for each scene context
    for (let i = 0; i < script.scenes.length; i++) {
      const scene = script.scenes[i];
      const sceneCharacters = [...new Set(scene.dialog.map(d => d.character))];
      
      for (const characterName of sceneCharacters) {
        const character = characters.find(c => c.name === characterName);
        if (character) {
          try {
            const imageUrl = await this.openaiService.generateCharacterImage(
              character,
              scene.visualDescription
            );
            const imagePath = await this.downloadImage(
              imageUrl,
              `character_${character.id}_scene_${i}.png`
            );
            characterImages.push(imagePath);
          } catch (error) {
            console.error(`Error generating character image for ${characterName}:`, error);
          }
        }
      }
    }

    return {
      backgroundImages,
      characterImages,
      audioFiles: [],
      soundEffects: []
    };
  }

  private async generateAudioAssets(script: VideoScript, characters: Character[]) {
    console.log("Generating audio assets...");
    
    // Generate speech for each dialog
    for (let sceneIndex = 0; sceneIndex < script.scenes.length; sceneIndex++) {
      const scene = script.scenes[sceneIndex];
      
      for (let dialogIndex = 0; dialogIndex < scene.dialog.length; dialogIndex++) {
        const dialog = scene.dialog[dialogIndex];
        const character = characters.find(c => c.name === dialog.character);
        
        if (character) {
          try {
            const audioBuffer = await this.openaiService.generateSpeech(dialog.text, character);
            const audioPath = path.join(
              this.assetsDir,
              "audio",
              `dialog_${sceneIndex}_${dialogIndex}.mp3`
            );
            fs.writeFileSync(audioPath, audioBuffer);
            
            // Update script with audio file path
            script.scenes[sceneIndex].dialog[dialogIndex].audioFile = audioPath;
          } catch (error) {
            console.error(`Error generating speech for dialog ${sceneIndex}-${dialogIndex}:`, error);
          }
        }
      }
    }

    // Generate ambient sound files (create simple tone-based ambient sounds)
    await this.generateAmbientSounds();
    await this.generateSoundEffects();
  }

  private async createAnimatedScenes(
    script: VideoScript,
    assets: VideoAssets
  ): Promise<string[]> {
    console.log("Creating animated scenes...");
    
    const sceneVideos: string[] = [];

    for (let i = 0; i < script.scenes.length; i++) {
      const scene = script.scenes[i];
      const sceneVideoPath = path.join(this.outputDir, `scene_${i}.mp4`);
      
      try {
        await this.createSceneVideo(scene, i, assets, sceneVideoPath);
        sceneVideos.push(sceneVideoPath);
      } catch (error) {
        console.error(`Error creating scene ${i}:`, error);
        throw error;
      }
    }

    return sceneVideos;
  }

  private async createSceneVideo(
    scene: any,
    sceneIndex: number,
    assets: VideoAssets,
    outputPath: string
  ): Promise<void> {
    const width = 1920;
    const height = 1080;
    const fps = 30;
    const duration = scene.duration;

    // Create animated frames
    const framesDir = path.join(this.outputDir, `frames_${sceneIndex}`);
    if (!fs.existsSync(framesDir)) {
      fs.mkdirSync(framesDir, { recursive: true });
    }

    const totalFrames = Math.floor(duration * fps);
    
    // Load background image
    let backgroundImage;
    try {
      backgroundImage = await loadImage(assets.backgroundImages[sceneIndex]);
    } catch (error) {
      console.error("Error loading background image:", error);
      backgroundImage = await this.createFallbackImage(width, height);
    }

    // Generate frames with animations
    for (let frame = 0; frame < totalFrames; frame++) {
      const canvas = createCanvas(width, height);
      const ctx = canvas.getContext("2d");
      
      // Draw background with slight animation (gentle parallax effect)
      const parallaxOffset = Math.sin((frame / totalFrames) * Math.PI * 2) * 10;
      ctx.drawImage(backgroundImage as any, parallaxOffset, 0, width, height);
      
      // Add gentle breathing animation to scene
      const breathingScale = 1 + Math.sin((frame / totalFrames) * Math.PI * 4) * 0.02;
      ctx.scale(breathingScale, breathingScale);
      
      // Add character animations during their dialog
      this.addCharacterAnimations(ctx, scene, frame, totalFrames, assets);
      
      // Add visual effects (sparkles, transitions)
      this.addVisualEffects(ctx, frame, totalFrames, width, height);
      
      // Save frame
      const frameBuffer = canvas.toBuffer("image/png");
      fs.writeFileSync(path.join(framesDir, `frame_${frame.toString().padStart(6, "0")}.png`), frameBuffer);
    }

    // Create video from frames using FFmpeg
    await this.createVideoFromFrames(framesDir, outputPath, fps, scene);
    
    // Clean up frames
    fs.rmSync(framesDir, { recursive: true, force: true });
  }

  private addCharacterAnimations(
    ctx: CanvasRenderingContext2D,
    scene: any,
    frame: number,
    totalFrames: number,
    assets: VideoAssets
  ) {
    const currentTime = (frame / totalFrames) * scene.duration;
    
    // Find active dialog at current time
    const activeDialog = scene.dialog.find((d: any) => 
      currentTime >= d.timing.start && currentTime <= d.timing.end
    );

    if (activeDialog) {
      // Add speaking character emphasis
      const speakingAnimation = Math.sin((frame % 20) / 20 * Math.PI * 2);
      
      // Simple character presence indicator (could be enhanced with actual character images)
      ctx.fillStyle = `rgba(255, 255, 100, ${0.3 + speakingAnimation * 0.2})`;
      ctx.fillRect(100, 800, 300, 200);
      
      // Add dialog text overlay
      ctx.fillStyle = "white";
      ctx.font = "24px Arial";
      ctx.strokeStyle = "black";
      ctx.lineWidth = 2;
      
      const words = activeDialog.text.split(" ");
      const wordsPerLine = 8;
      let y = 850;
      
      for (let i = 0; i < words.length; i += wordsPerLine) {
        const line = words.slice(i, i + wordsPerLine).join(" ");
        ctx.strokeText(line, 120, y);
        ctx.fillText(line, 120, y);
        y += 30;
      }
    }
  }

  private addVisualEffects(
    ctx: CanvasRenderingContext2D,
    frame: number,
    totalFrames: number,
    width: number,
    height: number
  ) {
    // Add gentle sparkle effects
    const sparkleCount = 5;
    for (let i = 0; i < sparkleCount; i++) {
      const sparklePhase = (frame + i * 20) / totalFrames;
      const x = (Math.sin(sparklePhase * Math.PI * 2) * 0.5 + 0.5) * width;
      const y = (Math.cos(sparklePhase * Math.PI * 1.5) * 0.5 + 0.5) * height;
      const opacity = Math.sin(sparklePhase * Math.PI * 4) * 0.5 + 0.5;
      
      ctx.fillStyle = `rgba(255, 255, 200, ${opacity * 0.3})`;
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private async createVideoFromFrames(
    framesDir: string,
    outputPath: string,
    fps: number,
    scene: any
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      let command = ffmpeg()
        .input(path.join(framesDir, "frame_%06d.png"))
        .inputFPS(fps)
        .videoCodec("libx264")
        .outputOptions([
          "-pix_fmt yuv420p",
          "-preset medium",
          "-crf 18"
        ]);

      // Add audio if available
      const audioFiles = scene.dialog
        .filter((d: any) => d.audioFile)
        .map((d: any) => d.audioFile);

      if (audioFiles.length > 0) {
        // Combine audio files for this scene
        const sceneAudioPath = path.join(this.outputDir, `scene_audio_${Date.now()}.mp3`);
        
        // For now, just use the first audio file
        // TODO: Implement proper audio mixing
        command = command.input(audioFiles[0]);
      }

      command
        .output(outputPath)
        .on("end", () => {
          console.log(`Scene video created: ${outputPath}`);
          resolve();
        })
        .on("error", (err) => {
          console.error("Error creating scene video:", err);
          reject(err);
        })
        .run();
    });
  }

  private async combineScenes(sceneVideos: string[], script: VideoScript): Promise<string> {
    const finalVideoPath = path.join(this.outputDir, `final_video_${Date.now()}.mp4`);
    
    return new Promise((resolve, reject) => {
      let command = ffmpeg();
      
      // Add all scene videos as inputs
      sceneVideos.forEach(videoPath => {
        command = command.input(videoPath);
      });

      // Create filter complex for concatenation
      const filterComplex = sceneVideos
        .map((_, index) => `[${index}:v][${index}:a]`)
        .join("") + `concat=n=${sceneVideos.length}:v=1:a=1[outv][outa]`;

      command
        .complexFilter(filterComplex)
        .outputOptions(["-map [outv]", "-map [outa]"])
        .videoCodec("libx264")
        .audioCodec("aac")
        .output(finalVideoPath)
        .on("end", () => {
          console.log("Final video created successfully");
          resolve(finalVideoPath);
        })
        .on("error", (err) => {
          console.error("Error combining scenes:", err);
          reject(err);
        })
        .run();
    });
  }

  private async generateThumbnail(videoPath: string, title: string): Promise<string> {
    const thumbnailPath = path.join(this.outputDir, `thumbnail_${Date.now()}.jpg`);
    
    return new Promise((resolve, reject) => {
      ffmpeg(videoPath)
        .screenshots({
          timestamps: ["10%"],
          filename: path.basename(thumbnailPath),
          folder: path.dirname(thumbnailPath),
          size: "1280x720"
        })
        .on("end", () => {
          console.log("Thumbnail generated successfully");
          resolve(thumbnailPath);
        })
        .on("error", (err) => {
          console.error("Error generating thumbnail:", err);
          reject(err);
        });
    });
  }

  private async downloadImage(url: string, filename: string): Promise<string> {
    const imagePath = path.join(this.assetsDir, "images", filename);
    
    try {
      const response = await fetch(url);
      const buffer = await response.arrayBuffer();
      fs.writeFileSync(imagePath, Buffer.from(buffer));
      return imagePath;
    } catch (error) {
      console.error("Error downloading image:", error);
      throw error;
    }
  }

  private async createFallbackBackground(sceneIndex: number): Promise<string> {
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext("2d");
    
    // Create a simple gradient background
    const gradient = ctx.createLinearGradient(0, 0, 0, 1080);
    gradient.addColorStop(0, "#87CEEB"); // Sky blue
    gradient.addColorStop(1, "#98FB98"); // Pale green
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1920, 1080);
    
    // Add some simple decorative elements
    ctx.fillStyle = "#FFD700";
    ctx.beginPath();
    ctx.arc(200, 200, 60, 0, Math.PI * 2);
    ctx.fill();
    
    const buffer = canvas.toBuffer("image/jpeg");
    const fallbackPath = path.join(this.assetsDir, "images", `fallback_${sceneIndex}.jpg`);
    fs.writeFileSync(fallbackPath, buffer);
    
    return fallbackPath;
  }

  private async createFallbackImage(width: number, height: number): Promise<any> {
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext("2d");
    
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, "#87CEEB");
    gradient.addColorStop(1, "#98FB98");
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    return canvas;
  }

  private async generateAmbientSounds(): Promise<void> {
    // Generate simple ambient sound files
    // This is a simplified implementation - in production, you'd use actual sound libraries
    const ambientSounds = ["wind", "birds", "nature", "gentle_stream"];
    
    ambientSounds.forEach(soundName => {
      const soundPath = path.join(this.assetsDir, "sounds", `${soundName}.mp3`);
      if (!fs.existsSync(soundPath)) {
        // Create placeholder file for now
        fs.writeFileSync(soundPath, Buffer.alloc(1024));
      }
    });
  }

  private async generateSoundEffects(): Promise<void> {
    // Generate sound effect files
    const soundEffects = ["bounce", "boink", "whoosh", "sparkle", "transition", "accent"];
    
    soundEffects.forEach(effectName => {
      const effectPath = path.join(this.assetsDir, "sounds", `${effectName}.mp3`);
      if (!fs.existsSync(effectPath)) {
        // Create placeholder file for now
        fs.writeFileSync(effectPath, Buffer.alloc(1024));
      }
    });
  }
}