import { google } from "googleapis";
import fs from "fs";
import path from "path";

export interface GoogleDriveUploadOptions {
  filePath: string;
  title: string;
  description: string;
  folderId?: string;
}

export interface GoogleDriveUploadResult {
  fileId: string;
  url: string;
}

export class GoogleDriveUploader {
  private drive: any;

  constructor() {
    const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
    const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
    const GOOGLE_REFRESH_TOKEN = process.env.GOOGLE_REFRESH_TOKEN;

    if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !GOOGLE_REFRESH_TOKEN) {
      throw new Error("Google Drive credentials not configured. Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REFRESH_TOKEN environment variables.");
    }

    const oauth2Client = new google.auth.OAuth2(
      GOOGLE_CLIENT_ID,
      GOOGLE_CLIENT_SECRET,
      "http://localhost:3000/oauth2callback"
    );

    oauth2Client.setCredentials({
      refresh_token: GOOGLE_REFRESH_TOKEN
    });

    this.drive = google.drive({ version: "v3", auth: oauth2Client });
  }

  async uploadVideo(options: GoogleDriveUploadOptions): Promise<GoogleDriveUploadResult> {
    const { filePath, title, description, folderId } = options;

    console.log(`☁️  Uploading to Google Drive: ${path.basename(filePath)}`);

    const fileMetadata: any = {
      name: title + ".mp4",
      description: description,
      mimeType: "video/mp4"
    };

    if (folderId) {
      fileMetadata.parents = [folderId];
    }

    const media = {
      mimeType: "video/mp4",
      body: fs.createReadStream(filePath)
    };

    const response = await this.drive.files.create({
      requestBody: fileMetadata,
      media: media,
      fields: "id, webViewLink"
    });

    const fileId = response.data.id;
    const url = response.data.webViewLink;

    await this.drive.permissions.create({
      fileId: fileId,
      requestBody: {
        role: "reader",
        type: "anyone"
      }
    });

    console.log(`✅ Upload complete: ${url}`);

    return {
      fileId,
      url
    };
  }

  async createFolder(name: string, parentFolderId?: string): Promise<string> {
    const fileMetadata: any = {
      name: name,
      mimeType: "application/vnd.google-apps.folder"
    };

    if (parentFolderId) {
      fileMetadata.parents = [parentFolderId];
    }

    const response = await this.drive.files.create({
      requestBody: fileMetadata,
      fields: "id"
    });

    return response.data.id;
  }

  async listFiles(folderId?: string): Promise<any[]> {
    const query = folderId ? `'${folderId}' in parents` : undefined;

    const response = await this.drive.files.list({
      q: query,
      fields: "files(id, name, mimeType, size, createdTime, webViewLink)",
      orderBy: "createdTime desc"
    });

    return response.data.files || [];
  }
}
