import OpenAI from "openai";
import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs/promises";
import path from "path";
import { nanoid } from "nanoid";
import crypto from "crypto";

const execAsync = promisify(exec);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface VideoChapter {
  id: string;
  title: string;
  duration: number;
  narration: string;
  visualCue: string;
  keyPoints?: string[];
  audioPath?: string;
}

export interface VideoOutline {
  title: string;
  description: string;
  topic: string;
  chapters: VideoChapter[];
  totalDuration: number;
}

export interface GenerationProgress {
  phase: "outline" | "narration" | "audio" | "video" | "complete" | "failed";
  currentChapter?: number;
  totalChapters?: number;
  message: string;
  error?: string;
}

export class RumbleVideoGenerator {
  private outputDir: string;
  private tempDir: string;

  constructor() {
    this.outputDir = path.join(process.cwd(), "rumble_videos");
    this.tempDir = path.join(process.cwd(), "temp_video_assets");
  }

  async ensureDirectories(): Promise<void> {
    await fs.mkdir(this.outputDir, { recursive: true });
    await fs.mkdir(this.tempDir, { recursive: true });
  }

  async generateOutline(
    topic: string,
    targetDuration: number,
    videoStyle: "educational" | "entertainment" | "documentary" | "tutorial"
  ): Promise<VideoOutline> {
    console.log(`📝 Generating outline for: ${topic}`);

    const chapterCount = Math.ceil(targetDuration / 300);
    const chapterDuration = Math.floor(targetDuration / chapterCount);

    const prompt = `Create a detailed ${targetDuration}-second (${Math.floor(targetDuration / 60)} minutes) ${videoStyle} video outline about: "${topic}"

Structure:
- Create ${chapterCount} chapters
- Each chapter should be approximately ${chapterDuration} seconds (${Math.floor(chapterDuration / 60)} minutes)
- Make it engaging, informative, and valuable
- Include strong hooks and clear transitions between chapters

For each chapter, provide:
1. A compelling chapter title
2. A brief description of visual elements/scenes
3. The main points to cover

Respond with JSON in this exact format:
{
  "title": "Engaging Video Title",
  "description": "Brief description of the video content",
  "chapters": [
    {
      "title": "Chapter 1 Title",
      "visualCue": "Description of visuals for this chapter",
      "keyPoints": ["point 1", "point 2", "point 3"]
    }
  ]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a professional video content creator specializing in ${videoStyle} content. Create engaging, well-structured video outlines that keep viewers engaged.`
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.8
    });

    const outlineData = JSON.parse(response.choices[0].message.content || "{}");

    const chapters: VideoChapter[] = outlineData.chapters.map((ch: any, index: number) => ({
      id: `chapter-${index + 1}`,
      title: ch.title,
      duration: chapterDuration,
      narration: "",
      visualCue: ch.visualCue,
      keyPoints: ch.keyPoints
    }));

    const outline: VideoOutline = {
      title: outlineData.title,
      description: outlineData.description,
      topic,
      chapters,
      totalDuration: chapterCount * chapterDuration
    };

    console.log(`✅ Outline created: ${chapters.length} chapters, ~${Math.floor(outline.totalDuration / 60)} minutes`);
    return outline;
  }

  async expandChapterNarration(
    chapter: VideoChapter,
    fullContext: { title: string; description: string; topic: string },
    chapterIndex: number,
    totalChapters: number
  ): Promise<string> {
    console.log(`📖 Expanding narration for Chapter ${chapterIndex + 1}: ${chapter.title}`);

    const isFirst = chapterIndex === 0;
    const isLast = chapterIndex === totalChapters - 1;

    const prompt = `Write a ${Math.floor(chapter.duration / 60)}-minute narration script for this chapter of a video about "${fullContext.topic}":

Video Title: ${fullContext.title}
Chapter ${chapterIndex + 1} of ${totalChapters}: ${chapter.title}
Visual Context: ${chapter.visualCue}

Requirements:
- Write ONLY the spoken narration (no stage directions)
- Make it conversational and engaging
- Target duration: ${Math.floor(chapter.duration / 60)} minutes when spoken
- ${isFirst ? "Include a strong hook in the first 10 seconds" : "Continue smoothly from previous content"}
- ${isLast ? "Include a strong call-to-action at the end" : "Set up a smooth transition to the next chapter"}
- Use natural speaking patterns with appropriate pauses
- Break complex ideas into digestible segments
- Include rhetorical questions to maintain engagement

Write the complete narration now:`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional video narrator. Write engaging, natural-sounding narration that keeps viewers engaged."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    const narration = response.choices[0].message.content || "";
    console.log(`✅ Narration expanded: ${narration.length} characters`);
    return narration;
  }

  async generateAudio(
    narration: string,
    voicePreference: "male" | "female" | "mixed",
    chapterIndex: number
  ): Promise<{ audioPath: string; actualDuration: number }> {
    console.log(`🎤 Generating audio for chapter ${chapterIndex + 1}...`);

    let voice: "alloy" | "echo" | "fable" | "onyx" | "nova" | "shimmer";
    
    if (voicePreference === "mixed") {
      voice = chapterIndex % 2 === 0 ? "onyx" : "nova";
    } else if (voicePreference === "male") {
      voice = "onyx";
    } else {
      voice = "nova";
    }

    const mp3 = await openai.audio.speech.create({
      model: "tts-1-hd",
      voice: voice,
      input: narration,
      speed: 1.0
    });

    const buffer = Buffer.from(await mp3.arrayBuffer());
    const audioPath = path.join(this.tempDir, `chapter_${chapterIndex}_${nanoid()}.mp3`);
    await fs.writeFile(audioPath, buffer);

    const { stdout } = await execAsync(
      `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${audioPath}"`
    );
    const actualDuration = parseFloat(stdout);

    console.log(`✅ Audio generated: ${Math.floor(actualDuration)} seconds`);
    return { audioPath, actualDuration };
  }

  async createVideoWithAudio(
    audioFiles: string[],
    outline: VideoOutline,
    outputPath: string
  ): Promise<{ duration: number; fileSize: number }> {
    console.log(`🎥 Creating final video with ${audioFiles.length} chapters...`);

    const fileListPath = path.join(this.tempDir, `filelist_${nanoid()}.txt`);
    const chapterVideos: string[] = [];

    for (let i = 0; i < audioFiles.length; i++) {
      const audioPath = audioFiles[i];
      const chapter = outline.chapters[i];
      const chapterVideoPath = path.join(this.tempDir, `chapter_${i}_video_${nanoid()}.mp4`);

      const { stdout } = await execAsync(
        `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${audioPath}"`
      );
      const duration = Math.ceil(parseFloat(stdout));

      const titleEscaped = chapter.title.replace(/'/g, "\\'").replace(/"/g, '\\"');
      const chapterNumberText = `Chapter ${i + 1}/${audioFiles.length}`;

      await execAsync(`ffmpeg -f lavfi -i "color=c=0x0a0e27:s=1920x1080:d=${duration}" \
        -i "${audioPath}" \
        -vf "drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${titleEscaped}':fontcolor=white:fontsize=64:x=(w-text_w)/2:y=(h-text_h)/2:borderw=3:bordercolor=black, \
             drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='${chapterNumberText}':fontcolor=0xaaaaaa:fontsize=32:x=(w-text_w)/2:y=h-100:borderw=2:bordercolor=black" \
        -c:v libx264 -preset fast -c:a aac -b:a 192k -shortest -pix_fmt yuv420p -y "${chapterVideoPath}"`);

      chapterVideos.push(chapterVideoPath);
      console.log(`✅ Chapter ${i + 1} video created`);
    }

    const fileListContent = chapterVideos.map(p => `file '${p}'`).join("\n");
    await fs.writeFile(fileListPath, fileListContent);

    await execAsync(
      `ffmpeg -f concat -safe 0 -i "${fileListPath}" -c copy -y "${outputPath}"`
    );

    const { stdout: durationStr } = await execAsync(
      `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${outputPath}"`
    );
    const finalDuration = Math.floor(parseFloat(durationStr));

    const stats = await fs.stat(outputPath);
    const fileSize = stats.size;

    for (const videoPath of chapterVideos) {
      await fs.unlink(videoPath).catch(() => {});
    }
    await fs.unlink(fileListPath).catch(() => {});

    console.log(`✅ Final video created: ${Math.floor(finalDuration / 60)}m ${finalDuration % 60}s, ${Math.floor(fileSize / 1024 / 1024)}MB`);
    return { duration: finalDuration, fileSize };
  }

  async generateVideo(
    topic: string,
    targetDuration: number,
    config: {
      videoStyle: "educational" | "entertainment" | "documentary" | "tutorial";
      voicePreference: "male" | "female" | "mixed";
    },
    progressCallback?: (progress: GenerationProgress) => void
  ): Promise<{
    filePath: string;
    duration: number;
    fileSize: number;
    script: string;
    checksum: string;
    chapters: Array<{ title: string; startTime: number; duration: number }>;
  }> {
    await this.ensureDirectories();

    try {
      progressCallback?.({
        phase: "outline",
        message: "Creating video outline..."
      });

      const outline = await this.generateOutline(topic, targetDuration, config.videoStyle);

      progressCallback?.({
        phase: "narration",
        totalChapters: outline.chapters.length,
        message: "Expanding chapter narrations..."
      });

      for (let i = 0; i < outline.chapters.length; i++) {
        const narration = await this.expandChapterNarration(
          outline.chapters[i],
          { title: outline.title, description: outline.description, topic: outline.topic },
          i,
          outline.chapters.length
        );
        outline.chapters[i].narration = narration;
      }

      progressCallback?.({
        phase: "audio",
        totalChapters: outline.chapters.length,
        message: "Generating audio..."
      });

      const audioFiles: string[] = [];
      let totalActualDuration = 0;
      
      for (let i = 0; i < outline.chapters.length; i++) {
        progressCallback?.({
          phase: "audio",
          currentChapter: i + 1,
          totalChapters: outline.chapters.length,
          message: `Generating audio for chapter ${i + 1}/${outline.chapters.length}...`
        });

        const { audioPath, actualDuration } = await this.generateAudio(
          outline.chapters[i].narration,
          config.voicePreference,
          i
        );
        outline.chapters[i].audioPath = audioPath;
        outline.chapters[i].duration = Math.ceil(actualDuration);
        audioFiles.push(audioPath);
        totalActualDuration += actualDuration;
      }

      console.log(`📊 Total audio duration: ${Math.floor(totalActualDuration / 60)}m ${Math.floor(totalActualDuration % 60)}s`);

      if (totalActualDuration < targetDuration) {
        const shortfall = targetDuration - totalActualDuration;
        console.log(`⚠️  Video is ${Math.floor(shortfall)} seconds short of ${Math.floor(targetDuration / 60)} minute target`);
        console.log(`🔄 Generating additional narration to meet duration requirement...`);

        const paddingNarration = await this.expandChapterNarration(
          {
            id: "bonus",
            title: "Closing Thoughts & Summary",
            duration: Math.ceil(shortfall),
            narration: "",
            visualCue: "Recap and final thoughts",
          },
          { title: outline.title, description: outline.description, topic: outline.topic },
          outline.chapters.length,
          outline.chapters.length + 1
        );

        const { audioPath: bonusAudioPath, actualDuration: bonusDuration } = await this.generateAudio(
          paddingNarration,
          config.voicePreference,
          outline.chapters.length
        );

        outline.chapters.push({
          id: `chapter-${outline.chapters.length + 1}`,
          title: "Closing Thoughts & Summary",
          duration: Math.ceil(bonusDuration),
          narration: paddingNarration,
          visualCue: "Recap and final thoughts",
          audioPath: bonusAudioPath
        });

        audioFiles.push(bonusAudioPath);
        totalActualDuration += bonusDuration;
        console.log(`✅ Added bonus chapter: ${Math.floor(bonusDuration)} seconds`);
      }

      outline.totalDuration = Math.ceil(totalActualDuration);
      console.log(`✅ Final duration: ${Math.floor(totalActualDuration / 60)}m ${Math.floor(totalActualDuration % 60)}s (${totalActualDuration >= targetDuration ? "✓" : "✗"} meets ${Math.floor(targetDuration / 60)}min requirement)`);
      
      if (totalActualDuration < targetDuration) {
        throw new Error(`Video duration (${Math.floor(totalActualDuration / 60)}m) is below required ${Math.floor(targetDuration / 60)}m`);
      }

      progressCallback?.({
        phase: "video",
        message: "Creating final video..."
      });

      const timestamp = Date.now();
      const videoId = nanoid();
      const outputPath = path.join(this.outputDir, `rumble_video_day_${timestamp}_${videoId}.mp4`);

      const { duration, fileSize } = await this.createVideoWithAudio(audioFiles, outline, outputPath);

      for (const audioPath of audioFiles) {
        await fs.unlink(audioPath).catch(() => {});
      }

      const fullScript = outline.chapters.map((ch, i) => 
        `[Chapter ${i + 1}: ${ch.title}]\n\n${ch.narration}\n`
      ).join("\n");

      const checksum = crypto.createHash("md5").update(fullScript).digest("hex");

      const chapterMetadata = outline.chapters.map((ch, i) => {
        const startTime = outline.chapters.slice(0, i).reduce((sum, c) => sum + c.duration, 0);
        return {
          title: ch.title,
          startTime,
          duration: ch.duration
        };
      });

      progressCallback?.({
        phase: "complete",
        message: "Video generation complete!"
      });

      return {
        filePath: outputPath,
        duration,
        fileSize,
        script: fullScript,
        checksum,
        chapters: chapterMetadata
      };

    } catch (error: any) {
      progressCallback?.({
        phase: "failed",
        message: "Video generation failed",
        error: error.message
      });
      throw error;
    }
  }

  async cleanupTempFiles(): Promise<void> {
    try {
      const files = await fs.readdir(this.tempDir);
      for (const file of files) {
        await fs.unlink(path.join(this.tempDir, file)).catch(() => {});
      }
    } catch (error) {
      console.error("Error cleaning up temp files:", error);
    }
  }
}

export const rumbleVideoGenerator = new RumbleVideoGenerator();
