import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Test with database connection only
import { db } from "./db";

app.get("/health", (req, res) => {
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    database: "connected"
  });
});

app.get("/api/test-db", async (req, res) => {
  try {
    // Test database connection
    const result = await db.execute("SELECT 1 as test");
    res.json({ message: "Database connection successful", result });
  } catch (error: any) {
    res.status(500).json({ error: "Database connection failed", message: error.message });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Isolated server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
});