#!/usr/bin/env npx tsx

import { RealYouTubeAutomation } from './real-youtube-automation';
import { CredentialValidator } from './credential-validator';

// Extract credentials from the JSON file
const credentials = {
  client_id: "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com",
  client_secret: "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",
  redirect_uri: "https://developers.google.com/oauthplayground"
};

async function setupRealAutomation() {
  console.log('🚀 Setting Up Real YouTube Automation');
  console.log('=====================================\n');
  
  console.log('📋 Credentials extracted from JSON file:');
  console.log('✅ Client ID: ' + credentials.client_id);
  console.log('✅ Client Secret: ' + credentials.client_secret);
  console.log('✅ Redirect URI: ' + credentials.redirect_uri);
  
  console.log('\n🔗 Next step: Get your refresh token');
  console.log('Go to: https://developers.google.com/oauthplayground/');
  console.log('\n📝 Steps:');
  console.log('1. Click the settings gear (top-right)');
  console.log('2. Check "Use your own OAuth credentials"');
  console.log('3. Enter your Client ID: ' + credentials.client_id);
  console.log('4. Enter your Client Secret: ' + credentials.client_secret);
  console.log('5. In left panel, select YouTube Data API v3');
  console.log('6. Select these scopes:');
  console.log('   ✓ https://www.googleapis.com/auth/youtube.upload');
  console.log('   ✓ https://www.googleapis.com/auth/youtube');
  console.log('7. Click "Authorize APIs"');
  console.log('8. Sign in with: jasonclarkagain@gmail.com');
  console.log('9. Grant permissions');
  console.log('10. Click "Exchange authorization code for tokens"');
  console.log('11. Copy the "refresh_token" value');
  
  console.log('\n🎯 Once you have the refresh token, the system will:');
  console.log('• Generate real educational videos');
  console.log('• Upload to your YouTube channel daily');
  console.log('• Create professional thumbnails');
  console.log('• Schedule 30 episodes automatically');
  console.log('• Start today with "The Water Cycle Adventure"');
  
  console.log('\n💡 The refresh token looks like:');
  console.log('1//04xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
  
  return credentials;
}

// Test function when refresh token is provided
async function testWithRefreshToken(refreshToken: string) {
  console.log('\n🧪 Testing YouTube Integration');
  console.log('==============================\n');
  
  const fullCredentials = {
    client_id: credentials.client_id,
    client_secret: credentials.client_secret,
    refresh_token: refreshToken
  };
  
  const validator = new CredentialValidator();
  
  console.log('Testing credentials...');
  const validation = await validator.validateCredentials(fullCredentials);
  
  if (validation.valid) {
    console.log('✅ YouTube connection successful!');
    console.log('\n📺 Channel Information:');
    console.log(`• Title: ${validation.channelInfo?.title}`);
    console.log(`• Subscribers: ${validation.channelInfo?.subscriberCount || 'N/A'}`);
    console.log(`• Videos: ${validation.channelInfo?.videoCount || 'N/A'}`);
    console.log(`• Upload Status: ${validation.channelInfo?.uploadsEnabled ? 'Enabled' : 'Check settings'}`);
    
    // Start real automation
    const automation = new RealYouTubeAutomation();
    await automation.setYouTubeCredentials(fullCredentials);
    
    console.log('\n🎬 Starting real video generation and upload...');
    await automation.generateTodaysRealVideo();
    
    console.log('\n🎉 SUCCESS! Real video uploaded to your YouTube channel');
    console.log('🕘 Daily automation will continue at 9:00 AM UTC for 30 days');
    
  } else {
    console.log(`❌ Connection failed: ${validation.error}`);
  }
}

async function main() {
  const creds = await setupRealAutomation();
  
  // Check if refresh token is provided as argument
  const refreshToken = process.argv[2];
  
  if (refreshToken && refreshToken.startsWith('1//')) {
    await testWithRefreshToken(refreshToken);
  } else {
    console.log('\n⏳ Waiting for refresh token...');
    console.log('Run this command when you have it:');
    console.log(`npx tsx setup-real-automation.ts "YOUR_REFRESH_TOKEN"`);
  }
}

if (require.main === module) {
  main().catch(console.error);
}

export { setupRealAutomation };