#!/usr/bin/env npx tsx

import OpenAI from "openai";
import { google } from 'googleapis';
import { createCanvas } from 'canvas';
import fs from 'fs/promises';
import path from 'path';
import ffmpeg from 'fluent-ffmpeg';
import { createReadStream } from 'fs';
import cron from 'node-cron';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const YOUTUBE_CREDENTIALS = {
  client_id: "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com",
  client_secret: "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"
};

interface Episode {
  number: number;
  title: string;
  topic: string;
  script: any;
  status: 'pending' | 'generating' | 'uploading' | 'uploaded' | 'failed';
  videoId?: string;
  url?: string;
  uploadTime?: string;
}

export class CompleteYouTubeAutomation {
  private episodes: Episode[] = [];
  private currentEpisode = 1;
  private outputDir: string;
  private youtube: any;
  private scheduledTask: cron.ScheduledTask | null = null;

  constructor() {
    this.outputDir = path.join(process.cwd(), "youtube_automation_output");
    this.initializeEpisodes();
    this.ensureDirectories();
  }

  private initializeEpisodes() {
    const topics = [
      "The Water Cycle Adventure", "Solar System Exploration", "How Plants Grow",
      "Animal Habitats", "Weather Patterns", "Ocean Life", "Dinosaur Discovery",
      "Counting Adventures", "Shape Recognition", "Pattern Discovery",
      "Simple Addition", "Measurement Fun", "Time Concepts", "Money Basics",
      "Alphabet Adventures", "Storytelling Basics", "Reading Together",
      "Writing Skills", "Communication", "Different Languages", "Poetry Fun",
      "Colors and Art", "Music Exploration", "World Cultures",
      "Creative Building", "Dance and Movement", "Cooking Together", "Nature Art",
      "Kindness Matters", "Problem Solving"
    ];

    this.episodes = topics.map((topic, index) => ({
      number: index + 1,
      title: `${topic} - Episode ${index + 1}`,
      topic,
      script: null,
      status: 'pending'
    }));
  }

  private async ensureDirectories() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
      await fs.mkdir(path.join(this.outputDir, 'videos'), { recursive: true });
      await fs.mkdir(path.join(this.outputDir, 'thumbnails'), { recursive: true });
      await fs.mkdir(path.join(this.outputDir, 'temp'), { recursive: true });
    } catch (error) {
      console.log("Output directories already exist");
    }
  }

  async initializeWithRefreshToken(refreshToken: string): Promise<boolean> {
    try {
      const oauth2Client = new google.auth.OAuth2(
        YOUTUBE_CREDENTIALS.client_id,
        YOUTUBE_CREDENTIALS.client_secret,
        'http://localhost:3000/oauth2callback'
      );

      oauth2Client.setCredentials({
        refresh_token: refreshToken
      });

      this.youtube = google.youtube({
        version: 'v3',
        auth: oauth2Client
      });

      // Test connection
      const channelResponse = await this.youtube.channels.list({
        part: ['snippet'],
        mine: true
      });

      if (channelResponse.data.items && channelResponse.data.items.length > 0) {
        console.log(`YouTube connection established for: ${channelResponse.data.items[0].snippet?.title}`);
        return true;
      }
      return false;
    } catch (error) {
      console.error("YouTube initialization failed:", error);
      return false;
    }
  }

  async generateEpisodeScript(episode: Episode): Promise<any> {
    const prompt = `Create a professional educational video script for "${episode.topic}" - Episode ${episode.number}/30.

Series: Amazing Learning Adventures - Educational Series
Characters: Captain Marina (wise educator), Curious Casey (enthusiastic student), Luna the Explorer (creative problem-solver)
Target: Educational content for families, G-rated, 5-6 minutes
YouTube Channel: jasonclarkagain@gmail.com

Create engaging educational content about ${episode.topic} with clear learning objectives.

Format as JSON:
{
  "title": "${episode.title}",
  "description": "Educational description with learning value",
  "educationalObjectives": ["objective 1", "objective 2", "objective 3"],
  "scenes": [
    {
      "duration": 300,
      "dialog": [
        {
          "character": "Captain Marina",
          "text": "Welcome to our adventure!",
          "timing": {"start": 0, "end": 5}
        }
      ],
      "visualDescription": "Colorful educational scene"
    }
  ],
  "tags": ["education", "learning", "family-friendly", "kids"]
}`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        temperature: 0.7
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.log(`Using fallback script for ${episode.topic}`);
      return {
        title: episode.title,
        description: `Join Captain Marina, Curious Casey, and Luna as they explore ${episode.topic}! An educational adventure perfect for curious families.`,
        educationalObjectives: [
          `Learn about ${episode.topic}`,
          "Engage with interactive content",
          "Develop curiosity and critical thinking"
        ],
        scenes: [{
          duration: 300,
          dialog: [{
            character: "Captain Marina",
            text: `Welcome to our amazing adventure about ${episode.topic}!`,
            timing: { start: 0, end: 5 }
          }],
          visualDescription: `Educational scene about ${episode.topic}`
        }],
        tags: ["education", "learning", "family-friendly", "kids", episode.topic.toLowerCase().replace(/\s+/g, '-')]
      };
    }
  }

  async createVideoFile(episode: Episode): Promise<string> {
    console.log(`Creating video for Episode ${episode.number}: ${episode.title}`);
    
    const videoPath = path.join(this.outputDir, 'videos', `episode_${episode.number}.mp4`);
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');
    
    // Generate video frames (5 minutes at 2 fps for efficiency)
    const frames: Buffer[] = [];
    const totalFrames = 600; // 5 minutes at 2 fps
    
    for (let frame = 0; frame < totalFrames; frame++) {
      // Background gradient
      const gradient = ctx.createLinearGradient(0, 0, 1920, 1080);
      gradient.addColorStop(0, '#4F46E5');
      gradient.addColorStop(0.5, '#10B981');
      gradient.addColorStop(1, '#F59E0B');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 1920, 1080);
      
      // Episode number
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 100px Arial';
      ctx.textAlign = 'center';
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 5;
      ctx.strokeText(`Episode ${episode.number}`, 960, 200);
      ctx.fillText(`Episode ${episode.number}`, 960, 200);
      
      // Title
      ctx.font = 'bold 80px Arial';
      const titleLines = this.wrapText(ctx, episode.title, 1700);
      titleLines.forEach((line, index) => {
        const y = 350 + (index * 90);
        ctx.strokeText(line, 960, y);
        ctx.fillText(line, 960, y);
      });
      
      // Series info
      ctx.font = '50px Arial';
      ctx.strokeText('Amazing Learning Adventures', 960, 600);
      ctx.fillText('Amazing Learning Adventures', 960, 600);
      
      // Characters
      ctx.font = '40px Arial';
      ctx.strokeText('Captain Marina • Curious Casey • Luna', 960, 700);
      ctx.fillText('Captain Marina • Curious Casey • Luna', 960, 700);
      
      // Time indicator
      const currentTime = Math.floor(frame / 2);
      const minutes = Math.floor(currentTime / 60);
      const seconds = currentTime % 60;
      ctx.font = '35px Arial';
      ctx.strokeText(`${minutes}:${seconds.toString().padStart(2, '0')}`, 960, 800);
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, '0')}`, 960, 800);
      
      // Educational badge
      ctx.fillStyle = '#F59E0B';
      ctx.fillRect(50, 950, 300, 80);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 40px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('EDUCATIONAL', 200, 1000);
      
      frames.push(canvas.toBuffer('image/png'));
    }
    
    // Create video using ffmpeg
    return new Promise((resolve, reject) => {
      const tempDir = path.join(this.outputDir, 'temp', `episode_${episode.number}`);
      
      fs.mkdir(tempDir, { recursive: true }).then(async () => {
        // Write frames
        for (let i = 0; i < frames.length; i++) {
          await fs.writeFile(
            path.join(tempDir, `frame_${i.toString().padStart(6, '0')}.png`),
            frames[i]
          );
        }
        
        // Create video
        ffmpeg()
          .input(path.join(tempDir, 'frame_%06d.png'))
          .inputFPS(2)
          .outputFPS(30)
          .videoCodec('libx264')
          .outputOptions([
            '-pix_fmt yuv420p',
            '-crf 23',
            '-preset medium'
          ])
          .size('1920x1080')
          .duration(300)
          .output(videoPath)
          .on('end', async () => {
            // Cleanup
            try {
              const files = await fs.readdir(tempDir);
              for (const file of files) {
                await fs.unlink(path.join(tempDir, file));
              }
              await fs.rmdir(tempDir);
            } catch (error) {
              console.warn("Cleanup warning:", error);
            }
            resolve(videoPath);
          })
          .on('error', reject)
          .run();
      });
    });
  }

  private wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
    const words = text.split(' ');
    const lines: string[] = [];
    let currentLine = words[0];

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const width = ctx.measureText(currentLine + " " + word).width;
      if (width < maxWidth) {
        currentLine += " " + word;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    lines.push(currentLine);
    return lines;
  }

  async createThumbnail(episode: Episode): Promise<string> {
    const thumbnailPath = path.join(this.outputDir, 'thumbnails', `episode_${episode.number}.png`);
    const canvas = createCanvas(1280, 720);
    const ctx = canvas.getContext('2d');
    
    // Background
    const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
    gradient.addColorStop(0, '#4F46E5');
    gradient.addColorStop(0.5, '#10B981');
    gradient.addColorStop(1, '#F59E0B');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1280, 720);
    
    // Episode badge
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(50, 50, 200, 100);
    ctx.fillStyle = '#4F46E5';
    ctx.font = 'bold 60px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`EP ${episode.number}`, 150, 115);
    
    // Title
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 70px Arial';
    ctx.textAlign = 'center';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    
    const titleLines = this.wrapText(ctx, episode.topic, 1100);
    titleLines.forEach((line, index) => {
      const y = 300 + (index * 80);
      ctx.strokeText(line, 640, y);
      ctx.fillText(line, 640, y);
    });
    
    // Series
    ctx.font = '45px Arial';
    ctx.strokeText('Amazing Learning Adventures', 640, 500);
    ctx.fillText('Amazing Learning Adventures', 640, 500);
    
    // Educational badge
    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(50, 570, 300, 80);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 40px Arial';
    ctx.fillText('EDUCATIONAL', 200, 620);
    
    await fs.writeFile(thumbnailPath, canvas.toBuffer('image/png'));
    return thumbnailPath;
  }

  async uploadToYouTube(episode: Episode, videoPath: string, thumbnailPath: string): Promise<any> {
    console.log(`Uploading Episode ${episode.number} to YouTube...`);
    
    const videoResponse = await this.youtube.videos.insert({
      part: ['snippet', 'status'],
      requestBody: {
        snippet: {
          title: episode.script.title,
          description: this.createDescription(episode),
          tags: episode.script.tags,
          categoryId: '27', // Education
          defaultLanguage: 'en'
        },
        status: {
          privacyStatus: 'public',
          selfDeclaredMadeForKids: true,
          embeddable: true
        }
      },
      media: {
        body: createReadStream(videoPath)
      }
    });

    const videoId = videoResponse.data.id;
    
    // Upload thumbnail
    try {
      await this.youtube.thumbnails.set({
        videoId: videoId,
        media: {
          body: createReadStream(thumbnailPath)
        }
      });
    } catch (error) {
      console.warn("Thumbnail upload warning:", error);
    }

    return {
      videoId,
      url: `https://www.youtube.com/watch?v=${videoId}`,
      uploadTime: new Date().toISOString()
    };
  }

  private createDescription(episode: Episode): string {
    return `🎓 ${episode.script.title} - Episode ${episode.number}/30

${episode.script.description}

📚 Learning Objectives:
${episode.script.educationalObjectives?.map((obj: string) => `• ${obj}`).join('\n')}

🌟 Meet Our Characters:
• Captain Marina - Your wise learning guide
• Curious Casey - Asks the best questions  
• Luna the Explorer - Discovers amazing things

👨‍👩‍👧‍👦 Perfect for families who love learning together!

🔔 Subscribe for daily educational adventures!
📺 New episodes every day at 9:00 AM UTC
🎯 30-day educational series covering science, math, language, arts, and life skills

#Education #Learning #FamilyFriendly #Kids #Educational #${episode.topic.replace(/\s+/g, '')}

---
Amazing Learning Adventures - Educational Series
Channel: jasonclarkagain@gmail.com`;
  }

  async processEpisode(episodeNumber: number): Promise<void> {
    const episode = this.episodes[episodeNumber - 1];
    if (!episode) return;

    try {
      episode.status = 'generating';
      console.log(`\nProcessing Episode ${episode.number}: ${episode.topic}`);
      
      // Generate script
      episode.script = await this.generateEpisodeScript(episode);
      console.log(`Script generated for: ${episode.script.title}`);
      
      // Create video
      const videoPath = await this.createVideoFile(episode);
      console.log(`Video created: ${videoPath}`);
      
      // Create thumbnail
      const thumbnailPath = await this.createThumbnail(episode);
      console.log(`Thumbnail created: ${thumbnailPath}`);
      
      // Upload to YouTube
      episode.status = 'uploading';
      const uploadResult = await this.uploadToYouTube(episode, videoPath, thumbnailPath);
      
      episode.status = 'uploaded';
      episode.videoId = uploadResult.videoId;
      episode.url = uploadResult.url;
      episode.uploadTime = uploadResult.uploadTime;
      
      console.log(`✅ Episode ${episode.number} uploaded successfully!`);
      console.log(`📺 Video ID: ${episode.videoId}`);
      console.log(`🔗 URL: ${episode.url}`);
      
      // Cleanup files
      await fs.unlink(videoPath);
      await fs.unlink(thumbnailPath);
      
      // Save progress
      await this.saveProgress();
      
    } catch (error) {
      episode.status = 'failed';
      console.error(`❌ Episode ${episode.number} failed:`, error);
    }
  }

  async saveProgress(): Promise<void> {
    const progress = {
      seriesTitle: "Amazing Learning Adventures - Educational Series",
      youtubeAccount: "jasonclarkagain@gmail.com",
      totalEpisodes: this.episodes.length,
      currentEpisode: this.currentEpisode,
      episodes: this.episodes.map(ep => ({
        number: ep.number,
        title: ep.title,
        topic: ep.topic,
        status: ep.status,
        videoId: ep.videoId,
        url: ep.url,
        uploadTime: ep.uploadTime
      })),
      lastUpdated: new Date().toISOString()
    };

    await fs.writeFile(
      path.join(this.outputDir, 'automation_progress.json'),
      JSON.stringify(progress, null, 2)
    );
  }

  async startDailyAutomation(): Promise<void> {
    console.log("🚀 Starting daily YouTube automation...");
    
    // Process today's episode
    await this.processEpisode(this.currentEpisode);
    this.currentEpisode++;
    
    // Schedule daily uploads
    this.scheduledTask = cron.schedule('0 9 * * *', async () => {
      if (this.currentEpisode <= this.episodes.length) {
        await this.processEpisode(this.currentEpisode);
        this.currentEpisode++;
      } else {
        console.log("🎉 30-day series completed!");
        this.stopAutomation();
      }
    }, {
      scheduled: true,
      timezone: "UTC"
    });
    
    console.log("✅ Daily automation active - uploads at 9:00 AM UTC");
  }

  stopAutomation(): void {
    if (this.scheduledTask) {
      this.scheduledTask.stop();
      this.scheduledTask = null;
    }
  }

  getStatus(): any {
    const uploaded = this.episodes.filter(ep => ep.status === 'uploaded').length;
    const failed = this.episodes.filter(ep => ep.status === 'failed').length;
    
    return {
      isActive: this.scheduledTask !== null,
      totalEpisodes: this.episodes.length,
      uploaded,
      failed,
      pending: this.episodes.length - uploaded - failed,
      currentEpisode: this.currentEpisode,
      nextEpisode: this.currentEpisode <= this.episodes.length ? this.episodes[this.currentEpisode - 1]?.topic : null,
      progress: `${uploaded}/${this.episodes.length} episodes uploaded`
    };
  }
}

// Main execution
async function main() {
  const refreshToken = process.argv[2];
  
  if (!refreshToken) {
    console.log("❌ Please provide YouTube refresh token");
    console.log("Get it from: https://developers.google.com/oauthplayground/");
    console.log("Usage: npx tsx complete-youtube-automation.ts \"REFRESH_TOKEN\"");
    return;
  }

  const automation = new CompleteYouTubeAutomation();
  
  console.log("🔧 Initializing YouTube automation...");
  const initialized = await automation.initializeWithRefreshToken(refreshToken);
  
  if (!initialized) {
    console.log("❌ YouTube initialization failed. Check your refresh token.");
    return;
  }

  console.log("✅ YouTube connection established");
  await automation.startDailyAutomation();
  
  console.log("\n🎉 SUCCESS! YouTube automation is now running!");
  console.log("📺 Videos will be uploaded daily to jasonclarkagain@gmail.com");
  console.log("🕘 Schedule: 9:00 AM UTC every day for 30 days");
  console.log("📊 Check automation_progress.json for status updates");
}

if (require.main === module) {
  main().catch(console.error);
}