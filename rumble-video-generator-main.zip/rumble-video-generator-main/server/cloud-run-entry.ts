#!/usr/bin/env node
/**
 * Cloud Run Production Entry Point
 * This file MUST be used for Cloud Run deployments to avoid port conflicts
 */

// FORCE production mode immediately - prevents all development features
process.env.NODE_ENV = "production";

import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import path from "path";
import { fileURLToPath } from "url";
import { createRoutes } from "./routes";
import { storage } from "./storage";
import { getRumbleCronService } from "./services/rumbleCron";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log("========================================");
console.log("CLOUD RUN PRODUCTION SERVER STARTING");
console.log("========================================");
console.log(`NODE_ENV: ${process.env.NODE_ENV}`);
console.log(`PORT from environment: ${process.env.PORT}`);
console.log("This server does NOT use Vite or HMR");
console.log("========================================");

async function startCloudRunServer() {
  const app = express();
  
  // CRITICAL: Use ONLY the PORT provided by Cloud Run
  // Cloud Run sets this dynamically - NEVER hardcode it
  const PORT = parseInt(process.env.PORT || "8080", 10);
  
  if (!process.env.PORT) {
    console.warn("⚠️ WARNING: PORT environment variable not set, using default 8080");
    console.warn("⚠️ Cloud Run should provide PORT - check deployment configuration");
  }
  
  console.log(`✅ Will listen on PORT ${PORT} (required by Cloud Run)`);

  // Middleware
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "blob:", "https:"],
        connectSrc: ["'self'", "https:"],
        fontSrc: ["'self'", "data:"],
      },
    },
  }));
  
  app.use(cors({
    origin: true,
    credentials: true
  }));
  
  app.use(morgan("combined"));
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // API Routes
  app.use(createRoutes(storage));

  // Health check endpoint - Cloud Run uses this
  app.get("/health", (req, res) => {
    res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      service: "rumble-video-generator",
      version: "1.0.0",
      port: PORT,
      env: process.env.NODE_ENV,
      message: "Cloud Run production server is healthy"
    });
  });

  // Root endpoint for Cloud Run health probes
  app.get("/", (req, res, next) => {
    const userAgent = req.headers["user-agent"] || "";
    const accept = req.headers.accept || "";
    
    // Health probes don't send browser headers
    const isBrowser = accept.includes("text/html") || userAgent.includes("Mozilla");
    
    if (!isBrowser) {
      // Return JSON for health probes
      return res.json({
        status: "healthy",
        service: "rumble-video-generator",
        port: PORT,
        timestamp: new Date().toISOString()
      });
    }
    
    // For browsers, continue to serve the app
    next();
  });

  // Serve static frontend files
  const clientDistPath = path.resolve(__dirname, "../client/dist");
  const clientSrcPath = path.resolve(__dirname, "../client");
  
  // Check if built files exist
  if (fs.existsSync(clientDistPath)) {
    console.log("✅ Serving built frontend from client/dist");
    app.use(express.static(clientDistPath));
    
    // SPA fallback - serve index.html for all non-API routes
    app.get("*", (req, res) => {
      const indexPath = path.join(clientDistPath, "index.html");
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send("Frontend not built. Run: npm run build");
      }
    });
  } else {
    console.warn("⚠️ Frontend not built - serving fallback");
    
    // Fallback HTML if build doesn't exist
    app.get("*", (req, res) => {
      res.send(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Rumble Video Generator</title>
            <style>
              body { 
                font-family: Arial, sans-serif; 
                display: flex; 
                justify-content: center; 
                align-items: center; 
                height: 100vh; 
                margin: 0;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
              }
              .container {
                text-align: center;
                padding: 2rem;
                background: rgba(255,255,255,0.1);
                border-radius: 10px;
                backdrop-filter: blur(10px);
              }
              h1 { margin-bottom: 1rem; }
              .status { 
                background: rgba(0,255,0,0.2); 
                padding: 0.5rem 1rem; 
                border-radius: 5px;
                margin-top: 1rem;
              }
              a { color: white; text-decoration: underline; }
            </style>
          </head>
          <body>
            <div class="container">
              <h1>🎬 Rumble Video Generator</h1>
              <p>Cloud Run Production Server</p>
              <div class="status">✅ Server is running on port ${PORT}</div>
              <p style="margin-top: 2rem;">
                <a href="/health">Health Check</a> | 
                <a href="/api/rumble/status">API Status</a>
              </p>
              <p style="margin-top: 2rem; font-size: 0.9em; opacity: 0.8;">
                Frontend needs to be built. Run: npm run build
              </p>
            </div>
          </body>
        </html>
      `);
    });
  }

  // Error handling middleware
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error("Server error:", err);
    res.status(500).json({
      error: "Internal server error",
      message: process.env.NODE_ENV === "production" ? "Something went wrong" : err.message
    });
  });

  // Initialize Rumble cron service
  const rumbleCron = getRumbleCronService(storage);
  rumbleCron.start();
  console.log("✅ Rumble cron service started (daily at 02:00 UTC)");

  // Create HTTP server and bind to PORT
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log("\n========================================");
    console.log("✅ CLOUD RUN SERVER STARTED SUCCESSFULLY");
    console.log("========================================");
    console.log(`📊 Listening on: 0.0.0.0:${PORT}`);
    console.log(`🌐 Health check: http://0.0.0.0:${PORT}/health`);
    console.log(`🎬 API endpoints: http://0.0.0.0:${PORT}/api/*`);
    console.log(`📅 Rumble cron: Daily at 02:00 UTC`);
    console.log(`🔧 Environment: ${process.env.NODE_ENV}`);
    console.log(`✅ NO Vite, NO HMR, NO port 24678`);
    console.log("========================================\n");
  });

  // Handle server errors
  server.on("error", (error: any) => {
    if (error.code === "EADDRINUSE") {
      console.error("\n========================================");
      console.error(`❌ CRITICAL ERROR: PORT ${PORT} IS IN USE`);
      console.error("========================================");
      console.error("This should NEVER happen in Cloud Run!");
      console.error("Check that:");
      console.error("1. This is the ONLY server file running");
      console.error("2. No other process is using port", PORT);
      console.error("3. Cloud Run container isn't starting multiple times");
      console.error("========================================\n");
      process.exit(1);
    } else {
      console.error("❌ Server error:", error);
      process.exit(1);
    }
  });

  // Graceful shutdown
  const shutdown = () => {
    console.log("\n📋 Shutting down gracefully...");
    rumbleCron.stop();
    server.close(() => {
      console.log("✅ Server closed cleanly");
      process.exit(0);
    });
    
    // Force exit after 10 seconds
    setTimeout(() => {
      console.warn("⚠️ Forced shutdown after timeout");
      process.exit(0);
    }, 10000);
  };

  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

// Handle uncaught errors
process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason);
});

process.on("uncaughtException", (error) => {
  console.error("Uncaught Exception:", error);
  process.exit(1);
});

// START THE SERVER
startCloudRunServer().catch((err) => {
  console.error("❌ Failed to start Cloud Run server:", err);
  process.exit(1);
});