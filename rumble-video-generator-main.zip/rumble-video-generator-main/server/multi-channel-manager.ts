import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';
import { createCanvas } from 'canvas';
import ffmpeg from 'fluent-ffmpeg';
import cron from 'node-cron';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface Channel {
  id: string;
  name: string;
  theme: string;
  characters: string[];
  targetAudience: string;
  contentStyle: string;
  uploadSchedule: string;
  description: string;
}

interface Episode {
  channelId: string;
  episodeNumber: number;
  title: string;
  topic: string;
  script: any;
  status: 'pending' | 'generating' | 'completed' | 'failed';
  videoPath?: string;
  thumbnailPath?: string;
  createdAt?: string;
  scheduledFor?: string;
}

class MultiChannelManager {
  private channels: Map<string, Channel> = new Map();
  private episodes: Episode[] = [];
  private outputDir: string;
  private scheduledTasks: Map<string, cron.ScheduledTask> = new Map();

  constructor() {
    this.outputDir = path.join(process.cwd(), 'server', 'multi_channel_output');
    this.initializeChannels();
    this.ensureDirectories();
  }

  private initializeChannels() {
    const channelConfigs = [
      {
        id: 'educational_adventures',
        name: 'Amazing Learning Adventures',
        theme: 'Educational content for children',
        characters: ['Captain Marina', 'Curious Casey', 'Luna'],
        targetAudience: 'Children ages 5-12',
        contentStyle: 'Interactive educational adventures',
        uploadSchedule: '0 9 * * *', // Daily at 9 AM
        description: 'Educational adventures with Captain Marina and friends'
      },
      {
        id: 'science_explorers',
        name: 'Science Explorers',
        theme: 'Science and discovery',
        characters: ['Dr. Spark', 'Wonder Kid', 'Experiment Bot'],
        targetAudience: 'Students ages 8-14',
        contentStyle: 'Science experiments and explanations',
        uploadSchedule: '0 15 * * *', // Daily at 3 PM
        description: 'Exciting science experiments and discoveries'
      },
      {
        id: 'story_time_magic',
        name: 'Story Time Magic',
        theme: 'Storytelling and creativity',
        characters: ['Narrator Nova', 'Story Sprite', 'Book Buddy'],
        targetAudience: 'Children ages 3-10',
        contentStyle: 'Interactive storytelling and moral lessons',
        uploadSchedule: '0 19 * * *', // Daily at 7 PM
        description: 'Magical stories that inspire and teach'
      },
      {
        id: 'math_adventures',
        name: 'Math Adventures',
        theme: 'Mathematics made fun',
        characters: ['Count Captain', 'Number Ninja', 'Equation Explorer'],
        targetAudience: 'Students ages 6-12',
        contentStyle: 'Math concepts through games and adventures',
        uploadSchedule: '0 10 * * *', // Daily at 10 AM
        description: 'Making math fun and accessible for everyone'
      },
      {
        id: 'creative_crafts',
        name: 'Creative Crafts Corner',
        theme: 'Arts, crafts, and creativity',
        characters: ['Artsy Amy', 'Crafty Carl', 'Creative Chloe'],
        targetAudience: 'Children ages 4-12',
        contentStyle: 'DIY crafts and artistic projects',
        uploadSchedule: '0 14 * * *', // Daily at 2 PM
        description: 'Inspiring creativity through fun craft projects'
      }
    ];

    channelConfigs.forEach(config => {
      this.channels.set(config.id, config);
    });
  }

  private ensureDirectories() {
    const baseDir = this.outputDir;
    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true });
    }

    this.channels.forEach(channel => {
      const channelDir = path.join(baseDir, channel.id);
      const dirs = [
        channelDir,
        path.join(channelDir, 'videos'),
        path.join(channelDir, 'thumbnails'),
        path.join(channelDir, 'scripts')
      ];

      dirs.forEach(dir => {
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
      });
    });
  }

  private generateTopicsForChannel(channelId: string): string[] {
    const channel = this.channels.get(channelId);
    if (!channel) return [];

    const topicSets = {
      educational_adventures: [
        "The Water Cycle Adventure", "Journey Through Solar System", "Amazing Plant Life",
        "Forest Animal Friends", "Weather Around the World", "Ocean Depths",
        "Dinosaur Time Machine", "Volcano Expedition", "Space Station Visit",
        "Arctic Animal Safari", "Rainforest Discovery", "Desert Survival",
        "Mountain Climbing Adventure", "Underwater Exploration", "Cave Discovery",
        "Butterfly Migration", "Bee Colony Adventure", "Bird Migration Journey",
        "Seasons Change Quest", "River Journey", "Lake Ecosystem",
        "Grassland Adventure", "Tundra Exploration", "Swamp Discovery",
        "Coral Reef Adventure", "Deep Sea Creatures", "Polar Bear Habitat",
        "Penguin Colony Visit", "Elephant Safari", "Monkey Jungle Trek"
      ],
      science_explorers: [
        "Chemical Reactions Lab", "Physics Fun with Magnets", "Electricity Experiments",
        "Light and Colors", "Sound Wave Discovery", "Matter States",
        "Gravity Adventures", "Simple Machines", "Weather Science",
        "Plant Growth Experiments", "Animal Behavior Study", "Microscopic World",
        "Crystals and Minerals", "Fossil Hunting", "Space Exploration",
        "Robotics Basics", "Coding for Kids", "Solar System Models",
        "Airplane Physics", "Bridge Building", "Tower Construction",
        "Lever and Pulley", "Gear Systems", "Hydraulics Demo",
        "Pneumatics Fun", "Battery Power", "Circuit Building",
        "Telescope Making", "Microscope Adventures", "Laboratory Safety"
      ],
      story_time_magic: [
        "The Brave Little Mouse", "Magic Garden Adventure", "Friendship Forest",
        "The Kindness Castle", "Rainbow Bridge Mystery", "Helping Hands Village",
        "The Sharing Tree", "Adventure Island", "Courage Cave",
        "The Honest Owl", "Patience Palace", "Teamwork Tournament",
        "The Grateful Giant", "Respect River", "Wisdom Woods",
        "The Forgiving Fox", "Trust Tower", "Joy Journey",
        "The Caring Cat", "Love Lake", "Hope Hill",
        "The Persistent Penguin", "Dream Drive", "Faith Forest",
        "The Generous Giraffe", "Peace Park", "Unity Valley",
        "The Responsible Rabbit", "Success Story", "Growth Garden",
        "The Confident Cheetah", "Imagination Island", "Wonder World"
      ],
      math_adventures: [
        "Counting Carnival", "Shape Safari", "Pattern Palace",
        "Addition Castle", "Subtraction Station", "Multiplication Mountain",
        "Division Desert", "Fraction Forest", "Decimal Discovery",
        "Geometry Garden", "Algebra Adventure", "Statistics Safari",
        "Probability Park", "Measurement Maze", "Time Travel Math",
        "Money Math Market", "Graph Gallery", "Coordinate Quest",
        "Angle Adventure", "Perimeter Playground", "Area Arena",
        "Volume Voyage", "Symmetry Show", "Transformation Tale",
        "Number Line Journey", "Place Value Palace", "Rounding Ranch",
        "Estimation Station", "Problem Solving Plaza", "Logic Land",
        "Calculator Challenge"
      ],
      creative_crafts: [
        "Paper Airplane Factory", "Origami Adventure", "Painting Paradise",
        "Clay Creations", "Recycled Art", "Nature Crafts",
        "Friendship Bracelets", "Cardboard Castles", "Sock Puppets",
        "Rock Painting", "Leaf Art", "Flower Pressing",
        "Collage Creation", "Mask Making", "Puppet Show",
        "Bead Jewelry", "Sewing Basics", "Knitting Fun",
        "Scrapbook Stories", "Photo Crafts", "Drawing Lessons",
        "Watercolor Wonders", "Chalk Art", "Crayon Creations",
        "Sticker Stories", "Glitter Art", "Foam Crafts",
        "Pipe Cleaner Animals", "Button Art", "Craft Stick Creations"
      ]
    };

    return topicSets[channelId] || [];
  }

  async generateChannelScript(channelId: string, topic: string, episodeNumber: number): Promise<any> {
    const channel = this.channels.get(channelId);
    if (!channel) throw new Error(`Channel ${channelId} not found`);

    const charactersText = channel.characters.join(', ');
    
    const prompt = `Create a 5-minute video script for "${channel.name}" about "${topic}" for ${channel.targetAudience}.

    Channel Style: ${channel.contentStyle}
    Characters: ${charactersText}
    
    Requirements:
    - Educational and engaging content
    - ${channel.characters.length} characters with distinct personalities
    - 5 scenes with detailed dialog and visuals
    - Family-friendly G-rated content
    - Interactive elements for engagement
    - Clear learning outcomes
    - Consistent with channel theme: ${channel.theme}
    
    Format as JSON with:
    {
      "channel_id": "${channelId}",
      "channel_name": "${channel.name}",
      "title": "${topic}",
      "episode_number": ${episodeNumber},
      "description": "Engaging episode description",
      "educational_objectives": ["objective1", "objective2", "objective3"],
      "target_audience": "${channel.targetAudience}",
      "characters": {
        ${channel.characters.map(char => `"${char.toLowerCase().replace(/\s+/g, '_')}": "Character description"`).join(',\n        ')}
      },
      "scenes": [
        {
          "scene_number": 1,
          "duration": 60,
          "setting": "detailed scene setting",
          "visual_description": "what viewers see in detail",
          "dialog": [
            {"character": "${channel.characters[0]}", "text": "Welcome message...", "emotion": "excited"},
            {"character": "${channel.characters[1]}", "text": "Question or response...", "emotion": "curious"},
            {"character": "${channel.characters[2]}", "text": "Discovery or explanation...", "emotion": "amazed"}
          ],
          "educational_focus": "what this scene teaches",
          "interactive_element": "question or activity for viewers"
        }
      ],
      "conclusion": "memorable wrap-up message",
      "call_to_action": "engagement prompt",
      "fun_facts": ["interesting fact 1", "interesting fact 2"],
      "vocabulary": ["new word 1", "new word 2", "new word 3"]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content);
  }

  async createChannelVideo(channelId: string, episode: Episode): Promise<string> {
    const channel = this.channels.get(channelId);
    if (!channel) throw new Error(`Channel ${channelId} not found`);

    const videoPath = path.join(
      this.outputDir,
      channelId,
      'videos',
      `episode_${episode.episodeNumber.toString().padStart(2, '0')}_${episode.title.replace(/[^a-zA-Z0-9]/g, '_')}.mp4`
    );

    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');

    // Create 5-minute video (300 seconds at 30 FPS = 9000 frames)
    const totalFrames = 9000;
    const frameDir = path.join(this.outputDir, channelId, 'temp_frames');
    if (!fs.existsSync(frameDir)) {
      fs.mkdirSync(frameDir, { recursive: true });
    }

    console.log(`Creating video for ${channel.name}: ${episode.title}`);

    // Generate theme-based color scheme
    const themeColors = this.getThemeColors(channelId);

    for (let frameIndex = 0; frameIndex < totalFrames; frameIndex++) {
      const sceneIndex = Math.floor(frameIndex / (totalFrames / 5));
      const progress = frameIndex / totalFrames;

      // Dynamic background based on channel theme
      const bgGradient = ctx.createLinearGradient(0, 0, 1920, 1080);
      bgGradient.addColorStop(0, themeColors.primary);
      bgGradient.addColorStop(1, themeColors.secondary);
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, 1920, 1080);

      // Add theme-specific decorative elements
      this.addThemeDecorations(ctx, channelId, frameIndex);

      // Channel branding
      ctx.fillStyle = themeColors.accent;
      ctx.font = 'bold 36px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(channel.name, 960, 80);

      // Episode title
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 64px Arial';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 4;
      ctx.strokeText(episode.title, 960, 300);
      ctx.fillText(episode.title, 960, 300);

      // Episode number
      ctx.font = 'bold 42px Arial';
      ctx.fillStyle = themeColors.text;
      ctx.fillText(`Episode ${episode.episodeNumber}`, 960, 380);

      // Characters
      ctx.font = '36px Arial';
      ctx.fillStyle = themeColors.secondary;
      ctx.fillText(channel.characters.join(' • '), 960, 550);

      // Scene indicator
      ctx.font = '32px Arial';
      ctx.fillStyle = themeColors.accent;
      ctx.fillText(`Scene ${sceneIndex + 1}/5`, 960, 450);

      // Progress bar
      const progressWidth = 800;
      const progressX = (1920 - progressWidth) / 2;
      const progressY = 750;
      
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.fillRect(progressX, progressY, progressWidth, 20);
      
      ctx.fillStyle = themeColors.accent;
      ctx.fillRect(progressX, progressY, progressWidth * progress, 20);

      // Educational focus
      if (episode.script && episode.script.scenes && episode.script.scenes[sceneIndex]) {
        const scene = episode.script.scenes[sceneIndex];
        ctx.font = '28px Arial';
        ctx.fillStyle = themeColors.text;
        ctx.fillText(`Focus: ${scene.educational_focus}`, 960, 850);
      }

      // Time indicator
      const minutes = Math.floor(frameIndex / 30 / 60);
      const seconds = Math.floor((frameIndex / 30) % 60);
      ctx.font = '24px Arial';
      ctx.fillStyle = themeColors.secondary;
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, '0')}`, 960, 950);

      // Save frame
      const frameBuffer = canvas.toBuffer('image/png');
      const framePath = path.join(frameDir, `frame_${frameIndex.toString().padStart(5, '0')}.png`);
      fs.writeFileSync(framePath, frameBuffer);

      if (frameIndex % 1000 === 0) {
        const progress = ((frameIndex / totalFrames) * 100).toFixed(1);
        console.log(`${channel.name}: Frame ${frameIndex}/${totalFrames} (${progress}%)`);
      }
    }

    // Create video with FFmpeg
    return new Promise((resolve, reject) => {
      ffmpeg()
        .input(path.join(frameDir, 'frame_%05d.png'))
        .inputOptions(['-r 30'])
        .outputOptions([
          '-c:v libx264',
          '-pix_fmt yuv420p',
          '-crf 18',
          '-preset medium',
          '-r 30',
          '-t 300'
        ])
        .output(videoPath)
        .on('progress', (progress) => {
          console.log(`${channel.name} video processing: ${progress.percent?.toFixed(1)}%`);
        })
        .on('end', () => {
          fs.rmSync(frameDir, { recursive: true, force: true });
          resolve(videoPath);
        })
        .on('error', reject)
        .run();
    });
  }

  private getThemeColors(channelId: string): { primary: string; secondary: string; accent: string; text: string } {
    const colorSchemes = {
      educational_adventures: {
        primary: '#87CEEB',
        secondary: '#4ECDC4',
        accent: '#FF6B6B',
        text: '#2C3E50'
      },
      science_explorers: {
        primary: '#9B59B6',
        secondary: '#3498DB',
        accent: '#F39C12',
        text: '#FFFFFF'
      },
      story_time_magic: {
        primary: '#E8B4E3',
        secondary: '#FFB6C1',
        accent: '#FFD700',
        text: '#4A0E4E'
      },
      math_adventures: {
        primary: '#28B463',
        secondary: '#5DADE2',
        accent: '#F1C40F',
        text: '#FFFFFF'
      },
      creative_crafts: {
        primary: '#F7DC6F',
        secondary: '#BB8FCE',
        accent: '#58D68D',
        text: '#2C3E50'
      }
    };

    return colorSchemes[channelId] || colorSchemes.educational_adventures;
  }

  private addThemeDecorations(ctx: CanvasRenderingContext2D, channelId: string, frameIndex: number) {
    const decorations = {
      educational_adventures: () => {
        // Floating water bubbles
        for (let i = 0; i < 8; i++) {
          const x = 100 + (i * 200) + Math.sin(frameIndex * 0.02 + i) * 30;
          const y = 150 + Math.cos(frameIndex * 0.015 + i) * 50;
          const size = 15 + Math.sin(frameIndex * 0.03 + i) * 5;
          
          ctx.fillStyle = 'rgba(135, 206, 235, 0.6)';
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      science_explorers: () => {
        // Molecular structures
        for (let i = 0; i < 6; i++) {
          const centerX = 200 + (i * 250);
          const centerY = 200 + Math.sin(frameIndex * 0.01 + i) * 30;
          
          ctx.fillStyle = 'rgba(244, 156, 18, 0.7)';
          ctx.beginPath();
          ctx.arc(centerX, centerY, 20, 0, Math.PI * 2);
          ctx.fill();
          
          // Connecting lines
          for (let j = 0; j < 3; j++) {
            const angle = (j * Math.PI * 2 / 3) + (frameIndex * 0.02);
            const x = centerX + Math.cos(angle) * 40;
            const y = centerY + Math.sin(angle) * 40;
            
            ctx.strokeStyle = 'rgba(244, 156, 18, 0.5)';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(x, y);
            ctx.stroke();
            
            ctx.fillStyle = 'rgba(52, 152, 219, 0.7)';
            ctx.beginPath();
            ctx.arc(x, y, 10, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      },
      story_time_magic: () => {
        // Magical sparkles
        for (let i = 0; i < 20; i++) {
          const x = Math.random() * 1920;
          const y = Math.random() * 1080;
          const size = 3 + Math.sin(frameIndex * 0.1 + i) * 2;
          
          ctx.fillStyle = `rgba(255, 215, 0, ${0.3 + Math.sin(frameIndex * 0.05 + i) * 0.3})`;
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      math_adventures: () => {
        // Geometric shapes
        const shapes = ['triangle', 'square', 'circle', 'hexagon'];
        for (let i = 0; i < 6; i++) {
          const x = 150 + (i * 280) + Math.sin(frameIndex * 0.02 + i) * 40;
          const y = 180 + Math.cos(frameIndex * 0.015 + i) * 30;
          
          ctx.fillStyle = 'rgba(241, 196, 15, 0.6)';
          ctx.strokeStyle = 'rgba(40, 180, 99, 0.8)';
          ctx.lineWidth = 3;
          
          const shape = shapes[i % shapes.length];
          if (shape === 'circle') {
            ctx.beginPath();
            ctx.arc(x, y, 25, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
          } else if (shape === 'square') {
            ctx.fillRect(x - 25, y - 25, 50, 50);
            ctx.strokeRect(x - 25, y - 25, 50, 50);
          }
        }
      },
      creative_crafts: () => {
        // Paint splashes
        for (let i = 0; i < 10; i++) {
          const x = Math.random() * 1920;
          const y = Math.random() * 1080;
          const size = 20 + Math.random() * 30;
          
          const colors = ['rgba(231, 76, 60, 0.6)', 'rgba(46, 204, 113, 0.6)', 'rgba(52, 152, 219, 0.6)', 'rgba(155, 89, 182, 0.6)'];
          ctx.fillStyle = colors[i % colors.length];
          
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    };

    const decoration = decorations[channelId];
    if (decoration) decoration();
  }

  async createChannelThumbnail(channelId: string, episode: Episode): Promise<string> {
    const channel = this.channels.get(channelId);
    if (!channel) throw new Error(`Channel ${channelId} not found`);

    const thumbnailPath = path.join(
      this.outputDir,
      channelId,
      'thumbnails',
      `episode_${episode.episodeNumber.toString().padStart(2, '0')}_thumbnail.png`
    );

    const canvas = createCanvas(1280, 720);
    const ctx = canvas.getContext('2d');
    const colors = this.getThemeColors(channelId);

    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
    gradient.addColorStop(0, colors.primary);
    gradient.addColorStop(1, colors.secondary);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1280, 720);

    // Channel name
    ctx.fillStyle = colors.accent;
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(channel.name, 640, 60);

    // Episode number badge
    ctx.fillStyle = colors.accent;
    ctx.beginPath();
    ctx.arc(150, 150, 80, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = colors.text === '#FFFFFF' ? '#000000' : '#FFFFFF';
    ctx.font = 'bold 48px Arial';
    ctx.fillText(`${episode.episodeNumber}`, 150, 165);

    // Title background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
    ctx.fillRect(0, 250, 1280, 200);

    // Title text
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 56px Arial';
    ctx.textAlign = 'center';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;

    const words = episode.title.split(' ');
    const lines = [];
    let currentLine = '';

    for (const word of words) {
      const testLine = currentLine + (currentLine ? ' ' : '') + word;
      const metrics = ctx.measureText(testLine);

      if (metrics.width > 1100 && currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) lines.push(currentLine);

    lines.forEach((line, index) => {
      const y = 320 + (index * 70);
      ctx.strokeText(line, 640, y);
      ctx.fillText(line, 640, y);
    });

    // Characters
    ctx.fillStyle = colors.accent;
    ctx.font = '32px Arial';
    ctx.fillText(channel.characters.join(' • '), 640, 520);

    // Target audience
    ctx.fillStyle = colors.text;
    ctx.font = '24px Arial';
    ctx.fillText(channel.targetAudience, 640, 580);

    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(thumbnailPath, buffer);

    return thumbnailPath;
  }

  async processChannelEpisode(channelId: string, episodeNumber: number): Promise<void> {
    const channel = this.channels.get(channelId);
    if (!channel) throw new Error(`Channel ${channelId} not found`);

    const topics = this.generateTopicsForChannel(channelId);
    if (episodeNumber > topics.length) {
      console.log(`No more topics for ${channel.name} episode ${episodeNumber}`);
      return;
    }

    const topic = topics[episodeNumber - 1];
    const episode: Episode = {
      channelId,
      episodeNumber,
      title: topic,
      topic,
      script: null,
      status: 'generating',
      createdAt: new Date().toISOString()
    };

    console.log(`\n🎬 Processing ${channel.name} - Episode ${episodeNumber}: ${topic}`);

    try {
      // Generate script
      console.log('📝 Generating script...');
      episode.script = await this.generateChannelScript(channelId, topic, episodeNumber);

      // Save script
      const scriptPath = path.join(
        this.outputDir,
        channelId,
        'scripts',
        `episode_${episodeNumber.toString().padStart(2, '0')}_script.json`
      );
      fs.writeFileSync(scriptPath, JSON.stringify(episode.script, null, 2));

      // Create thumbnail
      console.log('🖼️ Creating thumbnail...');
      episode.thumbnailPath = await this.createChannelThumbnail(channelId, episode);

      // Create video
      console.log('🎥 Creating video...');
      episode.videoPath = await this.createChannelVideo(channelId, episode);

      episode.status = 'completed';
      this.episodes.push(episode);

      // Save progress
      await this.saveProgress();

      console.log(`✅ ${channel.name} Episode ${episodeNumber} completed!`);
      console.log(`📹 Video: ${episode.videoPath}`);
      console.log(`🖼️ Thumbnail: ${episode.thumbnailPath}`);

    } catch (error: any) {
      console.error(`❌ ${channel.name} Episode ${episodeNumber} failed:`, error.message);
      episode.status = 'failed';
      this.episodes.push(episode);
      await this.saveProgress();
    }
  }

  async generateAllChannelsToday(): Promise<void> {
    console.log('🚀 Generating videos for all channels today...');
    
    const promises = Array.from(this.channels.keys()).map(channelId => {
      const currentEpisode = this.episodes.filter(e => e.channelId === channelId && e.status === 'completed').length + 1;
      return this.processChannelEpisode(channelId, currentEpisode);
    });

    await Promise.all(promises);
    console.log('✅ All channels processed for today!');
  }

  async startScheduledGeneration(): Promise<void> {
    console.log('📅 Starting scheduled generation for all channels...');

    // Generate initial videos for all channels
    await this.generateAllChannelsToday();

    // Schedule daily generation for each channel
    this.channels.forEach((channel, channelId) => {
      const task = cron.schedule(channel.uploadSchedule, async () => {
        const currentEpisode = this.episodes.filter(e => e.channelId === channelId && e.status === 'completed').length + 1;
        if (currentEpisode <= 30) {
          await this.processChannelEpisode(channelId, currentEpisode);
        }
      });

      this.scheduledTasks.set(channelId, task);
      console.log(`✅ Scheduled ${channel.name} for ${channel.uploadSchedule}`);
    });
  }

  async saveProgress(): Promise<void> {
    const progressPath = path.join(this.outputDir, 'progress.json');
    const progressData = {
      channels: Array.from(this.channels.entries()).map(([id, channel]) => ({
        id,
        ...channel,
        episodeCount: this.episodes.filter(e => e.channelId === id && e.status === 'completed').length
      })),
      episodes: this.episodes.map(ep => ({
        channelId: ep.channelId,
        episodeNumber: ep.episodeNumber,
        title: ep.title,
        status: ep.status,
        videoPath: ep.videoPath,
        thumbnailPath: ep.thumbnailPath,
        createdAt: ep.createdAt
      })),
      lastUpdated: new Date().toISOString()
    };

    fs.writeFileSync(progressPath, JSON.stringify(progressData, null, 2));
  }

  stopAllSchedules(): void {
    this.scheduledTasks.forEach((task, channelId) => {
      task.stop();
      console.log(`⏹️ Stopped ${channelId} schedule`);
    });
    this.scheduledTasks.clear();
  }

  getStatus(): any {
    const channelStats = Array.from(this.channels.entries()).map(([id, channel]) => {
      const channelEpisodes = this.episodes.filter(e => e.channelId === id);
      const completed = channelEpisodes.filter(e => e.status === 'completed').length;
      const failed = channelEpisodes.filter(e => e.status === 'failed').length;
      const pending = 30 - completed - failed;

      return {
        id,
        name: channel.name,
        theme: channel.theme,
        completed,
        failed,
        pending,
        uploadSchedule: channel.uploadSchedule,
        isScheduled: this.scheduledTasks.has(id)
      };
    });

    return {
      totalChannels: this.channels.size,
      totalEpisodes: this.episodes.length,
      outputDirectory: this.outputDir,
      channels: channelStats,
      allEpisodes: this.episodes.map(ep => ({
        channelId: ep.channelId,
        episodeNumber: ep.episodeNumber,
        title: ep.title,
        status: ep.status,
        createdAt: ep.createdAt
      }))
    };
  }
}

// Main execution
async function main() {
  const manager = new MultiChannelManager();

  console.log('🎯 Multi-Channel Video Generator');
  console.log('================================');
  console.log('Channels configured:');

  const status = manager.getStatus();
  status.channels.forEach(channel => {
    console.log(`- ${channel.name}: ${channel.theme}`);
  });

  console.log('\n🚀 Starting multi-channel generation...');

  if (process.argv.includes('--schedule')) {
    await manager.startScheduledGeneration();
    
    process.on('SIGINT', () => {
      console.log('\n🛑 Stopping all schedules...');
      manager.stopAllSchedules();
      process.exit(0);
    });

    console.log('\n✅ All channels scheduled. Press Ctrl+C to stop.');
    
    setInterval(() => {
      const currentStatus = manager.getStatus();
      console.log('\n📊 Channel Status:');
      currentStatus.channels.forEach(channel => {
        console.log(`${channel.name}: ${channel.completed}/30 episodes completed`);
      });
    }, 600000); // Status update every 10 minutes
    
  } else {
    // Generate one episode for each channel now
    await manager.generateAllChannelsToday();
    console.log('\n✅ Initial generation complete! Use --schedule to start daily automation.');
  }
}

if (require.main === module) {
  main().catch(console.error);
}

export { MultiChannelManager };