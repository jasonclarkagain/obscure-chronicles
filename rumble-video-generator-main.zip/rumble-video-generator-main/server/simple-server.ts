import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { db } from "./db";

dotenv.config();

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString()
  });
});

// API status endpoint
app.get("/api/status", async (req, res) => {
  try {
    const result = await db.execute("SELECT 1");
    res.json({
      status: "ok",
      database: "connected",
      message: "Multi-channel video generation system ready. Use CLI commands to generate videos."
    });
  } catch (error) {
    res.status(500).json({
      status: "error",
      database: "disconnected",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ Server running on port ${PORT}`);
  console.log(`📊 Health: http://localhost:${PORT}/health`);
  console.log(`📋 Status: http://localhost:${PORT}/api/status`);
  console.log(`\n🎬 Multi-Channel Video Generation System`);
  console.log(`Use CLI commands:`);
  console.log(`  ./multichannel.sh init`);
  console.log(`  ./multichannel.sh status`);
  console.log(`  ./multichannel.sh channels`);
});
