import { google } from 'googleapis';
import fs from 'fs/promises';
import path from 'path';
import { createReadStream } from 'fs';
import ffmpeg from 'fluent-ffmpeg';
import { createCanvas } from 'canvas';

interface YouTubeCredentials {
  client_id: string;
  client_secret: string;
  refresh_token: string;
  access_token?: string;
}

interface VideoUploadData {
  title: string;
  description: string;
  tags: string[];
  categoryId: string;
  privacyStatus: 'private' | 'public' | 'unlisted';
  videoPath: string;
  thumbnailPath?: string;
}

export class YouTubeUploader {
  private youtube: any;
  private oauth2Client: any;
  private outputDir: string;

  constructor() {
    this.outputDir = path.join(process.cwd(), "server", "output", "videos");
    this.ensureDirectories();
  }

  private async ensureDirectories() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
      await fs.mkdir(path.join(process.cwd(), "server", "output", "thumbnails"), { recursive: true });
    } catch (error) {
      console.log("Output directories already exist");
    }
  }

  async initializeYouTubeAPI(credentials: YouTubeCredentials): Promise<void> {
    this.oauth2Client = new google.auth.OAuth2(
      credentials.client_id,
      credentials.client_secret,
      'http://localhost:3000/oauth2callback'
    );

    this.oauth2Client.setCredentials({
      refresh_token: credentials.refresh_token,
      access_token: credentials.access_token
    });

    this.youtube = google.youtube({
      version: 'v3',
      auth: this.oauth2Client
    });

    console.log("✅ YouTube API initialized successfully");
  }

  async createVideoFile(script: any, episode: number): Promise<string> {
    console.log(`🎬 Creating video file for Episode ${episode}...`);
    
    const videoPath = path.join(this.outputDir, `episode_${episode}_${Date.now()}.mp4`);
    
    // Create a simple video using canvas and ffmpeg
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');
    
    // Generate frames for a 5-minute video (at 1 fps for simplicity)
    const frames: Buffer[] = [];
    const totalFrames = 300; // 5 minutes at 1 fps
    
    for (let frame = 0; frame < totalFrames; frame++) {
      // Clear canvas
      ctx.fillStyle = '#4F46E5';
      ctx.fillRect(0, 0, 1920, 1080);
      
      // Add gradient
      const gradient = ctx.createLinearGradient(0, 0, 1920, 1080);
      gradient.addColorStop(0, '#4F46E5');
      gradient.addColorStop(0.5, '#10B981');
      gradient.addColorStop(1, '#F59E0B');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 1920, 1080);
      
      // Add title
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 80px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(script.title, 960, 400);
      
      // Add episode info
      ctx.font = '50px Arial';
      ctx.fillText(`Episode ${episode}/30`, 960, 500);
      
      // Add series info
      ctx.font = '40px Arial';
      ctx.fillText('Amazing Learning Adventures', 960, 600);
      
      // Add time indicator
      const currentTime = Math.floor(frame / 60);
      ctx.font = '30px Arial';
      ctx.fillText(`${currentTime}:${(frame % 60).toString().padStart(2, '0')}`, 960, 700);
      
      // Add characters
      ctx.font = '35px Arial';
      ctx.fillText('with Captain Marina, Curious Casey & Luna', 960, 800);
      
      frames.push(canvas.toBuffer('image/png'));
    }
    
    // Create video using ffmpeg
    return new Promise((resolve, reject) => {
      const command = ffmpeg();
      
      // Add frames as input (we'll write them to temp files)
      const tempDir = path.join(this.outputDir, 'temp_frames');
      
      fs.mkdir(tempDir, { recursive: true }).then(async () => {
        // Write frames to temp files
        for (let i = 0; i < frames.length; i++) {
          await fs.writeFile(path.join(tempDir, `frame_${i.toString().padStart(6, '0')}.png`), frames[i]);
        }
        
        // Create video from frames
        command
          .input(path.join(tempDir, 'frame_%06d.png'))
          .inputFPS(1)
          .outputFPS(30)
          .videoCodec('libx264')
          .outputOptions([
            '-pix_fmt yuv420p',
            '-crf 23',
            '-preset medium'
          ])
          .size('1920x1080')
          .duration(300) // 5 minutes
          .output(videoPath)
          .on('end', async () => {
            // Clean up temp frames
            try {
              const files = await fs.readdir(tempDir);
              for (const file of files) {
                await fs.unlink(path.join(tempDir, file));
              }
              await fs.rmdir(tempDir);
            } catch (error) {
              console.log("Cleanup warning:", error);
            }
            
            console.log(`✅ Video created: ${videoPath}`);
            resolve(videoPath);
          })
          .on('error', (error) => {
            console.error("FFmpeg error:", error);
            reject(error);
          })
          .run();
      });
    });
  }

  async createThumbnail(script: any, episode: number): Promise<string> {
    console.log(`🖼️ Creating thumbnail for Episode ${episode}...`);
    
    const canvas = createCanvas(1280, 720);
    const ctx = canvas.getContext('2d');
    
    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
    gradient.addColorStop(0, '#4F46E5');
    gradient.addColorStop(0.5, '#10B981');
    gradient.addColorStop(1, '#F59E0B');
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1280, 720);
    
    // Episode number badge
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(50, 50, 200, 100);
    ctx.fillStyle = '#4F46E5';
    ctx.font = 'bold 60px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`EP ${episode}`, 150, 115);
    
    // Main title
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 70px Arial';
    ctx.textAlign = 'center';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    ctx.strokeText(script.title, 640, 300);
    ctx.fillText(script.title, 640, 300);
    
    // Series title
    ctx.font = '45px Arial';
    ctx.strokeText('Amazing Learning Adventures', 640, 400);
    ctx.fillText('Amazing Learning Adventures', 640, 400);
    
    // Characters
    ctx.font = '35px Arial';
    ctx.strokeText('Captain Marina • Curious Casey • Luna', 640, 500);
    ctx.fillText('Captain Marina • Curious Casey • Luna', 640, 500);
    
    // Educational badge
    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(50, 570, 300, 80);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 40px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('EDUCATIONAL', 200, 620);
    
    // YouTube branding
    ctx.fillStyle = '#FF0000';
    ctx.fillRect(1000, 570, 200, 80);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 35px Arial';
    ctx.fillText('YOUTUBE', 1100, 620);
    
    const thumbnailPath = path.join(process.cwd(), "server", "output", "thumbnails", `episode_${episode}_thumbnail.png`);
    const buffer = canvas.toBuffer('image/png');
    await fs.writeFile(thumbnailPath, buffer);
    
    console.log(`✅ Thumbnail created: ${thumbnailPath}`);
    return thumbnailPath;
  }

  async uploadVideo(uploadData: VideoUploadData): Promise<any> {
    console.log(`📤 Uploading video to YouTube: "${uploadData.title}"`);
    
    try {
      const videoResponse = await this.youtube.videos.insert({
        part: ['snippet', 'status'],
        requestBody: {
          snippet: {
            title: uploadData.title,
            description: uploadData.description,
            tags: uploadData.tags,
            categoryId: uploadData.categoryId,
            defaultLanguage: 'en',
            defaultAudioLanguage: 'en'
          },
          status: {
            privacyStatus: uploadData.privacyStatus,
            selfDeclaredMadeForKids: true, // Educational content for families
            embeddable: true,
            publicStatsViewable: true
          }
        },
        media: {
          body: createReadStream(uploadData.videoPath)
        }
      });

      const videoId = videoResponse.data.id;
      console.log(`✅ Video uploaded successfully! Video ID: ${videoId}`);
      
      // Upload thumbnail if provided
      if (uploadData.thumbnailPath) {
        try {
          await this.youtube.thumbnails.set({
            videoId: videoId,
            media: {
              body: createReadStream(uploadData.thumbnailPath)
            }
          });
          console.log(`✅ Thumbnail uploaded successfully`);
        } catch (thumbnailError) {
          console.warn("Thumbnail upload failed:", thumbnailError);
        }
      }

      return {
        success: true,
        videoId: videoId,
        url: `https://www.youtube.com/watch?v=${videoId}`,
        title: uploadData.title,
        uploadTime: new Date().toISOString()
      };

    } catch (error) {
      console.error("YouTube upload failed:", error);
      throw new Error(`Upload failed: ${error.message}`);
    }
  }

  async generateAndUploadEpisode(script: any, episode: number, credentials: YouTubeCredentials): Promise<any> {
    console.log(`\n🚀 Generating and uploading Episode ${episode}: "${script.title}"`);
    
    try {
      // Initialize YouTube API
      await this.initializeYouTubeAPI(credentials);
      
      // Create video file
      const videoPath = await this.createVideoFile(script, episode);
      
      // Create thumbnail
      const thumbnailPath = await this.createThumbnail(script, episode);
      
      // Prepare upload data
      const uploadData: VideoUploadData = {
        title: script.title,
        description: this.createYouTubeDescription(script, episode),
        tags: script.tags || ['education', 'learning', 'family-friendly', 'kids', 'educational'],
        categoryId: '27', // Education category
        privacyStatus: 'public',
        videoPath: videoPath,
        thumbnailPath: thumbnailPath
      };
      
      // Upload to YouTube
      const result = await this.uploadVideo(uploadData);
      
      // Clean up local files
      try {
        await fs.unlink(videoPath);
        await fs.unlink(thumbnailPath);
      } catch (cleanupError) {
        console.warn("File cleanup warning:", cleanupError);
      }
      
      return result;
      
    } catch (error) {
      console.error(`Failed to generate/upload Episode ${episode}:`, error);
      throw error;
    }
  }

  private createYouTubeDescription(script: any, episode: number): string {
    return `🎓 ${script.title} - Episode ${episode}/30

${script.description}

📚 Learning Objectives:
${script.educationalObjectives?.map((obj: string) => `• ${obj}`).join('\n') || '• Interactive educational content'}

🌟 Meet Our Characters:
• Captain Marina - Your wise learning guide who makes complex topics simple
• Curious Casey - Asks the best questions and explores with enthusiasm  
• Luna the Explorer - Discovers amazing things and solves problems creatively

👨‍👩‍👧‍👦 Perfect for families who love learning together!

🔔 Subscribe for daily educational adventures!
📺 New episodes every day at 9:00 AM UTC
🎯 30-day educational series covering science, math, language, arts, and life skills

💡 Interactive Learning Features:
• Ask questions along with Curious Casey
• Explore concepts with Captain Marina
• Problem-solve with Luna the Explorer
• Family-friendly discussions and activities

📖 Educational Standards Aligned:
This content supports early childhood education standards and encourages:
- Critical thinking and problem-solving
- Scientific observation and inquiry
- Mathematical concepts and reasoning
- Language development and communication
- Creative expression and cultural awareness
- Social-emotional learning and values

🌍 Join our learning community of curious families!

#Education #Learning #FamilyFriendly #Kids #Educational #Adventure #Science #Math #Language #Arts #LifeSkills #CharacterEducation #InteractiveLearning #EducationalSeries

---
This video is part of our comprehensive 30-day educational series designed to inspire curiosity, creativity, and lifelong learning in children and families.

Created with love for the global learning community.
Channel: jasonclarkagain@gmail.com`;
  }
}

export const youtubeUploader = new YouTubeUploader();