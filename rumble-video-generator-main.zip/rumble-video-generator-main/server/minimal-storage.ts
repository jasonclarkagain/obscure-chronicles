import { nanoid } from "nanoid";
import { eq } from "drizzle-orm";
import { db } from "./db";
import {
  videoThemes,
  videos,
  characters,
  generationQueue,
  type VideoTheme,
  type Video,
  type Character,
  type GenerationQueue,
  type InsertVideoTheme,
  type InsertVideo,
  type InsertCharacter,
  type InsertGenerationQueue,
} from "@shared/schema";

export interface IStorage {
  // Video Themes
  getVideoThemes(): Promise<VideoTheme[]>;
  getVideoTheme(id: string): Promise<VideoTheme | null>;
  createVideoTheme(theme: InsertVideoTheme): Promise<VideoTheme>;
  updateVideoTheme(id: string, theme: Partial<InsertVideoTheme>): Promise<VideoTheme | null>;
  deleteVideoTheme(id: string): Promise<boolean>;

  // Videos
  getVideos(): Promise<Video[]>;
  getVideo(id: string): Promise<Video | null>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: string, video: Partial<InsertVideo>): Promise<Video | null>;
  deleteVideo(id: string): Promise<boolean>;

  // Characters
  getCharacters(): Promise<Character[]>;
  getCharacter(id: string): Promise<Character | null>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: string, character: Partial<InsertCharacter>): Promise<Character | null>;
  deleteCharacter(id: string): Promise<boolean>;

  // Generation Queue
  getGenerationQueue(): Promise<GenerationQueue[]>;
  getQueueItem(id: string): Promise<GenerationQueue | null>;
  createQueueItem(item: InsertGenerationQueue): Promise<GenerationQueue>;
  updateQueueItem(id: string, item: Partial<InsertGenerationQueue>): Promise<GenerationQueue | null>;
  deleteQueueItem(id: string): Promise<boolean>;
  getPendingQueueItems(): Promise<GenerationQueue[]>;
}

export class MinimalDatabaseStorage implements IStorage {
  async getVideoThemes(): Promise<VideoTheme[]> {
    return await db.select().from(videoThemes);
  }

  async getVideoTheme(id: string): Promise<VideoTheme | null> {
    const [theme] = await db.select().from(videoThemes).where(eq(videoThemes.id, id));
    return theme || null;
  }

  async createVideoTheme(theme: InsertVideoTheme): Promise<VideoTheme> {
    const [newTheme] = await db
      .insert(videoThemes)
      .values({ ...theme, id: nanoid() })
      .returning();
    return newTheme;
  }

  async updateVideoTheme(id: string, theme: Partial<InsertVideoTheme>): Promise<VideoTheme | null> {
    const [updatedTheme] = await db
      .update(videoThemes)
      .set(theme)
      .where(eq(videoThemes.id, id))
      .returning();
    return updatedTheme || null;
  }

  async deleteVideoTheme(id: string): Promise<boolean> {
    const result = await db.delete(videoThemes).where(eq(videoThemes.id, id));
    return result.rowCount > 0;
  }

  async getVideos(): Promise<Video[]> {
    return await db.select().from(videos);
  }

  async getVideo(id: string): Promise<Video | null> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video || null;
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const [newVideo] = await db
      .insert(videos)
      .values({ ...video, id: nanoid() })
      .returning();
    return newVideo;
  }

  async updateVideo(id: string, video: Partial<InsertVideo>): Promise<Video | null> {
    const [updatedVideo] = await db
      .update(videos)
      .set(video)
      .where(eq(videos.id, id))
      .returning();
    return updatedVideo || null;
  }

  async deleteVideo(id: string): Promise<boolean> {
    const result = await db.delete(videos).where(eq(videos.id, id));
    return result.rowCount > 0;
  }

  async getCharacters(): Promise<Character[]> {
    return await db.select().from(characters);
  }

  async getCharacter(id: string): Promise<Character | null> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character || null;
  }

  async createCharacter(character: InsertCharacter): Promise<Character> {
    const [newCharacter] = await db
      .insert(characters)
      .values({ ...character, id: nanoid() })
      .returning();
    return newCharacter;
  }

  async updateCharacter(id: string, character: Partial<InsertCharacter>): Promise<Character | null> {
    const [updatedCharacter] = await db
      .update(characters)
      .set(character)
      .where(eq(characters.id, id))
      .returning();
    return updatedCharacter || null;
  }

  async deleteCharacter(id: string): Promise<boolean> {
    const result = await db.delete(characters).where(eq(characters.id, id));
    return result.rowCount > 0;
  }

  async getGenerationQueue(): Promise<GenerationQueue[]> {
    return await db.select().from(generationQueue);
  }

  async getQueueItem(id: string): Promise<GenerationQueue | null> {
    const [item] = await db.select().from(generationQueue).where(eq(generationQueue.id, id));
    return item || null;
  }

  async createQueueItem(item: InsertGenerationQueue): Promise<GenerationQueue> {
    const [newItem] = await db
      .insert(generationQueue)
      .values({ ...item, id: nanoid() })
      .returning();
    return newItem;
  }

  async updateQueueItem(id: string, item: Partial<InsertGenerationQueue>): Promise<GenerationQueue | null> {
    const [updatedItem] = await db
      .update(generationQueue)
      .set(item)
      .where(eq(generationQueue.id, id))
      .returning();
    return updatedItem || null;
  }

  async deleteQueueItem(id: string): Promise<boolean> {
    const result = await db.delete(generationQueue).where(eq(generationQueue.id, id));
    return result.rowCount > 0;
  }

  async getPendingQueueItems(): Promise<GenerationQueue[]> {
    return await db.select().from(generationQueue).where(eq(generationQueue.status, "pending"));
  }
}

export const storage = new MinimalDatabaseStorage();