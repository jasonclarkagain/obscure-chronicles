#!/usr/bin/env npx tsx

import { google } from 'googleapis';
import http from 'http';
import url from 'url';
import open from 'open';

/**
 * Helper script to generate YouTube OAuth tokens
 * Run this to get your refresh token if the OAuth playground doesn't work
 */

interface OAuthConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}

export class YouTubeOAuthHelper {
  private oauth2Client: any;
  private config: OAuthConfig;

  constructor(clientId: string, clientSecret: string) {
    this.config = {
      clientId,
      clientSecret,
      redirectUri: 'http://localhost:3000/oauth2callback'
    };

    this.oauth2Client = new google.auth.OAuth2(
      this.config.clientId,
      this.config.clientSecret,
      this.config.redirectUri
    );
  }

  async generateAuthUrl(): Promise<string> {
    const scopes = [
      'https://www.googleapis.com/auth/youtube.upload',
      'https://www.googleapis.com/auth/youtube'
    ];

    const authUrl = this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent' // Force consent to get refresh token
    });

    return authUrl;
  }

  async getTokensFromCode(code: string): Promise<any> {
    const { tokens } = await this.oauth2Client.getToken(code);
    return tokens;
  }

  async startOAuthFlow(): Promise<any> {
    return new Promise(async (resolve, reject) => {
      // Create a local server to handle the callback
      const server = http.createServer(async (req, res) => {
        if (req.url?.startsWith('/oauth2callback')) {
          const parsedUrl = url.parse(req.url, true);
          const code = parsedUrl.query.code as string;

          if (code) {
            try {
              const tokens = await this.getTokensFromCode(code);
              
              res.writeHead(200, { 'Content-Type': 'text/html' });
              res.end(`
                <html>
                  <body>
                    <h1>✅ Success!</h1>
                    <p>Authorization successful. You can close this window.</p>
                    <h2>Your Credentials:</h2>
                    <pre>${JSON.stringify(tokens, null, 2)}</pre>
                    <p>Copy the refresh_token value and use it in your environment variables.</p>
                  </body>
                </html>
              `);

              server.close();
              resolve(tokens);
            } catch (error) {
              res.writeHead(500, { 'Content-Type': 'text/plain' });
              res.end('Error getting tokens: ' + error.message);
              server.close();
              reject(error);
            }
          } else {
            res.writeHead(400, { 'Content-Type': 'text/plain' });
            res.end('No authorization code received');
            server.close();
            reject(new Error('No authorization code received'));
          }
        }
      });

      server.listen(3000, async () => {
        console.log('🚀 OAuth server started on http://localhost:3000');
        
        const authUrl = await this.generateAuthUrl();
        console.log('\n📋 Steps to authorize:');
        console.log('1. Click the URL below (or copy/paste it into your browser)');
        console.log('2. Sign in with jasonclarkagain@gmail.com');
        console.log('3. Grant permissions for YouTube access');
        console.log('4. You\'ll be redirected back automatically\n');
        console.log('🔗 Authorization URL:');
        console.log(authUrl);
        
        // Try to open the URL automatically
        try {
          await open(authUrl);
          console.log('\n✅ Browser opened automatically');
        } catch (error) {
          console.log('\n❗ Please copy the URL above and open it manually');
        }
      });
    });
  }
}

// Command line usage
async function main() {
  console.log('🎯 YouTube OAuth Helper');
  console.log('========================\n');
  
  // You need to provide your Client ID and Client Secret here
  const clientId = process.env.YOUTUBE_CLIENT_ID || 'YOUR_CLIENT_ID';
  const clientSecret = process.env.YOUTUBE_CLIENT_SECRET || 'YOUR_CLIENT_SECRET';
  
  if (clientId === 'YOUR_CLIENT_ID' || clientSecret === 'YOUR_CLIENT_SECRET') {
    console.log('❗ Please set your YouTube credentials:');
    console.log('');
    console.log('Option 1: Set environment variables:');
    console.log('  export YOUTUBE_CLIENT_ID="your_client_id"');
    console.log('  export YOUTUBE_CLIENT_SECRET="your_client_secret"');
    console.log('  npx tsx oauth-helper.ts');
    console.log('');
    console.log('Option 2: Edit this file and replace YOUR_CLIENT_ID and YOUR_CLIENT_SECRET');
    console.log('');
    console.log('Get these credentials from Google Cloud Console:');
    console.log('https://console.cloud.google.com/apis/credentials');
    return;
  }

  try {
    const helper = new YouTubeOAuthHelper(clientId, clientSecret);
    const tokens = await helper.startOAuthFlow();
    
    console.log('\n🎉 Success! Here are your tokens:');
    console.log('=====================================');
    console.log('YOUTUBE_CLIENT_ID=' + clientId);
    console.log('YOUTUBE_CLIENT_SECRET=' + clientSecret);
    console.log('YOUTUBE_REFRESH_TOKEN=' + tokens.refresh_token);
    console.log('=====================================');
    console.log('\nUse these in your environment variables to enable real YouTube uploads!');
    
  } catch (error) {
    console.error('❌ OAuth flow failed:', error);
  }
}

if (require.main === module) {
  main().catch(console.error);
}

export { YouTubeOAuthHelper };