import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { createRoutes } from "./routes";
import { storage } from "./storage";
import { getRumbleCronService } from "./services/rumbleCron";

// Only load .env in development - Cloud Run provides env vars directly
if (process.env.NODE_ENV !== "production") {
  dotenv.config();
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Prevent multiple instances from starting
let isServerStarting = false;

async function startServer() {
  if (isServerStarting) {
    console.log("⚠️ Server is already starting, skipping duplicate instance");
    return;
  }
  
  isServerStarting = true;

  const app = express();
  // Use environment PORT (provided by Cloud Run) or default
  const PORT = parseInt(process.env.PORT || "3000", 10);

  // Create Vite server in middleware mode
  // CRITICAL: Disable HMR completely in production to prevent port 24678 conflicts
  const isProduction = process.env.NODE_ENV === "production";
  console.log(`Creating Vite server (production=${isProduction})...`);
  
  const vite = await createViteServer({
    server: { 
      middlewareMode: true,
      // Disable HMR entirely in production to prevent port binding issues
      hmr: isProduction ? false : {
        host: '0.0.0.0',
        protocol: 'ws',
        port: 24680, // Use different port from 24678 to avoid conflicts
      },
    },
    appType: "spa",
    root: path.resolve(__dirname, "../client"),
  });
  console.log("Vite server created successfully");

  // Security middleware with relaxed CSP for Vite dev
  app.use(helmet({
    contentSecurityPolicy: false, // Disabled for Vite dev mode
  }));

  app.use(cors());
  app.use(morgan("combined"));
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // API Routes (these take priority over frontend)
  app.use(createRoutes(storage));

  // Health check endpoints
  app.get("/health", (req, res) => {
    res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      version: "1.0.0"
    });
  });

  // Root health check for deployment platforms (only respond to non-browser requests)
  app.get("/", (req, res, next) => {
    const userAgent = req.headers['user-agent'] || '';
    const accept = req.headers.accept || '';
    
    // Cloud Run health checks typically don't send browser-like headers
    const isBrowser = accept.includes('text/html') || userAgent.includes('Mozilla');
    
    if (!isBrowser) {
      // Return JSON for health check probes
      return res.json({
        status: "healthy",
        message: "Multi-Channel Video Generation System",
        version: "1.0.0"
      });
    }
    
    // Browsers continue to SPA handling
    next();
  });

  // Use Vite's middleware FIRST to handle all frontend assets and transformations
  app.use(vite.middlewares);

  // SPA fallback - serve index.html for non-existent routes (must be AFTER Vite middleware)
  app.use(async (req, res, next) => {
    const url = req.originalUrl;
    
    // Skip if already handled (API, health, or file returned by Vite)
    if (res.headersSent) {
      return;
    }
    
    // Skip API routes and health check
    if (url.startsWith("/api") || url === "/health") {
      return next();
    }

    // Serve index.html for all other routes (SPA client-side routes)
    try {
      const indexPath = path.resolve(__dirname, "../client/index.html");
      const fs = await import("fs");
      const html = await fs.promises.readFile(indexPath, "utf-8");
      const transformedHtml = await vite.transformIndexHtml(url, html);
      res.status(200).set({ "Content-Type": "text/html" }).send(transformedHtml);
    } catch (e: any) {
      console.error("Error serving index.html:", e);
      next(e);
    }
  });

  // Error handling middleware
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error("Unhandled error:", err);
    res.status(500).json({
      error: "Internal server error",
      message: process.env.NODE_ENV === "development" ? err.message : "Something went wrong"
    });
  });

  // Initialize Rumble cron service
  const rumbleCron = getRumbleCronService(storage);
  rumbleCron.start();

  // Start server with enhanced error handling
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 Multi-Channel Video Generation System`);
    console.log(`📊 Backend + Frontend running on http://0.0.0.0:${PORT}`);
    console.log(`✅ API endpoints: http://0.0.0.0:${PORT}/api/*`);
    console.log(`🌐 Web GUI: http://0.0.0.0:${PORT}/`);
    console.log(`💚 Health check: http://0.0.0.0:${PORT}/health`);
    console.log(`🎬 Rumble video generation: Daily at 02:00 UTC`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV || "development"}`);
  });

  server.on("error", (error: any) => {
    if (error.code === "EADDRINUSE") {
      console.error(`❌ Port ${PORT} is already in use`);
      console.error(`💡 This usually means another instance is running`);
      console.error(`💡 In Cloud Run, ensure only one server file is executed`);
      console.error(`💡 Check that server/vite-server.ts is the only entry point`);
      
      // In production, exit cleanly to let the platform restart
      if (process.env.NODE_ENV === "production") {
        console.log("🔄 Exiting to allow platform restart...");
        process.exit(1);
      } else {
        // In development, try to recover
        console.log("🔄 Attempting to exit and allow restart...");
        process.exit(1);
      }
    } else {
      console.error("❌ Server error:", error);
      process.exit(1);
    }
  });

  // Graceful shutdown
  process.on("SIGTERM", async () => {
    console.log("SIGTERM received, shutting down gracefully...");
    isServerStarting = false;
    rumbleCron.stop();
    server.close(() => {
      console.log("Server closed");
    });
    await vite.close();
    setTimeout(() => process.exit(0), 1000);
  });

  process.on("SIGINT", async () => {
    console.log("SIGINT received, shutting down gracefully...");
    isServerStarting = false;
    rumbleCron.stop();
    server.close(() => {
      console.log("Server closed");
    });
    await vite.close();
    setTimeout(() => process.exit(0), 1000);
  });
}

// Handle unhandled rejections
process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason);
});

process.on("uncaughtException", (error) => {
  console.error("Uncaught Exception:", error);
});

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  console.error(err.stack);
  process.exit(1);
});
