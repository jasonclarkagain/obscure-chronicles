import { eq } from "drizzle-orm";
import { db } from "./db";
import {
  videoThemes,
  videos,
  characters,
  generationQueue,
  youtubeChannels,
  episodes,
  contentCache,
  rumbleCampaigns,
  rumbleVideos,
  type VideoTheme,
  type Video,
  type Character,
  type GenerationQueue,
  type YouTubeChannel,
  type Episode,
  type ContentCache,
  type RumbleCampaign,
  type RumbleVideo,
  type InsertVideoTheme,
  type InsertVideo,
  type InsertCharacter,
  type InsertGenerationQueue,
  type InsertYouTubeChannel,
  type InsertEpisode,
  type InsertContentCache,
  type InsertRumbleCampaign,
  type InsertRumbleVideo,
} from "@shared/schema";
import { nanoid } from "nanoid";

export interface IStorage {
  // Video Themes
  getVideoThemes(): Promise<VideoTheme[]>;
  getVideoTheme(id: string): Promise<VideoTheme | null>;
  createVideoTheme(theme: InsertVideoTheme): Promise<VideoTheme>;
  updateVideoTheme(id: string, theme: Partial<InsertVideoTheme>): Promise<VideoTheme | null>;
  deleteVideoTheme(id: string): Promise<boolean>;

  // Videos
  getVideos(): Promise<Video[]>;
  getVideo(id: string): Promise<Video | null>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: string, video: Partial<InsertVideo>): Promise<Video | null>;
  deleteVideo(id: string): Promise<boolean>;

  // Characters
  getCharacters(): Promise<Character[]>;
  getCharacter(id: string): Promise<Character | null>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: string, character: Partial<InsertCharacter>): Promise<Character | null>;
  deleteCharacter(id: string): Promise<boolean>;

  // Generation Queue
  getGenerationQueue(): Promise<GenerationQueue[]>;
  getQueueItem(id: string): Promise<GenerationQueue | null>;
  createQueueItem(item: InsertGenerationQueue): Promise<GenerationQueue>;
  updateQueueItem(id: string, item: Partial<InsertGenerationQueue>): Promise<GenerationQueue | null>;
  deleteQueueItem(id: string): Promise<boolean>;
  getPendingQueueItems(): Promise<GenerationQueue[]>;

  // YouTube Channels
  getYouTubeChannels(): Promise<YouTubeChannel[]>;
  getYouTubeChannel(id: string): Promise<YouTubeChannel | null>;
  createYouTubeChannel(channel: InsertYouTubeChannel): Promise<YouTubeChannel>;
  updateYouTubeChannel(id: string, channel: Partial<InsertYouTubeChannel>): Promise<YouTubeChannel | null>;
  deleteYouTubeChannel(id: string): Promise<boolean>;

  // Episodes
  getEpisodes(): Promise<Episode[]>;
  getEpisode(id: string): Promise<Episode | null>;
  getEpisodesByChannel(channelId: string): Promise<Episode[]>;
  createEpisode(episode: InsertEpisode): Promise<Episode>;
  updateEpisode(id: string, episode: Partial<InsertEpisode>): Promise<Episode | null>;
  deleteEpisode(id: string): Promise<boolean>;
  getPendingEpisodes(): Promise<Episode[]>;

  // Content Cache
  getContentCache(): Promise<ContentCache[]>;
  getCachedContent(id: string): Promise<ContentCache | null>;
  getUnusedContentByChannel(channelId: string, type: "script" | "thumbnail"): Promise<ContentCache[]>;
  createCachedContent(content: InsertContentCache): Promise<ContentCache>;
  updateCachedContent(id: string, content: Partial<InsertContentCache>): Promise<ContentCache | null>;
  deleteCachedContent(id: string): Promise<boolean>;

  // Rumble Campaigns
  getRumbleCampaigns(): Promise<RumbleCampaign[]>;
  getRumbleCampaign(id: string): Promise<RumbleCampaign | null>;
  getActiveCampaign(): Promise<RumbleCampaign | null>;
  createRumbleCampaign(campaign: InsertRumbleCampaign): Promise<RumbleCampaign>;
  updateRumbleCampaign(id: string, campaign: Partial<InsertRumbleCampaign>): Promise<RumbleCampaign | null>;
  deleteRumbleCampaign(id: string): Promise<boolean>;

  // Rumble Videos
  getRumbleVideos(): Promise<RumbleVideo[]>;
  getRumbleVideo(id: string): Promise<RumbleVideo | null>;
  getRumbleVideosByCampaign(campaignId: string): Promise<RumbleVideo[]>;
  createRumbleVideo(video: InsertRumbleVideo): Promise<RumbleVideo>;
  updateRumbleVideo(id: string, video: Partial<InsertRumbleVideo>): Promise<RumbleVideo | null>;
  deleteRumbleVideo(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  constructor() {}

  async getVideoThemes(): Promise<VideoTheme[]> {
    return await db.select().from(videoThemes);
  }

  async getVideoTheme(id: string): Promise<VideoTheme | null> {
    const [theme] = await db.select().from(videoThemes).where(eq(videoThemes.id, id));
    return theme || null;
  }

  async createVideoTheme(theme: InsertVideoTheme): Promise<VideoTheme> {
    const [newTheme] = await db
      .insert(videoThemes)
      .values({ ...theme, id: nanoid() })
      .returning();
    return newTheme;
  }

  async updateVideoTheme(id: string, theme: Partial<InsertVideoTheme>): Promise<VideoTheme | null> {
    const [updatedTheme] = await db
      .update(videoThemes)
      .set(theme)
      .where(eq(videoThemes.id, id))
      .returning();
    return updatedTheme || null;
  }

  async deleteVideoTheme(id: string): Promise<boolean> {
    const result = await db.delete(videoThemes).where(eq(videoThemes.id, id));
    return result.rowCount > 0;
  }

  async getVideos(): Promise<Video[]> {
    return await db.select().from(videos);
  }

  async getVideo(id: string): Promise<Video | null> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video || null;
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const [newVideo] = await db
      .insert(videos)
      .values({ ...video, id: nanoid() })
      .returning();
    return newVideo;
  }

  async updateVideo(id: string, video: Partial<InsertVideo>): Promise<Video | null> {
    const [updatedVideo] = await db
      .update(videos)
      .set(video)
      .where(eq(videos.id, id))
      .returning();
    return updatedVideo || null;
  }

  async deleteVideo(id: string): Promise<boolean> {
    const result = await db.delete(videos).where(eq(videos.id, id));
    return result.rowCount > 0;
  }

  async getCharacters(): Promise<Character[]> {
    return await db.select().from(characters);
  }

  async getCharacter(id: string): Promise<Character | null> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character || null;
  }

  async createCharacter(character: InsertCharacter): Promise<Character> {
    const [newCharacter] = await db
      .insert(characters)
      .values({ ...character, id: nanoid() })
      .returning();
    return newCharacter;
  }

  async updateCharacter(id: string, character: Partial<InsertCharacter>): Promise<Character | null> {
    const [updatedCharacter] = await db
      .update(characters)
      .set(character)
      .where(eq(characters.id, id))
      .returning();
    return updatedCharacter || null;
  }

  async deleteCharacter(id: string): Promise<boolean> {
    const result = await db.delete(characters).where(eq(characters.id, id));
    return result.rowCount > 0;
  }

  async getGenerationQueue(): Promise<GenerationQueue[]> {
    return await db.select().from(generationQueue);
  }

  async getQueueItem(id: string): Promise<GenerationQueue | null> {
    const [item] = await db.select().from(generationQueue).where(eq(generationQueue.id, id));
    return item || null;
  }

  async createQueueItem(item: InsertGenerationQueue): Promise<GenerationQueue> {
    const [newItem] = await db
      .insert(generationQueue)
      .values({ ...item, id: nanoid() })
      .returning();
    return newItem;
  }

  async updateQueueItem(id: string, item: Partial<InsertGenerationQueue>): Promise<GenerationQueue | null> {
    const [updatedItem] = await db
      .update(generationQueue)
      .set(item)
      .where(eq(generationQueue.id, id))
      .returning();
    return updatedItem || null;
  }

  async deleteQueueItem(id: string): Promise<boolean> {
    const result = await db.delete(generationQueue).where(eq(generationQueue.id, id));
    return result.rowCount > 0;
  }

  async getPendingQueueItems(): Promise<GenerationQueue[]> {
    return await db.select().from(generationQueue).where(eq(generationQueue.status, "pending"));
  }

  // YouTube Channels
  async getYouTubeChannels(): Promise<YouTubeChannel[]> {
    return await db.select().from(youtubeChannels);
  }

  async getYouTubeChannel(id: string): Promise<YouTubeChannel | null> {
    const [channel] = await db.select().from(youtubeChannels).where(eq(youtubeChannels.id, id));
    return channel || null;
  }

  async createYouTubeChannel(channel: InsertYouTubeChannel): Promise<YouTubeChannel> {
    const [newChannel] = await db
      .insert(youtubeChannels)
      .values({ ...channel, id: nanoid() })
      .returning();
    return newChannel;
  }

  async updateYouTubeChannel(id: string, channel: Partial<InsertYouTubeChannel>): Promise<YouTubeChannel | null> {
    const [updatedChannel] = await db
      .update(youtubeChannels)
      .set(channel)
      .where(eq(youtubeChannels.id, id))
      .returning();
    return updatedChannel || null;
  }

  async deleteYouTubeChannel(id: string): Promise<boolean> {
    const result = await db.delete(youtubeChannels).where(eq(youtubeChannels.id, id));
    return result.rowCount > 0;
  }

  // Episodes
  async getEpisodes(): Promise<Episode[]> {
    return await db.select().from(episodes);
  }

  async getEpisode(id: string): Promise<Episode | null> {
    const [episode] = await db.select().from(episodes).where(eq(episodes.id, id));
    return episode || null;
  }

  async getEpisodesByChannel(channelId: string): Promise<Episode[]> {
    return await db.select().from(episodes).where(eq(episodes.channelId, channelId));
  }

  async createEpisode(episode: InsertEpisode): Promise<Episode> {
    const [newEpisode] = await db
      .insert(episodes)
      .values({ ...episode, id: nanoid() })
      .returning();
    return newEpisode;
  }

  async updateEpisode(id: string, episode: Partial<InsertEpisode>): Promise<Episode | null> {
    const [updatedEpisode] = await db
      .update(episodes)
      .set(episode)
      .where(eq(episodes.id, id))
      .returning();
    return updatedEpisode || null;
  }

  async deleteEpisode(id: string): Promise<boolean> {
    const result = await db.delete(episodes).where(eq(episodes.id, id));
    return result.rowCount > 0;
  }

  async getPendingEpisodes(): Promise<Episode[]> {
    return await db.select().from(episodes).where(eq(episodes.status, "pending"));
  }

  // Content Cache
  async getContentCache(): Promise<ContentCache[]> {
    return await db.select().from(contentCache);
  }

  async getCachedContent(id: string): Promise<ContentCache | null> {
    const [content] = await db.select().from(contentCache).where(eq(contentCache.id, id));
    return content || null;
  }

  async getUnusedContentByChannel(channelId: string, type: "script" | "thumbnail"): Promise<ContentCache[]> {
    return await db
      .select()
      .from(contentCache)
      .where(eq(contentCache.channelId, channelId))
      .where(eq(contentCache.type, type))
      .where(eq(contentCache.isUsed, false));
  }

  async createCachedContent(content: InsertContentCache): Promise<ContentCache> {
    const [newContent] = await db
      .insert(contentCache)
      .values({ ...content, id: nanoid() })
      .returning();
    return newContent;
  }

  async updateCachedContent(id: string, content: Partial<InsertContentCache>): Promise<ContentCache | null> {
    const [updatedContent] = await db
      .update(contentCache)
      .set(content)
      .where(eq(contentCache.id, id))
      .returning();
    return updatedContent || null;
  }

  async deleteCachedContent(id: string): Promise<boolean> {
    const result = await db.delete(contentCache).where(eq(contentCache.id, id));
    return result.rowCount > 0;
  }
}

export class MemStorage implements IStorage {
  private videoThemes: Map<string, VideoTheme> = new Map();
  private videos: Map<string, Video> = new Map();
  private characters: Map<string, Character> = new Map();
  private generationQueue: Map<string, GenerationQueue> = new Map();
  private youtubeChannels: Map<string, YouTubeChannel> = new Map();
  private episodes: Map<string, Episode> = new Map();
  private contentCache: Map<string, ContentCache> = new Map();
  private rumbleCampaigns: Map<string, RumbleCampaign> = new Map();
  private rumbleVideos: Map<string, RumbleVideo> = new Map();

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Default themes
    const educationalTheme: VideoTheme = {
      id: "educational",
      name: "Educational Adventures",
      description: "Fun and engaging educational content for all ages",
      prompts: {
        scenePrompt: "Create an educational adventure scene that teaches viewers about {topic} in a fun and engaging way. The scene should be colorful, inviting, and family-friendly.",
        characterPrompts: [
          "A wise and friendly teacher character with warm clothing and kind eyes",
          "An enthusiastic student character who asks great questions",
          "A curious explorer character who loves discovering new things"
        ],
        ambientSounds: ["gentle wind", "birds chirping", "soft nature sounds", "peaceful forest ambiance"],
        visualStyle: "bright, colorful, cartoon-style with clean lines and friendly expressions"
      },
      isActive: true,
      createdAt: new Date(),
    };

    const storyTheme: VideoTheme = {
      id: "storytelling",
      name: "Storytelling Adventures",
      description: "Creative storytelling with moral lessons and adventure",
      prompts: {
        scenePrompt: "Create a magical storytelling scene where characters embark on an adventure that teaches important life lessons. The scene should be enchanting and suitable for all ages.",
        characterPrompts: [
          "A wise storyteller with magical robes and twinkling eyes",
          "A brave young hero on an adventure",
          "A friendly magical creature who provides guidance",
          "A wise elder who shares important wisdom"
        ],
        ambientSounds: ["magical wind chimes", "soft rustling leaves", "distant castle bells", "gentle stream flowing"],
        visualStyle: "magical realism with warm lighting, fantasy elements, and dreamy atmospheres"
      },
      isActive: true,
      createdAt: new Date(),
    };

    // Default characters
    const characters: Character[] = [
      {
        id: "teacher-alex",
        name: "Teacher Alex",
        description: "A kind and knowledgeable educator who loves sharing knowledge",
        voiceProfile: {
          gender: "male",
          age: "adult",
          personality: "warm, encouraging, patient, and enthusiastic about learning"
        },
        visualStyle: "friendly middle-aged teacher with glasses, warm sweater, and encouraging smile",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "student-emma",
        name: "Student Emma",
        description: "A curious and eager learner who asks thoughtful questions",
        voiceProfile: {
          gender: "female",
          age: "child",
          personality: "curious, energetic, thoughtful, and eager to learn"
        },
        visualStyle: "bright-eyed child with backpack, notebook, and excited expression",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "explorer-sam",
        name: "Explorer Sam",
        description: "An adventurous character who loves discovering new places and ideas",
        voiceProfile: {
          gender: "male",
          age: "adult",
          personality: "adventurous, enthusiastic, brave, and inspiring"
        },
        visualStyle: "explorer with safari hat, binoculars, and adventure gear",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "storyteller-luna",
        name: "Storyteller Luna",
        description: "A magical storyteller who weaves enchanting tales",
        voiceProfile: {
          gender: "female",
          age: "adult",
          personality: "mysterious, wise, soothing, and captivating"
        },
        visualStyle: "mystical storyteller with flowing robes, starry decorations, and gentle smile",
        isActive: true,
        createdAt: new Date(),
      }
    ];

    this.videoThemes.set(educationalTheme.id, educationalTheme);
    this.videoThemes.set(storyTheme.id, storyTheme);
    
    characters.forEach(character => {
      this.characters.set(character.id, character);
    });
  }

  // Video Themes
  async getVideoThemes(): Promise<VideoTheme[]> {
    return Array.from(this.videoThemes.values());
  }

  async getVideoTheme(id: string): Promise<VideoTheme | null> {
    return this.videoThemes.get(id) || null;
  }

  async createVideoTheme(theme: InsertVideoTheme): Promise<VideoTheme> {
    const id = nanoid();
    const newTheme: VideoTheme = {
      ...theme,
      id,
      createdAt: new Date(),
    };
    this.videoThemes.set(id, newTheme);
    return newTheme;
  }

  async updateVideoTheme(id: string, theme: Partial<InsertVideoTheme>): Promise<VideoTheme | null> {
    const existing = this.videoThemes.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...theme };
    this.videoThemes.set(id, updated);
    return updated;
  }

  async deleteVideoTheme(id: string): Promise<boolean> {
    return this.videoThemes.delete(id);
  }

  // Videos
  async getVideos(): Promise<Video[]> {
    return Array.from(this.videos.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getVideo(id: string): Promise<Video | null> {
    return this.videos.get(id) || null;
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const id = nanoid();
    const newVideo: Video = {
      ...video,
      id,
      createdAt: new Date(),
      completedAt: null,
    };
    this.videos.set(id, newVideo);
    return newVideo;
  }

  async updateVideo(id: string, video: Partial<InsertVideo>): Promise<Video | null> {
    const existing = this.videos.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...video };
    this.videos.set(id, updated);
    return updated;
  }

  async deleteVideo(id: string): Promise<boolean> {
    return this.videos.delete(id);
  }

  // Characters
  async getCharacters(): Promise<Character[]> {
    return Array.from(this.characters.values());
  }

  async getCharacter(id: string): Promise<Character | null> {
    return this.characters.get(id) || null;
  }

  async createCharacter(character: InsertCharacter): Promise<Character> {
    const id = nanoid();
    const newCharacter: Character = {
      ...character,
      id,
      createdAt: new Date(),
    };
    this.characters.set(id, newCharacter);
    return newCharacter;
  }

  async updateCharacter(id: string, character: Partial<InsertCharacter>): Promise<Character | null> {
    const existing = this.characters.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...character };
    this.characters.set(id, updated);
    return updated;
  }

  async deleteCharacter(id: string): Promise<boolean> {
    return this.characters.delete(id);
  }

  // Generation Queue
  async getGenerationQueue(): Promise<GenerationQueue[]> {
    return Array.from(this.generationQueue.values()).sort((a, b) => 
      new Date(a.scheduledFor).getTime() - new Date(b.scheduledFor).getTime()
    );
  }

  async getQueueItem(id: string): Promise<GenerationQueue | null> {
    return this.generationQueue.get(id) || null;
  }

  async createQueueItem(item: InsertGenerationQueue): Promise<GenerationQueue> {
    const id = nanoid();
    const newItem: GenerationQueue = {
      ...item,
      id,
      createdAt: new Date(),
    };
    this.generationQueue.set(id, newItem);
    return newItem;
  }

  async updateQueueItem(id: string, item: Partial<InsertGenerationQueue>): Promise<GenerationQueue | null> {
    const existing = this.generationQueue.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...item };
    this.generationQueue.set(id, updated);
    return updated;
  }

  async deleteQueueItem(id: string): Promise<boolean> {
    return this.generationQueue.delete(id);
  }

  async getPendingQueueItems(): Promise<GenerationQueue[]> {
    return Array.from(this.generationQueue.values())
      .filter(item => item.status === "pending" && new Date(item.scheduledFor) <= new Date())
      .sort((a, b) => new Date(a.scheduledFor).getTime() - new Date(b.scheduledFor).getTime());
  }

  // YouTube Channels
  async getYouTubeChannels(): Promise<YouTubeChannel[]> {
    return Array.from(this.youtubeChannels.values());
  }

  async getYouTubeChannel(id: string): Promise<YouTubeChannel | null> {
    return this.youtubeChannels.get(id) || null;
  }

  async createYouTubeChannel(channel: InsertYouTubeChannel): Promise<YouTubeChannel> {
    const id = nanoid();
    const newChannel: YouTubeChannel = {
      ...channel,
      id,
      createdAt: new Date(),
      lastUpload: null,
    };
    this.youtubeChannels.set(id, newChannel);
    return newChannel;
  }

  async updateYouTubeChannel(id: string, channel: Partial<InsertYouTubeChannel>): Promise<YouTubeChannel | null> {
    const existing = this.youtubeChannels.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...channel };
    this.youtubeChannels.set(id, updated);
    return updated;
  }

  async deleteYouTubeChannel(id: string): Promise<boolean> {
    return this.youtubeChannels.delete(id);
  }

  // Episodes
  async getEpisodes(): Promise<Episode[]> {
    return Array.from(this.episodes.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getEpisode(id: string): Promise<Episode | null> {
    return this.episodes.get(id) || null;
  }

  async getEpisodesByChannel(channelId: string): Promise<Episode[]> {
    return Array.from(this.episodes.values())
      .filter(ep => ep.channelId === channelId)
      .sort((a, b) => a.episodeNumber - b.episodeNumber);
  }

  async createEpisode(episode: InsertEpisode): Promise<Episode> {
    const id = nanoid();
    const newEpisode: Episode = {
      ...episode,
      id,
      createdAt: new Date(),
      completedAt: null,
    };
    this.episodes.set(id, newEpisode);
    return newEpisode;
  }

  async updateEpisode(id: string, episode: Partial<InsertEpisode>): Promise<Episode | null> {
    const existing = this.episodes.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...episode };
    this.episodes.set(id, updated);
    return updated;
  }

  async deleteEpisode(id: string): Promise<boolean> {
    return this.episodes.delete(id);
  }

  async getPendingEpisodes(): Promise<Episode[]> {
    return Array.from(this.episodes.values())
      .filter(ep => ep.status === "pending");
  }

  // Content Cache
  async getContentCache(): Promise<ContentCache[]> {
    return Array.from(this.contentCache.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getCachedContent(id: string): Promise<ContentCache | null> {
    return this.contentCache.get(id) || null;
  }

  async getUnusedContentByChannel(channelId: string, type: "script" | "thumbnail"): Promise<ContentCache[]> {
    return Array.from(this.contentCache.values())
      .filter(c => c.channelId === channelId && c.type === type && !c.isUsed);
  }

  async createCachedContent(content: InsertContentCache): Promise<ContentCache> {
    const id = nanoid();
    const newContent: ContentCache = {
      ...content,
      id,
      createdAt: new Date(),
    };
    this.contentCache.set(id, newContent);
    return newContent;
  }

  async updateCachedContent(id: string, content: Partial<InsertContentCache>): Promise<ContentCache | null> {
    const existing = this.contentCache.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...content };
    this.contentCache.set(id, updated);
    return updated;
  }

  async deleteCachedContent(id: string): Promise<boolean> {
    return this.contentCache.delete(id);
  }

  // Rumble Campaigns
  async getRumbleCampaigns(): Promise<RumbleCampaign[]> {
    return Array.from(this.rumbleCampaigns.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getRumbleCampaign(id: string): Promise<RumbleCampaign | null> {
    return this.rumbleCampaigns.get(id) || null;
  }

  async getActiveCampaign(): Promise<RumbleCampaign | null> {
    return Array.from(this.rumbleCampaigns.values())
      .find(c => c.status === "active") || null;
  }

  async createRumbleCampaign(campaign: InsertRumbleCampaign): Promise<RumbleCampaign> {
    const id = nanoid();
    const newCampaign: RumbleCampaign = {
      ...campaign,
      id,
      videosGenerated: 0,
      currentDay: 0,
      lastGeneratedAt: null,
      nextScheduledAt: null,
      lastRunStatus: null,
      createdAt: new Date(),
      completedAt: null,
    };
    this.rumbleCampaigns.set(id, newCampaign);
    return newCampaign;
  }

  async updateRumbleCampaign(id: string, campaign: Partial<InsertRumbleCampaign>): Promise<RumbleCampaign | null> {
    const existing = this.rumbleCampaigns.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...campaign };
    this.rumbleCampaigns.set(id, updated);
    return updated;
  }

  async deleteRumbleCampaign(id: string): Promise<boolean> {
    return this.rumbleCampaigns.delete(id);
  }

  // Rumble Videos
  async getRumbleVideos(): Promise<RumbleVideo[]> {
    return Array.from(this.rumbleVideos.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getRumbleVideo(id: string): Promise<RumbleVideo | null> {
    return this.rumbleVideos.get(id) || null;
  }

  async getRumbleVideosByCampaign(campaignId: string): Promise<RumbleVideo[]> {
    return Array.from(this.rumbleVideos.values())
      .filter(v => v.campaignId === campaignId)
      .sort((a, b) => a.dayNumber - b.dayNumber);
  }

  async createRumbleVideo(video: InsertRumbleVideo): Promise<RumbleVideo> {
    const id = nanoid();
    const newVideo: RumbleVideo = {
      ...video,
      id,
      createdAt: new Date(),
      completedAt: null,
    };
    this.rumbleVideos.set(id, newVideo);
    return newVideo;
  }

  async updateRumbleVideo(id: string, video: Partial<InsertRumbleVideo>): Promise<RumbleVideo | null> {
    const existing = this.rumbleVideos.get(id);
    if (!existing) return null;
    
    const updated = { ...existing, ...video };
    this.rumbleVideos.set(id, updated);
    return updated;
  }

  async deleteRumbleVideo(id: string): Promise<boolean> {
    return this.rumbleVideos.delete(id);
  }
}

export const storage = new MemStorage();