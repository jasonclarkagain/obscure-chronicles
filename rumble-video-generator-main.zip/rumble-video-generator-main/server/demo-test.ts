import { storage } from "./storage";
import { JobManager } from "./job-manager";
import { nanoid } from "nanoid";

async function createDemoContent() {
  console.log("\n🎬 Creating Demo Content (No OpenAI API needed)\n");

  const channels = await storage.getYouTubeChannels();
  if (channels.length === 0) {
    console.log("❌ No channels found. Run './multichannel.sh init' first");
    return;
  }

  const channel = channels[0];
  console.log(`📺 Using channel: ${channel.name}`);

  console.log("\n📝 Creating cached scripts...");
  for (let i = 0; i < 3; i++) {
    const script = {
      title: `Amazing ${channel.contentStrategy.themes[i % channel.contentStrategy.themes.length]}`,
      description: `Learn about ${channel.contentStrategy.themes[i % channel.contentStrategy.themes.length]} in this fun educational video!`,
      scenes: [
        {
          text: "Welcome to our amazing learning adventure!",
          duration: 20,
          visualCue: "Bright colorful opening scene"
        },
        {
          text: "Let's explore this fascinating topic together.",
          duration: 20,
          visualCue: "Educational content display"
        },
        {
          text: "Thank you for joining us on this adventure!",
          duration: 20,
          visualCue: "Cheerful closing scene"
        }
      ],
      tags: ["education", "learning", "kids", "fun", "adventure"]
    };

    await storage.createCachedContent({
      type: "script",
      channelId: channel.id,
      data: { script },
      isUsed: false,
    });
    
    console.log(`   ✅ Script ${i + 1}: "${script.title}"`);
  }

  console.log("\n🎨 Creating cached thumbnails...");
  for (let i = 0; i < 3; i++) {
    await storage.createCachedContent({
      type: "thumbnail",
      channelId: channel.id,
      data: { 
        thumbnailPath: `demo_thumbnail_${i}.png`,
        metadata: { demo: true }
      },
      isUsed: false,
    });
    
    console.log(`   ✅ Thumbnail ${i + 1}`);
  }

  console.log("\n📺 Creating demo episodes...");
  for (let i = 0; i < 2; i++) {
    await storage.createEpisode({
      channelId: channel.id,
      episodeNumber: i + 1,
      title: `Demo Episode ${i + 1}`,
      topic: channel.contentStrategy.themes[i % channel.contentStrategy.themes.length],
      status: "pending",
      phase: "init",
      scriptCacheId: null,
      thumbnailCacheId: null,
      videoPath: null,
      errorMessage: null,
      retryCount: 0,
    });
    
    console.log(`   ✅ Episode ${i + 1}`);
  }

  console.log("\n✅ Demo content created!\n");
  console.log("Next steps:");
  console.log(`1. ./multichannel.sh status        # Check system status`);
  console.log(`2. ./multichannel.sh batch ${channel.id} 2   # Render 2 episodes`);
  console.log("");

  process.exit(0);
}

createDemoContent().catch((error) => {
  console.error("Error:", error);
  process.exit(1);
});
