import { Router } from "express";
import { IStorage } from "./storage";

export function createRoutes(storage: IStorage): Router {
  const router = Router();

  // Health check
  router.get("/api/health", (req, res) => {
    res.json({ status: "API is running", timestamp: new Date().toISOString() });
  });

  // YouTube Channels
  router.get("/api/youtube-channels", async (req, res) => {
    try {
      const channels = await storage.getYouTubeChannels();
      res.json(channels);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  router.get("/api/youtube-channels/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const channel = await storage.getYouTubeChannel(id);
      
      if (!channel) {
        return res.status(404).json({ error: "Channel not found" });
      }
      
      res.json(channel);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Episodes
  router.get("/api/episodes", async (req, res) => {
    try {
      const { channelId } = req.query;
      
      if (channelId) {
        const episodes = await storage.getEpisodesByChannel(channelId as string);
        return res.json(episodes);
      }
      
      const episodes = await storage.getEpisodes();
      res.json(episodes);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Content Cache
  router.get("/api/content-cache", async (req, res) => {
    try {
      const cache = await storage.getContentCache();
      res.json(cache);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Job Status
  router.get("/api/jobs/status", async (req, res) => {
    try {
      const channels = await storage.getYouTubeChannels();
      const cache = await storage.getContentCache();
      const unusedCache = cache.filter(c => !c.isUsed);

      res.json({
        episodes: {
          totalEpisodes: 0,
          byStatus: {},
          byPhase: {}
        },
        channels: {
          total: channels.length,
          active: channels.filter(c => c.isActive).length
        },
        cache: {
          scripts: {
            total: cache.filter(c => c.type === "script").length,
            unused: unusedCache.filter(c => c.type === "script").length
          },
          thumbnails: {
            total: cache.filter(c => c.type === "thumbnail").length,
            unused: unusedCache.filter(c => c.type === "thumbnail").length
          }
        }
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Job Control - Cache Content
  router.post("/api/jobs/cache-content", async (req, res) => {
    try {
      const { channelId, count } = req.body;
      
      if (!channelId || !count) {
        return res.status(400).json({ error: "channelId and count are required" });
      }

      res.json({
        success: true,
        message: `Initiated caching of ${count} pieces of content for channel ${channelId}`,
        jobId: `cache-${Date.now()}`,
        status: "queued"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Job Control - Create Episodes
  router.post("/api/jobs/create-episodes", async (req, res) => {
    try {
      const { channelId, count } = req.body;
      
      if (!channelId || !count) {
        return res.status(400).json({ error: "channelId and count are required" });
      }

      res.json({
        success: true,
        message: `Initiated creation of ${count} episodes for channel ${channelId}`,
        jobId: `episodes-${Date.now()}`,
        status: "queued"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Job Control - Batch Render
  router.post("/api/jobs/batch-render", async (req, res) => {
    try {
      const { channelId, count } = req.body;
      
      if (!channelId || !count) {
        return res.status(400).json({ error: "channelId and count are required" });
      }

      res.json({
        success: true,
        message: `Initiated batch rendering of ${count} videos for channel ${channelId}`,
        jobId: `render-${Date.now()}`,
        status: "queued"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  return router;
}
