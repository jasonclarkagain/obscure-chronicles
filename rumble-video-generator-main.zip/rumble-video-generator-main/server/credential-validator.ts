#!/usr/bin/env npx tsx

import { google } from 'googleapis';

interface YouTubeCredentials {
  client_id: string;
  client_secret: string;
  refresh_token: string;
}

export class CredentialValidator {
  async validateCredentials(credentials: YouTubeCredentials): Promise<{ valid: boolean; error?: string; channelInfo?: any }> {
    try {
      const oauth2Client = new google.auth.OAuth2(
        credentials.client_id,
        credentials.client_secret,
        'http://localhost:3000/oauth2callback'
      );

      oauth2Client.setCredentials({
        refresh_token: credentials.refresh_token
      });

      const youtube = google.youtube({
        version: 'v3',
        auth: oauth2Client
      });

      // Test the connection by getting channel info
      const channelResponse = await youtube.channels.list({
        part: ['snippet', 'statistics', 'status'],
        mine: true
      });

      if (channelResponse.data.items && channelResponse.data.items.length > 0) {
        const channel = channelResponse.data.items[0];
        
        return {
          valid: true,
          channelInfo: {
            title: channel.snippet?.title,
            description: channel.snippet?.description,
            customUrl: channel.snippet?.customUrl,
            subscriberCount: channel.statistics?.subscriberCount,
            videoCount: channel.statistics?.videoCount,
            viewCount: channel.statistics?.viewCount,
            uploadsEnabled: channel.status?.longUploadsStatus === 'allowed',
            verified: channel.status?.isLinked
          }
        };
      } else {
        return {
          valid: false,
          error: 'No YouTube channel found for this account'
        };
      }

    } catch (error) {
      return {
        valid: false,
        error: `Credential validation failed: ${error.message}`
      };
    }
  }

  async testUploadPermissions(credentials: YouTubeCredentials): Promise<{ canUpload: boolean; error?: string }> {
    try {
      const oauth2Client = new google.auth.OAuth2(
        credentials.client_id,
        credentials.client_secret,
        'http://localhost:3000/oauth2callback'
      );

      oauth2Client.setCredentials({
        refresh_token: credentials.refresh_token
      });

      const youtube = google.youtube({
        version: 'v3',
        auth: oauth2Client
      });

      // Check upload quota and permissions
      const quotaResponse = await youtube.channels.list({
        part: ['status'],
        mine: true
      });

      if (quotaResponse.data.items && quotaResponse.data.items.length > 0) {
        const channel = quotaResponse.data.items[0];
        const uploadsEnabled = channel.status?.longUploadsStatus === 'allowed';
        
        return {
          canUpload: uploadsEnabled || false,
          error: uploadsEnabled ? undefined : 'Long uploads not enabled on this channel'
        };
      }

      return {
        canUpload: false,
        error: 'Unable to verify upload permissions'
      };

    } catch (error) {
      return {
        canUpload: false,
        error: `Permission check failed: ${error.message}`
      };
    }
  }
}

// Test function
async function testCredentials() {
  console.log('YouTube Credential Validator');
  console.log('============================\n');

  const validator = new CredentialValidator();
  
  // Check if credentials are provided as environment variables
  const credentials = {
    client_id: process.env.YOUTUBE_CLIENT_ID || '',
    client_secret: process.env.YOUTUBE_CLIENT_SECRET || '',
    refresh_token: process.env.YOUTUBE_REFRESH_TOKEN || ''
  };

  if (!credentials.client_id || !credentials.client_secret || !credentials.refresh_token) {
    console.log('Missing credentials. Please set environment variables:');
    console.log('- YOUTUBE_CLIENT_ID');
    console.log('- YOUTUBE_CLIENT_SECRET');
    console.log('- YOUTUBE_REFRESH_TOKEN');
    return;
  }

  console.log('Testing credentials...');
  
  const validation = await validator.validateCredentials(credentials);
  
  if (validation.valid) {
    console.log('✅ Credentials are valid!');
    console.log('\nChannel Information:');
    console.log(`- Title: ${validation.channelInfo?.title}`);
    console.log(`- Subscribers: ${validation.channelInfo?.subscriberCount}`);
    console.log(`- Videos: ${validation.channelInfo?.videoCount}`);
    console.log(`- Views: ${validation.channelInfo?.viewCount}`);
    console.log(`- Verified: ${validation.channelInfo?.verified ? 'Yes' : 'No'}`);
    
    // Test upload permissions
    const uploadTest = await validator.testUploadPermissions(credentials);
    console.log(`- Upload Enabled: ${uploadTest.canUpload ? 'Yes' : 'No'}`);
    
    if (uploadTest.canUpload) {
      console.log('\n🎉 Ready for automated video uploads!');
    } else {
      console.log(`\n❌ Upload issue: ${uploadTest.error}`);
    }
    
  } else {
    console.log(`❌ Credential validation failed: ${validation.error}`);
  }
}

if (require.main === module) {
  testCredentials().catch(console.error);
}

// Export removed to avoid conflicts