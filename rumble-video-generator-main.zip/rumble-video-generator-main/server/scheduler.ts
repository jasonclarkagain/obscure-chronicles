import cron from 'node-cron';
import { nanoid } from 'nanoid';
import postgres from 'postgres';
import { youtubeUploader } from './youtube-uploader';

interface ScheduledTask {
  id: string;
  name: string;
  schedule: string;
  active: boolean;
  lastRun?: Date;
  nextRun?: Date;
}

export class VideoScheduler {
  private client: postgres.Sql;
  private tasks: Map<string, cron.ScheduledTask> = new Map();
  private scheduledJobs: ScheduledTask[] = [];

  constructor(dbClient: postgres.Sql) {
    this.client = dbClient;
    this.initializeScheduler();
  }

  private initializeScheduler() {
    console.log('Initializing video generation scheduler...');
    
    // Daily video generation at 9 AM UTC
    this.scheduleTask('daily-video-generation', '0 9 * * *', async () => {
      await this.generateDailyVideo();
    });

    // Queue processor every 5 minutes
    this.scheduleTask('queue-processor', '*/5 * * * *', async () => {
      await this.processGenerationQueue();
    });

    // System health check every hour
    this.scheduleTask('health-check', '0 * * * *', async () => {
      await this.performHealthCheck();
    });
  }

  private scheduleTask(name: string, schedule: string, handler: () => Promise<void>) {
    try {
      const task = cron.schedule(schedule, async () => {
        console.log(`Executing scheduled task: ${name}`);
        try {
          await handler();
          await this.updateTaskStatus(name, 'completed');
        } catch (error) {
          console.error(`Task ${name} failed:`, error);
          await this.updateTaskStatus(name, 'failed', error);
        }
      }, {
        scheduled: true,
        timezone: 'UTC'
      });

      this.tasks.set(name, task);
      
      this.scheduledJobs.push({
        id: nanoid(),
        name: name,
        schedule: schedule,
        active: true,
        nextRun: this.getNextRunTime(schedule)
      });

      console.log(`Scheduled task: ${name} (${schedule})`);
    } catch (error) {
      console.error(`Failed to schedule task ${name}:`, error);
    }
  }

  private async generateDailyVideo(): Promise<void> {
    console.log('Starting daily video generation...');

    try {
      // Get active themes
      const themes = await this.client`
        SELECT * FROM video_themes 
        WHERE is_active = true 
        ORDER BY RANDOM() 
        LIMIT 1
      `;

      if (themes.length === 0) {
        console.log('No active themes found for video generation');
        return;
      }

      const theme = themes[0];

      // Get active characters
      const characters = await this.client`
        SELECT * FROM characters 
        WHERE is_active = true 
        ORDER BY RANDOM() 
        LIMIT 3
      `;

      if (characters.length === 0) {
        console.log('No active characters found for video generation');
        return;
      }

      // Create generation queue item
      const queueItem = {
        id: nanoid(),
        theme_id: theme.id,
        scheduled_for: new Date(),
        status: 'pending',
        retry_count: 0,
        created_at: new Date()
      };

      await this.client`
        INSERT INTO generation_queue (id, theme_id, scheduled_for, status, retry_count, created_at)
        VALUES (${queueItem.id}, ${queueItem.theme_id}, ${queueItem.scheduled_for}, ${queueItem.status}, ${queueItem.retry_count}, ${queueItem.created_at})
      `;

      console.log(`Daily video generation queued: ${queueItem.id}`);

    } catch (error) {
      console.error('Daily video generation failed:', error);
      throw error;
    }
  }

  private async processGenerationQueue(): Promise<void> {
    try {
      const pendingItems = await this.client`
        SELECT * FROM generation_queue 
        WHERE status = 'pending' 
        AND scheduled_for <= NOW()
        ORDER BY created_at ASC
        LIMIT 5
      `;

      for (const item of pendingItems) {
        await this.processQueueItem(item);
      }

    } catch (error) {
      console.error('Queue processing failed:', error);
    }
  }

  private async processQueueItem(item: any): Promise<void> {
    try {
      console.log(`Processing queue item: ${item.id}`);

      // Mark as processing
      await this.client`
        UPDATE generation_queue 
        SET status = 'processing' 
        WHERE id = ${item.id}
      `;

      // Get theme and characters
      const [theme] = await this.client`
        SELECT * FROM video_themes WHERE id = ${item.theme_id}
      `;

      const characters = await this.client`
        SELECT * FROM characters 
        WHERE is_active = true 
        ORDER BY RANDOM() 
        LIMIT 3
      `;

      if (!theme || characters.length === 0) {
        throw new Error('Invalid theme or no characters available');
      }

      // Generate video (mock implementation)
      const videoScript = this.generateMockScript(theme, characters);
      
      const videoId = nanoid();
      const video = {
        id: videoId,
        title: videoScript.title,
        description: videoScript.description,
        theme_id: theme.id,
        status: 'completed',
        script: videoScript,
        metadata: {
          duration: videoScript.totalDuration,
          resolution: { width: 1920, height: 1080 },
          fps: 30,
          scheduled_generation: true
        },
        created_at: new Date(),
        completed_at: new Date()
      };

      // Save video to database
      await this.client`
        INSERT INTO videos (id, title, description, theme_id, status, script, metadata, created_at, completed_at)
        VALUES (${video.id}, ${video.title}, ${video.description}, ${video.theme_id}, ${video.status}, ${JSON.stringify(video.script)}, ${JSON.stringify(video.metadata)}, ${video.created_at}, ${video.completed_at})
      `;

      // Mark queue item as completed
      await this.client`
        UPDATE generation_queue 
        SET status = 'completed' 
        WHERE id = ${item.id}
      `;

      console.log(`Video generated and saved: ${videoId}`);

    } catch (error: any) {
      console.error(`Queue item processing failed: ${item.id}`, error);
      
      const retryCount = (item.retry_count || 0) + 1;
      const maxRetries = 3;

      if (retryCount < maxRetries) {
        await this.client`
          UPDATE generation_queue 
          SET status = 'pending', retry_count = ${retryCount}, error_message = ${error.message}
          WHERE id = ${item.id}
        `;
      } else {
        await this.client`
          UPDATE generation_queue 
          SET status = 'failed', retry_count = ${retryCount}, error_message = ${error.message}
          WHERE id = ${item.id}
        `;
      }
    }
  }

  private generateMockScript(theme: any, characters: any[]): any {
    return {
      title: `${theme.name} Adventure - ${new Date().toLocaleDateString()}`,
      description: `Educational video about ${theme.description}`,
      totalDuration: 90,
      scenes: [
        {
          id: 'scene-1',
          duration: 30,
          dialog: [
            {
              character: characters[0]?.name || 'Narrator',
              text: `Welcome to today's ${theme.name} adventure!`,
              timing: { start: 0, end: 5 }
            }
          ],
          visualDescription: `Educational scene about ${theme.description}`,
          ambientSounds: ['gentle music'],
          soundEffects: ['positive chime']
        }
      ]
    };
  }

  private async performHealthCheck(): Promise<void> {
    try {
      // Check database connectivity
      await this.client`SELECT 1`;
      
      // Check queue status
      const queueStats = await this.client`
        SELECT 
          status, 
          COUNT(*) as count 
        FROM generation_queue 
        WHERE created_at > NOW() - INTERVAL '24 hours'
        GROUP BY status
      `;

      console.log('System health check completed:', {
        database: 'healthy',
        queue_stats: queueStats,
        youtube_ready: youtubeUploader.isReady(),
        active_tasks: this.tasks.size
      });

    } catch (error) {
      console.error('Health check failed:', error);
    }
  }

  private async updateTaskStatus(taskName: string, status: string, error?: any): Promise<void> {
    const task = this.scheduledJobs.find(t => t.name === taskName);
    if (task) {
      task.lastRun = new Date();
      // Calculate next run time based on schedule
      task.nextRun = this.getNextRunTime(this.getTaskSchedule(taskName));
    }

    // Log task execution
    console.log(`Task ${taskName}: ${status}${error ? ` - ${error.message}` : ''}`);
  }

  private getTaskSchedule(taskName: string): string {
    const task = this.scheduledJobs.find(t => t.name === taskName);
    return task?.schedule || '0 0 * * *';
  }

  private getNextRunTime(schedule: string): Date {
    // Simple implementation - in production, use cron-parser library
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(9, 0, 0, 0); // Default to 9 AM next day
    return tomorrow;
  }

  getSchedulerStatus(): any {
    return {
      active_tasks: this.tasks.size,
      scheduled_jobs: this.scheduledJobs.map(job => ({
        name: job.name,
        schedule: job.schedule,
        active: job.active,
        last_run: job.lastRun,
        next_run: job.nextRun
      })),
      uptime: process.uptime()
    };
  }

  stopAllTasks(): void {
    this.tasks.forEach((task, name) => {
      task.stop();
      console.log(`Stopped task: ${name}`);
    });
    this.tasks.clear();
  }

  startTask(taskName: string): boolean {
    const task = this.tasks.get(taskName);
    if (task) {
      task.start();
      return true;
    }
    return false;
  }

  stopTask(taskName: string): boolean {
    const task = this.tasks.get(taskName);
    if (task) {
      task.stop();
      return true;
    }
    return false;
  }
}

export default VideoScheduler;