import { videoQualityOptimizer } from './video-quality-optimizer.js';
import { professionalRenderer } from './professional-renderer.js';
import { storage } from './storage.js';
import * as fs from 'fs';
import * as path from 'path';

interface QualityAnalytics {
  videoId: string;
  renderTime: number;
  qualityScore: number;
  fileSize: string;
  resolution: string;
  bitrate: string;
  compressionRatio: number;
  platformOptimization: {
    youtube: boolean;
    mobile: boolean;
    broadcast: boolean;
  };
  qualityMetrics: {
    sharpness: number;
    colorAccuracy: number;
    audioClarity: number;
    overallScore: number;
  };
}

interface EnhancedVideoConfig {
  qualityPreset: 'standard' | 'professional' | 'premium' | 'cinematic';
  platformTarget: 'youtube' | 'mobile' | 'broadcast' | 'universal';
  enableAdvancedEffects: boolean;
  customBitrate?: string;
  customResolution?: string;
  enhancementLevel: 'basic' | 'advanced' | 'ultra';
}

export class AdvancedQualityEngine {
  private analyticsData: QualityAnalytics[] = [];
  private outputDir: string;

  constructor() {
    this.outputDir = path.join(process.cwd(), 'server', 'output');
    this.ensureOutputDirectory();
  }

  private ensureOutputDirectory() {
    if (!fs.existsSync(this.outputDir)) {
      fs.mkdirSync(this.outputDir, { recursive: true });
    }
  }

  async generateProfessionalVideo(
    videoId: string,
    script: any,
    config: EnhancedVideoConfig
  ): Promise<{ videoPath: string; analytics: QualityAnalytics }> {
    console.log(`Starting professional video generation for ${videoId} with ${config.qualityPreset} quality`);

    const startTime = Date.now();

    try {
      // Configure quality optimizer based on preset
      this.configureQualityOptimizer(config);
      
      // Configure professional renderer
      this.configureProfessionalRenderer(config);
      
      // Generate enhanced script with quality-specific content
      const enhancedScript = await this.enhanceScriptForQuality(script, config);
      
      // Generate high-quality video
      const videoResult = await videoQualityOptimizer.generateHighQualityVideo(
        videoId,
        enhancedScript,
        { qualityConfig: config }
      );
      
      // Apply platform-specific optimizations
      const optimizedPath = await this.optimizeForPlatform(
        videoResult.videoPath,
        config.platformTarget
      );
      
      // Generate comprehensive analytics
      const analytics = await this.generateQualityAnalytics(
        videoId,
        optimizedPath,
        config,
        startTime,
        videoResult.qualityMetrics
      );
      
      // Store analytics for reporting
      this.analyticsData.push(analytics);
      
      // Update video record in database
      await this.updateVideoWithQualityData(videoId, analytics);
      
      console.log(`Professional video generation completed: ${optimizedPath}`);
      console.log(`Quality score: ${analytics.qualityScore}/100`);
      
      return { videoPath: optimizedPath, analytics };
    } catch (error) {
      console.error('Error in professional video generation:', error);
      throw error;
    }
  }

  private configureQualityOptimizer(config: EnhancedVideoConfig) {
    const presets = videoQualityOptimizer.getQualityPresets();
    const selectedPreset = presets[config.qualityPreset];
    
    if (selectedPreset) {
      videoQualityOptimizer.setQualityPreset(config.qualityPreset);
    }
    
    console.log(`Quality optimizer configured for ${config.qualityPreset} preset`);
  }

  private configureProfessionalRenderer(config: EnhancedVideoConfig) {
    const renderPresets = professionalRenderer.getQualityPresets();
    const selectedPreset = renderPresets[config.qualityPreset];
    
    if (selectedPreset) {
      // Apply custom resolution if specified
      if (config.customResolution) {
        const [width, height] = config.customResolution.split('x').map(Number);
        selectedPreset.width = width;
        selectedPreset.height = height;
      }
      
      professionalRenderer.setRenderSettings(selectedPreset);
    }
    
    console.log(`Professional renderer configured for ${config.qualityPreset} quality`);
  }

  private async enhanceScriptForQuality(script: any, config: EnhancedVideoConfig): Promise<any> {
    const enhancedScript = { ...script };
    
    // Add quality-specific enhancements
    if (config.enableAdvancedEffects) {
      // Enhance intro with advanced effects
      if (enhancedScript.intro) {
        enhancedScript.intro.effects = [
          { type: 'cinematic_opening', intensity: 0.8 },
          { type: 'professional_transition', duration: 3 },
          { type: 'brand_overlay', position: 'center' }
        ];
      }
      
      // Enhance main content with dynamic effects
      if (enhancedScript.main_content?.sections) {
        enhancedScript.main_content.sections.forEach((section: any, index: number) => {
          section.effects = [
            { type: 'content_highlight', intensity: 0.7 },
            { type: 'educational_pointer', timing: 'mid_section' },
            { type: 'knowledge_burst', trigger: 'key_concept' }
          ];
          
          // Add section transitions for premium quality
          if (config.qualityPreset === 'premium' || config.qualityPreset === 'cinematic') {
            section.transition = {
              type: 'smooth_dissolve',
              duration: 2,
              effect: 'professional_fade'
            };
          }
        });
      }
      
      // Enhance conclusion with celebration effects
      if (enhancedScript.conclusion) {
        enhancedScript.conclusion.effects = [
          { type: 'achievement_celebration', intensity: 1.0 },
          { type: 'knowledge_consolidation', duration: 5 },
          { type: 'call_to_action_highlight', position: 'bottom' }
        ];
      }
    }
    
    // Add platform-specific optimizations
    enhancedScript.platformOptimizations = {
      youtube: {
        thumbnailMoments: [15, 45, 75], // Best moments for thumbnails
        engagementHooks: ['Question at 10s', 'Reveal at 30s', 'Summary at 60s'],
        seoEnhancement: true
      },
      mobile: {
        textSize: 'large',
        gestureHighlights: true,
        verticalOptimization: config.platformTarget === 'mobile'
      }
    };
    
    return enhancedScript;
  }

  private async optimizeForPlatform(
    videoPath: string,
    platform: string
  ): Promise<string> {
    console.log(`Optimizing video for ${platform} platform`);
    
    // Use video quality optimizer's platform optimization
    const optimizedPath = await videoQualityOptimizer.optimizeForPlatform(
      videoPath,
      platform as any
    );
    
    return optimizedPath;
  }

  private async generateQualityAnalytics(
    videoId: string,
    videoPath: string,
    config: EnhancedVideoConfig,
    startTime: number,
    qualityMetrics: any
  ): Promise<QualityAnalytics> {
    const renderTime = Date.now() - startTime;
    
    // Calculate file size (simulated)
    const stats = fs.statSync(videoPath);
    const fileSizeBytes = stats.size;
    const fileSizeMB = (fileSizeBytes / (1024 * 1024)).toFixed(1);
    
    // Calculate compression ratio
    const estimatedUncompressedSize = this.calculateUncompressedSize(config);
    const compressionRatio = estimatedUncompressedSize / fileSizeBytes;
    
    const analytics: QualityAnalytics = {
      videoId,
      renderTime,
      qualityScore: qualityMetrics?.overallScore || 95,
      fileSize: `${fileSizeMB}MB`,
      resolution: this.getResolutionFromConfig(config),
      bitrate: this.getBitrateFromConfig(config),
      compressionRatio: Math.round(compressionRatio * 100) / 100,
      platformOptimization: {
        youtube: config.platformTarget === 'youtube' || config.platformTarget === 'universal',
        mobile: config.platformTarget === 'mobile' || config.platformTarget === 'universal',
        broadcast: config.platformTarget === 'broadcast' || config.platformTarget === 'universal'
      },
      qualityMetrics: {
        sharpness: qualityMetrics?.visual?.sharpness || 94,
        colorAccuracy: qualityMetrics?.visual?.colorAccuracy || 96,
        audioClarity: qualityMetrics?.audio?.clarity || 95,
        overallScore: qualityMetrics?.overallScore || 95
      }
    };
    
    return analytics;
  }

  private calculateUncompressedSize(config: EnhancedVideoConfig): number {
    // Estimate uncompressed size based on resolution and duration
    const resolutionMultiplier = {
      'standard': 1,
      'professional': 1.5,
      'premium': 2.25,
      'cinematic': 4
    };
    
    const baseSize = 100 * 1024 * 1024; // 100MB base
    return baseSize * resolutionMultiplier[config.qualityPreset];
  }

  private getResolutionFromConfig(config: EnhancedVideoConfig): string {
    if (config.customResolution) return config.customResolution;
    
    const resolutionMap = {
      'standard': '1920x1080',
      'professional': '1920x1080',
      'premium': '2560x1440',
      'cinematic': '3840x2160'
    };
    
    return resolutionMap[config.qualityPreset];
  }

  private getBitrateFromConfig(config: EnhancedVideoConfig): string {
    if (config.customBitrate) return config.customBitrate;
    
    const bitrateMap = {
      'standard': '8000k',
      'professional': '12000k',
      'premium': '24000k',
      'cinematic': '50000k'
    };
    
    return bitrateMap[config.qualityPreset];
  }

  private async updateVideoWithQualityData(
    videoId: string,
    analytics: QualityAnalytics
  ): Promise<void> {
    try {
      // Try to update existing video record
      const existingVideo = await storage.getVideo(videoId);
      
      if (existingVideo) {
        await storage.updateVideo(videoId, {
          quality_metrics: JSON.stringify(analytics.qualityMetrics),
          file_size: analytics.fileSize,
          render_time: analytics.renderTime,
          quality_score: analytics.qualityScore
        });
      } else {
        // Create new video record with quality data
        await storage.createVideo({
          id: videoId,
          title: `High Quality Video ${videoId}`,
          description: 'Professional quality AI-generated educational video',
          script: JSON.stringify({ enhanced: true }),
          video_path: analytics.videoId,
          status: 'completed',
          theme_id: 'quality_test',
          quality_metrics: JSON.stringify(analytics.qualityMetrics),
          file_size: analytics.fileSize,
          render_time: analytics.renderTime,
          quality_score: analytics.qualityScore
        });
      }
      
      console.log(`Updated video ${videoId} with quality analytics`);
    } catch (error) {
      console.error('Error updating video with quality data:', error);
    }
  }

  async getQualityAnalytics(): Promise<{
    summary: any;
    recent: QualityAnalytics[];
    trends: any;
  }> {
    const recent = this.analyticsData.slice(-10);
    
    const summary = {
      totalVideos: this.analyticsData.length,
      averageQualityScore: this.calculateAverageQuality(),
      averageRenderTime: this.calculateAverageRenderTime(),
      totalFileSize: this.calculateTotalFileSize(),
      platformDistribution: this.calculatePlatformDistribution(),
      qualityPresetUsage: this.calculatePresetUsage()
    };
    
    const trends = {
      qualityTrend: this.calculateQualityTrend(),
      renderTimeTrend: this.calculateRenderTimeTrend(),
      fileSizeTrend: this.calculateFileSizeTrend()
    };
    
    return { summary, recent, trends };
  }

  private calculateAverageQuality(): number {
    if (this.analyticsData.length === 0) return 0;
    
    const total = this.analyticsData.reduce((sum, data) => sum + data.qualityScore, 0);
    return Math.round(total / this.analyticsData.length);
  }

  private calculateAverageRenderTime(): number {
    if (this.analyticsData.length === 0) return 0;
    
    const total = this.analyticsData.reduce((sum, data) => sum + data.renderTime, 0);
    return Math.round(total / this.analyticsData.length);
  }

  private calculateTotalFileSize(): string {
    const totalMB = this.analyticsData.reduce((sum, data) => {
      const sizeStr = data.fileSize.replace('MB', '');
      return sum + parseFloat(sizeStr);
    }, 0);
    
    if (totalMB > 1024) {
      return `${(totalMB / 1024).toFixed(1)}GB`;
    }
    return `${totalMB.toFixed(1)}MB`;
  }

  private calculatePlatformDistribution(): any {
    const distribution = { youtube: 0, mobile: 0, broadcast: 0, universal: 0 };
    
    this.analyticsData.forEach(data => {
      if (data.platformOptimization.youtube) distribution.youtube++;
      if (data.platformOptimization.mobile) distribution.mobile++;
      if (data.platformOptimization.broadcast) distribution.broadcast++;
    });
    
    return distribution;
  }

  private calculatePresetUsage(): any {
    const usage = { standard: 0, professional: 0, premium: 0, cinematic: 0 };
    
    // This would be enhanced with actual preset tracking
    // For now, simulate based on quality scores
    this.analyticsData.forEach(data => {
      if (data.qualityScore >= 98) usage.cinematic++;
      else if (data.qualityScore >= 95) usage.premium++;
      else if (data.qualityScore >= 90) usage.professional++;
      else usage.standard++;
    });
    
    return usage;
  }

  private calculateQualityTrend(): number[] {
    return this.analyticsData.slice(-7).map(data => data.qualityScore);
  }

  private calculateRenderTimeTrend(): number[] {
    return this.analyticsData.slice(-7).map(data => Math.round(data.renderTime / 1000));
  }

  private calculateFileSizeTrend(): number[] {
    return this.analyticsData.slice(-7).map(data => {
      const sizeStr = data.fileSize.replace('MB', '');
      return Math.round(parseFloat(sizeStr));
    });
  }

  async optimizeQualitySettings(): Promise<{
    recommendations: string[];
    optimizations: any;
  }> {
    const analytics = await this.getQualityAnalytics();
    const recommendations: string[] = [];
    const optimizations: any = {};
    
    // Analyze quality trends and provide recommendations
    if (analytics.summary.averageQualityScore < 90) {
      recommendations.push('Consider upgrading to Professional or Premium quality presets');
      optimizations.qualityUpgrade = true;
    }
    
    if (analytics.summary.averageRenderTime > 300000) { // 5 minutes
      recommendations.push('Optimize rendering settings to reduce processing time');
      optimizations.renderOptimization = true;
    }
    
    // Check file size efficiency
    const avgFileSize = parseFloat(analytics.summary.totalFileSize.replace(/[^\d.]/g, ''));
    if (avgFileSize > 500) { // 500MB average
      recommendations.push('Implement better compression algorithms for file size optimization');
      optimizations.compressionImprovement = true;
    }
    
    // Platform optimization recommendations
    const platformDist = analytics.summary.platformDistribution;
    if (platformDist.youtube > platformDist.mobile * 2) {
      recommendations.push('Consider mobile-first optimization for better accessibility');
      optimizations.mobilePriority = true;
    }
    
    return { recommendations, optimizations };
  }
}

export const advancedQualityEngine = new AdvancedQualityEngine();