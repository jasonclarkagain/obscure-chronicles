import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { createRoutes } from "./routes-minimal";
import { storage } from "./storage";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startProductionServer() {
  const app = express();
  const PORT = process.env.PORT || 5000;

  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", "data:", "https:"],
      },
    },
  }));

  app.use(cors());
  app.use(morgan("combined"));
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // API Routes
  app.use(createRoutes(storage));

  // Health check endpoints
  app.get("/health", (req, res) => {
    res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      version: "1.0.0"
    });
  });

  // Root health check for deployment platforms
  app.get("/", (req, res, next) => {
    const userAgent = req.headers['user-agent'] || '';
    const accept = req.headers.accept || '';
    
    // Cloud Run health checks typically don't send browser-like headers
    const isBrowser = accept.includes('text/html') || userAgent.includes('Mozilla');
    
    if (!isBrowser) {
      // Return JSON for health check probes
      return res.json({
        status: "healthy",
        message: "Multi-Channel Video Generation System",
        version: "1.0.0"
      });
    }
    
    // Browsers continue to static file serving
    next();
  });

  // Serve static frontend files from dist/client
  const clientPath = path.resolve(__dirname, "../dist/client");
  app.use(express.static(clientPath));

  // SPA fallback - serve index.html for all other routes
  app.get("*", (req, res) => {
    res.sendFile(path.join(clientPath, "index.html"));
  });

  // Error handling middleware
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error("Unhandled error:", err);
    res.status(500).json({
      error: "Internal server error",
      message: process.env.NODE_ENV === "production" ? "Something went wrong" : err.message
    });
  });

  // Start server
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 Multi-Channel Video Generation System [PRODUCTION]`);
    console.log(`📊 Server running on http://0.0.0.0:${PORT}`);
    console.log(`✅ API endpoints: /api/*`);
    console.log(`🌐 Web GUI: /`);
    console.log(`💚 Health check: /health`);
  });

  server.on("error", (error: any) => {
    console.error("Server error:", error);
    process.exit(1);
  });

  // Graceful shutdown
  process.on("SIGTERM", () => {
    console.log("SIGTERM received, shutting down gracefully...");
    server.close(() => {
      console.log("Server closed");
      process.exit(0);
    });
  });

  process.on("SIGINT", () => {
    console.log("SIGINT received, shutting down gracefully...");
    server.close(() => {
      console.log("Server closed");
      process.exit(0);
    });
  });
}

// Handle unhandled rejections
process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason);
});

process.on("uncaughtException", (error) => {
  console.error("Uncaught Exception:", error);
  process.exit(1);
});

startProductionServer().catch((err) => {
  console.error("Failed to start server:", err);
  console.error(err.stack);
  process.exit(1);
});
