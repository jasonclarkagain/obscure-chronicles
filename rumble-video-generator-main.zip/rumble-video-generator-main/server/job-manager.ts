import { storage } from "./storage";
import { ContentGenerator } from "./content-generator";
import { VideoRenderer } from "./video-renderer";
import type { Episode, YouTubeChannel } from "@shared/schema";
import { mkdir } from "fs/promises";
import { join } from "path";

export class JobManager {
  private contentGen = new ContentGenerator();
  private renderer = new VideoRenderer();
  private outputDir = "server/output";
  private maxRetries = 3;

  async initialize() {
    await this.contentGen.initialize();
    await this.renderer.initialize();
    await mkdir(this.outputDir, { recursive: true });
    await mkdir(join(this.outputDir, "videos"), { recursive: true });
  }

  async processEpisode(episodeId: string): Promise<void> {
    const episode = await storage.getEpisode(episodeId);
    if (!episode) {
      throw new Error(`Episode ${episodeId} not found`);
    }

    const channel = await storage.getYouTubeChannel(episode.channelId);
    if (!channel) {
      throw new Error(`Channel ${episode.channelId} not found`);
    }

    console.log(`\n${'='.repeat(60)}`);
    console.log(`📺 Processing Episode #${episode.episodeNumber}`);
    console.log(`📋 Channel: ${channel.name}`);
    console.log(`📝 Topic: ${episode.topic}`);
    console.log(`📊 Current Phase: ${episode.phase}`);
    console.log(`${'='.repeat(60)}`);

    try {
      await this.runPhase(episode, channel);
    } catch (error: any) {
      console.error(`\n❌ Error in episode ${episodeId}:`, error.message);
      
      const retryCount = (episode.retryCount || 0) + 1;
      
      if (retryCount >= this.maxRetries) {
        await storage.updateEpisode(episodeId, {
          status: "failed",
          errorMessage: error.message,
          retryCount,
        });
        console.log(`🛑 Max retries reached. Episode marked as failed.`);
      } else {
        await storage.updateEpisode(episodeId, {
          errorMessage: error.message,
          retryCount,
        });
        console.log(`🔄 Retry ${retryCount}/${this.maxRetries} will be attempted.`);
      }
      
      throw error;
    }
  }

  private async runPhase(episode: Episode, channel: YouTubeChannel): Promise<void> {
    switch (episode.phase) {
      case "init":
        await this.initPhase(episode, channel);
        break;
      case "script":
        await this.scriptPhase(episode, channel);
        break;
      case "thumbnail":
        await this.thumbnailPhase(episode, channel);
        break;
      case "video":
        await this.videoPhase(episode, channel);
        break;
      case "done":
        console.log("✅ Episode already complete!");
        return;
    }

    if (episode.phase !== "done") {
      console.log(`\n🔄 Continuing to next phase...`);
      const updatedEpisode = await storage.getEpisode(episode.id);
      if (updatedEpisode) {
        await this.runPhase(updatedEpisode, channel);
      }
    }
  }

  private async initPhase(episode: Episode, channel: YouTubeChannel): Promise<void> {
    console.log("\n🚀 Phase: Initialization");
    
    await storage.updateEpisode(episode.id, {
      status: "content_ready",
      phase: "script",
    });
    
    console.log("✅ Init complete, moving to script phase");
  }

  private async scriptPhase(episode: Episode, channel: YouTubeChannel): Promise<void> {
    console.log("\n📝 Phase: Script Generation");

    const unusedScripts = await storage.getUnusedContentByChannel(channel.id, "script");
    
    let scriptCacheId: string;
    
    if (unusedScripts.length > 0) {
      const cached = unusedScripts[0];
      scriptCacheId = cached.id;
      
      await storage.updateCachedContent(cached.id, { isUsed: true });
      
      console.log(`✅ Using cached script: "${cached.data.script?.title}"`);
    } else {
      console.log("⚠️  No cached scripts available, generating new one...");
      
      const scripts = await this.contentGen.generateScriptsForChannel(channel, 1);
      if (scripts.length === 0) {
        throw new Error("Failed to generate script");
      }
      
      scriptCacheId = scripts[0];
      await storage.updateCachedContent(scriptCacheId, { isUsed: true });
    }

    await storage.updateEpisode(episode.id, {
      scriptCacheId,
      phase: "thumbnail",
    });
    
    console.log("✅ Script phase complete, moving to thumbnail phase");
  }

  private async thumbnailPhase(episode: Episode, channel: YouTubeChannel): Promise<void> {
    console.log("\n🎨 Phase: Thumbnail Generation");

    const unusedThumbnails = await storage.getUnusedContentByChannel(channel.id, "thumbnail");
    
    let thumbnailCacheId: string;
    
    if (unusedThumbnails.length > 0) {
      const cached = unusedThumbnails[0];
      thumbnailCacheId = cached.id;
      
      await storage.updateCachedContent(cached.id, { isUsed: true });
      
      console.log(`✅ Using cached thumbnail: ${cached.data.thumbnailPath}`);
    } else {
      console.log("⚠️  No cached thumbnails available, generating new one...");
      
      const thumbnails = await this.contentGen.generateThumbnailsForChannel(channel, 1);
      if (thumbnails.length === 0) {
        throw new Error("Failed to generate thumbnail");
      }
      
      thumbnailCacheId = thumbnails[0];
      await storage.updateCachedContent(thumbnailCacheId, { isUsed: true });
    }

    await storage.updateEpisode(episode.id, {
      thumbnailCacheId,
      phase: "video",
      status: "rendering",
    });
    
    console.log("✅ Thumbnail phase complete, moving to video phase");
  }

  private async videoPhase(episode: Episode, channel: YouTubeChannel): Promise<void> {
    console.log("\n🎬 Phase: Video Rendering");

    if (!episode.scriptCacheId) {
      throw new Error("No script found for episode");
    }

    const scriptCache = await storage.getCachedContent(episode.scriptCacheId);
    if (!scriptCache || !scriptCache.data.script) {
      throw new Error("Script cache not found");
    }

    const script = scriptCache.data.script;
    const videoPath = join(
      this.outputDir,
      "videos",
      `${channel.handle}_ep${episode.episodeNumber}_${Date.now()}.mp4`
    );

    await this.renderer.renderVideo({
      outputPath: videoPath,
      title: script.title,
      scenes: script.scenes,
      primaryColor: channel.branding.colorScheme.primary,
      secondaryColor: channel.branding.colorScheme.secondary,
      accentColor: channel.branding.colorScheme.accent,
    });

    await this.renderer.cleanup();

    await storage.updateEpisode(episode.id, {
      videoPath,
      phase: "done",
      status: "completed",
      completedAt: new Date(),
    });
    
    console.log(`\n✅ Video rendering complete!`);
    console.log(`📁 Video saved: ${videoPath}`);
    console.log(`\n🎉 Episode #${episode.episodeNumber} finished!`);
  }

  async batchProcessChannel(channelId: string, episodeCount: number = 5): Promise<void> {
    console.log(`\n🎯 Starting batch processing for channel ${channelId}`);
    console.log(`📊 Episodes to process: ${episodeCount}`);

    const channel = await storage.getYouTubeChannel(channelId);
    if (!channel) {
      throw new Error(`Channel ${channelId} not found`);
    }

    const episodes = await storage.getEpisodesByChannel(channelId);
    let processed = 0;

    for (const episode of episodes) {
      if (episode.status !== "completed" && processed < episodeCount) {
        try {
          await this.processEpisode(episode.id);
          processed++;
        } catch (error) {
          console.error(`Failed to process episode ${episode.id}`);
        }
      }
    }

    console.log(`\n✅ Batch processing complete: ${processed} episodes processed`);
  }

  async getStatus(): Promise<{
    totalEpisodes: number;
    byStatus: Record<string, number>;
    byPhase: Record<string, number>;
  }> {
    const episodes = await storage.getEpisodes();
    
    const byStatus: Record<string, number> = {};
    const byPhase: Record<string, number> = {};
    
    for (const episode of episodes) {
      byStatus[episode.status] = (byStatus[episode.status] || 0) + 1;
      byPhase[episode.phase] = (byPhase[episode.phase] || 0) + 1;
    }
    
    return {
      totalEpisodes: episodes.length,
      byStatus,
      byPhase,
    };
  }
}
