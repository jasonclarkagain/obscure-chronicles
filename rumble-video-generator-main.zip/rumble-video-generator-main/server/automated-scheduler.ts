import cron from 'node-cron';
import postgres from 'postgres';
import { nanoid } from 'nanoid';
import dotenv from 'dotenv';

dotenv.config();

const client = postgres(process.env.DATABASE_URL!);

interface VideoTemplate {
  title: string;
  description: string;
  educationalObjectives: string[];
  scenes: Array<{
    duration: number;
    dialog: Array<{
      character: string;
      text: string;
      timing: { start: number; end: number };
    }>;
    visualDescription: string;
    ambientSounds: string[];
    soundEffects: string[];
  }>;
}

class AutomatedVideoScheduler {
  private activeSchedule: cron.ScheduledTask | null = null;
  private dayCounter = 1;

  constructor() {
    this.initializeScheduler();
  }

  private initializeScheduler() {
    console.log('🎬 Starting 30-day automated video generation schedule...');
    
    // Schedule daily video generation at 9:00 AM UTC
    this.activeSchedule = cron.schedule('0 9 * * *', async () => {
      await this.generateDailyVideo();
    }, {
      scheduled: true,
      timezone: 'UTC'
    });

    // Generate first video immediately for testing
    this.generateDailyVideo();
  }

  private async generateDailyVideo(): Promise<void> {
    try {
      console.log(`📅 Day ${this.dayCounter}: Generating daily educational video...`);

      // Get active themes and characters from database
      const [themes, characters] = await Promise.all([
        client`SELECT * FROM video_themes WHERE is_active = true ORDER BY RANDOM() LIMIT 1`,
        client`SELECT * FROM characters WHERE is_active = true ORDER BY RANDOM() LIMIT 3`
      ]);

      if (themes.length === 0 || characters.length === 0) {
        throw new Error('No active themes or characters available');
      }

      const theme = themes[0];
      const selectedCharacters = characters;

      // Generate video content based on day and theme
      const videoTemplate = this.generateVideoContent(this.dayCounter, theme, selectedCharacters);
      
      const videoId = nanoid();
      const video = {
        id: videoId,
        title: videoTemplate.title,
        description: videoTemplate.description,
        theme_id: theme.id,
        status: 'completed',
        script: {
          scenes: videoTemplate.scenes
        },
        metadata: {
          duration: videoTemplate.scenes.reduce((total, scene) => total + scene.duration, 0),
          resolution: { width: 1920, height: 1080 },
          fps: 30,
          educational_objectives: videoTemplate.educationalObjectives,
          content_rating: 'G - Family Friendly',
          generation_day: this.dayCounter,
          automated_generation: true,
          scheduled_for: new Date().toISOString()
        },
        created_at: new Date(),
        completed_at: new Date()
      };

      // Save to database
      await client`
        INSERT INTO videos (id, title, description, theme_id, status, script, metadata, created_at, completed_at)
        VALUES (
          ${video.id},
          ${video.title},
          ${video.description},
          ${video.theme_id},
          ${video.status},
          ${JSON.stringify(video.script)},
          ${JSON.stringify(video.metadata)},
          ${video.created_at},
          ${video.completed_at}
        )
      `;

      console.log(`✅ Day ${this.dayCounter} video generated: "${video.title}" (ID: ${videoId})`);
      
      // Add to generation queue for processing
      await this.addToGenerationQueue(videoId, theme.id);
      
      this.dayCounter++;

      // Stop after 30 days
      if (this.dayCounter > 30) {
        console.log('🎯 30-day automation cycle completed!');
        this.stopScheduler();
      }

    } catch (error) {
      console.error(`❌ Day ${this.dayCounter} video generation failed:`, error);
    }
  }

  private generateVideoContent(day: number, theme: any, characters: any[]): VideoTemplate {
    const topics = [
      'Ocean Conservation', 'Space Exploration', 'Renewable Energy', 'Animal Habitats',
      'Weather Patterns', 'Plant Growth', 'Recycling Adventures', 'Healthy Eating',
      'Solar System', 'Water Cycle', 'Friendship Values', 'Cultural Diversity',
      'Math in Nature', 'Science Experiments', 'History Heroes', 'Art & Creativity',
      'Music & Rhythm', 'Community Helpers', 'Transportation', 'Geography Fun',
      'Language Learning', 'Safety First', 'Time & Seasons', 'Inventions',
      'Dinosaur Discovery', 'Underwater World', 'Forest Ecosystem', 'Desert Life',
      'Arctic Animals', 'Volcano Science'
    ];

    const topic = topics[(day - 1) % topics.length];
    const mainCharacter = characters[0]?.name || 'Captain Marina';
    const supportCharacter1 = characters[1]?.name || 'Curious Casey';
    const supportCharacter2 = characters[2]?.name || 'Luna the Storyteller';

    return {
      title: `${topic} Adventure - Day ${day}`,
      description: `Join ${mainCharacter} and friends as they explore ${topic.toLowerCase()} in this educational adventure filled with fun facts and important lessons.`,
      educationalObjectives: [
        `Understanding ${topic.toLowerCase()} concepts`,
        'Critical thinking and problem solving',
        'Environmental awareness and responsibility',
        'Teamwork and friendship values'
      ],
      scenes: [
        {
          duration: 25,
          dialog: [
            {
              character: mainCharacter,
              text: `Welcome back, young explorers! Today we're diving into the amazing world of ${topic.toLowerCase()}!`,
              timing: { start: 0, end: 5 }
            },
            {
              character: supportCharacter1,
              text: `I'm so excited! What will we learn about ${topic.toLowerCase()} today?`,
              timing: { start: 6, end: 10 }
            },
            {
              character: mainCharacter,
              text: `Great question! Let's start our adventure and discover some incredible facts together!`,
              timing: { start: 11, end: 17 }
            }
          ],
          visualDescription: `Colorful animated scene introducing ${topic.toLowerCase()} with engaging educational elements and friendly characters`,
          ambientSounds: ['upbeat learning music', 'nature sounds'],
          soundEffects: ['positive chimes', 'adventure music']
        },
        {
          duration: 35,
          dialog: [
            {
              character: supportCharacter2,
              text: `Did you know that ${topic.toLowerCase()} plays a crucial role in our world? Let me share some fascinating facts!`,
              timing: { start: 0, end: 7 }
            },
            {
              character: supportCharacter1,
              text: `Wow! That's amazing! How can we help protect and learn more about this?`,
              timing: { start: 8, end: 13 }
            },
            {
              character: mainCharacter,
              text: `Excellent thinking! We can make a difference through learning, caring, and taking positive action every day.`,
              timing: { start: 14, end: 22 }
            }
          ],
          visualDescription: `Educational montage showing real-world examples of ${topic.toLowerCase()} with animated characters explaining key concepts`,
          ambientSounds: ['inspiring background music', 'educational sounds'],
          soundEffects: ['discovery chimes', 'learning sounds']
        },
        {
          duration: 30,
          dialog: [
            {
              character: supportCharacter2,
              text: `Remember, every small action counts! Together we can make our world better.`,
              timing: { start: 0, end: 6 }
            },
            {
              character: supportCharacter1,
              text: `I can't wait to share what I learned with my family and friends!`,
              timing: { start: 7, end: 12 }
            },
            {
              character: mainCharacter,
              text: `That's the spirit! Join us tomorrow for another exciting educational adventure. Keep exploring and learning!`,
              timing: { start: 13, end: 20 }
            }
          ],
          visualDescription: `Uplifting conclusion scene with characters celebrating learning and encouraging continued education`,
          ambientSounds: ['celebratory music', 'positive atmosphere'],
          soundEffects: ['success sounds', 'cheerful chimes']
        }
      ]
    };
  }

  private async addToGenerationQueue(videoId: string, themeId: string): Promise<void> {
    const queueItem = {
      id: nanoid(),
      theme_id: themeId,
      scheduled_for: new Date(),
      status: 'pending',
      retry_count: 0,
      error_message: null,
      created_at: new Date()
    };

    await client`
      INSERT INTO generation_queue (id, theme_id, scheduled_for, status, retry_count, error_message, created_at)
      VALUES (${queueItem.id}, ${queueItem.theme_id}, ${queueItem.scheduled_for}, ${queueItem.status}, ${queueItem.retry_count}, ${queueItem.error_message}, ${queueItem.created_at})
    `;

    console.log(`📋 Added video ${videoId} to generation queue`);
  }

  public getScheduleStatus(): any {
    return {
      active: this.activeSchedule !== null,
      current_day: this.dayCounter,
      remaining_days: Math.max(0, 30 - this.dayCounter + 1),
      next_generation: this.activeSchedule ? 'Daily at 9:00 AM UTC' : 'Inactive',
      total_planned: 30
    };
  }

  public stopScheduler(): void {
    if (this.activeSchedule) {
      this.activeSchedule.stop();
      this.activeSchedule = null;
      console.log('🛑 Automated video scheduler stopped');
    }
  }

  public async getGeneratedVideosCount(): Promise<number> {
    const result = await client`
      SELECT COUNT(*) as count 
      FROM videos 
      WHERE metadata->>'automated_generation' = 'true'
    `;
    return parseInt(result[0].count);
  }
}

// Start the automated scheduler
const scheduler = new AutomatedVideoScheduler();

// Export for external access
export { AutomatedVideoScheduler, scheduler };

// Keep the process running
process.on('SIGTERM', () => {
  scheduler.stopScheduler();
  client.end();
  process.exit(0);
});

process.on('SIGINT', () => {
  scheduler.stopScheduler();
  client.end();
  process.exit(0);
});