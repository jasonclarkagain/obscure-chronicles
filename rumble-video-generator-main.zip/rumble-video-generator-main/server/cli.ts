import { storage } from "./storage";
import { ContentGenerator } from "./content-generator";
import { JobManager } from "./job-manager";
import { nanoid } from "nanoid";

const command = process.argv[2];
const arg1 = process.argv[3];
const arg2 = process.argv[4];

async function main() {
  switch (command) {
    case "init":
      await initializeSystem();
      break;
    case "cache":
      await cacheContent(arg1, parseInt(arg2) || 5);
      break;
    case "create-episodes":
      await createEpisodes(arg1, parseInt(arg2) || 5);
      break;
    case "render":
      await renderEpisode(arg1);
      break;
    case "batch":
      await batchRender(arg1, parseInt(arg2) || 5);
      break;
    case "status":
      await showStatus();
      break;
    case "channels":
      await listChannels();
      break;
    default:
      showHelp();
  }
}

async function resolveChannelId(channelIdOrHandle: string): Promise<string | null> {
  // Try direct ID lookup first
  const channel = await storage.getYouTubeChannel(channelIdOrHandle);
  if (channel) {
    return channel.id;
  }

  // If not found, try to find by handle
  const allChannels = await storage.getYouTubeChannels();
  const matchedChannel = allChannels.find(
    (c) => c.handle === channelIdOrHandle || `@${c.handle}` === channelIdOrHandle
  );

  return matchedChannel ? matchedChannel.id : null;
}

async function showHelp() {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║           Multi-Channel Video Generation System              ║
╚══════════════════════════════════════════════════════════════╝

📋 Commands:

  init
    Initialize the system with sample channels
    
  cache <channel-id-or-handle> [count]
    Pre-generate scripts and thumbnails for a channel
    Example: npm run cli cache learningadventures 10
    
  create-episodes <channel-id-or-handle> [count]
    Create episode entries for a channel
    Example: npm run cli create-episodes storytimemagic 30
    
  render <episode-id>
    Render a single episode (resumable)
    Example: npm run cli render ep_123
    
  batch <channel-id-or-handle> [count]
    Batch process multiple episodes for a channel
    Example: npm run cli batch mathadventures 5
    
  status
    Show system status and episode statistics
    
  channels
    List all channels

╔══════════════════════════════════════════════════════════════╗
║ Workflow Example:                                            ║
╚══════════════════════════════════════════════════════════════╝

1. npm run cli init                           # Setup channels
2. npm run cli cache learningadventures 10    # Pre-generate content
3. npm run cli create-episodes learningadventures 5  # Create episodes
4. npm run cli batch learningadventures 5     # Render all episodes
5. npm run cli status                         # Check progress

Videos will be saved to: server/output/videos/
Thumbnails will be saved to: server/content_output/thumbnails/

💡 TIP: You can use either channel ID or handle (e.g., 'learningadventures')
`);
}

async function initializeSystem() {
  console.log("\n🚀 Initializing Multi-Channel System...\n");

  const channels = [
    {
      id: nanoid(),
      name: "Amazing Learning Adventures",
      handle: "learningadventures",
      description: "Educational content for curious kids",
      category: "education" as const,
      targetAudience: "kids" as const,
      contentStrategy: {
        uploadSchedule: "daily" as const,
        contentTypes: ["educational", "science", "nature"],
        themes: ["science experiments", "animal facts", "space exploration"],
        tone: "educational" as const,
        averageDuration: 90,
        monetizationFocus: "ads" as const,
      },
      branding: {
        colorScheme: {
          primary: "#FF6B6B",
          secondary: "#4ECDC4",
          accent: "#FFE66D",
        },
        thumbnailStyle: "bright and colorful",
        fontFamily: "Arial",
      },
      isActive: true,
    },
    {
      id: nanoid(),
      name: "Story Time Magic",
      handle: "storytimemagic",
      description: "Magical stories and fairy tales",
      category: "entertainment" as const,
      targetAudience: "kids" as const,
      contentStrategy: {
        uploadSchedule: "daily" as const,
        contentTypes: ["storytelling", "fairy tales", "moral lessons"],
        themes: ["classic tales", "adventure stories", "bedtime stories"],
        tone: "entertaining" as const,
        averageDuration: 90,
        monetizationFocus: "ads" as const,
      },
      branding: {
        colorScheme: {
          primary: "#9B59B6",
          secondary: "#E74C3C",
          accent: "#F39C12",
        },
        thumbnailStyle: "magical and whimsical",
        fontFamily: "Arial",
      },
      isActive: true,
    },
    {
      id: nanoid(),
      name: "Math Adventures",
      handle: "mathadventures",
      description: "Making math fun and easy",
      category: "education" as const,
      targetAudience: "kids" as const,
      contentStrategy: {
        uploadSchedule: "daily" as const,
        contentTypes: ["math lessons", "problem solving", "number games"],
        themes: ["counting", "addition", "geometry", "patterns"],
        tone: "educational" as const,
        averageDuration: 90,
        monetizationFocus: "ads" as const,
      },
      branding: {
        colorScheme: {
          primary: "#3498DB",
          secondary: "#2ECC71",
          accent: "#E67E22",
        },
        thumbnailStyle: "clean and modern",
        fontFamily: "Arial",
      },
      isActive: true,
    },
  ];

  for (const channelData of channels) {
    try {
      const channel = await storage.createYouTubeChannel(channelData);
      console.log(`✅ Created channel: ${channel.name} (${channel.id})`);
    } catch (error: any) {
      console.error(`❌ Failed to create channel: ${error.message}`);
    }
  }

  console.log("\n✅ System initialized successfully!\n");
  console.log("Next steps:");
  console.log("1. Run 'npm run cli channels' to see channel IDs");
  console.log("2. Run 'npm run cli cache <channel-id> 10' to pre-generate content");
  console.log("3. Run 'npm run cli create-episodes <channel-id> 5' to create episodes");
  console.log("4. Run 'npm run cli batch <channel-id> 5' to render videos\n");
}

async function cacheContent(channelIdOrHandle: string, count: number) {
  if (!channelIdOrHandle) {
    console.error("❌ Channel ID or handle required");
    console.log("Usage: npm run cli cache <channel-id-or-handle> [count]");
    return;
  }

  const channelId = await resolveChannelId(channelIdOrHandle);
  if (!channelId) {
    console.error(`❌ Channel '${channelIdOrHandle}' not found`);
    console.log("💡 Run 'npm run cli channels' to see available channels");
    return;
  }

  const channel = await storage.getYouTubeChannel(channelId);
  if (!channel) {
    console.error(`❌ Channel ${channelId} not found`);
    return;
  }

  console.log(`\n🎯 Caching content for: ${channel.name}\n`);

  const generator = new ContentGenerator();
  await generator.initialize();

  console.log(`📝 Generating ${count} scripts...`);
  await generator.generateScriptsForChannel(channel, count);

  console.log(`\n🎨 Generating ${count} thumbnails...`);
  await generator.generateThumbnailsForChannel(channel, count);

  console.log(`\n✅ Content cached successfully!`);
  console.log(`📊 ${count} scripts and ${count} thumbnails ready to use\n`);
}

async function createEpisodes(channelIdOrHandle: string, count: number) {
  if (!channelIdOrHandle) {
    console.error("❌ Channel ID or handle required");
    console.log("Usage: npm run cli create-episodes <channel-id-or-handle> [count]");
    return;
  }

  const channelId = await resolveChannelId(channelIdOrHandle);
  if (!channelId) {
    console.error(`❌ Channel '${channelIdOrHandle}' not found`);
    console.log("💡 Run 'npm run cli channels' to see available channels");
    return;
  }

  const channel = await storage.getYouTubeChannel(channelId);
  if (!channel) {
    console.error(`❌ Channel ${channelId} not found`);
    return;
  }

  const existingEpisodes = await storage.getEpisodesByChannel(channelId);
  const startNumber = existingEpisodes.length + 1;

  console.log(`\n📺 Creating ${count} episodes for: ${channel.name}`);
  console.log(`📊 Starting from episode #${startNumber}\n`);

  const topics = channel.contentStrategy.themes;

  for (let i = 0; i < count; i++) {
    const episodeNumber = startNumber + i;
    const topic = topics[i % topics.length];

    const episode = await storage.createEpisode({
      channelId,
      episodeNumber,
      title: `Episode ${episodeNumber}: ${topic}`,
      topic,
      status: "pending",
      phase: "init",
      scriptCacheId: null,
      thumbnailCacheId: null,
      videoPath: null,
      errorMessage: null,
      retryCount: 0,
    });

    console.log(`✅ Created episode #${episodeNumber}: ${topic}`);
  }

  console.log(`\n✅ ${count} episodes created successfully!\n`);
}

async function renderEpisode(episodeId: string) {
  if (!episodeId) {
    console.error("❌ Episode ID required");
    console.log("Usage: npm run cli render <episode-id>");
    return;
  }

  const manager = new JobManager();
  await manager.initialize();

  await manager.processEpisode(episodeId);
}

async function batchRender(channelIdOrHandle: string, count: number) {
  if (!channelIdOrHandle) {
    console.error("❌ Channel ID or handle required");
    console.log("Usage: npm run cli batch <channel-id-or-handle> [count]");
    return;
  }

  const channelId = await resolveChannelId(channelIdOrHandle);
  if (!channelId) {
    console.error(`❌ Channel '${channelIdOrHandle}' not found`);
    console.log("💡 Run 'npm run cli channels' to see available channels");
    return;
  }

  const manager = new JobManager();
  await manager.initialize();

  await manager.batchProcessChannel(channelId, count);
}

async function showStatus() {
  const manager = new JobManager();
  const status = await manager.getStatus();

  console.log("\n╔══════════════════════════════════════════════════════════════╗");
  console.log("║                    System Status                             ║");
  console.log("╚══════════════════════════════════════════════════════════════╝\n");

  console.log(`📊 Total Episodes: ${status.totalEpisodes}`);
  
  console.log("\n📈 By Status:");
  for (const [statusName, count] of Object.entries(status.byStatus)) {
    const emoji = statusName === "completed" ? "✅" : statusName === "failed" ? "❌" : statusName === "rendering" ? "🎬" : "⏳";
    console.log(`   ${emoji} ${statusName}: ${count}`);
  }
  
  console.log("\n🔄 By Phase:");
  for (const [phase, count] of Object.entries(status.byPhase)) {
    console.log(`   📍 ${phase}: ${count}`);
  }

  const channels = await storage.getYouTubeChannels();
  console.log(`\n📺 Active Channels: ${channels.filter(c => c.isActive).length}`);
  
  const cache = await storage.getContentCache();
  const unusedCache = cache.filter(c => !c.isUsed);
  console.log(`\n💾 Content Cache:`);
  console.log(`   📝 Scripts: ${cache.filter(c => c.type === "script").length} (${unusedCache.filter(c => c.type === "script").length} unused)`);
  console.log(`   🎨 Thumbnails: ${cache.filter(c => c.type === "thumbnail").length} (${unusedCache.filter(c => c.type === "thumbnail").length} unused)`);

  console.log("\n");
}

async function listChannels() {
  const channels = await storage.getYouTubeChannels();

  console.log("\n╔══════════════════════════════════════════════════════════════╗");
  console.log("║                    YouTube Channels                          ║");
  console.log("╚══════════════════════════════════════════════════════════════╝\n");

  for (const channel of channels) {
    const episodes = await storage.getEpisodesByChannel(channel.id);
    console.log(`📺 ${channel.name}`);
    console.log(`   ID: ${channel.id}`);
    console.log(`   Handle: @${channel.handle}`);
    console.log(`   Episodes: ${episodes.length}`);
    console.log(`   Category: ${channel.category}`);
    console.log(`   Active: ${channel.isActive ? "✅ Yes" : "❌ No"}`);
    console.log("");
  }
}

main()
  .then(() => {
    console.log("Command completed successfully");
    process.exit(0);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
