#!/usr/bin/env node
/**
 * Production Entry Point for Cloud Run Deployment
 * This ensures proper port handling and disables all development features
 */

// CRITICAL: Force production mode to disable Vite HMR
process.env.NODE_ENV = "production";

import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import path from "path";
import { fileURLToPath } from "url";
import { createRoutes } from "./routes";
import { storage } from "./storage";
import { getRumbleCronService } from "./services/rumbleCron";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startProductionServer() {
  const app = express();
  
  // MUST use Cloud Run's PORT - no fallbacks, no alternatives
  const PORT = parseInt(process.env.PORT || "8080", 10);
  
  console.log(`🚀 Starting Production Server on PORT ${PORT}`);
  console.log(`🌍 NODE_ENV: ${process.env.NODE_ENV}`);

  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'"],
      },
    },
  }));

  app.use(cors());
  app.use(morgan("combined"));
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // API Routes
  app.use(createRoutes(storage));

  // Health check for Cloud Run
  app.get("/health", (req, res) => {
    res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      version: "1.0.0",
      port: PORT,
      env: "production"
    });
  });

  // Root health check for Cloud Run probes
  app.get("/", (req, res, next) => {
    const userAgent = req.headers['user-agent'] || '';
    const accept = req.headers.accept || '';
    
    // Cloud Run health checks don't send browser headers
    const isBrowser = accept.includes('text/html') || userAgent.includes('Mozilla');
    
    if (!isBrowser) {
      return res.json({
        status: "healthy",
        service: "rumble-video-generator",
        port: PORT
      });
    }
    
    // For browsers, serve the built frontend
    next();
  });

  // Serve static files from built client
  const clientPath = path.resolve(__dirname, "../client/dist");
  app.use(express.static(clientPath));

  // SPA fallback - serve index.html for client routes
  app.get("*", (req, res) => {
    res.sendFile(path.join(clientPath, "index.html"));
  });

  // Error handling
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error("Server error:", err);
    res.status(500).json({
      error: "Internal server error"
    });
  });

  // Initialize Rumble cron service
  const rumbleCron = getRumbleCronService(storage);
  rumbleCron.start();

  // Start server - MUST bind to PORT exactly
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log("=" .repeat(70));
    console.log(`✅ PRODUCTION SERVER RUNNING`);
    console.log(`📊 Port: ${PORT}`);
    console.log(`🌐 Service: Rumble Video Generator`);
    console.log(`💚 Health: http://0.0.0.0:${PORT}/health`);
    console.log(`🎬 Cron: Daily at 02:00 UTC`);
    console.log("=" .repeat(70));
  });

  server.on("error", (error: any) => {
    if (error.code === "EADDRINUSE") {
      console.error(`❌ PORT ${PORT} IS ALREADY IN USE!`);
      console.error(`
      This means another process is using port ${PORT}.
      In Cloud Run, this usually indicates:
      - Vite HMR is still running (ensure NODE_ENV=production)
      - Multiple server processes are starting
      - The .replit port configuration is conflicting
      `);
    } else {
      console.error(`❌ Server error:`, error);
    }
    process.exit(1);
  });

  // Graceful shutdown
  process.on("SIGTERM", () => {
    console.log("SIGTERM received, shutting down...");
    rumbleCron.stop();
    server.close(() => {
      console.log("Server closed");
      process.exit(0);
    });
  });
}

// Start server immediately
startProductionServer().catch((err) => {
  console.error("Failed to start production server:", err);
  process.exit(1);
});