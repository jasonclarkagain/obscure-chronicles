import * as cron from 'node-cron';
import postgres from 'postgres';
import OpenAI from 'openai';
import { nanoid } from 'nanoid';

const client = postgres(process.env.DATABASE_URL!);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface AdvancedScheduleConfig {
  weeklyThemes: boolean;
  seasonalContent: boolean;
  holidaySpecials: boolean;
  qualityChecks: boolean;
  analyticsTracking: boolean;
}

class AdvancedVideoScheduler {
  private config: AdvancedScheduleConfig;
  private scheduledTasks: Map<string, cron.ScheduledTask> = new Map();
  private isActive = false;

  constructor() {
    this.config = {
      weeklyThemes: true,
      seasonalContent: true,
      holidaySpecials: true,
      qualityChecks: true,
      analyticsTracking: true
    };

    this.initializeAdvancedScheduling();
  }

  private initializeAdvancedScheduling() {
    // Daily video generation at 9:00 AM UTC
    this.scheduleTask('daily-generation', '0 9 * * *', async () => {
      await this.generateDailyContent();
    });

    // Weekly theme rotation on Sundays at 8:00 AM UTC
    this.scheduleTask('weekly-themes', '0 8 * * 0', async () => {
      await this.rotateWeeklyThemes();
    });

    // Quality assurance check at 10:00 AM UTC daily
    this.scheduleTask('quality-check', '0 10 * * *', async () => {
      await this.performQualityCheck();
    });

    // Analytics collection every 6 hours
    this.scheduleTask('analytics-collection', '0 */6 * * *', async () => {
      await this.collectAnalytics();
    });

    // System health monitoring hourly
    this.scheduleTask('health-monitoring', '0 * * * *', async () => {
      await this.monitorSystemHealth();
    });

    this.isActive = true;
    console.log('Advanced video scheduler initialized with 5 automated tasks');
  }

  private scheduleTask(name: string, schedule: string, handler: () => Promise<void>) {
    const task = cron.schedule(schedule, async () => {
      try {
        console.log(`Starting scheduled task: ${name}`);
        await handler();
        await this.logTaskExecution(name, 'success');
        console.log(`Completed scheduled task: ${name}`);
      } catch (error) {
        console.error(`Error in scheduled task ${name}:`, error);
        await this.logTaskExecution(name, 'error', error);
      }
    }, { scheduled: false });

    this.scheduledTasks.set(name, task);
    task.start();
  }

  private async generateDailyContent(): Promise<void> {
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
    
    // Get enhanced topic suggestions based on current context
    const topics = this.getEnhancedTopics(dayOfYear);
    const selectedTopic = topics[dayOfYear % topics.length];

    // Get active characters for multi-character content
    const characters = await client`
      SELECT id, name, personality, voice_style, metadata
      FROM characters 
      WHERE is_active = true
      ORDER BY RANDOM()
      LIMIT 3
    `;

    if (characters.length === 0) {
      throw new Error('No active characters available for content generation');
    }

    // Generate advanced video content
    const videoId = nanoid();
    const description = this.generateAdvancedDescription(selectedTopic);
    const script = this.generateAdvancedScript(selectedTopic, characters);
    const tags = this.generateAdvancedTags(selectedTopic);

    // Get active theme
    const themes = await client`
      SELECT id, title, category, metadata
      FROM video_themes 
      WHERE is_active = true
      ORDER BY RANDOM()
      LIMIT 1
    `;

    const themeId = themes.length > 0 ? themes[0].id : null;

    // Create video record with enhanced metadata
    await client`
      INSERT INTO videos (
        id, title, description, theme_id, script, metadata, status, created_at
      ) VALUES (
        ${videoId},
        ${selectedTopic.title},
        ${description},
        ${themeId},
        ${JSON.stringify(script)},
        ${JSON.stringify({
          topic: selectedTopic,
          characters: characters.map(c => ({ id: c.id, name: c.name })),
          tags,
          educational_objectives: selectedTopic.objectives,
          difficulty_level: selectedTopic.difficulty,
          estimated_duration: selectedTopic.duration,
          content_type: 'educational',
          ai_generated: true,
          generation_date: today.toISOString(),
          quality_target: 95,
          target_audience: 'children_3_8'
        })},
        'queued',
        NOW()
      )
    `;

    // Add to generation queue
    await client`
      INSERT INTO generation_queue (
        id, video_id, status, priority, metadata, created_at
      ) VALUES (
        ${nanoid()},
        ${videoId},
        'pending',
        ${selectedTopic.priority || 1},
        ${JSON.stringify({
          enhanced_generation: true,
          quality_checks: true,
          advanced_optimization: true,
          scheduled_generation: true
        })},
        NOW()
      )
    `;

    console.log(`Generated daily content: ${selectedTopic.title} (${videoId})`);
  }

  private getEnhancedTopics(dayOfYear: number): any[] {
    const seasonalTopics = [
      // Educational fundamentals
      {
        title: "Amazing Ocean Creatures and Their Homes",
        objectives: ["Learn about marine life", "Understand ocean habitats", "Develop curiosity about nature"],
        difficulty: "beginner",
        duration: 240,
        priority: 1,
        category: "nature"
      },
      {
        title: "How Plants Grow from Seeds to Flowers",
        objectives: ["Understand plant life cycles", "Learn about nature's processes", "Encourage gardening interest"],
        difficulty: "beginner", 
        duration: 180,
        priority: 1,
        category: "science"
      },
      {
        title: "Community Helpers Who Keep Us Safe",
        objectives: ["Recognize community roles", "Understand helping others", "Build social awareness"],
        difficulty: "beginner",
        duration: 200,
        priority: 1,
        category: "social"
      },
      {
        title: "Weather Patterns: Sun, Rain, and Snow",
        objectives: ["Learn about weather", "Understand natural cycles", "Develop observation skills"],
        difficulty: "beginner",
        duration: 220,
        priority: 1,
        category: "science"
      },
      {
        title: "Counting and Sorting with Everyday Objects",
        objectives: ["Basic math skills", "Pattern recognition", "Logical thinking"],
        difficulty: "beginner",
        duration: 160,
        priority: 1,
        category: "math"
      },
      {
        title: "Colors and Shapes in Our World",
        objectives: ["Visual recognition", "Artistic appreciation", "Categorization skills"],
        difficulty: "beginner",
        duration: 140,
        priority: 1,
        category: "art"
      },
      {
        title: "Animal Families and Their Babies",
        objectives: ["Learn animal relationships", "Understand family concepts", "Develop empathy"],
        difficulty: "beginner",
        duration: 190,
        priority: 1,
        category: "nature"
      }
    ];

    return seasonalTopics;
  }

  private generateAdvancedDescription(topic: any): string {
    return `Join ${topic.category === 'nature' ? 'Captain Marina' : 'Curious Casey'} on an exciting educational adventure! ${topic.title} - perfect for young learners ages 3-8. This engaging video helps children ${topic.objectives.join(', ').toLowerCase()}. 

🎯 Educational Goals: ${topic.objectives.join(' • ')}
⏱️ Duration: ${Math.floor(topic.duration / 60)} minutes
🌟 Difficulty: ${topic.difficulty}

Subscribe for daily educational content that makes learning fun and engaging for young minds! All content is family-friendly and designed by educational specialists.

#EducationalVideos #KidsLearning #EarlyChildhood #${topic.category.charAt(0).toUpperCase() + topic.category.slice(1)}Education`;
  }

  private generateAdvancedScript(topic: any, characters: any[]): any {
    const mainCharacter = characters[0];
    const supportCharacter = characters[1] || characters[0];

    return {
      intro: {
        duration: 30,
        character: mainCharacter.name,
        text: `Hello, young explorers! I'm ${mainCharacter.name}, and today we're going to discover something amazing about ${topic.title.toLowerCase()}!`,
        visual_cues: ["excited_wave", "colorful_background", "educational_icons"],
        audio_effects: ["cheerful_music", "success_chime"]
      },
      main_content: {
        duration: topic.duration - 60,
        sections: topic.objectives.map((objective: string, index: number) => ({
          character: index % 2 === 0 ? mainCharacter.name : supportCharacter.name,
          objective,
          text: `Let's explore how ${objective.toLowerCase()}! This is so exciting to learn together.`,
          visual_cues: [`educational_scene_${index + 1}`, "interactive_elements"],
          audio_effects: ["learning_sound", "discovery_chime"]
        }))
      },
      conclusion: {
        duration: 30,
        character: mainCharacter.name,
        text: `What an amazing journey we've had learning about ${topic.title.toLowerCase()}! Remember to keep exploring and learning every day. See you next time!`,
        visual_cues: ["celebration", "recap_highlights", "subscribe_reminder"],
        audio_effects: ["accomplishment_music", "goodbye_chime"]
      },
      metadata: {
        total_characters: characters.length,
        educational_level: topic.difficulty,
        content_type: "interactive_educational",
        ai_optimized: true
      }
    };
  }

  private generateAdvancedTags(topic: any): string[] {
    const baseTags = [
      "educational videos for kids",
      "children learning",
      "preschool education",
      "kids entertainment",
      "early childhood development"
    ];

    const categoryTags = {
      nature: ["nature for kids", "animal education", "environmental learning"],
      science: ["kids science", "STEM education", "science experiments"],
      social: ["community helpers", "social skills", "character building"],
      math: ["kids math", "counting games", "number learning"],
      art: ["kids art", "creativity", "artistic expression"]
    };

    const specificTags = categoryTags[topic.category as keyof typeof categoryTags] || [];
    
    return [...baseTags, ...specificTags, topic.difficulty + " level", topic.category + " education"];
  }

  private async rotateWeeklyThemes(): Promise<void> {
    const themes = await client`
      SELECT id, title, metadata 
      FROM video_themes 
      ORDER BY created_at ASC
    `;

    if (themes.length > 1) {
      // Rotate active theme weekly
      const currentActive = await client`
        SELECT id FROM video_themes WHERE is_active = true LIMIT 1
      `;

      if (currentActive.length > 0) {
        const currentIndex = themes.findIndex(t => t.id === currentActive[0].id);
        const nextIndex = (currentIndex + 1) % themes.length;
        const nextTheme = themes[nextIndex];

        // Deactivate current theme
        await client`
          UPDATE video_themes SET is_active = false WHERE id = ${currentActive[0].id}
        `;

        // Activate next theme
        await client`
          UPDATE video_themes SET is_active = true WHERE id = ${nextTheme.id}
        `;

        console.log(`Rotated to new weekly theme: ${nextTheme.title}`);
      }
    }
  }

  private async performQualityCheck(): Promise<void> {
    const recentVideos = await client`
      SELECT id, title, metadata, status, created_at
      FROM videos 
      WHERE created_at > NOW() - INTERVAL '24 hours'
      AND status IN ('completed', 'uploaded')
    `;

    let totalQualityScore = 0;
    let checkedVideos = 0;

    for (const video of recentVideos) {
      const qualityScore = this.calculateQualityScore(video);
      
      // Update video metadata with quality score
      const updatedMetadata = {
        ...video.metadata,
        quality_check: {
          score: qualityScore,
          checked_at: new Date().toISOString(),
          automated_check: true
        }
      };

      await client`
        UPDATE videos 
        SET metadata = ${JSON.stringify(updatedMetadata)}
        WHERE id = ${video.id}
      `;

      totalQualityScore += qualityScore;
      checkedVideos++;
    }

    const averageQuality = checkedVideos > 0 ? totalQualityScore / checkedVideos : 0;
    console.log(`Quality check completed: ${checkedVideos} videos, average score: ${averageQuality.toFixed(1)}/100`);
  }

  private calculateQualityScore(video: any): number {
    let score = 85; // Base score

    const metadata = video.metadata || {};
    
    // Check educational objectives
    if (metadata.educational_objectives && metadata.educational_objectives.length >= 3) {
      score += 5;
    }

    // Check content structure
    if (metadata.script && typeof metadata.script === 'object') {
      score += 5;
    }

    // Check character involvement
    if (metadata.characters && metadata.characters.length >= 2) {
      score += 3;
    }

    // Check duration appropriateness
    if (metadata.estimated_duration && metadata.estimated_duration >= 120 && metadata.estimated_duration <= 300) {
      score += 2;
    }

    return Math.min(100, score);
  }

  private async collectAnalytics(): Promise<void> {
    const analyticsData = {
      timestamp: new Date().toISOString(),
      videos_generated_24h: 0,
      videos_uploaded_24h: 0,
      average_quality_score: 0,
      system_performance: {
        tasks_completed: this.scheduledTasks.size,
        scheduler_uptime: this.isActive ? 100 : 0
      }
    };

    // Collect video statistics
    const videoStats = await client`
      SELECT 
        COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '24 hours') as generated_24h,
        COUNT(*) FILTER (WHERE status = 'uploaded' AND created_at > NOW() - INTERVAL '24 hours') as uploaded_24h,
        AVG((metadata->>'quality_check'->>'score')::float) as avg_quality
      FROM videos
      WHERE created_at > NOW() - INTERVAL '7 days'
    `;

    if (videoStats.length > 0) {
      analyticsData.videos_generated_24h = parseInt(videoStats[0].generated_24h) || 0;
      analyticsData.videos_uploaded_24h = parseInt(videoStats[0].uploaded_24h) || 0;
      analyticsData.average_quality_score = parseFloat(videoStats[0].avg_quality) || 0;
    }

    console.log('Analytics collected:', analyticsData);
  }

  private async monitorSystemHealth(): Promise<void> {
    try {
      // Check database connectivity
      await client`SELECT 1`;
      
      // Check active tasks
      const activeTasks = Array.from(this.scheduledTasks.values()).filter(task => task.running);
      
      // Log system health
      const healthStatus = {
        timestamp: new Date().toISOString(),
        database_connected: true,
        active_tasks: activeTasks.length,
        total_tasks: this.scheduledTasks.size,
        scheduler_status: this.isActive ? 'running' : 'stopped'
      };

      console.log('System health check:', healthStatus);
    } catch (error) {
      console.error('System health check failed:', error);
    }
  }

  private async logTaskExecution(taskName: string, status: string, error?: any): Promise<void> {
    try {
      // Log task execution for monitoring
      console.log(`Task ${taskName}: ${status}${error ? ` - ${error.message}` : ''}`);
    } catch (logError) {
      console.error('Failed to log task execution:', logError);
    }
  }

  public getSchedulerStatus(): any {
    return {
      active: this.isActive,
      tasks: Array.from(this.scheduledTasks.keys()),
      config: this.config,
      uptime: this.isActive ? 'running' : 'stopped'
    };
  }

  public stopScheduler(): void {
    this.scheduledTasks.forEach(task => task.stop());
    this.isActive = false;
    console.log('Advanced scheduler stopped');
  }
}

export const advancedScheduler = new AdvancedVideoScheduler();