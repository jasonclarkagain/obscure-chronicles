import { google } from 'googleapis';
import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';
import { createCanvas } from 'canvas';
import ffmpeg from 'fluent-ffmpeg';

// Configuration - will be updated with user's refresh token
const CLIENT_ID = "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com";
const CLIENT_SECRET = "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";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function completeFinalTest() {
  console.log('🧪 YouTube Automation Final Test');
  console.log('=================================');
  
  // Check if refresh token is provided
  const refreshToken = process.env.YOUTUBE_REFRESH_TOKEN || process.argv[2];
  
  if (!refreshToken) {
    console.log('❌ No refresh token provided');
    console.log('Please provide refresh token as environment variable or command line argument');
    console.log('Usage: npx tsx server/final-automation-test.ts <refresh_token>');
    return;
  }
  
  console.log('✅ Refresh token provided');
  console.log(`Token: ${refreshToken.substring(0, 20)}...`);
  
  try {
    // Setup OAuth client
    const oauth2Client = new google.auth.OAuth2(
      CLIENT_ID,
      CLIENT_SECRET,
      'https://developers.google.com/oauthplayground'
    );
    
    oauth2Client.setCredentials({
      refresh_token: refreshToken
    });
    
    console.log('📝 OAuth client configured');
    
    // Test token refresh
    console.log('🔄 Testing token refresh...');
    const { credentials } = await oauth2Client.refreshAccessToken();
    console.log('✅ Access token refreshed successfully');
    
    // Create YouTube client
    const youtube = google.youtube({ 
      version: 'v3', 
      auth: oauth2Client 
    });
    
    console.log('🎥 Testing YouTube connection...');
    
    // Test channel access
    const channelResponse = await youtube.channels.list({
      part: ['snippet', 'statistics'],
      mine: true
    });
    
    if (channelResponse.data.items && channelResponse.data.items.length > 0) {
      const channel = channelResponse.data.items[0];
      const snippet = channel.snippet!;
      const stats = channel.statistics!;
      
      console.log('✅ YouTube channel connected successfully!');
      console.log(`📺 Channel: ${snippet.title}`);
      console.log(`📅 Created: ${snippet.publishedAt}`);
      console.log(`👥 Subscribers: ${stats.subscriberCount || 'Hidden'}`);
      console.log(`🎬 Videos: ${stats.videoCount || '0'}`);
      
      // Test video access
      const videosResponse = await youtube.videos.list({
        part: ['snippet'],
        mine: true,
        maxResults: 5
      });
      
      console.log(`📹 Recent videos: ${videosResponse.data.items?.length || 0}`);
      
      // Generate test script
      console.log('\n🤖 Testing AI script generation...');
      const testScript = await generateTestScript();
      console.log('✅ AI script generated successfully');
      
      // Test video creation
      console.log('\n🎬 Testing video creation...');
      const testVideoPath = await createTestVideo(testScript);
      console.log(`✅ Test video created: ${testVideoPath}`);
      
      // Test thumbnail creation
      console.log('\n🖼️ Testing thumbnail creation...');
      const testThumbnailPath = await createTestThumbnail();
      console.log(`✅ Test thumbnail created: ${testThumbnailPath}`);
      
      console.log('\n🎉 All tests passed! Ready for automation!');
      console.log('Next steps:');
      console.log('1. Run: npx tsx server/working-automation.ts');
      console.log('2. System will generate Episode 1 immediately');
      console.log('3. Daily automation will begin at 9:00 AM UTC');
      
      return true;
      
    } else {
      console.log('❌ No YouTube channel found');
      return false;
    }
    
  } catch (error: any) {
    console.error('❌ Test failed:', error.message);
    console.error('Error details:', error.response?.data || error.code);
    return false;
  }
}

async function generateTestScript(): Promise<any> {
  const prompt = `Create a 5-minute educational video script about "The Water Cycle Adventure" for children ages 5-12.

  Include:
  - Educational objectives
  - 3 characters: Captain Marina, Curious Casey, Luna
  - 5 scenes with dialog and visual descriptions
  - Family-friendly G-rated content
  
  Format as JSON with: title, description, educational_objectives, scenes`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0].message.content);
}

async function createTestVideo(script: any): Promise<string> {
  const outputDir = path.join(process.cwd(), 'server', 'test_output');
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  const videoPath = path.join(outputDir, 'test_video.mp4');
  const canvas = createCanvas(1920, 1080);
  const ctx = canvas.getContext('2d');
  
  // Create a simple test frame
  ctx.fillStyle = '#87CEEB';
  ctx.fillRect(0, 0, 1920, 1080);
  
  ctx.fillStyle = '#000000';
  ctx.font = 'bold 48px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('Test Video - Water Cycle Adventure', 960, 540);
  
  ctx.font = '32px Arial';
  ctx.fillText('Episode 1/30 - Educational Series', 960, 600);
  
  const frameBuffer = canvas.toBuffer('image/png');
  const framePath = path.join(outputDir, 'test_frame.png');
  fs.writeFileSync(framePath, frameBuffer);
  
  // Create video from single frame
  return new Promise((resolve, reject) => {
    ffmpeg()
      .input(framePath)
      .inputOptions(['-loop 1', '-t 5'])
      .outputOptions([
        '-c:v libx264',
        '-pix_fmt yuv420p',
        '-crf 23'
      ])
      .output(videoPath)
      .on('end', () => {
        fs.unlinkSync(framePath);
        resolve(videoPath);
      })
      .on('error', reject)
      .run();
  });
}

async function createTestThumbnail(): Promise<string> {
  const outputDir = path.join(process.cwd(), 'server', 'test_output');
  const thumbnailPath = path.join(outputDir, 'test_thumbnail.png');
  
  const canvas = createCanvas(1280, 720);
  const ctx = canvas.getContext('2d');
  
  // Gradient background
  const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
  gradient.addColorStop(0, '#FF6B6B');
  gradient.addColorStop(1, '#4ECDC4');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 1280, 720);
  
  // Title
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 64px Arial';
  ctx.textAlign = 'center';
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 3;
  ctx.strokeText('Water Cycle Adventure', 640, 300);
  ctx.fillText('Water Cycle Adventure', 640, 300);
  
  // Episode info
  ctx.font = 'bold 48px Arial';
  ctx.fillText('Episode 1/30', 640, 400);
  
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(thumbnailPath, buffer);
  
  return thumbnailPath;
}

if (require.main === module) {
  completeFinalTest().catch(console.error);
}