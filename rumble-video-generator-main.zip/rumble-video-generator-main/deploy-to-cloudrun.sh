#!/bin/bash

# Cloud Run Deployment Script - FIXES PORT 24678 ISSUE

set -e

echo "========================================="
echo "CLOUD RUN DEPLOYMENT - PORT FIX INCLUDED"
echo "========================================="

PROJECT_ID=${1:-your-project-id}
SERVICE_NAME="rumble-video-generator"
REGION=${2:-us-central1}
IMAGE_NAME="gcr.io/$PROJECT_ID/$SERVICE_NAME"

if [ "$PROJECT_ID" = "your-project-id" ]; then
    echo "❌ ERROR: Please provide your Google Cloud Project ID"
    echo "Usage: ./deploy-to-cloudrun.sh PROJECT_ID [REGION]"
    exit 1
fi

echo "📦 Project: $PROJECT_ID"
echo "🌍 Region: $REGION"
echo "🎬 Service: $SERVICE_NAME"
echo ""

# Check gcloud CLI
if ! command -v gcloud &> /dev/null; then
    echo "❌ ERROR: gcloud CLI not installed"
    echo "Install from: https://cloud.google.com/sdk/docs/install"
    exit 1
fi

# Set project
gcloud config set project $PROJECT_ID

# Enable required APIs
echo "🔧 Enabling Cloud Run and Build APIs..."
gcloud services enable run.googleapis.com cloudbuild.googleapis.com containerregistry.googleapis.com

# Build the container using the Cloud Run specific Dockerfile
echo "🏗️ Building container (using Dockerfile.cloudrun)..."
gcloud builds submit \
  --tag $IMAGE_NAME \
  --file Dockerfile.cloudrun \
  --timeout=30m

# Deploy to Cloud Run with correct configuration
echo "🚀 Deploying to Cloud Run..."
gcloud run deploy $SERVICE_NAME \
  --image $IMAGE_NAME \
  --region $REGION \
  --platform managed \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --timeout 3600 \
  --max-instances 10 \
  --min-instances 0 \
  --port 8080 \
  --set-env-vars="NODE_ENV=production" \
  --set-env-vars="PORT=8080"

# Get service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME \
  --region=$REGION \
  --format='value(status.url)')

echo ""
echo "========================================="
echo "✅ DEPLOYMENT SUCCESSFUL!"
echo "========================================="
echo "🌐 Service URL: $SERVICE_URL"
echo "💚 Health Check: $SERVICE_URL/health"
echo "🎬 Dashboard: $SERVICE_URL"
echo "========================================="
echo ""
echo "📝 Next Steps:"
echo "1. Add secrets in Cloud Run Console:"
echo "   - OPENAI_API_KEY (for AI features)"
echo "   - Any other API keys needed"
echo ""
echo "2. Test the deployment:"
echo "   curl $SERVICE_URL/health"
echo ""
echo "3. View logs if needed:"
echo "   gcloud run logs read --service=$SERVICE_NAME --region=$REGION"
echo ""
echo "✅ This deployment uses cloud-run-entry.ts which:"
echo "   - Does NOT use Vite or HMR"
echo "   - Does NOT bind to port 24678"
echo "   - ONLY uses Cloud Run's PORT variable"
echo "   - Sets NODE_ENV=production"
echo "========================================="