#!/usr/bin/env python3

import os
import json
import urllib.parse
import urllib.request
import http.server
import socketserver
import threading
import time

# Configuration
CLIENT_ID = "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com"
CLIENT_SECRET = "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"
PORT = 3000

# Get the domain from environment
DOMAIN = os.environ.get('REPLIT_DEV_DOMAIN', 'localhost')
if DOMAIN == 'localhost':
    BASE_URL = f"http://localhost:{PORT}"
else:
    BASE_URL = f"https://{DOMAIN}"

REDIRECT_URI = f"{BASE_URL}/oauth2callback"

print(f"OAuth Server Starting...")
print(f"Domain: {DOMAIN}")
print(f"Base URL: {BASE_URL}")
print(f"Redirect URI: {REDIRECT_URI}")

class SimpleOAuthHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            if self.path == '/':
                self.serve_home()
            elif self.path == '/authorize':
                self.start_oauth()
            elif self.path.startswith('/oauth2callback'):
                self.handle_callback()
            elif self.path == '/health':
                self.serve_health()
            else:
                self.serve_404()
        except Exception as e:
            print(f"Error handling request: {e}")
            self.serve_error(str(e))

    def serve_home(self):
        html = f'''<!DOCTYPE html>
<html>
<head>
    <title>YouTube OAuth</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background: #f0f0f0;
        }}
        .container {{
            max-width: 500px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .btn {{
            display: inline-block;
            background: #ff0000;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin: 20px 0;
        }}
        .btn:hover {{
            background: #cc0000;
        }}
        .info {{
            background: #e8f5e8;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>YouTube Automation Setup</h1>
        <div class="info">
            <p><strong>Account:</strong> jasonclarkagain@gmail.com</p>
            <p><strong>Purpose:</strong> 30-day educational video series</p>
            <p><strong>Schedule:</strong> Daily uploads at 9:00 AM UTC</p>
        </div>
        <a href="/authorize" class="btn">Authorize YouTube Access</a>
        <p><small>Server: {BASE_URL}</small></p>
    </div>
</body>
</html>'''
        
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        self.wfile.write(html.encode())

    def start_oauth(self):
        params = {{
            'client_id': CLIENT_ID,
            'redirect_uri': REDIRECT_URI,
            'scope': 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube',
            'response_type': 'code',
            'access_type': 'offline',
            'prompt': 'consent'
        }}
        
        auth_url = 'https://accounts.google.com/o/oauth2/auth?' + urllib.parse.urlencode(params)
        print(f"Redirecting to: {auth_url}")
        
        self.send_response(302)
        self.send_header('Location', auth_url)
        self.end_headers()

    def handle_callback(self):
        parsed_url = urllib.parse.urlparse(self.path)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        
        if 'error' in query_params:
            error_msg = query_params['error'][0]
            print(f"OAuth error: {error_msg}")
            self.serve_error(f"Authorization failed: {error_msg}")
            return
            
        if 'code' not in query_params:
            print("No authorization code received")
            self.serve_error("No authorization code received")
            return
            
        auth_code = query_params['code'][0]
        print(f"Authorization code received: {auth_code[:10]}...")
        
        try:
            # Exchange code for tokens
            token_data = {{
                'client_id': CLIENT_ID,
                'client_secret': CLIENT_SECRET,
                'code': auth_code,
                'grant_type': 'authorization_code',
                'redirect_uri': REDIRECT_URI
            }}
            
            token_request = urllib.request.Request(
                'https://oauth2.googleapis.com/token',
                data=urllib.parse.urlencode(token_data).encode(),
                headers={{'Content-Type': 'application/x-www-form-urlencoded'}}
            )
            
            print("Exchanging code for tokens...")
            with urllib.request.urlopen(token_request) as response:
                tokens = json.loads(response.read().decode())
            
            print("Token exchange successful!")
            
            # Test YouTube access
            channel_name = "Unknown"
            if 'access_token' in tokens:
                try:
                    yt_request = urllib.request.Request(
                        'https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true',
                        headers={{'Authorization': f"Bearer {tokens['access_token']}"}}
                    )
                    
                    with urllib.request.urlopen(yt_request) as yt_response:
                        yt_data = json.loads(yt_response.read().decode())
                        if yt_data.get('items'):
                            channel_name = yt_data['items'][0]['snippet']['title']
                            print(f"Connected to channel: {channel_name}")
                except Exception as e:
                    print(f"YouTube test failed: {e}")
            
            self.serve_success(tokens, channel_name)
            
        except Exception as e:
            print(f"Token exchange failed: {e}")
            self.serve_error(f"Token exchange failed: {e}")

    def serve_success(self, tokens, channel_name):
        refresh_token = tokens.get('refresh_token', 'NOT_RECEIVED')
        
        html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Authorization Successful</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 20px;
            background: #e8f5e8;
        }}
        .container {{
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .success {{
            color: #4CAF50;
            font-size: 3em;
            margin: 20px 0;
        }}
        .token-box {{
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            word-break: break-all;
            font-family: monospace;
            border: 2px solid #4CAF50;
        }}
        .copy-btn {{
            background: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px 0;
        }}
        .copy-btn:hover {{
            background: #45a049;
        }}
        .channel-info {{
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="success">✅</div>
        <h1>Authorization Successful!</h1>
        
        <div class="channel-info">
            <h3>YouTube Channel Connected</h3>
            <p><strong>Channel:</strong> {channel_name}</p>
            <p><strong>Account:</strong> jasonclarkagain@gmail.com</p>
        </div>
        
        <h3>Refresh Token (SAVE THIS!):</h3>
        <div class="token-box" id="token">{refresh_token}</div>
        <button class="copy-btn" onclick="copyToken()">Copy Token</button>
        
        <div style="margin-top: 30px;">
            <h4>Next Steps:</h4>
            <p>✅ YouTube API access confirmed</p>
            <p>✅ Upload permissions granted</p>
            <p>🚀 Ready to start 30-day automation</p>
        </div>
    </div>
    
    <script>
        function copyToken() {{
            const tokenElement = document.getElementById('token');
            const textArea = document.createElement('textarea');
            textArea.value = tokenElement.textContent;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            
            const btn = document.querySelector('.copy-btn');
            btn.textContent = 'Copied!';
            setTimeout(() => {{
                btn.textContent = 'Copy Token';
            }}, 2000);
        }}
    </script>
</body>
</html>'''
        
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        self.wfile.write(html.encode())

    def serve_health(self):
        health = {{'status': 'healthy', 'server': 'OAuth', 'timestamp': time.time()}}
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(health).encode())

    def serve_error(self, message):
        html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Error</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background: #ffe6e6;
        }}
        .container {{
            max-width: 500px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .error {{
            color: #f44336;
            font-size: 3em;
            margin: 20px 0;
        }}
        .retry {{
            background: #2196F3;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="error">❌</div>
        <h1>Error</h1>
        <p>{message}</p>
        <a href="/" class="retry">Try Again</a>
    </div>
</body>
</html>'''
        
        self.send_response(500)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        self.wfile.write(html.encode())

    def serve_404(self):
        self.send_response(404)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        html = '''<html><body style="text-align:center;padding:50px;">
        <h1>404 - Not Found</h1><a href="/">← Back to Home</a></body></html>'''
        self.wfile.write(html.encode())

    def log_message(self, format, *args):
        print(f"[{self.address_string()}] {format % args}")

def run_server():
    try:
        with socketserver.TCPServer(("0.0.0.0", PORT), SimpleOAuthHandler) as httpd:
            print(f"OAuth server running on port {PORT}")
            print(f"Visit: {BASE_URL}")
            httpd.serve_forever()
    except Exception as e:
        print(f"Server error: {e}")

if __name__ == '__main__':
    run_server()