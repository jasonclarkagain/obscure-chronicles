const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 5000;

const server = http.createServer((req, res) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  
  // Serve index.html for root
  if (req.url === '/' || req.url === '/index.html') {
    fs.readFile(path.join(__dirname, 'index.html'), (err, data) => {
      if (err) {
        res.writeHead(500);
        res.end('Error loading page');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
  } 
  // API endpoint for status
  else if (req.url === '/api/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'online',
      message: 'Multi-Channel Video Generation System',
      cli: 'Use ./multichannel.sh commands in the Shell',
      video_count: 1,
      channels: 3,
      timestamp: new Date().toISOString()
    }));
  }
  // Health check endpoint (required for Cloud Run)
  else if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'healthy',
      timestamp: new Date().toISOString()
    }));
  }
  // 404
  else {
    res.writeHead(404);
    res.end('Not found');
  }
});

const host = process.env.REPL_SLUG ? '0.0.0.0' : '0.0.0.0';

server.listen(PORT, host, () => {
  console.log(`✅ HTTP Server running on http://${host}:${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/`);
  console.log(`\n🎬 Multi-Channel Video Generation System Ready`);
  console.log(`   Use CLI commands in the Shell to generate videos`);
});

server.on('error', (err) => {
  console.error('Server error:', err);
});
