# YouTube API Setup Guide

## Current Status
- OAuth server is running on port 3000
- Domain: https://a542f69f-89b0-40c4-91f0-9684c95170bd-00-1qklzlvyeiq1b.kirk.replit.dev
- Ready for YouTube authorization

## Authorization Steps

### Method 1: Direct Authorization (Recommended)
1. Visit: https://accounts.google.com/o/oauth2/auth?client_id=205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com&redirect_uri=https%3A%2F%2Fa542f69f-89b0-40c4-91f0-9684c95170bd-00-1qklzlvyeiq1b.kirk.replit.dev%2Foauth2callback&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fyoutube.upload+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fyoutube&response_type=code&access_type=offline&prompt=consent&include_granted_scopes=true

2. Sign in with: jasonclarkagain@gmail.com

3. Grant YouTube permissions

4. Copy the refresh token from the success page

### Method 2: Via OAuth Server
1. Visit: https://a542f69f-89b0-40c4-91f0-9684c95170bd-00-1qklzlvyeiq1b.kirk.replit.dev
2. Click "Authorize YouTube Access"
3. Complete authorization flow
4. Copy refresh token

## What Happens Next
Once you provide the refresh token, the system will:
- Start Episode 1: "The Water Cycle Adventure"
- Generate professional video with AI script
- Upload to YouTube channel
- Schedule daily automation for remaining 29 episodes
- Begin 30-day educational series

## Technical Details
- Client ID: 205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com
- Scopes: YouTube Data API v3 + Upload permissions
- Redirect URI: https://a542f69f-89b0-40c4-91f0-9684c95170bd-00-1qklzlvyeiq1b.kirk.replit.dev/oauth2callback
- Daily schedule: 9:00 AM UTC uploads
- Video quality: 1920x1080, 30 FPS, professional rendering