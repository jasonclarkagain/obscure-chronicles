#!/bin/bash

echo "🚀 YouTube Automation System"
echo "============================"

# Check if refresh token is provided
if [ -z "$1" ]; then
    echo "❌ Please provide refresh token as argument"
    echo "Usage: ./run-youtube-automation.sh <refresh_token>"
    echo ""
    echo "📋 Authorization URLs:"
    echo "• Direct: https://accounts.google.com/o/oauth2/auth?client_id=205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com&redirect_uri=https%3A%2F%2Fa542f69f-89b0-40c4-91f0-9684c95170bd-00-1qklzlvyeiq1b.kirk.replit.dev%2Foauth2callback&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fyoutube.upload+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fyoutube&response_type=code&access_type=offline&prompt=consent&include_granted_scopes=true"
    echo "• Server: https://a542f69f-89b0-40c4-91f0-9684c95170bd-00-1qklzlvyeiq1b.kirk.replit.dev"
    exit 1
fi

REFRESH_TOKEN=$1

echo "✅ Refresh token provided: ${REFRESH_TOKEN:0:20}..."
echo "🔧 Starting YouTube automation..."

# Set environment variable
export YOUTUBE_REFRESH_TOKEN=$REFRESH_TOKEN

# Run the automation
npx tsx server/working-automation.ts $REFRESH_TOKEN