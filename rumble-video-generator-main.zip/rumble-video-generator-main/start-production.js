const { spawn } = require('child_process');
const path = require('path');

console.log('🚀 Starting Multi-Channel Video Generation System with full Express server...\n');

const serverProcess = spawn('npx', ['tsx', 'server/index.ts'], {
  stdio: 'inherit',
  env: {
    ...process.env,
    PORT: process.env.PORT || '5000',
    NODE_ENV: process.env.NODE_ENV || 'production'
  }
});

serverProcess.on('error', (err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

serverProcess.on('exit', (code) => {
  console.log(`Server process exited with code ${code}`);
  process.exit(code || 0);
});

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down...');
  serverProcess.kill('SIGTERM');
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down...');
  serverProcess.kill('SIGINT');
});
