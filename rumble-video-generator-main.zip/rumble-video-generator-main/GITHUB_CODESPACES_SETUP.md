# 🚀 GitHub Codespaces Setup Guide

This guide will help you set up the Rumble Video Generator project in GitHub Codespaces.

## Step 1: Export from Replit to GitHub

### Option A: Using Replit's Git Integration
1. In your Replit workspace, open the Shell
2. Initialize git and add GitHub remote:
```bash
git init
git add .
git commit -m "Initial commit - Rumble Video Generator"
```

3. Create a new repository on GitHub:
   - Go to https://github.com/new
   - Name it: `rumble-video-generator`
   - Keep it private if desired
   - Don't initialize with README (we already have files)

4. Connect and push to GitHub:
```bash
git remote add origin https://github.com/YOUR_USERNAME/rumble-video-generator.git
git branch -M main
git push -u origin main
```

### Option B: Download and Upload Manually
1. In Replit, click the three dots menu → "Download as zip"
2. Extract the zip on your local machine
3. Create a new GitHub repository
4. Upload the files through GitHub's web interface or use GitHub Desktop

## Step 2: Set Up GitHub Codespaces

### 1. Open in Codespaces
Once your code is on GitHub:
- Go to your repository on GitHub
- Click the green "Code" button
- Select "Codespaces" tab
- Click "Create codespace on main"

### 2. Initial Configuration
The codespace will automatically:
- Install Node.js 20
- Install FFmpeg for video processing
- Install all npm dependencies
- Set up the development environment

### 3. Environment Variables
Create a `.env` file in the root:
```bash
# Required for AI features
OPENAI_API_KEY=your-openai-api-key-here

# Optional for Google Drive uploads
GOOGLE_DRIVE_CLIENT_ID=your-client-id
GOOGLE_DRIVE_CLIENT_SECRET=your-client-secret

# Development settings
NODE_ENV=development
PORT=3000
```

### 4. Start the Application
```bash
# Install dependencies (if not auto-installed)
npm install

# Start the development server
npm run dev
```

The application will be available at:
- Frontend: http://localhost:3000
- API: http://localhost:3000/api
- Health Check: http://localhost:3000/health

## Step 3: Codespace Features

### Included Tools
- ✅ Node.js 20
- ✅ FFmpeg for video processing
- ✅ TypeScript support
- ✅ Tailwind CSS IntelliSense
- ✅ ESLint and Prettier
- ✅ Git and GitHub CLI

### Port Forwarding
Codespaces automatically forwards ports:
- Port 3000: Main application
- Port 5000: Alternative backend port
- Port 8080: Production port

### VS Code Extensions
Pre-configured extensions:
- ESLint
- Prettier
- TypeScript support
- Tailwind CSS IntelliSense
- Auto Rename Tag

## Step 4: Development Workflow

### Running the App
```bash
# Development mode with hot reload
npm run dev

# Build for production
npm run build

# Run production server
NODE_ENV=production npm start
```

### Testing Video Generation
```bash
# Generate a test video (without OpenAI)
npx tsx create-working-video.ts

# With OpenAI API (requires credits)
npx tsx test-video-generation.ts
```

### Database Operations
```bash
# The app uses in-memory storage by default
# For PostgreSQL, you'll need to set up a database connection
```

## Step 5: Deploying from Codespaces

### Deploy to Cloud Run
```bash
# Make the script executable
chmod +x deploy-to-cloudrun.sh

# Deploy (requires gcloud CLI setup)
./deploy-to-cloudrun.sh YOUR_PROJECT_ID
```

### Deploy to Vercel
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

## Troubleshooting

### Common Issues

1. **Port already in use:**
```bash
# Kill process on port 3000
npx kill-port 3000
```

2. **FFmpeg not found:**
```bash
# Install FFmpeg in codespace
sudo apt-get update && sudo apt-get install -y ffmpeg
```

3. **Canvas module issues:**
```bash
# Rebuild canvas module
npm rebuild canvas
```

4. **OpenAI API errors:**
- Ensure your API key has credits
- Check the key is correctly set in `.env`

## Project Structure
```
rumble-video-generator/
├── client/               # React frontend
│   ├── src/
│   └── dist/            # Built frontend
├── server/              # Express backend
│   ├── services/        # Video generation logic
│   ├── routes.ts        # API endpoints
│   └── storage.ts       # Data storage
├── shared/              # Shared types
├── rumble_videos/       # Generated videos
├── .devcontainer/       # Codespaces config
└── package.json         # Dependencies
```

## Quick Commands Reference

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build application
npm run build

# Generate test video
npx tsx create-working-video.ts

# Check server health
curl http://localhost:3000/health

# View logs
npm run logs
```

## Next Steps

1. **Add API Keys:**
   - Get OpenAI API key from https://platform.openai.com
   - Add credits to your OpenAI account

2. **Test Video Generation:**
   - Visit http://localhost:3000
   - Create a campaign
   - Generate your first video

3. **Customize:**
   - Modify video themes in `server/services/rumbleVideoGenerator.ts`
   - Update UI in `client/src/pages/RumbleDashboard.tsx`

## Support

If you encounter issues:
1. Check the logs in the terminal
2. Verify all environment variables are set
3. Ensure FFmpeg is installed
4. Check that ports 3000/5000/8080 are available

---

🎉 **Your Rumble Video Generator is now ready in GitHub Codespaces!**