#!/bin/bash

# Kill any existing servers
pkill -f "tsx server/simple-server.ts" || true
pkill -f "vite.*5000" || true

sleep 2

# Start backend
echo "🚀 Starting backend on port 3001..."
tsx server/simple-server.ts &
BACKEND_PID=$!

sleep 3

# Start frontend
echo "🎨 Starting frontend on port 5000..."
cd client && vite --host 0.0.0.0 --port 5000 &
FRONTEND_PID=$!

echo ""
echo "✅ Servers started!"
echo "   Backend PID: $BACKEND_PID"
echo "   Frontend PID: $FRONTEND_PID"
echo ""
echo "📊 Backend:  http://localhost:3001/health"
echo "🌐 Frontend: http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop servers"

# Wait for processes
wait
