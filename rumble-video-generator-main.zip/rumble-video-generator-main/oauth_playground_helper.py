#!/usr/bin/env python3

import urllib.parse
import json
import urllib.request

# Your YouTube OAuth credentials
CLIENT_ID = "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com"
CLIENT_SECRET = "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"

def get_refresh_token_via_playground():
    """Guide user through OAuth Playground process"""
    print("🔐 YouTube OAuth via Google OAuth Playground")
    print("=" * 60)
    print()
    print("This method bypasses the verification requirement.")
    print()
    print("STEP 1: Go to Google OAuth Playground")
    print("https://developers.google.com/oauthplayground")
    print()
    print("STEP 2: Configure OAuth Playground")
    print("1. Click the gear icon (⚙️) in the top right")
    print("2. Check 'Use your own OAuth credentials'")
    print(f"3. Enter OAuth Client ID: {CLIENT_ID}")
    print(f"4. Enter OAuth Client Secret: {CLIENT_SECRET}")
    print("5. Close the configuration")
    print()
    print("STEP 3: Select YouTube API Scopes")
    print("1. In the left panel, find 'YouTube API v3'")
    print("2. Check these scopes:")
    print("   ☑️ https://www.googleapis.com/auth/youtube")
    print("   ☑️ https://www.googleapis.com/auth/youtube.upload")
    print("3. Click 'Authorize APIs'")
    print()
    print("STEP 4: Complete Authorization")
    print("1. Sign in with: jasonclarkagain@gmail.com")
    print("2. Grant all permissions when prompted")
    print("3. You'll return to the OAuth Playground")
    print()
    print("STEP 5: Get Refresh Token")
    print("1. Click 'Exchange authorization code for tokens'")
    print("2. Copy the 'Refresh token' value")
    print()
    print("=" * 60)
    
    refresh_token = input("\nEnter the refresh token from OAuth Playground: ").strip()
    
    if refresh_token:
        # Save the refresh token
        with open('youtube_refresh_token.txt', 'w') as f:
            f.write(refresh_token)
        
        print(f"\n✅ Refresh token saved to: youtube_refresh_token.txt")
        print(f"🎬 Ready to start YouTube automation!")
        
        # Test the refresh token
        test_refresh_token(refresh_token)
        
        return refresh_token
    else:
        print("No refresh token provided.")
        return None

def test_refresh_token(refresh_token):
    """Test the refresh token by getting a new access token"""
    print(f"\n🧪 Testing refresh token...")
    
    try:
        token_data = {
            'client_id': CLIENT_ID,
            'client_secret': CLIENT_SECRET,
            'refresh_token': refresh_token,
            'grant_type': 'refresh_token'
        }
        
        req = urllib.request.Request(
            'https://oauth2.googleapis.com/token',
            data=urllib.parse.urlencode(token_data).encode(),
            headers={'Content-Type': 'application/x-www-form-urlencoded'}
        )
        
        with urllib.request.urlopen(req) as response:
            tokens = json.loads(response.read().decode())
        
        if 'access_token' in tokens:
            print(f"✅ Refresh token is valid!")
            
            # Test YouTube API access
            yt_req = urllib.request.Request(
                'https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true',
                headers={'Authorization': f"Bearer {tokens['access_token']}"}
            )
            
            with urllib.request.urlopen(yt_req) as yt_response:
                yt_data = json.loads(yt_response.read().decode())
                if yt_data.get('items'):
                    channel_name = yt_data['items'][0]['snippet']['title']
                    print(f"✅ YouTube API access confirmed!")
                    print(f"📺 Connected to channel: {channel_name}")
                else:
                    print("⚠️  No YouTube channel found")
        else:
            print("❌ Failed to get access token from refresh token")
            
    except Exception as e:
        print(f"❌ Refresh token test failed: {e}")

if __name__ == '__main__':
    get_refresh_token_via_playground()