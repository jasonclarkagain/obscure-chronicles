#!/bin/bash

# Start the integrated server and keep it running
while true; do
  echo "🚀 Starting Multi-Channel Video Generation System..."
  npx tsx server/vite-server.ts
  echo "⚠️  Server stopped. Restarting in 3 seconds..."
  sleep 3
done
