#!/bin/bash

echo "🎬 Multi-Channel Video Generator"
echo "==============================="
echo ""
echo "Available Channels:"
echo "1. Amazing Learning Adventures - Educational content for children"
echo "2. Science Explorers - Science experiments and discoveries"
echo "3. Story Time Magic - Interactive storytelling and moral lessons"
echo "4. Math Adventures - Mathematics made fun"
echo "5. Creative Crafts Corner - Arts, crafts, and creativity"
echo ""

if [ "$1" = "--schedule" ]; then
    echo "🚀 Starting scheduled generation for all channels..."
    echo "📅 Each channel will generate videos daily at different times"
    echo "⏰ Schedule:"
    echo "  - Amazing Learning Adventures: 9:00 AM UTC"
    echo "  - Math Adventures: 10:00 AM UTC"
    echo "  - Creative Crafts Corner: 2:00 PM UTC"
    echo "  - Science Explorers: 3:00 PM UTC"
    echo "  - Story Time Magic: 7:00 PM UTC"
    echo ""
    echo "Press Ctrl+C to stop all schedules"
    echo ""
    npx tsx server/multi-channel-manager.ts --schedule
elif [ "$1" = "--single" ]; then
    echo "🎯 Generating one episode for each channel now..."
    echo "📹 This will create 5 videos (one per channel)"
    echo ""
    npx tsx server/multi-channel-manager.ts
else
    echo "Usage:"
    echo "  ./start-multi-channel.sh --single    # Generate one episode for each channel now"
    echo "  ./start-multi-channel.sh --schedule  # Start daily scheduled generation"
    echo ""
    echo "Output Directory: server/multi_channel_output/"
    echo "Each channel will have its own subdirectory with videos, thumbnails, and scripts"
fi