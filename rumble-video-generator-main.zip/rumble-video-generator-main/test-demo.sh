#!/bin/bash

echo "🎬 Demo Multi-Channel Video Generator"
echo "===================================="
echo "This creates demo videos without using OpenAI API"
echo "Each channel will generate a 30-second demo video"
echo ""
echo "Channels:"
echo "1. Amazing Learning Adventures"
echo "2. Science Explorers"
echo "3. Story Time Magic"
echo "4. Math Adventures"
echo "5. Creative Crafts Corner"
echo ""
echo "🚀 Starting demo generation..."
echo ""

npx tsx server/demo-multi-channel.ts