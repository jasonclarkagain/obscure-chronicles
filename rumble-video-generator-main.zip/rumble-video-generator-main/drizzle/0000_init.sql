-- Initial migration (empty to satisfy Replit)
SELECT 1;
