#!/bin/bash

# Deployment script for Cloud Run

echo "🚀 Deploying Rumble Video Generator to Cloud Run..."

# Set variables
PROJECT_ID=${1:-your-project-id}
SERVICE_NAME="rumble-video-generator"
REGION=${2:-us-central1}

if [ "$PROJECT_ID" = "your-project-id" ]; then
    echo "❌ Please provide your Google Cloud Project ID"
    echo "Usage: ./deploy.sh PROJECT_ID [REGION]"
    exit 1
fi

echo "📦 Project ID: $PROJECT_ID"
echo "🌍 Region: $REGION"
echo "🔧 Service: $SERVICE_NAME"

# Check if gcloud is installed
if ! command -v gcloud &> /dev/null; then
    echo "❌ gcloud CLI not found. Please install it first."
    exit 1
fi

# Set the project
gcloud config set project $PROJECT_ID

# Enable required APIs
echo "🔧 Enabling required APIs..."
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
gcloud services enable containerregistry.googleapis.com

# Build and deploy using Cloud Build
echo "🏗️ Starting Cloud Build..."
gcloud builds submit --config=cloudbuild.yaml \
    --substitutions=_SERVICE_NAME=$SERVICE_NAME,_REGION=$REGION

# Get the service URL
echo "🔍 Getting service URL..."
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format='value(status.url)')

echo ""
echo "=" .repeat(70)
echo "✅ DEPLOYMENT SUCCESSFUL!"
echo "=" .repeat(70)
echo "🌐 Service URL: $SERVICE_URL"
echo "💚 Health Check: $SERVICE_URL/health"
echo "🎬 Dashboard: $SERVICE_URL"
echo "=" .repeat(70)
echo ""
echo "📝 Next steps:"
echo "1. Set environment variables in Cloud Run console:"
echo "   - OPENAI_API_KEY (if using AI features)"
echo "   - GOOGLE_DRIVE_CREDENTIALS (if using Google Drive)"
echo "2. Visit $SERVICE_URL to access the dashboard"
echo "3. Create a campaign and start generating videos!"