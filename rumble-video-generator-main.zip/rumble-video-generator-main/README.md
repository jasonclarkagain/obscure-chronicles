# 🎬 Rumble Video Generator

An automated video generation system that creates 30+ minute educational videos daily for 30 consecutive days, designed for Rumble's creator program requirements.

## ✨ Features

- 🎥 **Automated Video Generation**: Creates 30+ minute videos with chapters
- 📅 **30-Day Campaigns**: Track progress through month-long streaming campaigns
- 🤖 **AI-Powered Content**: Uses OpenAI GPT-4 for scripts and narration
- 🎨 **Dynamic Visuals**: Generates engaging visuals for each chapter
- ⏰ **Daily Automation**: Cron job runs at 02:00 UTC daily
- ☁️ **Cloud Storage**: Optional Google Drive integration
- 📊 **Web Dashboard**: Monitor campaigns and trigger manual generation

## 🚀 Quick Start

### Prerequisites
- Node.js 20+
- FFmpeg
- OpenAI API Key (with credits)

### Installation

1. **Clone the repository:**
```bash
git clone https://github.com/YOUR_USERNAME/rumble-video-generator.git
cd rumble-video-generator
```

2. **Install dependencies:**
```bash
npm install
```

3. **Set up environment variables:**
```bash
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY
```

4. **Start the application:**
```bash
npm run dev
```

5. **Access the dashboard:**
Open http://localhost:3000 in your browser

## 📦 GitHub Codespaces Setup

1. Fork this repository
2. Click "Code" → "Codespaces" → "Create codespace on main"
3. Wait for automatic setup (2-3 minutes)
4. Run `npm run dev` in the terminal
5. Access the forwarded port URL

## 🎯 Usage

### Creating a Campaign
1. Visit the dashboard at http://localhost:3000
2. Click "Create Campaign"
3. Enter campaign details
4. Videos will generate automatically daily

### Manual Video Generation
1. Go to the dashboard
2. Find your active campaign
3. Click "Generate Video"
4. Video will be created in `rumble_videos/` directory

### Generated Video Specifications
- Duration: 30+ minutes
- Resolution: 1920x1080 (Full HD)
- Format: MP4 (H.264)
- Structure: 6-7 chapters, 5+ minutes each
- Audio: AI narration with TTS

## 🏗️ Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Frontend  │────▶│   Backend   │────▶│   Storage   │
│    React    │     │   Express   │     │  In-Memory  │
└─────────────┘     └─────────────┘     └─────────────┘
                           │
                    ┌──────┴──────┐
                    │             │
              ┌─────▼───┐   ┌────▼────┐
              │ OpenAI  │   │ FFmpeg  │
              │   API   │   │ Process │
              └─────────┘   └─────────┘
```

## 🛠️ Development

### Project Structure
```
├── client/           # React frontend
├── server/          # Express backend
│   ├── services/    # Business logic
│   └── routes.ts    # API endpoints
├── shared/          # Shared types
└── rumble_videos/   # Output directory
```

### Available Scripts
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm test            # Run tests
```

### API Endpoints
- `GET /api/rumble/campaigns` - List campaigns
- `POST /api/rumble/campaigns` - Create campaign
- `GET /api/rumble/videos` - List videos
- `POST /api/rumble/generate` - Generate video
- `GET /health` - Health check

## 🚀 Deployment

### Cloud Run
```bash
./deploy-to-cloudrun.sh YOUR_PROJECT_ID
```

### Docker
```bash
docker build -t rumble-video-generator .
docker run -p 3000:3000 -e OPENAI_API_KEY=xxx rumble-video-generator
```

### Environment Variables
- `OPENAI_API_KEY` - Required for AI features
- `NODE_ENV` - Set to "production" for deployment
- `PORT` - Server port (default: 3000)

## 📝 Configuration

### Video Settings
Edit `server/services/rumbleVideoGenerator.ts`:
- Chapter count
- Duration per chapter
- Video themes
- Voice settings

### Cron Schedule
Edit `server/services/rumbleCron.ts`:
- Default: Daily at 02:00 UTC
- Format: `'0 2 * * *'`

## 🔧 Troubleshooting

### OpenAI API Errors
- **Error 429**: Add credits at https://platform.openai.com/billing
- **Error 401**: Check API key in `.env`

### Port Conflicts
- Use `PORT=8080 npm run dev` to change port
- Check for other processes: `lsof -i :3000`

### FFmpeg Issues
- Ensure FFmpeg is installed: `ffmpeg -version`
- Install if missing: `apt-get install ffmpeg`

## 📄 License

MIT License - See LICENSE file for details

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📞 Support

For issues and questions:
- Open an issue on GitHub
- Check existing issues first
- Include error logs and steps to reproduce

---

Built with ❤️ for content creators