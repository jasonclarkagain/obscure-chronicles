# Multi-Channel Video Generator - Quick Start Guide

## What This System Does

Creates professional 60-second educational videos for multiple YouTube channels:
- ✅ Pre-generates scripts using OpenAI GPT-4
- ✅ Creates custom thumbnails with Canvas
- ✅ Renders videos with FFmpeg (template-based animations)
- ✅ Tracks progress with resumable jobs
- ✅ Handles errors automatically (3 retry attempts)
- ✅ **Works offline after content is cached** (no API calls during rendering)

## System Requirements

✅ All dependencies already installed:
- Node.js + TypeScript
- PostgreSQL database
- FFmpeg
- Canvas
- OpenAI API (for content generation only)

## Getting Started (5 Steps)

### Step 1: Initialize the System
```bash
./multichannel.sh init
```
This creates 3 sample channels:
- Amazing Learning Adventures
- Story Time Magic  
- Math Adventures

### Step 2: List Your Channels
```bash
./multichannel.sh channels
```
Copy the channel ID you want to use (e.g., `sveRbLFOY3TAcmlji1PbK`)

### Step 3: Pre-Generate Content (Requires OpenAI API)
```bash
./multichannel.sh cache <channel-id> 10
```
Example:
```bash
./multichannel.sh cache sveRbLFOY3TAcmlji1PbK 10
```
This creates 10 scripts and 10 thumbnails that can be reused.

**Note:** This step uses OpenAI API. If you hit quota limits, you can use the demo mode:
```bash
npx tsx server/demo-test.ts
```

### Step 4: Create Episode Entries
```bash
./multichannel.sh create-episodes <channel-id> 5
```
Example:
```bash
./multichannel.sh create-episodes sveRbLFOY3TAcmlji1PbK 5
```
This creates 5 episode records ready for rendering.

### Step 5: Render Videos
```bash
./multichannel.sh batch <channel-id> 5
```
Example:
```bash
./multichannel.sh batch sveRbLFOY3TAcmlji1PbK 5
```
This renders 5 videos (~2 minutes each).

## Check Progress

```bash
./multichannel.sh status
```

Shows:
- Total episodes
- Status breakdown (pending, rendering, completed, failed)
- Phase tracking
- Content cache status

## Output Files

**Videos:**
```
server/output/videos/*.mp4
```
Ready to upload to YouTube manually.

**Thumbnails:**
```
server/content_output/thumbnails/*.png
```
Use these when uploading videos.

## Advanced Usage

### Render a Single Episode
```bash
./multichannel.sh render <episode-id>
```

### Check Available Commands
```bash
./multichannel.sh
```

## Workflow for Multiple Channels

1. Cache content for each channel (do once):
   ```bash
   ./multichannel.sh cache channel1_id 20
   ./multichannel.sh cache channel2_id 20
   ./multichannel.sh cache channel3_id 20
   ```

2. Create episodes for each channel:
   ```bash
   ./multichannel.sh create-episodes channel1_id 10
   ./multichannel.sh create-episodes channel2_id 10
   ./multichannel.sh create-episodes channel3_id 10
   ```

3. Batch render for all channels:
   ```bash
   ./multichannel.sh batch channel1_id 10
   ./multichannel.sh batch channel2_id 10
   ./multichannel.sh batch channel3_id 10
   ```

4. Upload videos manually to each YouTube account

## Video Specifications

- **Duration:** 60 seconds (3 scenes x 20 seconds)
- **Resolution:** 1920x1080
- **FPS:** 10
- **Format:** MP4 (H.264)
- **File Size:** ~1MB per video

## Troubleshooting

**OpenAI API Quota Error:**
- Use demo mode: `npx tsx server/demo-test.ts`
- Or wait for quota reset

**Rendering Too Slow:**
- Videos render at ~2 minutes each
- FPS already optimized to 10
- Consider shorter scenes (15s instead of 20s)

**Episode Failed:**
- Check status: `./multichannel.sh status`
- System automatically retries 3 times
- Re-run: `./multichannel.sh render <episode-id>`

**Database Connection Issues:**
- Check DATABASE_URL environment variable
- Verify PostgreSQL is running

## Next Steps

1. ✅ System is ready to use
2. Generate content for your channels
3. Render videos
4. Upload manually to YouTube accounts
5. Scale up: create more channels, cache more content

## Need Help?

- Check status: `./multichannel.sh status`
- List channels: `./multichannel.sh channels`
- View this guide: `cat QUICKSTART.md`
