#!/bin/bash

echo "🚀 Starting AI Video Generation Platform..."

# Kill existing processes
pkill -f "tsx unified-server" 2>/dev/null || true
pkill -f "vite" 2>/dev/null || true
sleep 2

echo "📦 Starting Backend Server..."
cd server
npx tsx unified-server.ts &
BACKEND_PID=$!
echo "Backend PID: $BACKEND_PID"

echo "🌐 Starting Frontend Server..."
cd ../client
npx vite --host 0.0.0.0 --port 5173 &
FRONTEND_PID=$!
echo "Frontend PID: $FRONTEND_PID"

echo "⏳ Waiting for services to start..."
sleep 10

echo "🔍 Checking services..."
curl -f -s "http://localhost:3001/health" > /dev/null && echo "✅ Backend: http://localhost:3001" || echo "❌ Backend failed"
curl -f -s "http://localhost:5173" > /dev/null && echo "✅ Frontend: http://localhost:5173" || echo "❌ Frontend failed"

echo "🎯 Services ready!"
wait