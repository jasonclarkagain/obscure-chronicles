import { google } from 'googleapis';
import * as readline from 'readline';
import * as fs from 'fs';

/**
 * This script helps you get the YouTube OAuth credentials needed for automated uploads.
 * 
 * Run this ONCE to get your refresh token, then save it in Replit Secrets.
 */

// Get these from Google Cloud Console
const CLIENT_ID = process.env.YOUTUBE_CLIENT_ID || '';
const CLIENT_SECRET = process.env.YOUTUBE_CLIENT_SECRET || '';
const REDIRECT_URI = 'http://localhost:3000/oauth2callback';

const SCOPES = ['https://www.googleapis.com/auth/youtube.upload'];

async function getRefreshToken() {
  console.log('🔑 YouTube OAuth Credential Helper\n');
  
  if (!CLIENT_ID || !CLIENT_SECRET) {
    console.error('❌ ERROR: Missing credentials!\n');
    console.log('Before running this script, you need to:');
    console.log('1. Go to https://console.cloud.google.com/');
    console.log('2. Create a new project');
    console.log('3. Enable YouTube Data API v3');
    console.log('4. Create OAuth 2.0 Client ID (Desktop app)');
    console.log('5. Set these in Replit Secrets:');
    console.log('   - YOUTUBE_CLIENT_ID');
    console.log('   - YOUTUBE_CLIENT_SECRET\n');
    console.log('📚 Full guide: https://developers.google.com/youtube/v3/guides/authentication\n');
    process.exit(1);
  }
  
  const oauth2Client = new google.auth.OAuth2(
    CLIENT_ID,
    CLIENT_SECRET,
    REDIRECT_URI
  );
  
  // Generate auth URL - CRITICAL: access_type=offline gets the refresh token
  const authUrl = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    prompt: 'consent', // Force consent screen to ensure refresh token
  });
  
  console.log('Step 1: Authorize this app');
  console.log('─────────────────────────────────────');
  console.log('Copy this URL and open it in your browser:\n');
  console.log(authUrl);
  console.log('\n');
  
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  
  rl.question('Step 2: Enter the code from the URL (after ?code=): ', async (code) => {
    rl.close();
    
    try {
      // Exchange authorization code for tokens
      const { tokens } = await oauth2Client.getToken(code);
      
      console.log('\n✅ SUCCESS! Here are your tokens:\n');
      console.log('─────────────────────────────────────');
      console.log(JSON.stringify(tokens, null, 2));
      console.log('─────────────────────────────────────\n');
      
      if (tokens.refresh_token) {
        console.log('🎉 IMPORTANT: Save this refresh token!\n');
        console.log('Add this to your Replit Secrets:');
        console.log(`YOUTUBE_REFRESH_TOKEN=${tokens.refresh_token}\n`);
        
        // Save to file for reference
        fs.writeFileSync('youtube-tokens.json', JSON.stringify(tokens, null, 2));
        console.log('💾 Tokens also saved to: youtube-tokens.json');
        console.log('⚠️  DO NOT commit this file to Git!\n');
      } else {
        console.log('⚠️  No refresh token received.');
        console.log('This might happen if you already authorized before.');
        console.log('To fix: Revoke access at https://myaccount.google.com/permissions');
        console.log('Then run this script again.\n');
      }
      
      console.log('Next step: Run the upload script!');
      console.log('npx tsx generate-and-upload.ts\n');
      
    } catch (error: any) {
      console.error('\n❌ Error getting tokens:', error.message);
      console.log('\nMake sure:');
      console.log('- You copied the entire code from the URL');
      console.log('- Your redirect URI in Google Console includes: ' + REDIRECT_URI);
    }
  });
}

getRefreshToken();
