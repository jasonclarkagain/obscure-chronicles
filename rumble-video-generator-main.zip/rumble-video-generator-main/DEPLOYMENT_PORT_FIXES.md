# Deployment Port Conflict Fixes

## Issue
The deployment was failing with `EADDRINUSE` errors on port 24678, indicating multiple server instances were competing for the same port.

## Applied Fixes

### 1. Environment-Based PORT Configuration
**Changed:** Port now properly reads from Cloud Run's `PORT` environment variable
```typescript
const PORT = parseInt(process.env.PORT || "3000", 10);
```
- Uses `parseInt()` to ensure PORT is a number
- Defaults to 3000 in development
- Cloud Run will provide its own PORT in production

### 2. Conditional .env Loading
**Changed:** Only load .env file in development
```typescript
if (process.env.NODE_ENV !== "production") {
  dotenv.config();
}
```
- Cloud Run provides environment variables directly
- Prevents conflicts from .env file in production

### 3. Instance Guard
**Added:** Prevent duplicate server instances
```typescript
let isServerStarting = false;

async function startServer() {
  if (isServerStarting) {
    console.log("⚠️ Server is already starting, skipping duplicate instance");
    return;
  }
  isServerStarting = true;
  // ... rest of server setup
}
```

### 4. Enhanced EADDRINUSE Error Handling
**Added:** Better error handling for port conflicts
```typescript
server.on("error", (error: any) => {
  if (error.code === "EADDRINUSE") {
    console.error(`❌ Port ${PORT} is already in use`);
    console.error(`💡 This usually means another instance is running`);
    console.error(`💡 In Cloud Run, ensure only one server file is executed`);
    console.error(`💡 Check that server/vite-server.ts is the only entry point`);
    
    if (process.env.NODE_ENV === "production") {
      console.log("🔄 Exiting to allow platform restart...");
      process.exit(1);
    }
  }
});
```

### 5. Disabled HMR in Production
**Changed:** Vite HMR only enabled in development
```typescript
hmr: process.env.NODE_ENV === "production" ? false : {
  host: '0.0.0.0',
  protocol: 'ws',
}
```
- HMR (Hot Module Replacement) disabled in production
- Prevents unnecessary WebSocket connections
- Reduces port conflicts

### 6. Improved Graceful Shutdown
**Enhanced:** Proper server cleanup on shutdown
```typescript
process.on("SIGTERM", async () => {
  console.log("SIGTERM received, shutting down gracefully...");
  isServerStarting = false;
  rumbleCron.stop();
  server.close(() => {
    console.log("Server closed");
  });
  await vite.close();
  setTimeout(() => process.exit(0), 1000);
});
```

## Entry Point Verification

The `.replit` file correctly specifies:
```toml
[deployment]
run = ["npx", "tsx", "server/vite-server.ts"]
deploymentTarget = "cloudrun"
```

**Only `server/vite-server.ts` should run in deployment.**

Other server files (index.ts, production-server.ts, etc.) are legacy/unused and should not interfere since the deployment configuration explicitly runs only vite-server.ts.

## Expected Behavior

### Development (Local)
- Server starts on port 3000
- HMR enabled for hot reload
- Loads .env file
- Detailed logging

### Production (Cloud Run)
- Server uses Cloud Run's provided PORT environment variable
- HMR disabled
- No .env loading (uses Cloud Run env vars)
- Instance guard prevents duplicate starts
- Enhanced error logging for troubleshooting

## Testing

After these fixes, the deployment should:
1. ✅ Start on the correct port provided by Cloud Run
2. ✅ Handle EADDRINUSE errors gracefully
3. ✅ Only run one server instance
4. ✅ Use production environment variables correctly
5. ✅ Shut down cleanly on SIGTERM/SIGINT

## Deployment

The system is now ready to redeploy to Cloud Run with these fixes applied.
