# YouTube Auto-Upload Setup Guide

## ✅ What Works Right Now

The video generation script **WORKS** - it creates a 15-second video with FFmpeg.

Now you just need YouTube credentials to upload it.

---

## 🚀 Quick Setup (5 Steps)

### Step 1: Create Google Cloud Project

1. Go to https://console.cloud.google.com/
2. Click "New Project"
3. Name it (e.g., "YouTube AutoUpload")
4. Click "Create"

### Step 2: Enable YouTube API

1. In your project, go to **APIs & Services → Library**
2. Search for "YouTube Data API v3"
3. Click it, then click **Enable**

### Step 3: Create OAuth Credentials

1. Go to **APIs & Services → OAuth consent screen**
2. Choose **External** (unless you have Google Workspace)
3. Fill in:
   - App name: "YouTube AutoUpload"
   - User support email: Your email
   - Developer contact: Your email
4. Click **Save and Continue**
5. On "Scopes" screen, click **Add or Remove Scopes**
   - Search for `youtube.upload`
   - Check the box
   - Click **Update**, then **Save and Continue**
6. On "Test users" screen:
   - Click **Add Users**
   - Add your Google/YouTube email
   - Click **Save and Continue**

7. Go to **APIs & Services → Credentials**
8. Click **Create Credentials → OAuth 2.0 Client ID**
9. Choose **Desktop app**
10. Name it "YouTube Upload Client"
11. Click **Create**
12. **Download the JSON file** (you'll see Client ID and Secret)

### Step 4: Add Credentials to Replit

In your Replit project:

1. Click the **lock icon** (🔒) in the sidebar (Secrets)
2. Add three secrets:
   ```
   YOUTUBE_CLIENT_ID = (paste from downloaded JSON)
   YOUTUBE_CLIENT_SECRET = (paste from downloaded JSON)
   ```

### Step 5: Get Your Refresh Token

Run this command:

```bash
npx tsx get-youtube-credentials.ts
```

1. It will print a URL
2. Copy and paste the URL into your browser
3. Sign in with your YouTube account
4. Click "Allow"
5. You'll be redirected to a URL with `?code=...`
6. Copy the code (everything after `?code=`)
7. Paste it into the terminal when asked
8. It will print your **REFRESH_TOKEN**
9. Add it to Replit Secrets:
   ```
   YOUTUBE_REFRESH_TOKEN = (paste the token)
   ```

---

## 🎬 Upload Your First Video

Now run:

```bash
npx tsx generate-and-upload.ts
```

It will:
1. Generate a 15-second video
2. Upload it to YouTube
3. Print the YouTube URL

**Boom! You're done!**

---

## 💰 Making Money on YouTube

### YouTube Partner Requirements

To monetize, you need:
- **1,000 subscribers**
- **4,000 watch hours** in the past 12 months
- OR **10 million Shorts views** in 90 days

### Tips for Growth

1. **Longer videos** = More ads = More money
   - Aim for 10-15 minutes
   - Videos 8+ minutes can have mid-roll ads

2. **Daily uploads** = More views
   - Consistency matters
   - Use scheduling

3. **Good topics** that people search for:
   - "How to..." tutorials
   - Top 10 lists
   - News/trending topics
   - Product reviews
   - Meditation/sleep sounds
   - Lo-fi music

4. **AI Content Ideas**:
   - Motivation quotes with background music
   - True crime stories
   - History facts
   - Book summaries
   - Tech news
   - Stock market analysis

### Revenue Estimates

- **1,000 views** ≈ $1-5 (varies by niche)
- **100,000 views/month** ≈ $100-500
- **1 million views/month** ≈ $1,000-5,000

**Finance/tech niches pay more than entertainment.**

---

## 📊 YouTube API Limits

- **10,000 units/day** (free quota)
- **Each upload = ~1,600 units**
- **You can upload ~6 videos/day**

For more uploads, request quota increase (can take days).

---

## 🔄 Automating Daily Uploads

### Option 1: Cron Job (Replit)

Create a cron job to run daily:

```bash
# Edit crontab
crontab -e

# Add this line to run at 9 AM daily:
0 9 * * * cd /path/to/project && npx tsx generate-and-upload.ts
```

### Option 2: n8n (Recommended)

1. Set up n8n (workflow automation tool)
2. Create workflow:
   - **Trigger**: Schedule (daily at specific time)
   - **Action**: Run script or call Replit
   - **OpenAI**: Generate video script/images
   - **FFmpeg**: Create video
   - **YouTube**: Upload

### Option 3: GitHub Actions (Free)

Use GitHub Actions to run on schedule.

---

## 🎯 Next Steps to Scale

1. **Improve video quality**:
   - Add AI-generated images (DALL-E)
   - Add voiceover (OpenAI TTS)
   - Add background music
   - Make videos 10+ minutes

2. **Use better topics**:
   - Research trending keywords
   - Use Google Trends
   - Check what competitors do

3. **Optimize titles/thumbnails**:
   - Use clickable titles
   - Create eye-catching thumbnails
   - Add relevant tags

4. **Scale to multiple channels**:
   - Different niches
   - Diversify income

---

## ⚠️ Important Notes

- **Don't violate YouTube's TOS** - use original content
- **AI content is allowed** but must be disclosed
- **Copyright-free music/images only**
- **Monetization takes time** - focus on quality + quantity

---

## 🆘 Troubleshooting

### "Invalid grant" error
- Your refresh token expired
- Revoke access: https://myaccount.google.com/permissions
- Run `get-youtube-credentials.ts` again

### "Quota exceeded" error
- You hit the 6 uploads/day limit
- Wait 24 hours or request quota increase

### Video upload fails
- Check file size (< 256 GB)
- Check video format (MP4 recommended)
- Check internet connection

---

## 📚 Resources

- YouTube Partner Program: https://www.youtube.com/howyoutubeworks/policies/monetization-policies/
- Google Cloud Console: https://console.cloud.google.com/
- YouTube Analytics: Track views/revenue
- TubeBuddy/VidIQ: Keyword research tools

Good luck! 🚀
