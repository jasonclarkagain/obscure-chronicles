# Quick Start: Generate & Upload YouTube Videos

## What This Does
Creates a simple video and uploads it to YouTube automatically.

## Step 1: Install FFmpeg
```bash
# FFmpeg should already be installed on Replit
# Test it:
ffmpeg -version
```

## Step 2: Get YouTube API Credentials

1. Go to https://console.cloud.google.com/
2. Create a new project
3. Enable YouTube Data API v3
4. Create OAuth 2.0 credentials (Desktop app)
5. Download the credentials JSON

You'll need:
- Client ID
- Client Secret  
- Refresh Token (get this by running the OAuth flow once)

## Step 3: Set Environment Variables

In Replit Secrets (or .env file), add:
```
YOUTUBE_CLIENT_ID=your_client_id
YOUTUBE_CLIENT_SECRET=your_client_secret
YOUTUBE_REFRESH_TOKEN=your_refresh_token
```

## Step 4: Run It

```bash
npx tsx generate-and-upload.ts
```

## What Happens

1. Creates a 15-second video with text
2. Uploads it to YouTube
3. Prints the YouTube URL
4. Cleans up temp files

## For Making Money

To actually make money on YouTube you need:

1. **1,000 subscribers + 4,000 watch hours** to monetize
2. **Videos 8+ minutes long** for mid-roll ads (more money)
3. **Daily uploads** (consistency matters)
4. **Good topics** that people search for

## Next Steps

- Use OpenAI to generate video scripts
- Use AI to generate images for the video
- Use text-to-speech for narration
- Make videos 10-15 minutes long
- Upload multiple per day
- Use trending topics/keywords

## Cost Estimate

- OpenAI API: ~$0.50-2 per video (GPT-4 + images + TTS)
- YouTube API: Free (10,000 quota per day = ~6 uploads)
- Replit: Free tier works for testing

## Scaling to Daily Uploads

Use n8n or cron to run this script automatically:
- Schedule for specific times
- Generate different topics each day
- Track which videos perform best
