# RUN THIS EVERY DAY

```bash
npx tsx daily-video.ts
```

That's it. One command. Runs in 2-3 minutes. Makes a 10-12 minute video with voiceover.

---

## What it does:
1. Picks a money-making topic (rotates daily)
2. Writes script with GPT-4
3. Creates professional voiceover
4. Makes video
5. Saves to `video_2025-XX-XX.mp4`

---

## To auto-upload to YouTube:
Run once: `npx tsx get-youtube-credentials.ts`

Then the daily script will upload automatically.

---

## To run for 30 days straight:

```bash
# Add to crontab to run at 9 AM daily
crontab -e

# Add this line:
0 9 * * * cd ~/your-project && npx tsx daily-video.ts
```

Or just run it manually once a day. Takes 2 minutes.

---

**No more complexity. Just run it.**
