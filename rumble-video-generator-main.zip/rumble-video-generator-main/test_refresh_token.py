#!/usr/bin/env python3

import urllib.parse
import urllib.request
import json
import sys

def test_refresh_token():
    """Test the refresh token by getting a new access token"""
    
    if len(sys.argv) != 2:
        print("Usage: python3 test_refresh_token.py <refresh_token>")
        return
    
    refresh_token = sys.argv[1]
    
    client_id = "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com"
    client_secret = "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"
    
    # Try to refresh the token
    token_data = {
        'client_id': client_id,
        'client_secret': client_secret,
        'refresh_token': refresh_token,
        'grant_type': 'refresh_token'
    }
    
    try:
        print("🔄 Testing refresh token...")
        
        req = urllib.request.Request(
            'https://oauth2.googleapis.com/token',
            data=urllib.parse.urlencode(token_data).encode(),
            headers={'Content-Type': 'application/x-www-form-urlencoded'}
        )
        
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode())
            
        if 'access_token' in result:
            print("✅ Refresh token is valid!")
            print(f"📋 Access token: {result['access_token'][:20]}...")
            print(f"⏱️ Expires in: {result.get('expires_in', 'Unknown')} seconds")
            
            # Test YouTube API access
            print("\n🎥 Testing YouTube API access...")
            
            yt_req = urllib.request.Request(
                'https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true',
                headers={'Authorization': f"Bearer {result['access_token']}"}
            )
            
            with urllib.request.urlopen(yt_req) as yt_response:
                yt_data = json.loads(yt_response.read().decode())
                
            if yt_data.get('items'):
                channel = yt_data['items'][0]['snippet']
                print(f"✅ YouTube channel connected: {channel['title']}")
                print(f"📅 Channel created: {channel['publishedAt']}")
                print("🚀 Ready for automation!")
                return True
            else:
                print("❌ No YouTube channel found")
                return False
                
        else:
            print("❌ Failed to get access token")
            print(f"Response: {result}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

if __name__ == '__main__':
    test_refresh_token()