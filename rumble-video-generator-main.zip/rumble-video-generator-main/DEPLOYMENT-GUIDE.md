# Cloud Run Deployment Guide

## Problem
Cloud Run deployments don't have Node.js dev tools (npx, tsx) and can't run TypeScript directly. We need to compile TypeScript to JavaScript and build the frontend first.

## Solution: Two-Stage Build Process

### Step 1: Add Build Scripts to package.json

Open `package.json` and replace the `"scripts"` section with:

```json
"scripts": {
  "test": "echo \"Error: no test specified\" && exit 1",
  "build": "npm run build:client && npm run build:server",
  "build:client": "cd client && vite build --outDir ../dist/client",
  "build:server": "tsc -p tsconfig.server.json",
  "start": "node dist/server/production.js",
  "dev": "./run.sh"
},
```

### Step 2: Configure .replit Deployment

Open `.replit` file and update the `[deployment]` section at the bottom:

**Change from:**
```toml
[deployment]
deploymentTarget = "cloudrun"
```

**To:**
```toml
[deployment]
build = ["npm", "run", "build"]
run = ["npm", "start"]
deploymentTarget = "cloudrun"
```

## What This Does

1. **Build Phase** (`npm run build`):
   - Compiles TypeScript server code → `dist/server/`
   - Builds React frontend with Vite → `dist/client/`

2. **Run Phase** (`npm start`):
   - Runs the compiled `dist/server/production.js`
   - Serves static files from `dist/client/`
   - No TypeScript compilation needed at runtime

## Files Created

✅ `server/production.ts` - Production server (serves static files)  
✅ `tsconfig.server.json` - TypeScript compiler config for server

## What You Need to Do Manually

1. **Edit package.json**:
   - Add the `scripts` section shown above

2. **Edit .replit**:
   - Add `build = ["npm", "run", "build"]`
   - Add `run = ["npm", "start"]`
   - Keep `deploymentTarget = "cloudrun"`

3. **Deploy**:
   - Click the "Deploy" button
   - Choose "Autoscale" or "Reserved VM"
   - The build will compile everything, then run the production server

## Testing Locally

You can test the production build locally:

```bash
# Build everything
npm run build

# Run production server
npm start
```

Then visit http://localhost:5000

## Why This Works

- ✅ No TypeScript compilation at runtime
- ✅ No Vite dev server in production
- ✅ Static files served by Express
- ✅ All dependencies compiled into JavaScript
- ✅ Works in Cloud Run's Node.js environment
