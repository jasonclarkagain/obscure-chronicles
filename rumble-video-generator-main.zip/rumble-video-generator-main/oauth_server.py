#!/usr/bin/env python3

import os
import json
import urllib.parse
import urllib.request
import http.server
import socketserver
import webbrowser
from threading import Thread

# OAuth Configuration  
CLIENT_ID = "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com"
CLIENT_SECRET = "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"

# Dynamic redirect URI
DOMAIN = os.environ.get('REPLIT_DEV_DOMAIN', 'localhost')
PORT = 3000
if DOMAIN == 'localhost':
    BASE_URL = f"http://localhost:{PORT}"
else:
    BASE_URL = f"https://{DOMAIN}"
REDIRECT_URI = f"{BASE_URL}/oauth2callback"

print(f"OAuth Server Configuration:")
print(f"Domain: {DOMAIN}")
print(f"Base URL: {BASE_URL}")
print(f"Redirect URI: {REDIRECT_URI}")

class OAuthHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            if self.path == '/':
                self.send_home_page()
            elif self.path == '/authorize':
                self.start_oauth_flow()
            elif self.path.startswith('/oauth2callback'):
                self.handle_oauth_callback()
            elif self.path == '/health':
                self.send_health_check()
            else:
                self.send_404()
        except Exception as e:
            print(f"Request error: {e}")
            self.send_error_page(str(e))

    def send_home_page(self):
        html = f'''<!DOCTYPE html>
<html>
<head>
    <title>YouTube Automation OAuth</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{ 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            text-align: center; 
            min-height: 100vh;
        }}
        .container {{ 
            max-width: 600px; 
            margin: 0 auto; 
            background: rgba(255,255,255,0.1); 
            padding: 40px; 
            border-radius: 20px; 
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }}
        .title {{ 
            font-size: 2.5em; 
            margin-bottom: 10px; 
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }}
        .subtitle {{ 
            font-size: 1.2em; 
            margin-bottom: 30px; 
            opacity: 0.9;
        }}
        .status-card {{ 
            background: rgba(255,255,255,0.2); 
            padding: 20px; 
            border-radius: 15px; 
            margin: 20px 0; 
            border-left: 5px solid #4CAF50;
        }}
        .auth-button {{ 
            display: inline-block; 
            background: linear-gradient(45deg, #FF6B6B, #FF8E8E); 
            color: white; 
            padding: 15px 30px; 
            border-radius: 50px; 
            text-decoration: none; 
            font-weight: bold; 
            font-size: 1.1em;
            margin: 20px 0; 
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 15px rgba(255,107,107,0.4);
        }}
        .auth-button:hover {{ 
            transform: translateY(-2px); 
            box-shadow: 0 6px 20px rgba(255,107,107,0.6);
        }}
        .info-grid {{ 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 15px; 
            margin: 20px 0;
        }}
        .info-item {{ 
            background: rgba(255,255,255,0.1); 
            padding: 15px; 
            border-radius: 10px;
        }}
        .tech-details {{ 
            background: rgba(0,0,0,0.2); 
            padding: 15px; 
            border-radius: 10px; 
            margin-top: 20px; 
            font-family: monospace; 
            font-size: 0.9em;
            text-align: left;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="title">🎬 YouTube Automation</div>
        <div class="subtitle">AI-Powered Educational Video System</div>
        
        <div class="status-card">
            <h3>System Ready</h3>
            <div class="info-grid">
                <div class="info-item">
                    <div>📹 30-Day Series</div>
                    <div>Educational Content</div>
                </div>
                <div class="info-item">
                    <div>🤖 AI Generation</div>
                    <div>OpenAI + FFmpeg</div>
                </div>
                <div class="info-item">
                    <div>📺 Auto Upload</div>
                    <div>Daily at 9:00 AM UTC</div>
                </div>
                <div class="info-item">
                    <div>👨‍👩‍👧‍👦 Family Friendly</div>
                    <div>G-Rated Content</div>
                </div>
            </div>
        </div>
        
        <div><strong>Account:</strong> jasonclarkagain@gmail.com</div>
        
        <a href="/authorize" class="auth-button">
            🔐 Authorize YouTube Access
        </a>
        
        <div class="status-card">
            <h4>After Authorization:</h4>
            <p>✅ Get refresh token for permanent access</p>
            <p>🚀 Start automated video generation</p>
            <p>📊 Enable daily upload schedule</p>
            <p>🎓 Begin 30-day educational series</p>
        </div>
        
        <div class="tech-details">
            <strong>Technical Configuration:</strong><br>
            Server: {BASE_URL}<br>
            Redirect: {REDIRECT_URI}<br>
            Client ID: {CLIENT_ID[:20]}...<br>
            Scopes: YouTube Data API v3 + Upload
        </div>
    </div>
</body>
</html>'''
        
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

    def start_oauth_flow(self):
        # Build authorization URL
        params = {{
            'client_id': CLIENT_ID,
            'redirect_uri': REDIRECT_URI,
            'scope': 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube',
            'response_type': 'code',
            'access_type': 'offline',
            'prompt': 'consent',
            'include_granted_scopes': 'true'
        }}
        
        auth_url = 'https://accounts.google.com/o/oauth2/auth?' + urllib.parse.urlencode(params)
        print(f"Authorization URL: {auth_url}")
        
        # Redirect to Google OAuth
        self.send_response(302)
        self.send_header('Location', auth_url)
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()

    def handle_oauth_callback(self):
        # Parse callback URL
        parsed_url = urllib.parse.urlparse(self.path)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        
        print(f"OAuth callback received: {query_params}")
        
        # Check for authorization error
        if 'error' in query_params:
            error_msg = query_params['error'][0]
            print(f"OAuth error: {error_msg}")
            self.send_error_page(f"Authorization failed: {error_msg}")
            return
            
        # Check for authorization code
        if 'code' not in query_params:
            print("No authorization code received")
            self.send_error_page("No authorization code received")
            return
            
        auth_code = query_params['code'][0]
        print(f"Authorization code received: {auth_code[:20]}...")
        
        try:
            # Exchange authorization code for tokens
            token_request_data = {{
                'client_id': CLIENT_ID,
                'client_secret': CLIENT_SECRET,
                'code': auth_code,
                'grant_type': 'authorization_code',
                'redirect_uri': REDIRECT_URI
            }}
            
            token_request = urllib.request.Request(
                'https://oauth2.googleapis.com/token',
                data=urllib.parse.urlencode(token_request_data).encode('utf-8'),
                headers={{'Content-Type': 'application/x-www-form-urlencoded'}}
            )
            
            print("Exchanging authorization code for tokens...")
            with urllib.request.urlopen(token_request) as response:
                token_response = json.loads(response.read().decode('utf-8'))
            
            print("Token exchange successful!")
            print(f"Access token: {'✅' if 'access_token' in token_response else '❌'}")
            print(f"Refresh token: {'✅' if 'refresh_token' in token_response else '❌'}")
            
            # Test YouTube access
            channel_name = "Unknown Channel"
            if 'access_token' in token_response:
                try:
                    youtube_request = urllib.request.Request(
                        'https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true',
                        headers={{'Authorization': f"Bearer {token_response['access_token']}"}}
                    )
                    
                    with urllib.request.urlopen(youtube_request) as yt_response:
                        yt_data = json.loads(yt_response.read().decode('utf-8'))
                        if yt_data.get('items'):
                            channel_name = yt_data['items'][0]['snippet']['title']
                            print(f"Connected to YouTube channel: {channel_name}")
                except Exception as yt_error:
                    print(f"YouTube API test failed: {yt_error}")
                    channel_name = f"API Test Failed: {yt_error}"
            
            # Send success page with tokens
            self.send_success_page(token_response, channel_name)
            
        except Exception as token_error:
            print(f"Token exchange failed: {token_error}")
            self.send_error_page(f"Token exchange failed: {token_error}")

    def send_success_page(self, tokens, channel_name):
        refresh_token = tokens.get('refresh_token', 'NOT_RECEIVED')
        access_token = tokens.get('access_token', 'NOT_RECEIVED')
        expires_in = tokens.get('expires_in', 0)
        
        html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Authorization Successful!</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{ 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); 
            color: white; 
            text-align: center; 
            min-height: 100vh;
        }}
        .container {{ 
            max-width: 800px; 
            margin: 0 auto; 
            background: rgba(255,255,255,0.1); 
            padding: 40px; 
            border-radius: 20px; 
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
        }}
        .success-icon {{ 
            font-size: 4em; 
            margin-bottom: 20px; 
        }}
        .title {{ 
            font-size: 2.5em; 
            margin-bottom: 20px; 
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }}
        .channel-info {{ 
            background: rgba(76, 175, 80, 0.3); 
            padding: 20px; 
            border-radius: 15px; 
            margin: 20px 0; 
            border-left: 5px solid #2E7D32;
        }}
        .token-container {{ 
            background: rgba(0,0,0,0.3); 
            padding: 20px; 
            border-radius: 15px; 
            margin: 25px 0; 
            text-align: left;
        }}
        .token-label {{ 
            font-weight: bold; 
            color: #FFD54F; 
            margin-bottom: 10px;
            font-size: 1.1em;
        }}
        .token-value {{ 
            font-family: 'Courier New', monospace; 
            word-break: break-all; 
            background: rgba(0,0,0,0.4); 
            padding: 15px; 
            border-radius: 8px; 
            font-size: 0.9em;
            border: 1px solid rgba(255,255,255,0.2);
        }}
        .status-grid {{ 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 15px; 
            margin: 20px 0;
        }}
        .status-item {{ 
            background: rgba(255,255,255,0.2); 
            padding: 15px; 
            border-radius: 10px;
        }}
        .next-steps {{ 
            background: rgba(255,255,255,0.2); 
            padding: 25px; 
            border-radius: 15px; 
            margin: 25px 0;
        }}
        .copy-btn {{ 
            background: #FF9800; 
            color: white; 
            border: none; 
            padding: 8px 16px; 
            border-radius: 20px; 
            cursor: pointer; 
            font-size: 0.9em;
            margin-top: 10px;
        }}
        .copy-btn:hover {{ 
            background: #F57C00; 
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="success-icon">🎉</div>
        <div class="title">Authorization Successful!</div>
        
        <div class="channel-info">
            <h3>🎬 YouTube Channel Connected</h3>
            <p><strong>Channel:</strong> {channel_name}</p>
            <p><strong>Account:</strong> jasonclarkagain@gmail.com</p>
        </div>
        
        <div class="status-grid">
            <div class="status-item">
                <div><strong>Access Token:</strong></div>
                <div>{'✅ Received' if access_token != 'NOT_RECEIVED' else '❌ Missing'}</div>
                <div><small>Expires in {expires_in} seconds</small></div>
            </div>
            <div class="status-item">
                <div><strong>Refresh Token:</strong></div>
                <div>{'✅ Received' if refresh_token != 'NOT_RECEIVED' else '❌ Missing'}</div>
                <div><small>Permanent access</small></div>
            </div>
        </div>
        
        <div class="token-container">
            <div class="token-label">🔐 REFRESH TOKEN (Save This!):</div>
            <div class="token-value" id="refreshToken">{refresh_token}</div>
            <button class="copy-btn" onclick="copyToken()">📋 Copy Token</button>
        </div>
        
        <div class="next-steps">
            <h4>🚀 Next Steps:</h4>
            <p>✅ YouTube API access confirmed</p>
            <p>✅ Upload permissions granted</p>
            <p>✅ Ready for automated video generation</p>
            <p>🎬 30-day educational series ready to begin</p>
            <p>⏰ Daily uploads will start at 9:00 AM UTC</p>
        </div>
        
        <p><strong>⚠️ Important:</strong> Save the refresh token above securely!</p>
    </div>
    
    <script>
        function copyToken() {{
            const tokenElement = document.getElementById('refreshToken');
            const textArea = document.createElement('textarea');
            textArea.value = tokenElement.textContent;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            
            const btn = document.querySelector('.copy-btn');
            btn.textContent = '✅ Copied!';
            setTimeout(() => {{
                btn.textContent = '📋 Copy Token';
            }}, 2000);
        }}
    </script>
</body>
</html>'''
        
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

    def send_error_page(self, error_message):
        html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Authorization Error</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            padding: 50px; 
            text-align: center; 
            background: linear-gradient(135deg, #f44336, #d32f2f); 
            color: white; 
            min-height: 100vh;
        }}
        .container {{ 
            max-width: 600px; 
            margin: 0 auto; 
            background: rgba(255,255,255,0.1); 
            padding: 40px; 
            border-radius: 20px;
        }}
        .error-icon {{ font-size: 4em; margin-bottom: 20px; }}
        .retry-btn {{ 
            display: inline-block; 
            background: #FF9800; 
            color: white; 
            padding: 12px 24px; 
            border-radius: 25px; 
            text-decoration: none; 
            margin-top: 20px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="error-icon">❌</div>
        <h1>Authorization Failed</h1>
        <p><strong>Error:</strong> {error_message}</p>
        <a href="/" class="retry-btn">🔄 Try Again</a>
    </div>
</body>
</html>'''
        
        self.send_response(500)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

    def send_health_check(self):
        health_data = {{
            "status": "healthy",
            "server": "YouTube OAuth Server",
            "base_url": BASE_URL,
            "redirect_uri": REDIRECT_URI,
            "timestamp": "2025-07-14T18:45:00Z"
        }}
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(json.dumps(health_data, indent=2).encode('utf-8'))

    def send_404(self):
        self.send_response(404)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        html = '''<html><body style="text-align:center;padding:50px;font-family:Arial;">
        <h1>404 - Not Found</h1><a href="/">← Back to Home</a></body></html>'''
        self.wfile.write(html.encode('utf-8'))

    def log_message(self, format, *args):
        # Custom logging format
        print(f"[{self.address_string()}] {format % args}")

def main():
    print("🚀 Starting YouTube OAuth Server")
    print("=" * 50)
    print(f"🌐 Server URL: {BASE_URL}")
    print(f"🔐 Redirect URI: {REDIRECT_URI}")
    print(f"📱 Client ID: {CLIENT_ID}")
    print("=" * 50)
    
    try:
        with socketserver.TCPServer(("0.0.0.0", PORT), OAuthHandler) as httpd:
            print(f"✅ OAuth server running on port {PORT}")
            print(f"🎯 Visit: {BASE_URL}")
            print("📡 Waiting for authorization requests...")
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server shutdown requested")
    except Exception as e:
        print(f"❌ Server error: {e}")

if __name__ == '__main__':
    main()