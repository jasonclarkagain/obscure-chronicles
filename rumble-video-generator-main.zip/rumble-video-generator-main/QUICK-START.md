# Multi-Channel Video Generation - Quick Start Guide

## ✅ Fixed: Use Channel Handles Instead of IDs!

You can now use **simple channel handles** instead of long IDs. No more copying and pasting complex IDs!

## Available Channels

Based on your setup, you have these channels:

| Channel Name | Handle | Category |
|--------------|--------|----------|
| Amazing Learning Adventures | `learningadventures` | education |
| Story Time Magic | `storytimemagic` | entertainment |
| Math Adventures | `mathadventures` | education |

## Quick Commands

### 1. List All Channels
```bash
./multichannel.sh channels
```

### 2. Create Episodes (Using Handle!)
```bash
# Create 5 episodes for Learning Adventures
./multichannel.sh create-episodes learningadventures 5

# Create 10 episodes for Story Time Magic
./multichannel.sh create-episodes storytimemagic 10

# Create 5 episodes for Math Adventures
./multichannel.sh create-episodes mathadventures 5
```

### 3. Pre-Generate Content (Cache Scripts & Thumbnails)
```bash
# Cache 10 scripts and thumbnails for Learning Adventures
./multichannel.sh cache learningadventures 10

# Cache content for Story Time Magic
./multichannel.sh cache storytimemagic 10
```

### 4. Batch Render Videos
```bash
# Render 5 videos for Learning Adventures
./multichannel.sh batch learningadventures 5

# Render 3 videos for Story Time Magic
./multichannel.sh batch storytimemagic 3
```

### 5. Check System Status
```bash
./multichannel.sh status
```

## Typical Workflow

Here's a complete workflow to generate videos for a channel:

```bash
# 1. Check what channels exist
./multichannel.sh channels

# 2. Pre-generate scripts and thumbnails (avoids API rate limits during rendering)
./multichannel.sh cache learningadventures 10

# 3. Create episode entries
./multichannel.sh create-episodes learningadventures 5

# 4. Render all videos
./multichannel.sh batch learningadventures 5

# 5. Check progress
./multichannel.sh status
```

## Output Locations

- **Videos**: `server/output/videos/`
- **Thumbnails**: `server/content_output/thumbnails/`

Videos are ready for manual upload to YouTube!

## Current Status

You currently have:
- **Amazing Learning Adventures**: 5 episodes created (ready to render)
- **Story Time Magic**: 3 episodes created (ready to render)
- **Math Adventures**: 0 episodes (needs episodes created)

## Next Steps

To generate your first batch of videos:

```bash
# Option 1: Generate 3 videos for Learning Adventures
./multichannel.sh cache learningadventures 5
./multichannel.sh batch learningadventures 3

# Option 2: Generate 2 videos for Story Time Magic
./multichannel.sh cache storytimemagic 5
./multichannel.sh batch storytimemagic 2
```

Each video takes about **2-3 minutes** to render (60-second videos at 10 FPS).

## Troubleshooting

**Q: I see "Channel not found" error**
- Make sure you're using the handle without `@` symbol
- Run `./multichannel.sh channels` to see available handles

**Q: Address already in use error**
- This is just noise from the web server running in the background
- The CLI commands still work fine - just ignore this error

**Q: How do I add more channels?**
- Run `./multichannel.sh init` to add the 3 default channels
- Or manually add channels to the database using the storage API
