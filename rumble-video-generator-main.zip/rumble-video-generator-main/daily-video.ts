#!/usr/bin/env tsx
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import OpenAI from 'openai';
import { google } from 'googleapis';

const execAsync = promisify(exec);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// High-view topics that work
const TOPICS = [
  "How to Make Money Online in 2024 - Complete Beginner's Guide",
  "10 Side Hustles That Actually Pay $1000+ Per Month",
  "Passive Income: 7 Ways to Make Money While You Sleep",
  "Best Investment Strategies for Beginners in 2024",
  "How to Budget and Save Money - Simple Tips That Work",
  "Cryptocurrency Explained: Complete Guide for Beginners",
  "How to Start Affiliate Marketing and Make Your First $1000",
  "Real Estate Investing for Beginners - No Money Required",
  "How to Build a Successful YouTube Channel in 2024",
  "Top 10 Online Business Ideas You Can Start Today",
  "Personal Finance Tips Everyone Should Know",
  "How to Improve Your Credit Score Fast",
  "Minimalist Living: How to Declutter Your Life and Save Money",
  "Digital Marketing for Beginners - Complete Guide",
  "How to Start Freelancing and Work From Anywhere",
];

async function generateScript(topic: string): Promise<string> {
  console.log('  Writing script with AI...');
  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{
      role: "user",
      content: `Write a 10-12 minute YouTube video script about: "${topic}"

Make it:
- Engaging hook in first 10 seconds
- Conversational and natural
- Educational with real value
- 5-7 main points with examples
- Strong call to action at end

Write ONLY the narration text, ready to be spoken. No stage directions.`
    }],
    temperature: 0.8
  });
  return response.choices[0].message.content || '';
}

async function generateVoiceover(text: string, output: string): Promise<void> {
  console.log('  Generating voiceover...');
  const mp3 = await openai.audio.speech.create({
    model: "tts-1-hd",
    voice: "onyx",
    input: text,
    speed: 1.0
  });
  const buffer = Buffer.from(await mp3.arrayBuffer());
  fs.writeFileSync(output, buffer);
}

async function createVideo(audioPath: string, title: string, output: string): Promise<void> {
  console.log('  Creating video...');
  
  // Get audio duration
  const { stdout } = await execAsync(`ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${audioPath}"`);
  const duration = Math.ceil(parseFloat(stdout));
  
  // Clean title for display
  const displayTitle = title.split('-')[0].trim();
  
  // Create video with gradient background and text
  await execAsync(`ffmpeg -f lavfi -i "color=c=0x0a0e27:s=1920x1080:d=${duration}" \
    -i "${audioPath}" \
    -vf "drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${displayTitle.replace(/'/g, "\\'")}':fontcolor=white:fontsize=60:x=(w-text_w)/2:y=(h-text_h)/2:borderw=3:bordercolor=black" \
    -c:v libx264 -preset fast -c:a aac -b:a 192k -shortest -pix_fmt yuv420p -y "${output}"`);
}

async function uploadToYouTube(videoPath: string, title: string, description: string): Promise<string | null> {
  const { YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN } = process.env;
  
  if (!YOUTUBE_CLIENT_ID || !YOUTUBE_CLIENT_SECRET || !YOUTUBE_REFRESH_TOKEN) {
    return null;
  }
  
  console.log('  Uploading to YouTube...');
  const oauth2Client = new google.auth.OAuth2(
    YOUTUBE_CLIENT_ID,
    YOUTUBE_CLIENT_SECRET,
    'http://localhost:3000/oauth2callback'
  );
  oauth2Client.setCredentials({ refresh_token: YOUTUBE_REFRESH_TOKEN });
  
  const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
  
  const response = await youtube.videos.insert({
    part: ['snippet', 'status'],
    requestBody: {
      snippet: {
        title,
        description: description.substring(0, 4900) + '\n\n#MakeMoney #Tutorial #Education',
        categoryId: '22',
      },
      status: { privacyStatus: 'public' },
    },
    media: { body: fs.createReadStream(videoPath) },
  });
  
  return response.data.id || null;
}

async function main() {
  console.log('🎬 DAILY VIDEO GENERATOR\n');
  
  // Pick topic (rotate daily)
  const dayOfYear = Math.floor(Date.now() / 86400000);
  const topic = TOPICS[dayOfYear % TOPICS.length];
  const date = new Date().toISOString().split('T')[0];
  
  console.log(`📅 ${date}`);
  console.log(`📝 Topic: ${topic}\n`);
  
  const audioFile = `audio_${date}.mp3`;
  const videoFile = `video_${date}.mp4`;
  
  try {
    // 1. Generate script
    const script = await generateScript(topic);
    console.log(`✅ Script ready (${script.length} chars)\n`);
    
    // 2. Generate voiceover
    await generateVoiceover(script, audioFile);
    console.log('✅ Voiceover created\n');
    
    // 3. Create video
    await createVideo(audioFile, topic, videoFile);
    console.log('✅ Video created\n');
    
    // 4. Upload to YouTube (if credentials exist)
    const videoId = await uploadToYouTube(videoFile, topic, script);
    
    if (videoId) {
      console.log('✅ UPLOADED TO YOUTUBE!');
      console.log(`🔗 https://youtube.com/watch?v=${videoId}\n`);
      // Clean up after successful upload
      fs.unlinkSync(audioFile);
      fs.unlinkSync(videoFile);
    } else {
      console.log('⚠️  No YouTube credentials - video saved locally');
      console.log(`📁 ${videoFile}\n`);
      console.log('To auto-upload: Run get-youtube-credentials.ts\n');
      fs.unlinkSync(audioFile);
    }
    
  } catch (error: any) {
    console.error('❌ ERROR:', error.message);
    process.exit(1);
  }
}

main();
