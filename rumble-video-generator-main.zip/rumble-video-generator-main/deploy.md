# Deployment Configuration

## Required Manual Steps

Since `.replit` file cannot be edited programmatically, you need to manually add the deployment configuration:

### 1. Edit `.replit` file

Open `.replit` and update the `[deployment]` section:

```toml
[deployment]
run = ["npx", "tsx", "server/vite-server.ts"]
deploymentTarget = "cloudrun"
```

### 2. Verify Port Configuration

The server is already configured to:
- ✅ Bind to `0.0.0.0` (required for Cloud Run)
- ✅ Use PORT environment variable
- ✅ Single external port (5000)

### 3. Health Check Endpoints

The application now supports health checks at:
- `/health` - Explicit health check endpoint (returns JSON)
- `/` - Root endpoint (returns JSON for non-browser requests, HTML for browsers)

### 4. Deploy

After updating `.replit`:
1. Click the "Deploy" button in Replit
2. Choose "Autoscale" or "Reserved VM" deployment
3. The deployment will use the configured run command

## Troubleshooting

**If deployment still fails:**
- Ensure only port 5000 is exposed in the Networking tab
- Verify no other ports are configured in `.replit`
- Check deployment logs for specific error messages

**Health Check Issues:**
- The root endpoint now responds to health check probes with JSON
- Browser requests to `/` will still get the React SPA
