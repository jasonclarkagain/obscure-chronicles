import { pgTable, text, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Video Theme Configuration
export const videoThemes = pgTable("video_themes", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  prompts: jsonb("prompts").notNull().$type<{
    scenePrompt: string;
    characterPrompts: string[];
    ambientSounds: string[];
    visualStyle: string;
  }>(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export interface VideoTheme {
  id: string;
  name: string;
  description: string;
  prompts: {
    scenePrompt: string;
    characterPrompts: string[];
    ambientSounds: string[];
    visualStyle: string;
  };
  isActive: boolean | null;
  createdAt: Date | null;
}

// Generated Videos
export const videos = pgTable("videos", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  themeId: text("theme_id").references(() => videoThemes.id),
  status: text("status").notNull().$type<"generating" | "completed" | "uploading" | "uploaded" | "failed">(),
  script: jsonb("script").notNull().$type<{
    scenes: Array<{
      id: string;
      duration: number;
      dialog: Array<{
        character: string;
        text: string;
        audioFile?: string;
        timing: { start: number; end: number };
      }>;
      visualDescription: string;
      backgroundImage?: string;
      characterImages: string[];
      ambientSounds: string[];
      soundEffects: string[];
    }>;
  }>(),
  metadata: jsonb("metadata").$type<{
    duration: number;
    resolution: { width: number; height: number };
    fps: number;
    fileSize?: number;
    youtubeVideoId?: string;
    uploadedAt?: string;
  }>(),
  filePath: text("file_path"),
  thumbnailPath: text("thumbnail_path"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export interface Video {
  id: string;
  title: string;
  description: string;
  themeId: string | null;
  status: "generating" | "completed" | "uploading" | "uploaded" | "failed";
  script: {
    scenes: Array<{
      id: string;
      duration: number;
      dialog: Array<{
        character: string;
        text: string;
        audioFile?: string;
        timing: { start: number; end: number };
      }>;
      visualDescription: string;
      backgroundImage?: string;
      characterImages: string[];
      ambientSounds: string[];
      soundEffects: string[];
    }>;
  };
  metadata: {
    duration: number;
    resolution: { width: number; height: number };
    fps: number;
    fileSize?: number;
    youtubeVideoId?: string;
    uploadedAt?: string;
  } | null;
  filePath: string | null;
  thumbnailPath: string | null;
  createdAt: Date | null;
  completedAt: Date | null;
}

// Characters for multi-character dialog
export const characters = pgTable("characters", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  voiceProfile: jsonb("voice_profile").notNull().$type<{
    gender: "male" | "female";
    age: "child" | "adult" | "elderly";
    personality: string;
    accent?: string;
  }>(),
  visualStyle: text("visual_style").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export interface Character {
  id: string;
  name: string;
  description: string;
  voiceProfile: {
    gender: "male" | "female";
    age: "child" | "adult" | "elderly";
    personality: string;
    accent?: string;
  };
  visualStyle: string;
  isActive: boolean | null;
  createdAt: Date | null;
}

// Generation Queue for scheduling
export const generationQueue = pgTable("generation_queue", {
  id: text("id").primaryKey(),
  themeId: text("theme_id").references(() => videoThemes.id),
  scheduledFor: timestamp("scheduled_for").notNull(),
  status: text("status").notNull().$type<"pending" | "processing" | "completed" | "failed">(),
  retryCount: integer("retry_count").default(0),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export interface GenerationQueue {
  id: string;
  themeId: string | null;
  scheduledFor: Date;
  status: "pending" | "processing" | "completed" | "failed";
  retryCount: number | null;
  errorMessage: string | null;
  createdAt: Date | null;
}

// Schema exports for validation
export const insertVideoThemeSchema = createInsertSchema(videoThemes).omit({
  id: true,
  createdAt: true,
});

export const insertVideoSchema = createInsertSchema(videos).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertCharacterSchema = createInsertSchema(characters).omit({
  id: true,
  createdAt: true,
});

export const insertGenerationQueueSchema = createInsertSchema(generationQueue).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertVideoTheme = z.infer<typeof insertVideoThemeSchema>;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type InsertCharacter = z.infer<typeof insertCharacterSchema>;
export type InsertGenerationQueue = z.infer<typeof insertGenerationQueueSchema>;

// Validation schemas for API
export const createThemeSchema = insertVideoThemeSchema.extend({
  prompts: z.object({
    scenePrompt: z.string().min(10),
    characterPrompts: z.array(z.string()).min(2).max(4),
    ambientSounds: z.array(z.string()),
    visualStyle: z.string().min(5),
  }),
});

export const createCharacterSchema = insertCharacterSchema.extend({
  voiceProfile: z.object({
    gender: z.enum(["male", "female"]),
    age: z.enum(["child", "adult", "elderly"]),
    personality: z.string().min(5),
    accent: z.string().optional(),
  }),
});

// YouTube Channels Management
export const youtubeChannels = pgTable("youtube_channels", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  handle: text("handle").notNull().unique(),
  description: text("description").notNull(),
  category: text("category").notNull().$type<"education" | "entertainment" | "gaming" | "lifestyle" | "technology" | "science" | "arts" | "music">(),
  targetAudience: text("target_audience").notNull().$type<"kids" | "teens" | "adults" | "families" | "professionals">(),
  contentStrategy: jsonb("content_strategy").notNull().$type<{
    uploadSchedule: "daily" | "weekly" | "bi-weekly";
    contentTypes: string[];
    themes: string[];
    tone: "casual" | "professional" | "educational" | "entertaining";
    averageDuration: number;
    monetizationFocus: "ads" | "sponsorships" | "merchandise" | "memberships" | "mixed";
  }>(),
  branding: jsonb("branding").notNull().$type<{
    colorScheme: {
      primary: string;
      secondary: string;
      accent: string;
    };
    logoUrl?: string;
    bannerUrl?: string;
    thumbnailStyle: string;
    fontFamily: string;
  }>(),
  youtubeCredentials: jsonb("youtube_credentials").$type<{
    channelId?: string;
    accessToken?: string;
    refreshToken?: string;
    apiQuota?: number;
  }>(),
  monetization: jsonb("monetization").$type<{
    isEligible?: boolean;
    estimatedRevenue?: number;
    cpm?: number;
    watchTimeTarget?: number;
    subscriberTarget?: number;
    strategies?: string[];
  }>(),
  analytics: jsonb("analytics").$type<{
    subscriberCount?: number;
    totalViews?: number;
    averageViewDuration?: number;
    engagement?: number;
    revenuePerMille?: number;
    growthRate?: number;
    lastUpdated?: string;
  }>(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  lastUpload: timestamp("last_upload"),
});

export interface YouTubeChannel {
  id: string;
  name: string;
  handle: string;
  description: string;
  category: "education" | "entertainment" | "gaming" | "lifestyle" | "technology" | "science" | "arts" | "music";
  targetAudience: "kids" | "teens" | "adults" | "families" | "professionals";
  contentStrategy: {
    uploadSchedule: "daily" | "weekly" | "bi-weekly";
    contentTypes: string[];
    themes: string[];
    tone: "casual" | "professional" | "educational" | "entertaining";
    averageDuration: number;
    monetizationFocus: "ads" | "sponsorships" | "merchandise" | "memberships" | "mixed";
  };
  branding: {
    colorScheme: {
      primary: string;
      secondary: string;
      accent: string;
    };
    logoUrl?: string;
    bannerUrl?: string;
    thumbnailStyle: string;
    fontFamily: string;
  };
  youtubeCredentials?: {
    channelId?: string;
    accessToken?: string;
    refreshToken?: string;
    apiQuota?: number;
  };
  monetization?: {
    isEligible?: boolean;
    estimatedRevenue?: number;
    cpm?: number;
    watchTimeTarget?: number;
    subscriberTarget?: number;
    strategies?: string[];
  };
  analytics?: {
    subscriberCount?: number;
    totalViews?: number;
    averageViewDuration?: number;
    engagement?: number;
    revenuePerMille?: number;
    growthRate?: number;
    lastUpdated?: string;
  };
  isActive: boolean | null;
  createdAt: Date | null;
  lastUpload: Date | null;
}

// Schema exports for new tables
export const insertYouTubeChannelSchema = createInsertSchema(youtubeChannels).omit({
  id: true,
  createdAt: true,
  lastUpload: true,
});

export type InsertYouTubeChannel = z.infer<typeof insertYouTubeChannelSchema>;

// Episodes for Multi-Channel System
export const episodes = pgTable("episodes", {
  id: text("id").primaryKey(),
  channelId: text("channel_id").references(() => youtubeChannels.id).notNull(),
  episodeNumber: integer("episode_number").notNull(),
  title: text("title").notNull(),
  topic: text("topic").notNull(),
  status: text("status").notNull().$type<"pending" | "content_ready" | "rendering" | "completed" | "failed">(),
  phase: text("phase").notNull().$type<"init" | "script" | "thumbnail" | "video" | "done">(),
  scriptCacheId: text("script_cache_id"),
  thumbnailCacheId: text("thumbnail_cache_id"),
  videoPath: text("video_path"),
  duration: integer("duration").default(90),
  errorMessage: text("error_message"),
  retryCount: integer("retry_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export interface Episode {
  id: string;
  channelId: string;
  episodeNumber: number;
  title: string;
  topic: string;
  status: "pending" | "content_ready" | "rendering" | "completed" | "failed";
  phase: "init" | "script" | "thumbnail" | "video" | "done";
  scriptCacheId: string | null;
  thumbnailCacheId: string | null;
  videoPath: string | null;
  duration: number | null;
  errorMessage: string | null;
  retryCount: number | null;
  createdAt: Date | null;
  completedAt: Date | null;
}

// Content Cache for Pre-generated Assets
export const contentCache = pgTable("content_cache", {
  id: text("id").primaryKey(),
  type: text("type").notNull().$type<"script" | "thumbnail">(),
  channelId: text("channel_id").references(() => youtubeChannels.id),
  data: jsonb("data").notNull().$type<{
    script?: {
      title: string;
      description: string;
      scenes: Array<{
        text: string;
        duration: number;
        visualCue: string;
      }>;
      tags: string[];
    };
    thumbnailPath?: string;
    metadata?: Record<string, any>;
  }>(),
  isUsed: boolean("is_used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export interface ContentCache {
  id: string;
  type: "script" | "thumbnail";
  channelId: string | null;
  data: {
    script?: {
      title: string;
      description: string;
      scenes: Array<{
        text: string;
        duration: number;
        visualCue: string;
      }>;
      tags: string[];
    };
    thumbnailPath?: string;
    metadata?: Record<string, any>;
  };
  isUsed: boolean | null;
  createdAt: Date | null;
}

// Insert schemas
export const insertEpisodeSchema = createInsertSchema(episodes).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertContentCacheSchema = createInsertSchema(contentCache).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertEpisode = z.infer<typeof insertEpisodeSchema>;
export type InsertContentCache = z.infer<typeof insertContentCacheSchema>;

// Rumble Campaign Management
export const rumbleCampaigns = pgTable("rumble_campaigns", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().$type<"active" | "paused" | "completed" | "failed">(),
  startDate: timestamp("start_date").notNull(),
  targetDays: integer("target_days").notNull().default(30),
  videosGenerated: integer("videos_generated").default(0),
  currentDay: integer("current_day").default(0),
  targetDuration: integer("target_duration").notNull().default(1800),
  lastGeneratedAt: timestamp("last_generated_at"),
  nextScheduledAt: timestamp("next_scheduled_at"),
  lastRunStatus: text("last_run_status").$type<"success" | "failed" | "skipped" | null>(),
  config: jsonb("config").notNull().$type<{
    topics: string[];
    videoStyle: "educational" | "entertainment" | "documentary" | "tutorial";
    voicePreference: "male" | "female" | "mixed";
    uploadToGoogleDrive: boolean;
    googleDriveFolderId?: string;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export interface RumbleCampaign {
  id: string;
  name: string;
  description: string;
  status: "active" | "paused" | "completed" | "failed";
  startDate: Date;
  targetDays: number;
  videosGenerated: number | null;
  currentDay: number | null;
  targetDuration: number;
  lastGeneratedAt: Date | null;
  nextScheduledAt: Date | null;
  lastRunStatus: "success" | "failed" | "skipped" | null;
  config: {
    topics: string[];
    videoStyle: "educational" | "entertainment" | "documentary" | "tutorial";
    voicePreference: "male" | "female" | "mixed";
    uploadToGoogleDrive: boolean;
    googleDriveFolderId?: string;
  };
  createdAt: Date | null;
  completedAt: Date | null;
}

// Rumble Videos
export const rumbleVideos = pgTable("rumble_videos", {
  id: text("id").primaryKey(),
  campaignId: text("campaign_id").references(() => rumbleCampaigns.id),
  dayNumber: integer("day_number").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  topic: text("topic").notNull(),
  status: text("status").notNull().$type<"queued" | "generating" | "completed" | "failed" | "uploaded_gdrive">(),
  script: text("script"),
  transcriptChecksum: text("transcript_checksum"),
  duration: integer("duration"),
  filePath: text("file_path"),
  fileSize: integer("file_size"),
  googleDriveFileId: text("google_drive_file_id"),
  googleDriveUrl: text("google_drive_url"),
  metadata: jsonb("metadata").$type<{
    resolution: { width: number; height: number };
    fps: number;
    audioFormat: string;
    videoCodec: string;
    bitrate?: number;
    chapters?: Array<{
      title: string;
      startTime: number;
      duration: number;
    }>;
  }>(),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export interface RumbleVideo {
  id: string;
  campaignId: string | null;
  dayNumber: number;
  title: string;
  description: string;
  topic: string;
  status: "queued" | "generating" | "completed" | "failed" | "uploaded_gdrive";
  script: string | null;
  transcriptChecksum: string | null;
  duration: number | null;
  filePath: string | null;
  fileSize: number | null;
  googleDriveFileId: string | null;
  googleDriveUrl: string | null;
  metadata: {
    resolution: { width: number; height: number };
    fps: number;
    audioFormat: string;
    videoCodec: string;
    bitrate?: number;
    chapters?: Array<{
      title: string;
      startTime: number;
      duration: number;
    }>;
  } | null;
  errorMessage: string | null;
  createdAt: Date | null;
  completedAt: Date | null;
}

// Insert schemas
export const insertRumbleCampaignSchema = createInsertSchema(rumbleCampaigns).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertRumbleVideoSchema = createInsertSchema(rumbleVideos).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

// Types
export type InsertRumbleCampaign = z.infer<typeof insertRumbleCampaignSchema>;
export type InsertRumbleVideo = z.infer<typeof insertRumbleVideoSchema>;

// Validation schemas for API
export const createRumbleCampaignSchema = insertRumbleCampaignSchema.extend({
  config: z.object({
    topics: z.array(z.string()).default([]),
    videoStyle: z.enum(["educational", "entertainment", "documentary", "tutorial"]),
    voicePreference: z.enum(["male", "female", "mixed"]),
    uploadToGoogleDrive: z.boolean().default(false),
    googleDriveFolderId: z.string().optional()
  })
});

export const updateRumbleCampaignSchema = createRumbleCampaignSchema.partial();