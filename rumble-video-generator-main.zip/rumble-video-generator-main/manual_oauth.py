#!/usr/bin/env python3

import urllib.parse
import json
import urllib.request
import webbrowser

# Your credentials
CLIENT_ID = "205140773221-l05997n9e8864fvj2ks2tve2pj7b2blp.apps.googleusercontent.com"
CLIENT_SECRET = "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"
REDIRECT_URI = "https://a542f69f-89b0-40c4-91f0-9684c95170bd-00-1qklzlvyeiq1b.kirk.replit.dev/oauth2callback"

def generate_auth_url():
    """Generate YouTube OAuth authorization URL"""
    params = {
        'client_id': CLIENT_ID,
        'redirect_uri': REDIRECT_URI,
        'scope': 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube',
        'response_type': 'code',
        'access_type': 'offline',
        'prompt': 'consent',
        'include_granted_scopes': 'true'
    }
    
    auth_url = 'https://accounts.google.com/o/oauth2/auth?' + urllib.parse.urlencode(params)
    return auth_url

def exchange_code_for_tokens(authorization_code):
    """Exchange authorization code for tokens"""
    token_data = {
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'code': authorization_code,
        'grant_type': 'authorization_code',
        'redirect_uri': REDIRECT_URI
    }
    
    try:
        req = urllib.request.Request(
            'https://oauth2.googleapis.com/token',
            data=urllib.parse.urlencode(token_data).encode(),
            headers={'Content-Type': 'application/x-www-form-urlencoded'}
        )
        
        with urllib.request.urlopen(req) as response:
            tokens = json.loads(response.read().decode())
            return tokens
    except Exception as e:
        print(f"Token exchange failed: {e}")
        return None

def test_youtube_access(access_token):
    """Test YouTube API access"""
    try:
        req = urllib.request.Request(
            'https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true',
            headers={'Authorization': f'Bearer {access_token}'}
        )
        
        with urllib.request.urlopen(req) as response:
            data = json.loads(response.read().decode())
            if data.get('items'):
                channel = data['items'][0]['snippet']
                return channel['title']
            return None
    except Exception as e:
        print(f"YouTube test failed: {e}")
        return None

def main():
    print("🔐 YouTube OAuth Authorization")
    print("=" * 50)
    
    # Generate authorization URL
    auth_url = generate_auth_url()
    print(f"1. Visit this URL to authorize:")
    print(f"   {auth_url}")
    print()
    print("2. Sign in with: jasonclarkagain@gmail.com")
    print("3. Grant YouTube permissions")
    print("4. Copy the authorization code from the callback URL")
    print()
    
    # Get authorization code from user
    auth_code = input("Enter the authorization code: ").strip()
    
    if not auth_code:
        print("No authorization code provided")
        return
    
    print("Exchanging code for tokens...")
    tokens = exchange_code_for_tokens(auth_code)
    
    if not tokens:
        print("Failed to get tokens")
        return
    
    print("✅ Token exchange successful!")
    print(f"Access token: {'✅' if 'access_token' in tokens else '❌'}")
    print(f"Refresh token: {'✅' if 'refresh_token' in tokens else '❌'}")
    
    # Test YouTube access
    if 'access_token' in tokens:
        channel_name = test_youtube_access(tokens['access_token'])
        if channel_name:
            print(f"✅ Connected to YouTube channel: {channel_name}")
        else:
            print("⚠️ YouTube API test failed")
    
    # Display refresh token
    refresh_token = tokens.get('refresh_token')
    if refresh_token:
        print()
        print("🔑 REFRESH TOKEN (Save this!):")
        print("=" * 50)
        print(refresh_token)
        print("=" * 50)
        print()
        print("✅ Ready to start YouTube automation!")
    else:
        print("❌ No refresh token received")

if __name__ == '__main__':
    main()