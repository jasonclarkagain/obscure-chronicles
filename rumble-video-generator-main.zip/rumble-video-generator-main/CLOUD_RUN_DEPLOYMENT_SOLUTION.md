# ✅ CLOUD RUN DEPLOYMENT - DEFINITIVE SOLUTION

## THE PROBLEM
Cloud Run deployment keeps failing with "Port 24678 is already in use" because:
1. The `.replit` deployment configuration runs `server/vite-server.ts`
2. Without `NODE_ENV=production`, Vite starts HMR on port 24678
3. Cloud Run expects the app to listen on `process.env.PORT` (usually 8080)
4. The Replit port mapping (24678→80) conflicts with Cloud Run

## THE SOLUTION

### Option 1: Deploy with Custom Script (RECOMMENDED)
```bash
# This uses our Cloud Run specific entry point
./deploy-to-cloudrun.sh YOUR_PROJECT_ID us-central1
```

This script:
- Uses `Dockerfile.cloudrun` which sets NODE_ENV=production
- Runs `server/cloud-run-entry.ts` which NEVER uses Vite
- Only listens on Cloud Run's PORT variable
- Completely avoids port 24678

### Option 2: Manual Cloud Run Deployment

1. **Build the container:**
```bash
docker build -f Dockerfile.cloudrun -t gcr.io/YOUR_PROJECT/rumble-video .
```

2. **Push to registry:**
```bash
docker push gcr.io/YOUR_PROJECT/rumble-video
```

3. **Deploy with correct settings:**
```bash
gcloud run deploy rumble-video \
  --image gcr.io/YOUR_PROJECT/rumble-video \
  --set-env-vars="NODE_ENV=production" \
  --port 8080
```

### Option 3: Fix Replit Deployment Configuration

Since you cannot edit `.replit` directly, you need to:

1. **In Replit Deployment Settings:**
   - Change the run command from `npx tsx server/vite-server.ts`
   - To: `NODE_ENV=production npx tsx server/cloud-run-entry.ts`

2. **Or set environment variables:**
   - `NODE_ENV=production`
   - Let Cloud Run provide PORT automatically

## WHY THIS WORKS

### The Problem Flow:
```
.replit says: run server/vite-server.ts
  ↓
vite-server.ts starts without NODE_ENV=production
  ↓
Vite creates HMR server on port 24678
  ↓
Port 24678 conflicts → EADDRINUSE error
  ↓
Server crashes and restarts repeatedly
```

### The Solution Flow:
```
Cloud Run runs: server/cloud-run-entry.ts
  ↓
Sets NODE_ENV=production immediately
  ↓
NO Vite middleware, NO HMR
  ↓
Only listens on process.env.PORT (8080)
  ↓
No port conflicts, deployment succeeds! ✅
```

## FILES CREATED

1. **`server/cloud-run-entry.ts`**
   - Production-only server
   - No Vite, no HMR, no port 24678
   - Only uses Cloud Run's PORT

2. **`Dockerfile.cloudrun`**
   - Multi-stage build
   - Sets NODE_ENV=production
   - Uses cloud-run-entry.ts

3. **`deploy-to-cloudrun.sh`**
   - Automated deployment script
   - Configures everything correctly

## VERIFICATION

After deployment, verify it's working:
```bash
# Check health
curl YOUR_SERVICE_URL/health

# View logs
gcloud run logs read --service=rumble-video-generator

# Check for port issues
gcloud run services describe rumble-video-generator | grep PORT
```

## IMPORTANT NOTES

⚠️ **NEVER use `server/vite-server.ts` for Cloud Run deployments**
- It starts Vite HMR on port 24678
- Cloud Run needs exclusive control of its assigned PORT

✅ **ALWAYS use `server/cloud-run-entry.ts` for Cloud Run**
- Production-only, no development features
- Respects Cloud Run's PORT environment variable
- No port conflicts

## SUCCESS CRITERIA

Your deployment succeeds when:
- ✅ No EADDRINUSE errors
- ✅ Server listens on PORT from environment (8080)
- ✅ Health check responds at /health
- ✅ No mention of port 24678 in logs
- ✅ NODE_ENV is "production"

---

This is the definitive solution that bypasses all Replit port configuration issues and works perfectly with Cloud Run's requirements.