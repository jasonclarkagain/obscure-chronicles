# 🔧 Fix GitHub Authentication & Workflow Scope Error

## The Problem
You're getting a "workflow scope" error because GitHub needs proper authentication permissions to:
- Push code to your repository
- Create/modify GitHub Actions workflows
- Access the repository fully

## Solution 1: Use GitHub Personal Access Token (Recommended)

### Step 1: Create a Personal Access Token
1. Go to GitHub.com → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Or directly visit: https://github.com/settings/tokens/new
3. Create a new token with these scopes:
   - ✅ **repo** (Full control of private repositories)
   - ✅ **workflow** (Update GitHub Action workflows)
   - ✅ **write:packages** (Upload packages to GitHub)
   - ✅ **delete:packages** (Delete packages from GitHub)
4. Set expiration (recommend 90 days)
5. Click "Generate token"
6. **COPY THE TOKEN NOW** (you won't see it again!)

### Step 2: Configure Git to Use Token
In your Replit Shell, run:
```bash
# Set your GitHub username and email
git config --global user.name "YOUR_GITHUB_USERNAME"
git config --global user.email "YOUR_EMAIL@gmail.com"

# Update the remote URL to use token authentication
git remote set-url origin https://YOUR_GITHUB_USERNAME:YOUR_TOKEN@github.com/jasonclarkagain/rumble-video-generator.git
```

Replace:
- `YOUR_GITHUB_USERNAME` with your actual GitHub username
- `YOUR_TOKEN` with the token you just created
- `YOUR_EMAIL@gmail.com` with your GitHub email

### Step 3: Push Your Code
```bash
# Now push should work:
git add .
git commit -m "Add Codespaces configuration and documentation"
git push origin main
```

## Solution 2: Use GitHub CLI (Alternative)

### Step 1: Authenticate with GitHub CLI
```bash
# Login to GitHub
gh auth login

# Choose:
# - GitHub.com
# - HTTPS
# - Authenticate with a web browser (or paste token)
# - Follow the prompts
```

### Step 2: Set Required Scopes
```bash
# Ensure you have workflow scope
gh auth refresh -s workflow,repo,write:packages
```

### Step 3: Push Using GitHub CLI
```bash
# Push your code
gh repo sync
# or
git push
```

## Solution 3: Use SSH Key (Advanced)

### Step 1: Generate SSH Key
```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
# Press Enter for default location
# Set a passphrase (optional)
```

### Step 2: Add SSH Key to GitHub
```bash
# Copy your public key
cat ~/.ssh/id_ed25519.pub

# Go to GitHub.com → Settings → SSH and GPG keys
# Click "New SSH key"
# Paste the key and save
```

### Step 3: Update Remote to Use SSH
```bash
git remote set-url origin git@github.com:jasonclarkagain/rumble-video-generator.git
```

## Quick Fix Script
Run this complete script after creating your token:
```bash
#!/bin/bash
echo "Enter your GitHub username:"
read GITHUB_USER
echo "Enter your GitHub personal access token:"
read -s GITHUB_TOKEN
echo "Enter your email:"
read EMAIL

# Configure git
git config --global user.name "$GITHUB_USER"
git config --global user.email "$EMAIL"

# Update remote with authentication
git remote set-url origin https://${GITHUB_USER}:${GITHUB_TOKEN}@github.com/jasonclarkagain/rumble-video-generator.git

# Test push
git add .
git commit -m "Add Codespaces configuration"
git push origin main

echo "✅ GitHub authentication configured successfully!"
```

## After Fixing Authentication

Once authentication works:
1. Your code will push to GitHub
2. Go to https://github.com/jasonclarkagain/rumble-video-generator
3. Click "Code" → "Codespaces" → "Create codespace on main"
4. Your development environment will be ready!

## Important Notes
- **Keep your token secret** - Never commit it to code
- **Token expiration** - Set a reminder to renew before it expires
- **Scope requirements** - The "workflow" scope is required for GitHub Actions

## Still Having Issues?

If you continue to see errors:
1. Verify your token has the correct scopes
2. Check that your GitHub username is correct
3. Ensure the repository exists at the URL
4. Try creating a new token with all scopes selected

The key is ensuring your token has both **repo** and **workflow** scopes enabled!