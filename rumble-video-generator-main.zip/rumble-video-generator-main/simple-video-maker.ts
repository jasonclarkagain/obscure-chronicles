#!/usr/bin/env npx tsx

import fs from "fs";
import path from "path";
import { createCanvas } from "canvas";
import { execSync } from "child_process";

console.log("🎬 Creating 30+ minute Rumble video...\n");

const outputDir = "./rumble_videos";
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Create a single image
console.log("🖼️ Creating video content...");
const canvas = createCanvas(1920, 1080);
const ctx = canvas.getContext("2d");

// Ocean theme background
const gradient = ctx.createLinearGradient(0, 0, 0, 1080);
gradient.addColorStop(0, "#001f3f");
gradient.addColorStop(0.5, "#004080");
gradient.addColorStop(1, "#0066cc");
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, 1920, 1080);

// Add wave patterns
ctx.strokeStyle = "rgba(255,255,255,0.2)";
ctx.lineWidth = 4;
for (let i = 0; i < 10; i++) {
  ctx.beginPath();
  for (let x = 0; x <= 1920; x += 20) {
    const y = 540 + Math.sin(x * 0.01 + i) * 100 * Math.sin(i);
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
}

// Title
ctx.fillStyle = "#FFFFFF";
ctx.font = "bold 120px Arial";
ctx.textAlign = "center";
ctx.shadowColor = "rgba(0,0,0,0.8)";
ctx.shadowBlur = 30;
ctx.fillText("Ocean Education", 960, 400);

ctx.font = "60px Arial";
ctx.fillText("30+ Minute Educational Video", 960, 520);

ctx.font = "48px Arial";
ctx.fillText("Perfect for Rumble Streaming", 960, 620);

// Duration indicator
ctx.fillStyle = "rgba(255,255,255,0.9)";
ctx.font = "36px Arial";
ctx.fillText("Duration: 31 minutes | 1920x1080 HD | Educational Content", 960, 900);

// Save image
const imagePath = path.join(outputDir, "video_frame.png");
fs.writeFileSync(imagePath, canvas.toBuffer("image/png"));
console.log("✅ Content created");

// Create video using FFmpeg directly
console.log("🎥 Generating 31-minute video...");
const videoPath = path.join(outputDir, `rumble_video_${Date.now()}.mp4`);

try {
  // Create 31-minute video from single image
  const ffmpegCmd = `ffmpeg -loop 1 -i ${imagePath} -c:v libx264 -t 1860 -pix_fmt yuv420p -preset ultrafast -an ${videoPath} -y 2>/dev/null`;
  
  console.log("Encoding... (this takes about 30 seconds)");
  execSync(ffmpegCmd, { stdio: 'inherit' });
  
  const stats = fs.statSync(videoPath);
  
  console.log("\n" + "=".repeat(70));
  console.log("✅ ✅ ✅ VIDEO SUCCESSFULLY CREATED! ✅ ✅ ✅");
  console.log("=".repeat(70));
  console.log(`📍 Location: ${videoPath}`);
  console.log(`📁 File size: ${(stats.size / 1024 / 1024).toFixed(2)} MB`);
  console.log(`⏱️ Duration: 31 minutes`);
  console.log(`🎬 Resolution: 1920x1080 HD`);
  console.log(`📺 Format: MP4 (H.264)`);
  console.log("=".repeat(70));
  console.log("🚀 READY TO UPLOAD TO RUMBLE!");
  console.log("=".repeat(70));
  
} catch (error) {
  console.error("Error:", error.message);
  process.exit(1);
}

console.log("\n✨ Done! Your 30+ minute video is ready for Rumble!");