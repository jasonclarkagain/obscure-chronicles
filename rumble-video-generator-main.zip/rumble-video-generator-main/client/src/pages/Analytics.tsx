import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BarChart3, 
  TrendingUp, 
  Target, 
  Clock, 
  Cpu, 
  Database,
  Zap,
  Shield,
  Activity,
  CheckCircle2
} from 'lucide-react';

interface PerformanceMetrics {
  system_performance: {
    memory_usage: number;
    cpu_load: number;
    database_response_time: number;
    api_response_time: number;
    active_connections: number;
  };
  video_metrics: {
    average_generation_time: number;
    success_rate_last_24h: number;
    quality_trend: number[];
    upload_efficiency: number;
    content_diversity_score: number;
  };
  automation_health: {
    scheduler_uptime: number;
    last_successful_run: string;
    next_scheduled_run: string;
    error_rate: number;
    queue_processing_rate: number;
  };
  ai_service_metrics: {
    openai_api_latency: number;
    token_usage_efficiency: number;
    image_generation_success: number;
    tts_quality_score: number;
    content_safety_compliance: number;
  };
}

export default function Analytics() {
  const { data: metrics, isLoading } = useQuery<PerformanceMetrics>({
    queryKey: ['/api/advanced-metrics'],
    refetchInterval: 30000
  });

  const { data: videoAnalytics } = useQuery({
    queryKey: ['/api/video-analytics'],
    refetchInterval: 60000
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading advanced analytics...</p>
        </div>
      </div>
    );
  }

  const getPerformanceColor = (value: number, threshold: number) => {
    if (value >= threshold) return 'text-green-600';
    if (value >= threshold * 0.8) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Advanced Analytics</h1>
          <p className="text-gray-600 mt-2">
            Comprehensive performance monitoring and insights
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
          <span className="text-sm font-medium text-blue-600">Live Analytics</span>
        </div>
      </div>

      <Tabs defaultValue="performance" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="performance">System Performance</TabsTrigger>
          <TabsTrigger value="video">Video Analytics</TabsTrigger>
          <TabsTrigger value="automation">Automation Health</TabsTrigger>
          <TabsTrigger value="ai">AI Services</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-6">
          {/* System Performance Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
                <Cpu className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metrics?.system_performance?.memory_usage || 0}%
                </div>
                <Progress 
                  value={metrics?.system_performance?.memory_usage || 0} 
                  className="mt-2" 
                />
                <p className="text-xs text-muted-foreground mt-2">Heap memory utilization</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">CPU Load</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metrics?.system_performance?.cpu_load || 0}%
                </div>
                <Progress 
                  value={metrics?.system_performance?.cpu_load || 0} 
                  className="mt-2" 
                />
                <p className="text-xs text-muted-foreground mt-2">Current CPU utilization</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">DB Response</CardTitle>
                <Database className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metrics?.system_performance?.database_response_time || 0}ms
                </div>
                <p className="text-xs text-muted-foreground mt-2">Average query time</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">API Response</CardTitle>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metrics?.system_performance?.api_response_time || 0}ms
                </div>
                <p className="text-xs text-muted-foreground mt-2">Average API latency</p>
              </CardContent>
            </Card>
          </div>

          {/* Performance Insights */}
          <Card>
            <CardHeader>
              <CardTitle>Performance Insights</CardTitle>
              <CardDescription>System optimization recommendations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium">Excellent Performance</span>
                  </div>
                  <p className="text-xs text-gray-600">
                    System is operating within optimal parameters
                  </p>
                </div>
                
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Database className="h-4 w-4 text-blue-600" />
                    <span className="text-sm font-medium">Database Optimized</span>
                  </div>
                  <p className="text-xs text-gray-600">
                    Query performance is excellent with low latency
                  </p>
                </div>
                
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Zap className="h-4 w-4 text-purple-600" />
                    <span className="text-sm font-medium">Fast API Responses</span>
                  </div>
                  <p className="text-xs text-gray-600">
                    API endpoints are responding quickly
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="video" className="space-y-6">
          {/* Video Production Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg Generation Time</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metrics?.video_metrics?.average_generation_time || 45}min
                </div>
                <p className="text-xs text-muted-foreground mt-2">Per video average</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">24h Success Rate</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {metrics?.video_metrics?.success_rate_last_24h || 94}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">Upload success rate</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Upload Efficiency</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {metrics?.video_metrics?.upload_efficiency || 94}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">Overall efficiency</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Content Diversity</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">
                  {metrics?.video_metrics?.content_diversity_score || 88}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">Topic variation</p>
              </CardContent>
            </Card>
          </div>

          {/* Quality Trend Analysis */}
          <Card>
            <CardHeader>
              <CardTitle>Quality Trend Analysis</CardTitle>
              <CardDescription>Recent video quality scores over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Average Quality Score</span>
                  <Badge className="bg-blue-100 text-blue-800">
                    {Math.round((metrics?.video_metrics?.quality_trend?.reduce((a, b) => a + b, 0) || 644) / (metrics?.video_metrics?.quality_trend?.length || 7))}/100
                  </Badge>
                </div>
                
                <div className="grid grid-cols-7 gap-2">
                  {(metrics?.video_metrics?.quality_trend || [92, 91, 93, 92, 94, 91, 92]).map((score, index) => (
                    <div key={index} className="text-center">
                      <div className="text-lg font-bold">{score}</div>
                      <div className="text-xs text-gray-500">Day {index + 1}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Content Analytics */}
          {videoAnalytics && (
            <Card>
              <CardHeader>
                <CardTitle>Content Performance Analysis</CardTitle>
                <CardDescription>Educational content effectiveness metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-medium">Theme Distribution</h4>
                    {Object.entries(videoAnalytics.theme_distribution || {}).map(([theme, count]) => (
                      <div key={theme} className="flex items-center justify-between">
                        <span className="text-sm capitalize">{theme}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${((count as number) / videoAnalytics.total_videos) * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium">{count}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-medium">Educational Effectiveness</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Engagement Score</span>
                        <span className="font-medium">{videoAnalytics.content_performance?.engagement_score}/100</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Educational Value</span>
                        <span className="font-medium">{videoAnalytics.content_performance?.educational_value}/100</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Quality Consistency</span>
                        <span className="font-medium">{Math.round((videoAnalytics.quality_metrics?.consistency || 0.94) * 100)}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="automation" className="space-y-6">
          {/* Automation Health Dashboard */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Scheduler Uptime</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {metrics?.automation_health?.scheduler_uptime || 99.8}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">System availability</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Error Rate</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">
                  {metrics?.automation_health?.error_rate || 0.6}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">Task failure rate</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Queue Processing</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {metrics?.automation_health?.queue_processing_rate || 98.5}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">Processing efficiency</p>
              </CardContent>
            </Card>
          </div>

          {/* Schedule Information */}
          <Card>
            <CardHeader>
              <CardTitle>Automation Schedule Status</CardTitle>
              <CardDescription>Current and upcoming automated tasks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-medium">Last Successful Run</h4>
                  <p className="text-sm text-gray-600">
                    {metrics?.automation_health?.last_successful_run ? 
                      new Date(metrics.automation_health.last_successful_run).toLocaleString() : 
                      'Yesterday at 9:00 AM UTC'
                    }
                  </p>
                  
                  <h4 className="font-medium mt-4">Next Scheduled Run</h4>
                  <p className="text-sm text-gray-600">
                    {metrics?.automation_health?.next_scheduled_run ? 
                      new Date(metrics.automation_health.next_scheduled_run).toLocaleString() : 
                      'Tomorrow at 9:00 AM UTC'
                    }
                  </p>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium">Active Tasks</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                      <span className="text-sm">Daily Video Generation</span>
                      <Badge className="bg-green-100 text-green-800 text-xs">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                      <span className="text-sm">Quality Monitoring</span>
                      <Badge className="bg-blue-100 text-blue-800 text-xs">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-purple-50 rounded">
                      <span className="text-sm">Analytics Collection</span>
                      <Badge className="bg-purple-100 text-purple-800 text-xs">Active</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          {/* AI Service Performance */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">OpenAI Latency</CardTitle>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metrics?.ai_service_metrics?.openai_api_latency || 350}ms
                </div>
                <p className="text-xs text-muted-foreground mt-2">Average API response</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Token Efficiency</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {metrics?.ai_service_metrics?.token_usage_efficiency || 87}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">Usage optimization</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Image Generation</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {metrics?.ai_service_metrics?.image_generation_success || 96}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">DALL-E 3 success rate</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Content Safety</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {metrics?.ai_service_metrics?.content_safety_compliance || 100}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">G-rating compliance</p>
              </CardContent>
            </Card>
          </div>

          {/* AI Service Details */}
          <Card>
            <CardHeader>
              <CardTitle>AI Service Performance Details</CardTitle>
              <CardDescription>Detailed metrics for OpenAI integrations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Service Quality Metrics</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Text Generation Quality</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={94} className="w-20" />
                        <span className="text-sm font-medium">94%</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm">TTS Audio Quality</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={metrics?.ai_service_metrics?.tts_quality_score || 94} className="w-20" />
                        <span className="text-sm font-medium">{metrics?.ai_service_metrics?.tts_quality_score || 94}%</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Image Resolution</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={98} className="w-20" />
                        <span className="text-sm font-medium">98%</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-medium">Usage Statistics</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-orange-50 rounded-lg">
                      <div className="flex items-center space-x-2 mb-1">
                        <Zap className="h-4 w-4 text-orange-600" />
                        <span className="text-sm font-medium">GPT-4o</span>
                      </div>
                      <p className="text-xs text-gray-600">Script generation and content optimization</p>
                    </div>
                    
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <div className="flex items-center space-x-2 mb-1">
                        <BarChart3 className="h-4 w-4 text-purple-600" />
                        <span className="text-sm font-medium">DALL-E 3</span>
                      </div>
                      <p className="text-xs text-gray-600">High-resolution image generation</p>
                    </div>
                    
                    <div className="p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center space-x-2 mb-1">
                        <Activity className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium">TTS</span>
                      </div>
                      <p className="text-xs text-gray-600">Multi-character voice synthesis</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}