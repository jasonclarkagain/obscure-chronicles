import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Youtube, Video, Database, PlayCircle, Plus, FileText, Image as ImageIcon, CheckCircle, Clock, XCircle } from "lucide-react";
import type { YouTubeChannel, Episode } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Channels() {
  const { toast } = useToast();
  const [selectedChannel, setSelectedChannel] = useState<string | null>(null);

  const { data: channels, isLoading: loadingChannels } = useQuery<YouTubeChannel[]>({
    queryKey: ["/api/youtube-channels"],
  });

  const { data: allEpisodes } = useQuery<Episode[]>({
    queryKey: ["/api/episodes"],
  });

  const cacheContentMutation = useMutation({
    mutationFn: async ({ channelId, count }: { channelId: string; count: number }) => {
      return apiRequest("/api/jobs/cache-content", {
        method: "POST",
        body: JSON.stringify({ channelId, count }),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Content Caching Started",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/content-cache"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createEpisodesMutation = useMutation({
    mutationFn: async ({ channelId, count }: { channelId: string; count: number }) => {
      return apiRequest("/api/jobs/create-episodes", {
        method: "POST",
        body: JSON.stringify({ channelId, count }),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Episodes Created",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/episodes"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const batchRenderMutation = useMutation({
    mutationFn: async ({ channelId, count }: { channelId: string; count: number }) => {
      return apiRequest("/api/jobs/batch-render", {
        method: "POST",
        body: JSON.stringify({ channelId, count }),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Batch Rendering Started",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/episodes"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (loadingChannels) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Channels</h1>
        <p className="text-muted-foreground">Loading channels...</p>
      </div>
    );
  }

  const activeChannels = channels?.filter(c => c.isActive) || [];
  const selectedChannelData = selectedChannel ? channels?.find(c => c.id === selectedChannel) : null;
  const channelEpisodes = selectedChannel ? allEpisodes?.filter(e => e.channelId === selectedChannel) || [] : [];

  const getEpisodeStats = (episodes: Episode[]) => {
    return {
      pending: episodes.filter(e => e.status === "pending").length,
      rendering: episodes.filter(e => e.status === "rendering").length,
      completed: episodes.filter(e => e.status === "completed").length,
      failed: episodes.filter(e => e.status === "failed").length,
    };
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">YouTube Channels</h1>
        <p className="text-muted-foreground mt-2">
          Manage your multi-channel video production pipeline
        </p>
      </div>

      {activeChannels.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Youtube className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Channels Yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first channel to start generating videos
            </p>
            <Button data-testid="button-create-first-channel">
              <Plus className="mr-2 h-4 w-4" />
              Create Channel
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {activeChannels.map((channel) => {
            const episodes = allEpisodes?.filter(e => e.channelId === channel.id) || [];
            const stats = getEpisodeStats(episodes);

            return (
              <Card
                key={channel.id}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedChannel === channel.id ? "ring-2 ring-primary" : ""
                }`}
                onClick={() => setSelectedChannel(channel.id)}
                style={{ borderTopColor: channel.branding.colorScheme.primary, borderTopWidth: "4px" }}
                data-testid={`channel-card-${channel.id}`}
              >
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold"
                      style={{ backgroundColor: channel.branding.colorScheme.primary }}
                    >
                      {channel.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-lg" data-testid={`channel-name-${channel.id}`}>{channel.name}</div>
                      <div className="text-sm text-muted-foreground font-normal" data-testid={`channel-handle-${channel.id}`}>
                        @{channel.handle}
                      </div>
                    </div>
                  </CardTitle>
                  <CardDescription className="line-clamp-2">{channel.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex gap-2 flex-wrap">
                      <Badge variant="outline" data-testid={`channel-category-${channel.id}`}>{channel.category}</Badge>
                      <Badge variant="secondary" data-testid={`channel-audience-${channel.id}`}>{channel.targetAudience}</Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Video className="h-4 w-4 text-blue-600" />
                        <span data-testid={`channel-episode-count-${channel.id}`}>{episodes.length} episodes</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span data-testid={`channel-completed-count-${channel.id}`}>{stats.completed} done</span>
                      </div>
                    </div>

                    {stats.rendering > 0 && (
                      <div className="flex items-center gap-2 text-sm text-purple-600">
                        <PlayCircle className="h-4 w-4" />
                        <span data-testid={`channel-rendering-count-${channel.id}`}>{stats.rendering} rendering now</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {selectedChannelData && (
        <Card data-testid="selected-channel-details">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold"
                style={{ backgroundColor: selectedChannelData.branding.colorScheme.primary }}
              >
                {selectedChannelData.name.charAt(0)}
              </div>
              {selectedChannelData.name} - Episode Management
            </CardTitle>
            <CardDescription>
              Create episodes, cache content, and manage video generation for this channel
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 md:grid-cols-4">
              <div className="flex items-center gap-3 p-3 border rounded-lg" data-testid="detail-pending">
                <Clock className="h-8 w-8 text-yellow-600" />
                <div>
                  <div className="text-2xl font-bold">{getEpisodeStats(channelEpisodes).pending}</div>
                  <div className="text-sm text-muted-foreground">Pending</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 border rounded-lg" data-testid="detail-rendering">
                <PlayCircle className="h-8 w-8 text-purple-600" />
                <div>
                  <div className="text-2xl font-bold">{getEpisodeStats(channelEpisodes).rendering}</div>
                  <div className="text-sm text-muted-foreground">Rendering</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 border rounded-lg" data-testid="detail-completed">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div>
                  <div className="text-2xl font-bold">{getEpisodeStats(channelEpisodes).completed}</div>
                  <div className="text-sm text-muted-foreground">Completed</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 border rounded-lg" data-testid="detail-failed">
                <XCircle className="h-8 w-8 text-red-600" />
                <div>
                  <div className="text-2xl font-bold">{getEpisodeStats(channelEpisodes).failed}</div>
                  <div className="text-sm text-muted-foreground">Failed</div>
                </div>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <Card data-testid="action-cache">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Database className="h-4 w-4" />
                    Cache Content
                  </CardTitle>
                  <CardDescription>Pre-generate scripts and thumbnails</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => cacheContentMutation.mutate({ channelId: selectedChannel!, count: 5 })}
                    disabled={cacheContentMutation.isPending}
                    data-testid="button-cache-5"
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Cache 5 Items
                  </Button>
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => cacheContentMutation.mutate({ channelId: selectedChannel!, count: 10 })}
                    disabled={cacheContentMutation.isPending}
                    data-testid="button-cache-10"
                  >
                    <ImageIcon className="mr-2 h-4 w-4" />
                    Cache 10 Items
                  </Button>
                </CardContent>
              </Card>

              <Card data-testid="action-episodes">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    Create Episodes
                  </CardTitle>
                  <CardDescription>Add new episode entries to the queue</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => createEpisodesMutation.mutate({ channelId: selectedChannel!, count: 5 })}
                    disabled={createEpisodesMutation.isPending}
                    data-testid="button-create-5"
                  >
                    <Video className="mr-2 h-4 w-4" />
                    Create 5 Episodes
                  </Button>
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => createEpisodesMutation.mutate({ channelId: selectedChannel!, count: 10 })}
                    disabled={createEpisodesMutation.isPending}
                    data-testid="button-create-10"
                  >
                    <Video className="mr-2 h-4 w-4" />
                    Create 10 Episodes
                  </Button>
                </CardContent>
              </Card>

              <Card data-testid="action-render">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2">
                    <PlayCircle className="h-4 w-4" />
                    Batch Render
                  </CardTitle>
                  <CardDescription>Start rendering pending episodes</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button
                    className="w-full"
                    onClick={() => batchRenderMutation.mutate({ channelId: selectedChannel!, count: 3 })}
                    disabled={batchRenderMutation.isPending}
                    data-testid="button-render-3"
                  >
                    <PlayCircle className="mr-2 h-4 w-4" />
                    Render 3 Videos
                  </Button>
                  <Button
                    className="w-full"
                    onClick={() => batchRenderMutation.mutate({ channelId: selectedChannel!, count: 5 })}
                    disabled={batchRenderMutation.isPending}
                    data-testid="button-render-5"
                  >
                    <PlayCircle className="mr-2 h-4 w-4" />
                    Render 5 Videos
                  </Button>
                </CardContent>
              </Card>
            </div>

            {channelEpisodes.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Recent Episodes</h3>
                <div className="space-y-2">
                  {channelEpisodes.slice(0, 10).map((episode) => (
                    <div
                      key={episode.id}
                      className="flex items-center justify-between p-3 border rounded-lg"
                      data-testid={`episode-${episode.id}`}
                    >
                      <div className="flex-1">
                        <div className="font-medium" data-testid={`episode-title-${episode.id}`}>{episode.title}</div>
                        <div className="text-sm text-muted-foreground">
                          Phase: {episode.phase} | Topic: {episode.topic}
                        </div>
                      </div>
                      <Badge
                        variant={
                          episode.status === "completed"
                            ? "default"
                            : episode.status === "rendering"
                            ? "secondary"
                            : episode.status === "failed"
                            ? "destructive"
                            : "outline"
                        }
                        data-testid={`episode-status-${episode.id}`}
                      >
                        {episode.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
