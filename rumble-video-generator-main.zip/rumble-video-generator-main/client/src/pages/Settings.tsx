import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Settings as SettingsIcon, Youtube, Clock, Database, Zap, Shield } from 'lucide-react';

export default function Settings() {
  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">System Settings</h1>
          <p className="text-gray-600 mt-2">
            Configuration and preferences for AI video generation
          </p>
        </div>
        <Badge variant="outline" className="bg-blue-50 text-blue-700">
          Production Environment
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* YouTube Integration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Youtube className="h-5 w-5 text-red-600" />
              <span>YouTube Integration</span>
            </CardTitle>
            <CardDescription>
              Automated upload and channel management settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Target Account</span>
                <Badge className="bg-green-100 text-green-800">
                  jasonclarkagain@gmail.com
                </Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Upload Schedule</span>
                <Badge variant="outline">Daily at 9:00 AM UTC</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Content Rating</span>
                <Badge className="bg-blue-100 text-blue-800">G - Family Friendly</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">SEO Optimization</span>
                <Badge className="bg-green-100 text-green-800">Enabled</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Automation Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-600" />
              <span>Automation Schedule</span>
            </CardTitle>
            <CardDescription>
              Automated task timing and frequency
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Daily Generation</span>
                <Badge variant="outline">9:00 AM UTC</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Quality Assurance</span>
                <Badge variant="outline">10:00 AM UTC</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Analytics Collection</span>
                <Badge variant="outline">Every 6 hours</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Health Monitoring</span>
                <Badge variant="outline">Hourly</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Database Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="h-5 w-5 text-purple-600" />
              <span>Database Configuration</span>
            </CardTitle>
            <CardDescription>
              Data storage and management settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Database Type</span>
                <Badge className="bg-purple-100 text-purple-800">PostgreSQL</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Connection Status</span>
                <Badge className="bg-green-100 text-green-800">Connected</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Auto Backup</span>
                <Badge className="bg-blue-100 text-blue-800">Enabled</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Query Optimization</span>
                <Badge className="bg-green-100 text-green-800">Active</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-orange-600" />
              <span>AI Configuration</span>
            </CardTitle>
            <CardDescription>
              OpenAI integration and model settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Text Generation</span>
                <Badge className="bg-orange-100 text-orange-800">GPT-4o</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Image Creation</span>
                <Badge className="bg-orange-100 text-orange-800">DALL-E 3</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Text-to-Speech</span>
                <Badge className="bg-orange-100 text-orange-800">OpenAI TTS</Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Quality Target</span>
                <Badge className="bg-blue-100 text-blue-800">92/100</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security & Content Safety */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-green-600" />
            <span>Security & Content Safety</span>
          </CardTitle>
          <CardDescription>
            Content filtering and safety measures
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <Shield className="h-6 w-6 mx-auto text-green-600 mb-2" />
              <h4 className="font-medium text-sm">Content Filtering</h4>
              <Badge className="bg-green-100 text-green-800 text-xs mt-1">Active</Badge>
            </div>
            
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <SettingsIcon className="h-6 w-6 mx-auto text-blue-600 mb-2" />
              <h4 className="font-medium text-sm">G-Rating Verification</h4>
              <Badge className="bg-blue-100 text-blue-800 text-xs mt-1">100% Compliant</Badge>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <Database className="h-6 w-6 mx-auto text-purple-600 mb-2" />
              <h4 className="font-medium text-sm">Data Encryption</h4>
              <Badge className="bg-purple-100 text-purple-800 text-xs mt-1">AES-256</Badge>
            </div>
            
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <Zap className="h-6 w-6 mx-auto text-orange-600 mb-2" />
              <h4 className="font-medium text-sm">API Security</h4>
              <Badge className="bg-orange-100 text-orange-800 text-xs mt-1">Secured</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Information */}
      <Card>
        <CardHeader>
          <CardTitle>System Information</CardTitle>
          <CardDescription>Platform version and configuration details</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h4 className="font-medium">Platform Details</h4>
              <div className="text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-gray-500">Version:</span>
                  <span>AI Video Generator v1.0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Environment:</span>
                  <span>Production</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Uptime:</span>
                  <span>99.9%</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-medium">Performance Metrics</h4>
              <div className="text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-gray-500">Response Time:</span>
                  <span>&lt; 2s average</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Success Rate:</span>
                  <span>94%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Quality Score:</span>
                  <span>92/100</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}