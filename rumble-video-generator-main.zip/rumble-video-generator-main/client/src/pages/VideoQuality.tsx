import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Video, 
  Settings, 
  Zap, 
  Monitor, 
  Cpu, 
  HardDrive,
  Play,
  Download,
  CheckCircle,
  TrendingUp,
  BarChart,
  Target,
  Sparkles
} from 'lucide-react';
import { queryClient } from '@/lib/queryClient';

interface QualityPreset {
  resolution: string;
  frameRate: number;
  bitrate: string;
  colorSpace: string;
  audioQuality: string;
}

interface QualitySettings {
  qualityPresets: Record<string, QualityPreset>;
}

export default function VideoQuality() {
  const [selectedPreset, setSelectedPreset] = useState<string>('professional');
  const [testInProgress, setTestInProgress] = useState(false);
  const [platformTarget, setPlatformTarget] = useState<string>('youtube');
  const [advancedEffects, setAdvancedEffects] = useState(true);

  const { data: qualitySettings, isLoading } = useQuery<QualitySettings>({
    queryKey: ['/api/quality-optimizer-settings'],
    refetchInterval: 30000
  });

  const { data: renderPresets } = useQuery({
    queryKey: ['/api/render-quality-presets'],
    refetchInterval: 60000
  });

  const { data: qualityAnalytics } = useQuery({
    queryKey: ['/api/quality-analytics'],
    refetchInterval: 30000
  });

  const { data: qualityRecommendations } = useQuery({
    queryKey: ['/api/quality-optimization-recommendations'],
    refetchInterval: 300000 // 5 minutes
  });

  const { data: productionMetrics } = useQuery({
    queryKey: ['/api/production-quality-metrics'],
    refetchInterval: 60000 // 1 minute
  });

  const { data: productionConfig } = useQuery({
    queryKey: ['/api/production-quality-config'],
    refetchInterval: 300000 // 5 minutes
  });

  const qualityTestMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/advanced-quality-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          qualityPreset: selectedPreset,
          platformTarget,
          enableAdvancedEffects: advancedEffects,
          enhancementLevel: 'ultra'
        })
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/quality-analytics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/video-analytics'] });
      setTestInProgress(false);
    },
    onError: () => {
      setTestInProgress(false);
    }
  });

  const handleQualityTest = async () => {
    setTestInProgress(true);
    qualityTestMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading video quality settings...</p>
        </div>
      </div>
    );
  }

  const presets = qualitySettings?.qualityPresets || {};

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Video Quality & Rendering</h1>
          <p className="text-gray-600 mt-2">
            Professional high-resolution video generation and optimization
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Video className="h-5 w-5 text-blue-600" />
          <span className="text-sm font-medium text-blue-600">Ultra HD Ready</span>
        </div>
      </div>

      {/* Quality Presets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Object.entries(presets).map(([key, preset]) => (
          <Card 
            key={key}
            className={`cursor-pointer transition-all ${
              selectedPreset === key ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:shadow-md'
            }`}
            onClick={() => setSelectedPreset(key)}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-lg capitalize flex items-center justify-between">
                {key}
                {selectedPreset === key && <CheckCircle className="h-5 w-5 text-blue-600" />}
              </CardTitle>
              <CardDescription>
                {key === 'cinematic' && 'Ultimate 4K Quality'}
                {key === 'premium' && 'Enhanced 1440p'}
                {key === 'professional' && 'Studio Quality 1080p'}
                {key === 'standard' && 'High Quality 1080p'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Resolution:</span>
                <Badge variant="outline">{preset.resolution}</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Frame Rate:</span>
                <Badge variant="outline">{preset.frameRate} FPS</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Quality:</span>
                <Badge variant="outline">{preset.bitrate}</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Audio:</span>
                <Badge variant="outline">{preset.audioQuality}</Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Current Settings Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <span>Current Quality Configuration</span>
          </CardTitle>
          <CardDescription>
            Active settings for video generation pipeline
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h4 className="font-medium text-sm">Video Settings</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Resolution:</span>
                  <span className="text-sm font-medium">
                    {presets[selectedPreset]?.resolution || 'Not set'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Frame Rate:</span>
                  <span className="text-sm font-medium">
                    {presets[selectedPreset]?.frameRate || 'Not set'} FPS
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Color Space:</span>
                  <span className="text-sm font-medium">
                    {presets[selectedPreset]?.colorSpace || 'Not set'}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-medium text-sm">Quality Metrics</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Bitrate:</span>
                  <span className="text-sm font-medium">
                    {presets[selectedPreset]?.bitrate || 'Not set'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Audio Quality:</span>
                  <span className="text-sm font-medium">
                    {presets[selectedPreset]?.audioQuality || 'Not set'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Codec:</span>
                  <span className="text-sm font-medium">H.264/AVC</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-medium text-sm">Professional Features</h4>
              <div className="space-y-2">
                <Badge className="bg-green-100 text-green-800">Color Grading</Badge>
                <Badge className="bg-green-100 text-green-800">Anti-aliasing</Badge>
                <Badge className="bg-green-100 text-green-800">Particle Effects</Badge>
                <Badge className="bg-green-100 text-green-800">HDR Support</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rendering Performance */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Cpu className="h-5 w-5" />
              <span>Rendering Performance</span>
            </CardTitle>
            <CardDescription>Current system performance metrics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Processing Speed</span>
                <span className="font-medium">Optimized</span>
              </div>
              <Progress value={92} className="h-2" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Quality Score</span>
                <span className="font-medium">94/100</span>
              </div>
              <Progress value={94} className="h-2" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Render Efficiency</span>
                <span className="font-medium">Excellent</span>
              </div>
              <Progress value={96} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Monitor className="h-5 w-5" />
              <span>Output Specifications</span>
            </CardTitle>
            <CardDescription>Technical specifications for generated videos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Container:</span>
                <p className="font-medium">MP4</p>
              </div>
              <div>
                <span className="text-gray-600">Codec:</span>
                <p className="font-medium">H.264/AVC</p>
              </div>
              <div>
                <span className="text-gray-600">Audio Codec:</span>
                <p className="font-medium">AAC</p>
              </div>
              <div>
                <span className="text-gray-600">Pixel Format:</span>
                <p className="font-medium">YUV420P</p>
              </div>
              <div>
                <span className="text-gray-600">Profile:</span>
                <p className="font-medium">High</p>
              </div>
              <div>
                <span className="text-gray-600">Level:</span>
                <p className="font-medium">4.1</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quality Test */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5" />
            <span>Quality Test</span>
          </CardTitle>
          <CardDescription>
            Test the video generation pipeline with current quality settings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-2">
                Generate a test video using the <strong>{selectedPreset}</strong> quality preset
              </p>
              <p className="text-xs text-gray-500">
                This will create a sample video to verify quality settings and performance
              </p>
            </div>
            <Button 
              onClick={handleQualityTest}
              disabled={testInProgress || qualityTestMutation.isPending}
              className="flex items-center space-x-2"
            >
              {testInProgress || qualityTestMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Testing...</span>
                </>
              ) : (
                <>
                  <Play className="h-4 w-4" />
                  <span>Run Quality Test</span>
                </>
              )}
            </Button>
          </div>
          
          {qualityTestMutation.data && (
            <div className="mt-4 p-4 bg-green-50 rounded-lg">
              <h4 className="font-medium text-green-800 mb-2">Quality Test Results</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-green-600">Overall Score:</span>
                  <p className="font-medium">{qualityTestMutation.data.qualityMetrics?.overallScore}/100</p>
                </div>
                <div>
                  <span className="text-green-600">Video Path:</span>
                  <p className="font-medium truncate">{qualityTestMutation.data.videoPath}</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Production Quality Integration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Video className="h-5 w-5" />
            <span>Production Quality Test</span>
          </CardTitle>
          <CardDescription>
            Test the complete production-ready quality pipeline
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-gray-600 mb-2">
                Generate a complete production-quality video with daily automation pipeline
              </p>
              <p className="text-xs text-gray-500">
                This tests the full integration including themes, characters, and professional rendering
              </p>
            </div>
            <Button 
              onClick={async () => {
                setTestInProgress(true);
                try {
                  const response = await fetch('/api/production-quality-test', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                  });
                  const result = await response.json();
                  console.log('Production quality test result:', result);
                  queryClient.invalidateQueries({ queryKey: ['/api/production-quality-metrics'] });
                } catch (error) {
                  console.error('Production test error:', error);
                } finally {
                  setTestInProgress(false);
                }
              }}
              disabled={testInProgress}
              className="flex items-center space-x-2"
            >
              {testInProgress ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Testing...</span>
                </>
              ) : (
                <>
                  <Play className="h-4 w-4" />
                  <span>Test Production Pipeline</span>
                </>
              )}
            </Button>
          </div>
          
          {productionMetrics && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 p-4 bg-green-50 rounded-lg">
              <div>
                <h4 className="font-medium text-green-800 mb-2">Production Metrics</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Daily Average Quality:</span>
                    <span className="font-medium">{productionMetrics.dailyAverageQuality}/100</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Weekly Trend:</span>
                    <span className="font-medium">
                      {productionMetrics.weeklyTrends?.length > 0 ? 'Tracking' : 'No data'}
                    </span>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-green-800 mb-2">Platform Performance</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>YouTube:</span>
                    <span className="font-medium">{productionMetrics.platformPerformance?.youtube || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Mobile:</span>
                    <span className="font-medium">{productionMetrics.platformPerformance?.mobile || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Advanced Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5" />
            <span>Advanced Configuration</span>
          </CardTitle>
          <CardDescription>
            Professional video generation settings and platform optimization
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Platform Target</label>
                <select
                  value={platformTarget}
                  onChange={(e) => setPlatformTarget(e.target.value)}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="youtube">YouTube Optimized</option>
                  <option value="mobile">Mobile Optimized</option>
                  <option value="broadcast">Broadcast Quality</option>
                  <option value="universal">Universal Compatibility</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="advancedEffects"
                  checked={advancedEffects}
                  onChange={(e) => setAdvancedEffects(e.target.checked)}
                  className="rounded"
                />
                <label htmlFor="advancedEffects" className="text-sm font-medium">
                  Enable Advanced Effects
                </label>
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-medium text-sm">Current Configuration</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Quality Preset:</span>
                  <Badge className="capitalize">{selectedPreset}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Platform Target:</span>
                  <Badge className="capitalize">{platformTarget}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Advanced Effects:</span>
                  <Badge variant={advancedEffects ? "default" : "secondary"}>
                    {advancedEffects ? "Enabled" : "Disabled"}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quality Analytics */}
      {qualityAnalytics && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5" />
              <span>Quality Analytics</span>
            </CardTitle>
            <CardDescription>
              Performance metrics and quality trends
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Summary</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Total Videos:</span>
                    <span className="font-medium">{qualityAnalytics.summary?.totalVideos || 0}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Avg Quality Score:</span>
                    <span className="font-medium">{qualityAnalytics.summary?.averageQualityScore || 0}/100</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Avg Render Time:</span>
                    <span className="font-medium">{Math.round((qualityAnalytics.summary?.averageRenderTime || 0) / 1000)}s</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Platform Distribution</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>YouTube:</span>
                    <span className="font-medium">{qualityAnalytics.summary?.platformDistribution?.youtube || 0}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Mobile:</span>
                    <span className="font-medium">{qualityAnalytics.summary?.platformDistribution?.mobile || 0}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Broadcast:</span>
                    <span className="font-medium">{qualityAnalytics.summary?.platformDistribution?.broadcast || 0}</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Quality Trends</h4>
                <div className="space-y-2">
                  {qualityAnalytics.trends?.qualityTrend?.slice(-3).map((score: number, index: number) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>Recent {index + 1}:</span>
                      <span className="font-medium">{score}/100</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quality Recommendations */}
      {qualityRecommendations && qualityRecommendations.recommendations?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="h-5 w-5" />
              <span>Optimization Recommendations</span>
            </CardTitle>
            <CardDescription>
              AI-powered suggestions to improve video quality and performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {qualityRecommendations.recommendations.map((recommendation: string, index: number) => (
                <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                  <BarChart className="h-5 w-5 text-blue-600 mt-0.5" />
                  <p className="text-sm text-blue-800">{recommendation}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}