import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, UserCheck, Star, CheckCircle } from 'lucide-react';

interface Character {
  id: string;
  name: string;
  description: string;
  personality: string;
  voice_style: string;
  is_active: boolean;
  metadata: any;
  created_at: string;
}

export default function Characters() {
  const { data: characters, isLoading } = useQuery<Character[]>({
    queryKey: ['/api/characters'],
    refetchInterval: 60000
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading character cast...</p>
        </div>
      </div>
    );
  }

  const activeCharacters = characters?.filter(char => char.is_active) || [];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Character Cast</h1>
          <p className="text-gray-600 mt-2">
            Manage AI-generated characters for educational videos
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="bg-green-50 text-green-700">
            {activeCharacters.length} Active Characters
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {characters?.map((character) => (
          <Card key={character.id} className={character.is_active ? 'border-green-200 bg-green-50/30' : ''}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center space-x-2">
                  <Users className="h-5 w-5 text-green-600" />
                  <span>{character.name}</span>
                </CardTitle>
                {character.is_active ? (
                  <Badge className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Active
                  </Badge>
                ) : (
                  <Badge variant="outline">Inactive</Badge>
                )}
              </div>
              <CardDescription>
                {character.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Personality:</span>
                    <Badge variant="outline" className="text-xs max-w-32 truncate">
                      {character.personality}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Voice Style:</span>
                    <Badge variant="outline" className="text-xs max-w-32 truncate">
                      {character.voice_style}
                    </Badge>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Created:</span>
                  <span>{new Date(character.created_at).toLocaleDateString()}</span>
                </div>

                {character.metadata?.specialties && (
                  <div className="space-y-2">
                    <span className="text-sm font-medium text-gray-700">Specialties:</span>
                    <div className="flex flex-wrap gap-1">
                      {character.metadata.specialties.slice(0, 3).map((specialty: string, index: number) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {character.metadata?.educational_role && (
                  <div className="text-sm">
                    <span className="text-gray-500">Role: </span>
                    <span className="font-medium">{character.metadata.educational_role}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )) || (
          <div className="col-span-full">
            <Card>
              <CardContent className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Users className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No characters found</h3>
                  <p className="text-gray-500">Character cast will appear here once configured.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Character Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Characters</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{characters?.length || 0}</div>
            <p className="text-xs text-muted-foreground">Available characters</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Cast</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{activeCharacters.length}</div>
            <p className="text-xs text-muted-foreground">Currently generating content</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Voice Styles</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {characters ? [...new Set(characters.map(c => c.voice_style))].length : 0}
            </div>
            <p className="text-xs text-muted-foreground">Unique voice styles</p>
          </CardContent>
        </Card>
      </div>

      {/* Featured Characters */}
      {activeCharacters.length > 0 && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Featured Cast Members</CardTitle>
            <CardDescription>Currently active characters in video production</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {activeCharacters.slice(0, 3).map((character) => (
                <div key={character.id} className="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {character.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold">{character.name}</h4>
                    <p className="text-sm text-gray-600">{character.personality}</p>
                    <Badge variant="outline" className="text-xs mt-1">
                      {character.voice_style}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}