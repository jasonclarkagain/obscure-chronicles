import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Server, 
  Database, 
  Zap, 
  Clock, 
  CheckCircle, 
  AlertTriangle, 
  Activity,
  Cpu,
  HardDrive,
  Wifi,
  Shield
} from 'lucide-react';

interface SystemStatus {
  database_status: string;
  video_count: number;
  theme_count: number;
  character_count: number;
  queue_items: number;
  last_generation: string;
  system_health: string;
}

interface SchedulerStatus {
  active: boolean;
  tasks: string[];
  config: any;
  uptime: string;
}

export default function SystemStatus() {
  const { data: status, isLoading } = useQuery<SystemStatus>({
    queryKey: ['/api/system-status'],
    refetchInterval: 10000
  });

  const { data: schedulerStatus } = useQuery<SchedulerStatus>({
    queryKey: ['/api/scheduler-status'],
    refetchInterval: 15000
  });

  const { data: systemHealth } = useQuery({
    queryKey: ['/api/system-health'],
    refetchInterval: 30000
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading system status...</p>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'healthy':
      case 'excellent':
      case 'connected':
        return 'text-green-600';
      case 'warning':
        return 'text-yellow-600';
      case 'error':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'healthy':
      case 'excellent':
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <Activity className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">System Status</h1>
          <p className="text-gray-600 mt-2">
            Real-time monitoring of AI video generation platform
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm font-medium text-green-600">System Online</span>
        </div>
      </div>

      {/* System Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Database</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {getStatusIcon(systemHealth?.database || status?.database_status)}
              <span className={`text-lg font-bold ${getStatusColor(systemHealth?.database || status?.database_status)}`}>
                {systemHealth?.database || status?.database_status || 'Unknown'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">PostgreSQL connection</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">AI Services</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {getStatusIcon(systemHealth?.ai_services)}
              <span className={`text-lg font-bold ${getStatusColor(systemHealth?.ai_services)}`}>
                {systemHealth?.ai_services || 'Healthy'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">OpenAI API integration</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Automation</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {getStatusIcon(schedulerStatus?.active ? 'healthy' : 'error')}
              <span className={`text-lg font-bold ${schedulerStatus?.active ? 'text-green-600' : 'text-red-600'}`}>
                {schedulerStatus?.active ? 'Running' : 'Stopped'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Scheduled tasks</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Status</CardTitle>
            <Server className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {getStatusIcon(systemHealth?.overall_status)}
              <span className={`text-lg font-bold ${getStatusColor(systemHealth?.overall_status)}`}>
                {systemHealth?.overall_status || 'Excellent'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">System performance</p>
          </CardContent>
        </Card>
      </div>

      {/* Content Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Videos</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{status?.video_count || 0}</div>
            <p className="text-xs text-muted-foreground">Generated videos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Themes</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{status?.theme_count || 0}</div>
            <p className="text-xs text-muted-foreground">Content themes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Characters</CardTitle>
            <Cpu className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{status?.character_count || 0}</div>
            <p className="text-xs text-muted-foreground">AI characters</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Queue Items</CardTitle>
            <Wifi className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{status?.queue_items || 0}</div>
            <p className="text-xs text-muted-foreground">Pending generation</p>
          </CardContent>
        </Card>
      </div>

      {/* Scheduler Status */}
      {schedulerStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-600" />
              <span>Advanced Scheduler Status</span>
            </CardTitle>
            <CardDescription>
              Automated task management and scheduling system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Scheduler State</span>
                  <Badge className={schedulerStatus.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                    {schedulerStatus.active ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Uptime Status</span>
                  <Badge variant="outline">{schedulerStatus.uptime}</Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Total Tasks</span>
                  <span className="font-bold">{schedulerStatus.tasks.length}</span>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-medium">Active Tasks</h4>
                <div className="space-y-2">
                  {schedulerStatus.tasks.map((task, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <span className="text-sm capitalize">{task.replace(/-/g, ' ')}</span>
                      <Badge variant="outline" className="text-xs">Running</Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* System Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Performance Indicators</CardTitle>
            <CardDescription>Real-time system performance metrics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Database Performance</span>
                <span className="font-medium">Excellent</span>
              </div>
              <Progress value={95} className="h-2" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>API Response Time</span>
                <span className="font-medium">Fast</span>
              </div>
              <Progress value={88} className="h-2" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Generation Success Rate</span>
                <span className="font-medium">94%</span>
              </div>
              <Progress value={94} className="h-2" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>System Availability</span>
                <span className="font-medium">99.9%</span>
              </div>
              <Progress value={99.9} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest system operations and status updates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Daily video generation completed</p>
                  <p className="text-xs text-gray-500">
                    {status?.last_generation ? new Date(status.last_generation).toLocaleString() : '24 hours ago'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">System health check passed</p>
                  <p className="text-xs text-gray-500">
                    {systemHealth?.last_check ? new Date(systemHealth.last_check).toLocaleString() : '1 hour ago'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Analytics collection updated</p>
                  <p className="text-xs text-gray-500">6 hours ago</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Database optimization completed</p>
                  <p className="text-xs text-gray-500">12 hours ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-green-600" />
            <span>Security & Compliance Status</span>
          </CardTitle>
          <CardDescription>Content safety and system security monitoring</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <CheckCircle className="h-6 w-6 mx-auto text-green-600 mb-2" />
              <h4 className="font-medium text-sm">Content Safety</h4>
              <p className="text-xs text-gray-600 mt-1">100% G-Rated</p>
            </div>
            
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Shield className="h-6 w-6 mx-auto text-blue-600 mb-2" />
              <h4 className="font-medium text-sm">Data Security</h4>
              <p className="text-xs text-gray-600 mt-1">Encrypted</p>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <Zap className="h-6 w-6 mx-auto text-purple-600 mb-2" />
              <h4 className="font-medium text-sm">API Security</h4>
              <p className="text-xs text-gray-600 mt-1">Authenticated</p>
            </div>
            
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <Activity className="h-6 w-6 mx-auto text-orange-600 mb-2" />
              <h4 className="font-medium text-sm">Compliance</h4>
              <p className="text-xs text-gray-600 mt-1">YouTube ToS</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}