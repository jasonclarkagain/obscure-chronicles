import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Sparkles,
  Youtube,
  DollarSign,
  Users,
  TrendingUp,
  Palette,
  Target,
  Play,
  CheckCircle,
  Zap
} from 'lucide-react';
import { queryClient } from '@/lib/queryClient';

interface ChannelGenerationRequest {
  category: "education" | "entertainment" | "gaming" | "lifestyle" | "technology" | "science" | "arts" | "music";
  targetAudience: "kids" | "teens" | "adults" | "families" | "professionals";
  monetizationFocus: "ads" | "sponsorships" | "merchandise" | "memberships" | "mixed";
  niche?: string;
  tone?: "casual" | "professional" | "educational" | "entertaining";
}

export default function ChannelCreator() {
  const [formData, setFormData] = useState<ChannelGenerationRequest>({
    category: "education",
    targetAudience: "families",
    monetizationFocus: "mixed"
  });

  const [generatedChannel, setGeneratedChannel] = useState<any>(null);

  const generateChannelMutation = useMutation({
    mutationFn: async (data: ChannelGenerationRequest) => {
      const response = await fetch('/api/generate-channel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      if (!response.ok) {
        throw new Error('Failed to generate channel');
      }

      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedChannel(data.channel);
      queryClient.invalidateQueries({ queryKey: ['/api/youtube-channels'] });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    generateChannelMutation.mutate(formData);
  };

  if (generatedChannel) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <CheckCircle className="h-12 w-12 text-green-600 mr-3" />
            <h1 className="text-3xl font-bold text-green-800">Channel Created Successfully!</h1>
          </div>
          <p className="text-gray-600">Your AI-powered YouTube channel is ready for monetization</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Channel Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Youtube className="h-5 w-5 text-red-500" />
                <span>Channel Overview</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{generatedChannel.name}</h3>
                <p className="text-gray-600">{generatedChannel.handle}</p>
              </div>
              
              <div>
                <Label className="text-sm font-medium">Description</Label>
                <p className="text-sm text-gray-700 mt-1">{generatedChannel.description}</p>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">{generatedChannel.category}</Badge>
                <Badge variant="outline">{generatedChannel.targetAudience}</Badge>
                <Badge variant="outline">{generatedChannel.contentStrategy.uploadSchedule}</Badge>
              </div>

              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-600">{generatedChannel.contentStrategy.averageDuration}s</div>
                  <div className="text-xs text-gray-500">Avg Duration</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">
                    {generatedChannel.monetization.subscriberTarget.toLocaleString()}
                  </div>
                  <div className="text-xs text-gray-500">Sub Target</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">
                    {generatedChannel.monetization.watchTimeTarget}h
                  </div>
                  <div className="text-xs text-gray-500">Watch Time</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Branding */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Palette className="h-5 w-5" />
                <span>Professional Branding</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Color Scheme</Label>
                <div className="flex space-x-2 mt-2">
                  <div 
                    className="w-8 h-8 rounded"
                    style={{ backgroundColor: generatedChannel.branding.colorScheme.primary }}
                    title="Primary"
                  ></div>
                  <div 
                    className="w-8 h-8 rounded"
                    style={{ backgroundColor: generatedChannel.branding.colorScheme.secondary }}
                    title="Secondary"
                  ></div>
                  <div 
                    className="w-8 h-8 rounded"
                    style={{ backgroundColor: generatedChannel.branding.colorScheme.accent }}
                    title="Accent"
                  ></div>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Font Family</Label>
                <p className="text-sm text-gray-700 mt-1" style={{ fontFamily: generatedChannel.branding.fontFamily }}>
                  {generatedChannel.branding.fontFamily}
                </p>
              </div>

              <div>
                <Label className="text-sm font-medium">Thumbnail Style</Label>
                <p className="text-sm text-gray-700 mt-1">{generatedChannel.branding.thumbnailStyle}</p>
              </div>

              {generatedChannel.bannerUrl && (
                <div>
                  <Label className="text-sm font-medium">Generated Banner</Label>
                  <div className="mt-2 border rounded-lg overflow-hidden">
                    <img 
                      src={generatedChannel.bannerUrl} 
                      alt="Channel Banner"
                      className="w-full h-24 object-cover"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Content Strategy */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Play className="h-5 w-5" />
                <span>Content Strategy</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Content Types</Label>
                <div className="flex flex-wrap gap-1 mt-2">
                  {generatedChannel.contentStrategy.contentTypes.map((type: string, index: number) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {type}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Themes</Label>
                <div className="flex flex-wrap gap-1 mt-2">
                  {generatedChannel.contentStrategy.themes.map((theme: string, index: number) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {theme}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Tone</Label>
                <p className="text-sm text-gray-700 mt-1 capitalize">{generatedChannel.contentStrategy.tone}</p>
              </div>
            </CardContent>
          </Card>

          {/* Monetization Strategy */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span>Monetization Strategy</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Primary Focus</Label>
                <p className="text-sm text-gray-700 mt-1 capitalize">{generatedChannel.contentStrategy.monetizationFocus}</p>
              </div>

              <div>
                <Label className="text-sm font-medium">Revenue Strategies</Label>
                <div className="flex flex-wrap gap-1 mt-2">
                  {generatedChannel.monetization.strategies.map((strategy: string, index: number) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {strategy}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="text-center">
                  <div className="text-lg font-bold text-green-600">
                    {generatedChannel.monetization.subscriberTarget.toLocaleString()}
                  </div>
                  <div className="text-xs text-gray-500">Subscriber Target</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-600">
                    {generatedChannel.monetization.watchTimeTarget}h
                  </div>
                  <div className="text-xs text-gray-500">Watch Time Goal</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-center space-x-4">
          <Button 
            onClick={() => {
              setGeneratedChannel(null);
              setFormData({
                category: "education",
                targetAudience: "families", 
                monetizationFocus: "mixed"
              });
            }}
            variant="outline"
          >
            Create Another Channel
          </Button>
          
          <Button className="bg-red-600 hover:bg-red-700">
            <Youtube className="h-4 w-4 mr-2" />
            Connect to YouTube
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">AI YouTube Channel Generator</h1>
        <p className="text-gray-600">Create monetization-optimized channels with professional branding and content strategies</p>
      </div>

      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Sparkles className="h-5 w-5" />
              <span>Channel Configuration</span>
            </CardTitle>
            <CardDescription>
              Configure your channel for maximum growth and monetization potential
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Category Selection */}
            <div className="space-y-2">
              <Label htmlFor="category">Content Category</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value: any) => setFormData({...formData, category: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="education">Education (High CPM)</SelectItem>
                  <SelectItem value="technology">Technology (Premium RPM)</SelectItem>
                  <SelectItem value="science">Science (Educational Sponsors)</SelectItem>
                  <SelectItem value="entertainment">Entertainment (Viral Potential)</SelectItem>
                  <SelectItem value="gaming">Gaming (High Engagement)</SelectItem>
                  <SelectItem value="lifestyle">Lifestyle (Brand Partnerships)</SelectItem>
                  <SelectItem value="arts">Arts & Creativity</SelectItem>
                  <SelectItem value="music">Music & Performance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Target Audience */}
            <div className="space-y-2">
              <Label htmlFor="targetAudience">Target Audience</Label>
              <Select 
                value={formData.targetAudience} 
                onValueChange={(value: any) => setFormData({...formData, targetAudience: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select audience" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="kids">Kids (Educational & Safe)</SelectItem>
                  <SelectItem value="teens">Teenagers (Trending Content)</SelectItem>
                  <SelectItem value="adults">Adults (Professional Content)</SelectItem>
                  <SelectItem value="families">Families (Broad Appeal)</SelectItem>
                  <SelectItem value="professionals">Professionals (B2B Focus)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Monetization Focus */}
            <div className="space-y-2">
              <Label htmlFor="monetizationFocus">Monetization Strategy</Label>
              <Select 
                value={formData.monetizationFocus} 
                onValueChange={(value: any) => setFormData({...formData, monetizationFocus: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select strategy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ads">Ad Revenue (YouTube Partner)</SelectItem>
                  <SelectItem value="sponsorships">Brand Sponsorships</SelectItem>
                  <SelectItem value="merchandise">Merchandise Sales</SelectItem>
                  <SelectItem value="memberships">Channel Memberships</SelectItem>
                  <SelectItem value="mixed">Mixed Revenue Streams</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Optional Niche */}
            <div className="space-y-2">
              <Label htmlFor="niche">Specific Niche (Optional)</Label>
              <Input
                placeholder="e.g., AI tutorials, cooking for kids, tech reviews"
                value={formData.niche || ''}
                onChange={(e) => setFormData({...formData, niche: e.target.value})}
              />
            </div>

            {/* Tone */}
            <div className="space-y-2">
              <Label htmlFor="tone">Content Tone</Label>
              <Select 
                value={formData.tone || ''} 
                onValueChange={(value: any) => setFormData({...formData, tone: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select tone (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="casual">Casual & Friendly</SelectItem>
                  <SelectItem value="professional">Professional & Authoritative</SelectItem>
                  <SelectItem value="educational">Educational & Informative</SelectItem>
                  <SelectItem value="entertaining">Entertaining & Fun</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button 
              type="submit" 
              className="w-full"
              disabled={generateChannelMutation.isPending}
            >
              {generateChannelMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Generating Channel...
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  Generate AI-Powered Channel
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </form>

      {/* Features Preview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
        <Card>
          <CardContent className="pt-6 text-center">
            <Youtube className="h-8 w-8 text-red-500 mx-auto mb-3" />
            <h3 className="font-medium mb-2">Professional Branding</h3>
            <p className="text-sm text-gray-600">AI-generated banners, color schemes, and visual identity</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6 text-center">
            <TrendingUp className="h-8 w-8 text-green-500 mx-auto mb-3" />
            <h3 className="font-medium mb-2">Growth Optimization</h3>
            <p className="text-sm text-gray-600">Data-driven strategies for rapid subscriber growth</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6 text-center">
            <DollarSign className="h-8 w-8 text-blue-500 mx-auto mb-3" />
            <h3 className="font-medium mb-2">Revenue Maximization</h3>
            <p className="text-sm text-gray-600">Multi-stream monetization for maximum ROI</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}