import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  Video, 
  PlayCircle, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Youtube, 
  Database,
  FileText,
  Image as ImageIcon,
  TrendingUp,
  Activity
} from "lucide-react";
import type { YouTubeChannel, Episode } from "@shared/schema";

interface JobStatus {
  episodes: {
    totalEpisodes: number;
    byStatus: Record<string, number>;
    byPhase: Record<string, number>;
  };
  channels: {
    total: number;
    active: number;
  };
  cache: {
    scripts: { total: number; unused: number };
    thumbnails: { total: number; unused: number };
  };
}

export function Dashboard() {
  const { data: channels, isLoading: loadingChannels } = useQuery<YouTubeChannel[]>({
    queryKey: ["/api/youtube-channels"],
  });

  const { data: episodes, isLoading: loadingEpisodes } = useQuery<Episode[]>({
    queryKey: ["/api/episodes"],
  });

  const { data: jobStatus, isLoading: loadingStatus } = useQuery<JobStatus>({
    queryKey: ["/api/jobs/status"],
  });

  if (loadingChannels || loadingEpisodes || loadingStatus) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Multi-Channel Video Generation
          </h1>
          <p className="text-muted-foreground mt-2">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const activeChannels = channels?.filter(c => c.isActive) || [];
  const pendingEpisodes = episodes?.filter(e => e.status === "pending") || [];
  const renderingEpisodes = episodes?.filter(e => e.status === "rendering") || [];
  const completedEpisodes = episodes?.filter(e => e.status === "completed") || [];
  const failedEpisodes = episodes?.filter(e => e.status === "failed") || [];

  const stats = [
    {
      title: "Active Channels",
      value: activeChannels.length,
      icon: Youtube,
      color: "text-red-600",
      bgColor: "bg-red-50 dark:bg-red-950",
      link: "/channels",
    },
    {
      title: "Total Episodes",
      value: episodes?.length || 0,
      icon: Video,
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-950",
      link: "/channels",
    },
    {
      title: "Rendering",
      value: renderingEpisodes.length,
      icon: PlayCircle,
      color: "text-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-950",
    },
    {
      title: "Completed",
      value: completedEpisodes.length,
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-950",
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Multi-Channel Video Generation
        </h1>
        <p className="text-muted-foreground mt-2 text-lg">
          Manage and monitor your YouTube video production pipeline
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, i) => (
          <Card key={i} className="hover:shadow-lg transition-shadow" data-testid={`stat-card-${i}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold" data-testid={`stat-value-${i}`}>{stat.value}</div>
              {stat.link && (
                <Link href={stat.link}>
                  <a className="text-xs text-muted-foreground hover:text-primary mt-1 inline-block" data-testid={`stat-link-${i}`}>
                    View details →
                  </a>
                </Link>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card data-testid="episode-status-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Episode Status
            </CardTitle>
            <CardDescription>Current status of all episodes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between" data-testid="status-pending">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-yellow-600" />
                <span>Pending</span>
              </div>
              <Badge variant="secondary">{pendingEpisodes.length}</Badge>
            </div>
            <div className="flex items-center justify-between" data-testid="status-rendering">
              <div className="flex items-center gap-2">
                <PlayCircle className="h-4 w-4 text-purple-600" />
                <span>Rendering</span>
              </div>
              <Badge variant="secondary">{renderingEpisodes.length}</Badge>
            </div>
            <div className="flex items-center justify-between" data-testid="status-completed">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Completed</span>
              </div>
              <Badge variant="secondary">{completedEpisodes.length}</Badge>
            </div>
            <div className="flex items-center justify-between" data-testid="status-failed">
              <div className="flex items-center gap-2">
                <XCircle className="h-4 w-4 text-red-600" />
                <span>Failed</span>
              </div>
              <Badge variant="secondary">{failedEpisodes.length}</Badge>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="content-cache-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Content Cache
            </CardTitle>
            <CardDescription>Pre-generated content ready for use</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between" data-testid="cache-scripts">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-blue-600" />
                <span>Scripts</span>
              </div>
              <div className="flex gap-2">
                <Badge variant="outline" data-testid="cache-scripts-total">
                  {jobStatus?.cache.scripts.total || 0} total
                </Badge>
                <Badge variant="secondary" data-testid="cache-scripts-unused">
                  {jobStatus?.cache.scripts.unused || 0} unused
                </Badge>
              </div>
            </div>
            <div className="flex items-center justify-between" data-testid="cache-thumbnails">
              <div className="flex items-center gap-2">
                <ImageIcon className="h-4 w-4 text-purple-600" />
                <span>Thumbnails</span>
              </div>
              <div className="flex gap-2">
                <Badge variant="outline" data-testid="cache-thumbnails-total">
                  {jobStatus?.cache.thumbnails.total || 0} total
                </Badge>
                <Badge variant="secondary" data-testid="cache-thumbnails-unused">
                  {jobStatus?.cache.thumbnails.unused || 0} unused
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card data-testid="channels-overview-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Youtube className="h-5 w-5" />
            Your Channels
          </CardTitle>
          <CardDescription>Active YouTube channels in your network</CardDescription>
        </CardHeader>
        <CardContent>
          {activeChannels.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No active channels yet</p>
              <Link href="/channels">
                <Button data-testid="button-get-started">
                  <Youtube className="mr-2 h-4 w-4" />
                  Get Started
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {activeChannels.map((channel) => {
                const channelEpisodes = episodes?.filter(e => e.channelId === channel.id) || [];
                const completed = channelEpisodes.filter(e => e.status === "completed").length;
                
                return (
                  <div 
                    key={channel.id} 
                    className="p-4 border rounded-lg hover:shadow-md transition-shadow"
                    style={{ borderColor: channel.branding.colorScheme.primary }}
                    data-testid={`channel-card-${channel.id}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold" data-testid={`channel-name-${channel.id}`}>{channel.name}</h3>
                        <p className="text-sm text-muted-foreground" data-testid={`channel-handle-${channel.id}`}>@{channel.handle}</p>
                      </div>
                      <Badge variant="outline" data-testid={`channel-category-${channel.id}`}>{channel.category}</Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span data-testid={`channel-episodes-${channel.id}`}>{channelEpisodes.length} episodes</span>
                      <span data-testid={`channel-completed-${channel.id}`}>{completed} completed</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          
          <div className="mt-6 flex gap-4">
            <Link href="/channels">
              <Button data-testid="button-view-channels">View All Channels</Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      <Card data-testid="quick-actions-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Quick Actions
          </CardTitle>
          <CardDescription>Common workflows to get started</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Link href="/channels">
              <Button className="w-full" variant="outline" data-testid="button-action-channels">
                <Youtube className="mr-2 h-4 w-4" />
                Manage Channels
              </Button>
            </Link>
            <Link href="/channels">
              <Button className="w-full" variant="outline" data-testid="button-action-episodes">
                <Video className="mr-2 h-4 w-4" />
                View Episodes
              </Button>
            </Link>
            <Link href="/status">
              <Button className="w-full" variant="outline" data-testid="button-action-status">
                <Activity className="mr-2 h-4 w-4" />
                System Status
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
