import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Palette, Play, Users, CheckCircle } from 'lucide-react';

interface VideoTheme {
  id: string;
  title: string;
  description: string;
  category: string;
  is_active: boolean;
  metadata: any;
  created_at: string;
}

export default function Themes() {
  const { data: themes, isLoading } = useQuery<VideoTheme[]>({
    queryKey: ['/api/themes'],
    refetchInterval: 60000
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading educational themes...</p>
        </div>
      </div>
    );
  }

  const activeThemes = themes?.filter(theme => theme.is_active) || [];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Educational Themes</h1>
          <p className="text-gray-600 mt-2">
            Manage content themes for AI video generation
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="bg-blue-50 text-blue-700">
            {activeThemes.length} Active Themes
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {themes?.map((theme) => (
          <Card key={theme.id} className={theme.is_active ? 'border-blue-200 bg-blue-50/30' : ''}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center space-x-2">
                  <Palette className="h-5 w-5 text-blue-600" />
                  <span>{theme.title}</span>
                </CardTitle>
                {theme.is_active ? (
                  <Badge className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Active
                  </Badge>
                ) : (
                  <Badge variant="outline">Inactive</Badge>
                )}
              </div>
              <CardDescription>
                {theme.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Category:</span>
                  <Badge variant="outline" className="text-xs">
                    {theme.category}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Created:</span>
                  <span>{new Date(theme.created_at).toLocaleDateString()}</span>
                </div>

                {theme.metadata?.educational_objectives && (
                  <div className="space-y-2">
                    <span className="text-sm font-medium text-gray-700">Educational Objectives:</span>
                    <ul className="text-xs text-gray-600 space-y-1">
                      {theme.metadata.educational_objectives.slice(0, 3).map((objective: string, index: number) => (
                        <li key={index} className="flex items-start space-x-1">
                          <span className="text-blue-500">•</span>
                          <span>{objective}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )) || (
          <div className="col-span-full">
            <Card>
              <CardContent className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Palette className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No themes found</h3>
                  <p className="text-gray-500">Educational themes will appear here once configured.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Theme Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Themes</CardTitle>
            <Palette className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{themes?.length || 0}</div>
            <p className="text-xs text-muted-foreground">Available themes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Themes</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{activeThemes.length}</div>
            <p className="text-xs text-muted-foreground">Currently generating content</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Categories</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {themes ? [...new Set(themes.map(t => t.category))].length : 0}
            </div>
            <p className="text-xs text-muted-foreground">Theme categories</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}