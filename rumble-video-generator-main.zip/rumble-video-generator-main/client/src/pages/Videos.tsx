import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Video, Play, Clock, CheckCircle, Youtube, Eye, Calendar } from 'lucide-react';

interface Video {
  id: string;
  title: string;
  description: string;
  status: string;
  theme_id: string;
  script: any;
  metadata: any;
  created_at: string;
  completed_at?: string;
}

export default function Videos() {
  const { data: videos, isLoading } = useQuery<Video[]>({
    queryKey: ['/api/videos'],
    refetchInterval: 30000
  });

  const { data: systemStatus } = useQuery({
    queryKey: ['/api/system-status'],
    refetchInterval: 60000
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading video library...</p>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'uploaded': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'generating': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'uploaded': return <Youtube className="h-4 w-4" />;
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'generating': return <Clock className="h-4 w-4" />;
      default: return <Video className="h-4 w-4" />;
    }
  };

  const uploadedVideos = videos?.filter(v => v.status === 'uploaded') || [];
  const recentVideos = videos?.slice(0, 20) || [];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Video Library</h1>
          <p className="text-gray-600 mt-2">
            Manage and monitor your AI-generated educational content
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-sm text-gray-500">
            Total Videos: {videos?.length || 0}
          </div>
          <Badge variant="outline" className="bg-green-50 text-green-700">
            {uploadedVideos.length} Uploaded
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Videos</CardTitle>
            <Video className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{videos?.length || 0}</div>
            <p className="text-xs text-muted-foreground">
              Educational series generated
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Uploaded</CardTitle>
            <Youtube className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{uploadedVideos.length}</div>
            <p className="text-xs text-muted-foreground">
              Live on YouTube
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {videos?.length ? Math.round((uploadedVideos.length / videos.length) * 100) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              Upload success rate
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">All Videos</TabsTrigger>
          <TabsTrigger value="uploaded">Uploaded</TabsTrigger>
          <TabsTrigger value="recent">Recent</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="grid gap-4">
            {videos?.map((video) => (
              <Card key={video.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(video.status)}
                        <h3 className="text-lg font-semibold truncate">{video.title}</h3>
                        <Badge className={getStatusColor(video.status)}>
                          {video.status}
                        </Badge>
                      </div>
                      
                      <p className="text-gray-600 text-sm line-clamp-2">
                        {video.description}
                      </p>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span>
                            {new Date(video.created_at).toLocaleDateString()}
                          </span>
                        </div>
                        
                        {video.metadata?.topic && (
                          <div className="flex items-center space-x-1">
                            <Eye className="h-4 w-4" />
                            <span>Topic: {video.metadata.topic}</span>
                          </div>
                        )}
                        
                        {video.metadata?.duration && (
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>{video.metadata.duration}s</span>
                          </div>
                        )}
                      </div>

                      {video.metadata?.youtube_account && (
                        <div className="flex items-center space-x-2 text-sm">
                          <Youtube className="h-4 w-4 text-red-600" />
                          <span className="text-gray-600">
                            {video.metadata.youtube_account}
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="text-right space-y-2">
                      {video.metadata?.overall_quality_score && (
                        <div className="text-sm">
                          <span className="text-gray-500">Quality: </span>
                          <span className="font-semibold text-blue-600">
                            {video.metadata.overall_quality_score}/100
                          </span>
                        </div>
                      )}
                      
                      {video.metadata?.content_rating && (
                        <Badge variant="outline" className="text-xs">
                          {video.metadata.content_rating}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {!videos || videos.length === 0 && (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <Video className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No videos found</h3>
                    <p className="text-gray-500">Videos will appear here once generation begins.</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="uploaded" className="space-y-4">
          <div className="grid gap-4">
            {uploadedVideos.map((video) => (
              <Card key={video.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center space-x-2">
                        <Youtube className="h-5 w-5 text-red-600" />
                        <h3 className="text-lg font-semibold">{video.title}</h3>
                        <Badge className="bg-green-100 text-green-800">
                          Live on YouTube
                        </Badge>
                      </div>
                      
                      <p className="text-gray-600 text-sm">
                        {video.description}
                      </p>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>Uploaded: {new Date(video.created_at).toLocaleDateString()}</span>
                        {video.metadata?.youtube_account && (
                          <span>Account: {video.metadata.youtube_account}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="recent" className="space-y-4">
          <div className="grid gap-4">
            {recentVideos.map((video) => (
              <Card key={video.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(video.status)}
                      <div>
                        <h3 className="font-semibold">{video.title}</h3>
                        <p className="text-sm text-gray-500">
                          {new Date(video.created_at).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(video.status)}>
                      {video.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}