import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Play, Download, Calendar, Clock, HardDrive, Cloud } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { RumbleCampaign, RumbleVideo } from "@shared/schema";

export default function RumbleDashboard() {
  const { toast } = useToast();

  const { data: statusData } = useQuery({
    queryKey: ["/api/rumble/status"],
    refetchInterval: 10000
  });

  const { data: campaign } = useQuery<RumbleCampaign>({
    queryKey: ["/api/rumble/campaigns", statusData?.activeCampaign?.id],
    enabled: !!statusData?.activeCampaign?.id
  });

  const { data: videos = [] } = useQuery<RumbleVideo[]>({
    queryKey: ["/api/rumble/videos"],
    queryFn: () => queryClient.fetchQuery({ 
      queryKey: ["/api/rumble/videos"] 
    })
  });

  const campaignVideos = videos.filter(v => v.campaignId === campaign?.id);

  const generateMutation = useMutation({
    mutationFn: async () => {
      if (!campaign) throw new Error("No active campaign");
      return apiRequest("/api/rumble/generate", {
        method: "POST",
        body: JSON.stringify({ campaignId: campaign.id })
      });
    },
    onSuccess: () => {
      toast({
        title: "Video Generation Started",
        description: "The next video is being generated. This may take 10-20 minutes."
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rumble/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rumble/videos"] });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const progressPercentage = campaign 
    ? ((campaign.currentDay || 0) / campaign.targetDays) * 100 
    : 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Rumble Video Generator
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Automated 30+ minute video generation for Rumble streaming
            </p>
          </div>
          
          {campaign && campaign.status === "active" && (
            <Button
              data-testid="button-generate-now"
              onClick={() => generateMutation.mutate()}
              disabled={generateMutation.isPending}
              size="lg"
            >
              <Play className="w-4 h-4 mr-2" />
              {generateMutation.isPending ? "Generating..." : "Generate Now"}
            </Button>
          )}
        </div>

        {campaign ? (
          <>
            <Card className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                      {campaign.name}
                    </h2>
                    <p className="text-gray-600 dark:text-gray-400">
                      {campaign.description}
                    </p>
                  </div>
                  <Badge 
                    data-testid={`badge-status-${campaign.status}`}
                    variant={campaign.status === "active" ? "default" : "secondary"}
                  >
                    {campaign.status}
                  </Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">
                      Progress
                    </span>
                    <span className="font-semibold text-gray-900 dark:text-white" data-testid="text-progress">
                      Day {campaign.currentDay || 0} of {campaign.targetDays}
                    </span>
                  </div>
                  <Progress value={progressPercentage} className="h-3" />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4">
                  <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Calendar className="w-5 h-5 text-blue-500" />
                    <div>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Videos</p>
                      <p className="text-lg font-bold text-gray-900 dark:text-white" data-testid="text-videos-generated">
                        {campaign.videosGenerated || 0}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Clock className="w-5 h-5 text-green-500" />
                    <div>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Target</p>
                      <p className="text-lg font-bold text-gray-900 dark:text-white">
                        {Math.floor(campaign.targetDuration / 60)}min
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <HardDrive className="w-5 h-5 text-purple-500" />
                    <div>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Style</p>
                      <p className="text-sm font-semibold text-gray-900 dark:text-white capitalize">
                        {campaign.config.videoStyle}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Cloud className="w-5 h-5 text-orange-500" />
                    <div>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Drive</p>
                      <p className="text-sm font-semibold text-gray-900 dark:text-white">
                        {campaign.config.uploadToGoogleDrive ? "Enabled" : "Disabled"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                Generated Videos ({campaignVideos.length})
              </h3>

              <div className="grid gap-4">
                {campaignVideos.length === 0 ? (
                  <Card className="p-8 text-center">
                    <p className="text-gray-600 dark:text-gray-400">
                      No videos generated yet. Click "Generate Now" to create your first video.
                    </p>
                  </Card>
                ) : (
                  campaignVideos
                    .sort((a, b) => b.dayNumber - a.dayNumber)
                    .map((video) => (
                      <Card key={video.id} className="p-4" data-testid={`card-video-${video.id}`}>
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <Badge variant="outline" data-testid={`badge-day-${video.dayNumber}`}>
                                Day {video.dayNumber}
                              </Badge>
                              <Badge 
                                variant={
                                  video.status === "completed" || video.status === "uploaded_gdrive"
                                    ? "default"
                                    : video.status === "generating"
                                    ? "secondary"
                                    : video.status === "failed"
                                    ? "destructive"
                                    : "outline"
                                }
                                data-testid={`badge-video-status-${video.status}`}
                              >
                                {video.status}
                              </Badge>
                            </div>
                            <h4 className="font-semibold text-gray-900 dark:text-white">
                              {video.title}
                            </h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              {video.topic}
                            </p>
                            {video.duration && (
                              <div className="flex gap-4 mt-2 text-xs text-gray-500 dark:text-gray-400">
                                <span data-testid={`text-duration-${video.id}`}>
                                  Duration: {Math.floor(video.duration / 60)}m {video.duration % 60}s
                                </span>
                                {video.fileSize && (
                                  <span>
                                    Size: {Math.floor(video.fileSize / 1024 / 1024)}MB
                                  </span>
                                )}
                              </div>
                            )}
                            {video.errorMessage && (
                              <p className="text-sm text-red-600 dark:text-red-400 mt-2">
                                Error: {video.errorMessage}
                              </p>
                            )}
                          </div>

                          {video.filePath && (video.status === "completed" || video.status === "uploaded_gdrive") && (
                            <div className="flex gap-2">
                              {video.googleDriveUrl && (
                                <Button
                                  data-testid={`button-view-gdrive-${video.id}`}
                                  variant="outline"
                                  size="sm"
                                  onClick={() => window.open(video.googleDriveUrl!, "_blank")}
                                >
                                  <Cloud className="w-4 h-4 mr-2" />
                                  View in Drive
                                </Button>
                              )}
                              <Button
                                data-testid={`button-download-${video.id}`}
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  toast({
                                    title: "Download Info",
                                    description: `Video saved at: ${video.filePath}`
                                  });
                                }}
                              >
                                <Download className="w-4 h-4 mr-2" />
                                File Path
                              </Button>
                            </div>
                          )}
                        </div>
                      </Card>
                    ))
                )}
              </div>
            </div>
          </>
        ) : (
          <Card className="p-12 text-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              No Active Campaign
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Create a campaign to start generating 30+ minute videos daily for Rumble
            </p>
            <Button 
              data-testid="button-create-campaign"
              size="lg"
              onClick={() => {
                toast({
                  title: "Creating Campaign",
                  description: "Use the API to create a campaign: POST /api/rumble/campaigns"
                });
              }}
            >
              Create Campaign
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
