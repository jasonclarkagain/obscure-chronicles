import { QueryClientProvider } from "@tanstack/react-query";
import { Router, Route, Switch } from "wouter";
import { queryClient } from "@/lib/queryClient";
import { ThemeProvider } from "@/components/ThemeProvider";
import { Toaster } from "@/components/ui/toaster";
import Navigation from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Dashboard } from "@/pages/Dashboard";
import Videos from "@/pages/Videos";
import Themes from "@/pages/Themes";
import Characters from "@/pages/Characters";
import Settings from "@/pages/Settings";
import SystemStatus from "@/pages/SystemStatus";
import Analytics from "@/pages/Analytics";
import VideoQuality from "@/pages/VideoQuality";
import Channels from "@/pages/Channels";
import ChannelCreator from "@/pages/ChannelCreator";
import RumbleDashboard from "@/pages/RumbleDashboard";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="ai-video-theme">
        <div className="min-h-screen bg-background">
          <Navigation />
          <main className="container mx-auto px-4 py-8">
            <Router>
              <Switch>
                <Route path="/" component={RumbleDashboard} />
                <Route path="/youtube" component={Dashboard} />
                <Route path="/videos" component={Videos} />
                <Route path="/themes" component={Themes} />
                <Route path="/characters" component={Characters} />
                <Route path="/settings" component={Settings} />
                <Route path="/status" component={SystemStatus} />
                <Route path="/analytics" component={Analytics} />
                <Route path="/quality" component={VideoQuality} />
                <Route path="/channels" component={Channels} />
                <Route path="/create-channel" component={ChannelCreator} />
                <Route>
                  <div className="text-center py-16">
                    <h1 className="text-2xl font-bold mb-4">Page Not Found</h1>
                    <p className="text-muted-foreground">
                      The page you're looking for doesn't exist.
                    </p>
                  </div>
                </Route>
              </Switch>
            </Router>
          </main>
          <Footer />
          <Toaster />
        </div>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;