#!/bin/bash

echo "🚀 Starting Multi-Channel Video Generation System..."
echo "📦 Integrated Server (Backend + Frontend on port 5000)"
echo ""
echo "⚠️  Keep this tab active - closing it will stop the server"
echo ""

# Start the integrated Vite + Express server
npx tsx server/vite-server.ts
