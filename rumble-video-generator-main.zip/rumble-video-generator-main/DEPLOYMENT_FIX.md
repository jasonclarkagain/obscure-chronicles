# ✅ DEPLOYMENT FIX - PORT 24678 EADDRINUSE ERROR

## Root Cause Identified
The error "Port 24678 is already in use" happens because:
1. **Vite's HMR (Hot Module Replacement)** binds to port 24678 when `NODE_ENV` is not "production"
2. Cloud Run doesn't set `NODE_ENV=production` by default
3. The `.replit` file has port 24678 configured, causing conflicts

## The Solution

### For Cloud Run Deployment:

1. **Use the Production Entry Point**
   ```bash
   npx tsx server/production-entry.ts
   ```
   This file:
   - Forces `NODE_ENV=production` to disable Vite HMR
   - Only listens on `process.env.PORT` (no fallbacks)
   - Serves built static files instead of using Vite middleware

2. **Set Environment Variables in Cloud Run**
   ```
   NODE_ENV=production
   PORT=8080  (or let Cloud Run set it)
   OPENAI_API_KEY=your-key
   ```

3. **Build Frontend Before Deployment**
   ```bash
   npm run build
   ```

### For Replit Deployment Settings:

Since you cannot edit `.replit` directly:

1. **In Replit Deployment Configuration:**
   - Change run command to: `NODE_ENV=production npx tsx server/production-entry.ts`
   - Or use: `npx tsx server/vite-server.ts` with `NODE_ENV=production` set as environment variable

2. **Required Environment Variables:**
   - `NODE_ENV=production` (CRITICAL - prevents HMR port binding)
   - Let Cloud Run provide `PORT` automatically

## Why This Works

- Setting `NODE_ENV=production` completely disables Vite's HMR
- HMR won't try to bind to port 24678
- Server only listens on the PORT provided by Cloud Run
- No port conflicts or EADDRINUSE errors

## Quick Test

Test locally with production mode:
```bash
NODE_ENV=production PORT=3000 npx tsx server/production-entry.ts
```

## Clean Deployment

The production entry point (`server/production-entry.ts`):
- ✅ Forces production mode
- ✅ Disables all development features
- ✅ Only uses assigned PORT
- ✅ No port scanning or fallbacks
- ✅ Serves static built files

## Important Notes

⚠️ **Always set `NODE_ENV=production` for deployments** - this is the key to preventing the port 24678 conflict.

✅ **This solution is tested and follows Cloud Run best practices.**