#!/bin/bash

echo "🚀 Starting Production YouTube Automation"
echo "=========================================="

# Kill any existing processes
pkill -f "production-server" 2>/dev/null || true
pkill -f "deployment-oauth" 2>/dev/null || true
pkill -f "working-automation" 2>/dev/null || true

# Wait for cleanup
sleep 3

# Start production server
cd server
echo "Starting production server on port 3000..."
npx tsx production-server.ts

echo "Server should be accessible at the Replit URL"