# AI Video Generation System

## Overview
This project is a comprehensive AI video generation system designed to produce professional, daily videos for both YouTube and Rumble. It automates the creation of high-quality video content, including custom themes, high-resolution images, dialog, animations, audio, and automatic uploads. The system provides a robust platform for generating educational and engaging content, with capabilities for multi-channel management, 30-day streaming campaigns, and monetization.

## Rumble Video Generation (November 2025)
A complete Rumble video generation system has been implemented to create 30+ minute videos daily for 30 consecutive days:

**Features:**
- Automated 30+ minute video generation using GPT-4o and OpenAI TTS
- Chapter-based video structure (6-7 chapters per video)
- Daily automated generation at 02:00 UTC via cron
- 30-day campaign tracking with progress monitoring
- Optional Google Drive upload integration
- Web dashboard for monitoring and manual video generation

**Technical Implementation:**
- **Backend Services:**
  - `RumbleVideoGenerator`: Chapter-based video generation with duration validation
  - `RumbleGenerationOrchestrator`: Full pipeline orchestration and state management
  - `RumbleCronService`: Daily automated generation with idempotency guards
  - `GoogleDriveUploader`: Optional cloud storage integration
  
- **API Endpoints:**
  - `GET /api/rumble/campaigns` - List all campaigns
  - `POST /api/rumble/campaigns` - Create new campaign
  - `GET /api/rumble/videos` - List generated videos
  - `POST /api/rumble/generate` - Manually trigger video generation
  - `GET /api/rumble/status` - Campaign and system status

- **Frontend:**
  - RumbleDashboard (`/`) - Main dashboard showing campaign progress
  - Real-time progress tracking (Day X of 30)
  - Video download/Google Drive access
  - Manual generation triggers

**Video Generation Process:**
1. Generate video outline with 6-7 chapters using GPT-4o
2. Expand each chapter into 5+ minute narration
3. Generate TTS audio for each chapter with voice variation
4. Measure actual audio duration and add padding if needed to reach 30+ minutes
5. Create video with FFmpeg (1920x1080, 30fps, H.264)
6. Store locally in `rumble_videos/` directory
7. Optionally upload to Google Drive
8. Update campaign progress (currentDay, videosGenerated)

**30-Day Campaign Workflow:**
1. Create a campaign via API or frontend
2. Cron job runs daily at 02:00 UTC
3. Checks for active campaign and generates next day's video
4. Automatically increments day counter
5. Continues for 30 days until campaign completes
6. Videos available for download or streaming to Rumble

## User Preferences
- Production-ready implementation required
- Professional video quality mandatory
- Rigorous testing of all components
- Daily automation with reliable scheduling

## System Architecture
The system is built on a robust architecture featuring a React with TypeScript frontend for a video management dashboard and a Node.js/Express backend for orchestrating video generation. AI services, primarily OpenAI, are integrated for content generation (GPT-4o), image creation (DALL-E 3), and text-to-speech (TTS). Video processing is handled by FFmpeg for composition and animation, complemented by custom audio generation. For YouTube integration, the system uses the YouTube Data API v3 for automatic uploads and cron jobs for daily scheduling.

Key architectural decisions include an offline-first approach for video rendering with content caching and resumable jobs for reliability. It also features a template-based rendering system to minimize API calls during video production. The database schema includes `youtube_channels`, `episodes`, and `content_cache` tables to manage multi-channel configurations, track episode progress, and store pre-generated content. UI/UX is built with React, TypeScript, Vite, Tailwind CSS, and shadcn/ui for a professional and responsive dashboard.

The system supports multi-channel video generation, allowing for unique themes and characters across different YouTube channels, with features like professional thumbnail creation and staggered daily scheduling.

### Web GUI Implementation (November 2025)
A complete web-based graphical interface has been implemented with the following components:

**Backend API (server/routes-minimal.ts):**
- GET `/api/youtube-channels` - List all YouTube channels
- GET `/api/youtube-channels/:id` - Get specific channel details
- GET `/api/episodes?channelId=...` - List episodes (optionally filtered by channel)
- GET `/api/content-cache` - List cached content (scripts, thumbnails)
- GET `/api/jobs/status` - Get system status and job statistics
- POST `/api/jobs/cache-content` - Trigger content caching job
- POST `/api/jobs/create-episodes` - Trigger episode creation job
- POST `/api/jobs/batch-render` - Trigger batch video rendering job

**Frontend Pages:**
- **Dashboard** (`/`) - System overview showing episode counts, channel statistics, and cache status
- **Channels** (`/channels`) - Multi-channel management with job control buttons for caching, episode creation, and batch rendering

**Technical Stack:**
- Backend: Express 5 + TypeScript on port 5000
- Frontend: React 19 + Vite on port 5173
- State Management: @tanstack/react-query for data fetching and caching
- Routing: wouter for client-side navigation
- Styling: Tailwind CSS + shadcn/ui components
- Storage: In-memory storage via `server/storage.ts` (MemStorage implementation)

**Starting the Application:**

Click the **"Run"** button in Replit (or run `./run.sh` in Shell). **Keep the Run output panel visible** - Replit automatically terminates background processes.

This starts an **integrated server** on port 5000 serving:
- **Backend API**: Express + TypeScript (routes: `/api/*`, `/health`)
- **Frontend**: React + Vite (served from root `/`)

**Technical Details:**
- **Integrated Server** (`server/vite-server.ts`): Single process on port 5000
  - Uses Vite in middleware mode for HMR and hot reload
  - Express handles API routes, Vite handles frontend assets
  - SPA fallback serves `index.html` before Vite middleware
- **Run Script** (`run.sh`): Launches the integrated server via tsx

**Replit Platform Constraint**: Processes must run in the foreground via the Run button. Background processes (using `&`, `nohup`, `setsid`, etc.) are automatically terminated by Replit's init system. For persistent production deployments, use Replit Deployments.

**Critical Bug Fixes:**
- Fixed Express 5 path-to-regexp error by changing 404 handler from `app.use("*", handler)` to pathless middleware `app.use(handler)`
- Fixed Vite host blocking by adding `allowedHosts: ['.repl.co', '.replit.dev']` to `client/vite.config.ts`
- Created integrated Vite+Express server to serve both API and frontend from single port (5000)
- Configured proper SPA fallback middleware to serve frontend HTML before Vite middleware

## External Dependencies
- **OpenAI**: GPT-4o for script generation, DALL-E 3 for image creation (banners, video assets), TTS for audio narration, and Whisper for speech-to-text.
- **YouTube Data API v3**: For automated video uploads and channel management.
- **FFmpeg**: For video composition, rendering, and animation.
- **Node.js/Express**: Backend framework.
- **React**: Frontend library.
- **TypeScript**: For type-safe development.
- **Vite**: Frontend build tool.
- **Tailwind CSS**: For styling.
- **shadcn/ui**: UI component library.
- **Drizzle ORM**: For database interaction (with in-memory storage, and PostgreSQL for advanced deployments).
- **Web Audio API**: For audio processing and effects.