#!/bin/bash

echo "Starting AI Video Generation Platform..."

# Kill any existing processes
pkill -f "tsx unified-server" 2>/dev/null || true
pkill -f "vite" 2>/dev/null || true

# Wait for ports to be available
sleep 2

echo "Starting backend server on port 3001..."
cd server && npx tsx unified-server.ts &
BACKEND_PID=$!

echo "Starting frontend on port 5173..."
cd ../client && npx vite --host 0.0.0.0 --port 5173 &
FRONTEND_PID=$!

echo "Backend PID: $BACKEND_PID"
echo "Frontend PID: $FRONTEND_PID"

# Wait for services to start
sleep 5

# Check if services are running
echo "Checking backend health..."
curl -f -s "http://localhost:3001/health" > /dev/null && echo "✓ Backend is running" || echo "✗ Backend failed to start"

echo "Checking frontend..."
curl -f -s "http://localhost:5173" > /dev/null && echo "✓ Frontend is running" || echo "✗ Frontend failed to start"

echo "AI Video Generation Platform is ready!"
echo "Frontend: http://localhost:5173"
echo "Backend API: http://localhost:3001"