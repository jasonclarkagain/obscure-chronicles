# 🚀 Quick Start Guide

## Starting the Application

### Using the Application

1. Click the green **"Run"** button at the top of Replit
2. Wait ~10 seconds for startup
3. You'll see: "✅ Backend + Frontend running on http://localhost:5000"
4. Click the **"Webview"** button (or open the URL shown)

**CRITICAL:** The server runs in the foreground. Switching tabs is OK, but **keep the Run output panel visible** (don't close it completely). This is a Replit platform limitation - background processes are automatically terminated.

**Alternative:** Run `./run.sh` in the Shell tab and keep it open.

## What's Running?

- **Integrated Server on Port 5000**
  - Backend API: http://localhost:5000/api/*
  - Frontend GUI: http://localhost:5000/
  - Health check: http://localhost:5000/health

## Features

### 🏠 Dashboard (/)
- System overview with real-time statistics
- Episode counts by status (Planned, Rendering, Completed, Failed)
- Channel performance metrics
- Content cache status

### 📺 Channels (/channels)
- View all YouTube channels (3 pre-loaded sample channels)
- Channel details: name, category, target audience
- Job control buttons:
  - **Cache Content** - Pre-generate scripts and thumbnails
  - **Create Episodes** - Generate new video episodes
  - **Batch Render** - Render multiple videos at once

## Troubleshooting

**Server stopped/not responding?**
- Check if the Run output panel is still visible
- Don't close the Run panel - keep it open (minimized is OK, but must stay visible)
- If it stopped, click Run again
- Test: `curl http://localhost:5000/health` should return JSON

**"Blocked request. This host is not allowed"?**
- Fixed! Vite config allows Replit hostnames (`.repl.co`, `.replit.dev`)
- If you still see this, restart with the Run button

**"Not found" error on /?**
- Use the Webview button, don't manually edit URLs
- Server is on port 5000 and serves both API and frontend
- Check server is running: `curl http://localhost:5000/health`

**Need to stop the server?**
- Click the Stop button in Replit, or
- Press Ctrl+C in the Shell if you used `./run.sh`

## File Structure

```
client/             - React frontend
├── src/
│   ├── pages/     - Dashboard & Channels pages
│   └── App.tsx    - Main app with routing
server/            - Express backend
├── index.ts       - Main backend server
├── routes-minimal.ts - API routes
└── storage.ts     - In-memory storage
shared/            - Shared types (schema.ts)
```

## API Endpoints

- GET `/api/youtube-channels` - List channels
- GET `/api/episodes` - List episodes
- GET `/api/content-cache` - View cached content
- GET `/api/jobs/status` - System status
- POST `/api/jobs/cache-content` - Trigger content caching
- POST `/api/jobs/create-episodes` - Create new episodes
- POST `/api/jobs/batch-render` - Batch render videos
