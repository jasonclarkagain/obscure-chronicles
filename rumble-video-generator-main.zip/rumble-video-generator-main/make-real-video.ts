import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { google } from 'googleapis';
import OpenAI from 'openai';

const execAsync = promisify(exec);

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

async function generateScript(topic: string, duration: number): Promise<string> {
  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{
      role: "user",
      content: `Create a ${duration}-minute YouTube video script about: ${topic}

Requirements:
- Engaging hook in first 10 seconds
- Clear sections with headers
- Educational and valuable content
- Natural speaking style
- Call to action at end

Format as plain text, ready to be spoken.`
    }],
    temperature: 0.7
  });
  
  return response.choices[0].message.content || '';
}

async function generateAudio(text: string, outputPath: string): Promise<void> {
  const mp3 = await openai.audio.speech.create({
    model: "tts-1",
    voice: "onyx",
    input: text,
  });
  
  const buffer = Buffer.from(await mp3.arrayBuffer());
  fs.writeFileSync(outputPath, buffer);
}

async function createVideo(audioPath: string, title: string, outputPath: string): Promise<void> {
  // Get audio duration
  const { stdout } = await execAsync(`ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${audioPath}"`);
  const duration = Math.ceil(parseFloat(stdout));
  
  // Create video with audio + visual
  const ffmpegCommand = `ffmpeg -f lavfi -i color=c=0x1a1a2e:s=1920x1080:d=${duration} \
    -i "${audioPath}" \
    -vf "drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${title.replace(/'/g, "\\'")}':fontcolor=white:fontsize=72:x=(w-text_w)/2:y=(h-text_h)/2" \
    -c:v libx264 -c:a aac -shortest -pix_fmt yuv420p -y "${outputPath}"`;
  
  await execAsync(ffmpegCommand);
}

async function uploadToYouTube(videoPath: string, title: string, description: string) {
  const CLIENT_ID = process.env.YOUTUBE_CLIENT_ID;
  const CLIENT_SECRET = process.env.YOUTUBE_CLIENT_SECRET;
  const REFRESH_TOKEN = process.env.YOUTUBE_REFRESH_TOKEN;
  
  if (!CLIENT_ID || !CLIENT_SECRET || !REFRESH_TOKEN) {
    console.error('❌ Missing YouTube credentials');
    return null;
  }
  
  const oauth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, 'http://localhost:3000/oauth2callback');
  oauth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });
  
  const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
  
  const response = await youtube.videos.insert({
    part: ['snippet', 'status'],
    requestBody: {
      snippet: {
        title,
        description: description + '\n\n#AI #Education #Tutorial',
        categoryId: '22',
      },
      status: {
        privacyStatus: 'public',
      },
    },
    media: {
      body: fs.createReadStream(videoPath),
    },
  });
  
  return response.data.id;
}

async function main() {
  const topic = process.argv[2] || 'How to Make Money Online in 2024';
  const durationMinutes = parseInt(process.argv[3]) || 10;
  
  console.log(`🎬 Creating ${durationMinutes}-minute video about: ${topic}\n`);
  
  // Check for OpenAI key
  if (!process.env.OPENAI_API_KEY) {
    console.error('❌ OPENAI_API_KEY not set');
    console.log('Get one at: https://platform.openai.com/api-keys');
    console.log('Cost: ~$0.50-2 per video');
    process.exit(1);
  }
  
  const timestamp = Date.now();
  const audioPath = `audio_${timestamp}.mp3`;
  const videoPath = `video_${timestamp}.mp4`;
  
  try {
    // 1. Generate script
    console.log('✍️  Generating script with GPT-4...');
    const script = await generateScript(topic, durationMinutes);
    console.log(`✅ Script: ${script.length} characters\n`);
    
    // 2. Generate voiceover
    console.log('🎤 Generating voiceover with OpenAI TTS...');
    await generateAudio(script, audioPath);
    console.log('✅ Audio created\n');
    
    // 3. Create video
    console.log('🎥 Creating video with FFmpeg...');
    await createVideo(audioPath, topic, videoPath);
    console.log(`✅ Video created: ${videoPath}\n`);
    
    // 4. Upload to YouTube
    console.log('📤 Uploading to YouTube...');
    const videoId = await uploadToYouTube(videoPath, topic, script.substring(0, 500));
    
    if (videoId) {
      console.log('✅ UPLOADED!');
      console.log(`🔗 https://youtube.com/watch?v=${videoId}\n`);
    } else {
      console.log(`⚠️  Video saved locally: ${videoPath}`);
    }
    
    // Cleanup
    if (fs.existsSync(audioPath)) fs.unlinkSync(audioPath);
    if (videoId && fs.existsSync(videoPath)) fs.unlinkSync(videoPath);
    
  } catch (error: any) {
    console.error('❌ Error:', error.message);
    throw error;
  }
}

main();
