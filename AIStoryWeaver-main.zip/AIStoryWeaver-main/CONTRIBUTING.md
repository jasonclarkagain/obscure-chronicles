# Contributing to StoryWeave

Thank you for your interest in contributing to StoryWeave! This document provides guidelines and information for contributors.

## Getting Started

1. Fork the repository on GitHub
2. Clone your fork locally
3. Create a new branch for your feature or bug fix
4. Make your changes
5. Test your changes thoroughly
6. Submit a pull request

## Development Setup

### Prerequisites
- Node.js 20 or higher
- npm or yarn package manager
- OpenAI API key (for AI features)

### Installation
```bash
# Clone your fork
git clone https://github.com/yourusername/storyweave.git
cd storyweave

# Install dependencies
npm install

# Create environment file
cp .env.example .env
# Add your OpenAI API key to .env

# Start development server
npm run dev
```

## Code Style

- Use TypeScript for all new code
- Follow the existing code formatting
- Use meaningful variable and function names
- Add comments for complex logic
- Ensure proper error handling

## Testing

- Test your changes in the development environment
- Verify AI features work with valid API keys
- Test both story creation and reading flows
- Check responsive design on different screen sizes

## Pull Request Process

1. Update the README.md if you're adding new features
2. Make sure your code follows the existing style
3. Test your changes thoroughly
4. Create a clear and descriptive pull request title
5. Provide a detailed description of your changes
6. Link any related issues

## Feature Requests

- Open an issue with the "enhancement" label
- Provide a clear description of the feature
- Explain the use case and benefits
- Be open to discussion and feedback

## Bug Reports

- Open an issue with the "bug" label
- Provide steps to reproduce the bug
- Include error messages and screenshots if applicable
- Specify your environment (OS, browser, Node version)

## Areas for Contribution

- UI/UX improvements
- AI prompt optimization
- New story genres and themes
- Performance optimizations
- Documentation improvements
- Testing and bug fixes

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help create a welcoming environment
- Report any inappropriate behavior

## Questions?

If you have questions about contributing, please:
- Open an issue for discussion
- Check existing issues and documentation
- Contact the maintainers

Thank you for contributing to StoryWeave!