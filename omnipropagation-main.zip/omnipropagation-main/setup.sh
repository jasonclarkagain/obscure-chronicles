#!/bin/bash
echo "Setting up..."
python3 -m pip install flask 2>/dev/null || pip install flask
