from flask import Flask
app = Flask(__name__)
@app.route("/")
def home(): return "C&C Active"
print("C&C: http://localhost:5000")
app.run()
