# OmniPropagation Security Testing

Cross-platform security testing framework.

## Quick Start:
```bash
# Clone repository
git clone [YOUR-REPO-URL]
cd omnipropagation
./setup.sh
```
